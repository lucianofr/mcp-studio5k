---
type: AOI
title: "MALHA_03 - Malha de Controle Padrão (PID)"
description: "Add-On Instruction padrão para malha de controle PID contínuo com cascata, feedforward, output tracking, override e bumpless transfer."
tags: [rockwell, controllogix, aoi, pid, fbd, malha-controle, timbopeba]
resource: "MALHA_03_AOI_R2.L5X"
timestamp: 2025-05-09T00:00:00Z
---

# MALHA_03 (Revisão 2.0)

> **Add-On Instruction:** `MALHA_03`
> **Revisão:** 2.0 | **Software Revision:** v30.02 (Studio 5000 v30)
> **Vendor:** AUTOMAÇÃO – MINA DE TIMBOPEBA
> **Criada em:** 24/07/2019 | **Última edição:** 09/05/2025
> **Linguagem da rotina `Logic`:** FBD (Function Block Diagram)
> **Fonte:** `MALHA_03_AOI_R2.L5X`

## Visão geral

AOI padrão da casa para malha de controle **PID** de processo contínuo. Encapsula:

- Controlador PID com ação selecionável (direta/reversa), ganhos `JGP`/`JTI`/`JTD`
- Transferência bumpless (Manual↔Automático, SP normal↔cascata)
- Controle em cascata (mestre/escravo) com anti-windup vindo da malha escrava
- Override/seleção de saída com limites dedicados
- Feedforward (`JFF`)
- Output Tracking
- Filtro lead/lag na PV (`LAG_PV`)
- Clamp de SP/PV/saída com detecção de saturação e anti-windup
- Palavras compactas `CMD`/`EST`/`DIAG` para FactoryTalk View

Rotina `Logic` (FBD) combina `SCALE`, `LEAD_LAG`, `DOMINANT_SET`, `FBD_BOOLEAN_AND`/`OR` e `TON` (reset temporizado de comandos) em torno do núcleo PID.

### Estrutura de dados associada

| UDT | Parâmetro | Função |
|-----|-----------|--------|
| `PID_STD_CMD_02` | `CMD` | Palavra de comando (escrita pela IHM) |
| `PID_STD_EST_02` | `EST` | Palavra de estado (lida pela IHM) |
| `PID_STD_DIAG_02` | `DIAG` | Palavra de diagnóstico |

Passadas por referência (`InOut`).

## Convenções

- **Usage** — `Input`, `Output`, `InOut` (referência bidirecional).
- **Visible** — se aparece por padrão na chamada da instrução.
- **Required** — se obrigatório na assinatura.
- **Prefixos:** `J` = ajuste/engenharia (`JSP`, `JGP`); `R` = retorno calculado (`RSD`, `RGP`); `E` = estado (`EMA`, `ESAT`); `X` = auxiliar/derivado (`XPV`, `XEST`).

## Parâmetros de sistema

| Parâmetro | Tipo | Usage | Descrição |
|-----------|------|-------|-----------|
| `EnableIn` | BOOL | Input | Habilitação da instrução (sistema, oculto) |
| `EnableOut` | BOOL | Output | Eco da habilitação (sistema, oculto) |

## Parâmetros `InOut` (referências obrigatórias)

Todos `Required = true`, `Visible = true`.

| Parâmetro | Tipo | Descrição |
|-----------|------|-----------|
| `CMD` | `PID_STD_CMD_02` | Palavra de comando (Manual, Automático, Avançado, SP calculado) |
| `EST` | `PID_STD_EST_02` | Palavra de estado do PID |
| `DIAG` | `PID_STD_DIAG_02` | Palavra de diagnóstico da malha e controle avançado |
| `JSP` | REAL | Setpoint da malha |
| `JSD` | REAL | Saída do controlador (MV) — InOut p/ escrita externa em Manual e retorno bumpless |

## Parâmetros de entrada (`Input`)

### Setpoint e variável de processo

| Parâmetro | Tipo | Default | Descrição |
|-----------|------|---------|-----------|
| `JSPY` | REAL | 0.0 | SP calculado — usado em modo SP calculado/cascata (`CSPC`/`ESPC`) |
| `JSP_MIN` | REAL | 0.0 | Limite mínimo do SP (clamp) |
| `JSP_MAX` | REAL | 0.0 | Limite máximo do SP (clamp) |
| `PV` | REAL | 1400.0 | Variável de processo |
| `PV_MIN` | REAL | 0.0 | Limite mínimo da PV |
| `PV_MAX` | REAL | 0.0 | Limite máximo da PV |

### Sintonia do PID

| Parâmetro | Tipo | Default | Descrição |
|-----------|------|---------|-----------|
| `JGP` | REAL | 0.0 | Ganho proporcional (Kp) |
| `JTI` | REAL | 0.0 | Tempo integral, min/rep. `0` desativa integral |
| `JTD` | REAL | 0.0 | Tempo derivativo, min. `0` desativa derivativa |
| `SREV` | BOOL | 0 | Sentido da ação: `0`=direta, `1`=reversa |

### Limites de saída

| Parâmetro | Tipo | Default | Descrição |
|-----------|------|---------|-----------|
| `JSD_MIN` | REAL | 0.0 | Limite mínimo da saída |
| `JSD_MAX` | REAL | 0.0 | Limite máximo da saída |
| `JSD_MIN_OVER` | REAL | 0.0 | Limite mínimo da saída em override |
| `JSD_MAX_OVER` | REAL | 0.0 | Limite máximo da saída em override |
| `JSD_MODE` | BOOL | 0 | *(oculto)* Habilita limites de saída em Manual |

### Cascata (mestre → escrava)

| Parâmetro | Tipo | Default | Descrição |
|-----------|------|---------|-----------|
| `JSP_SL_MIN` | REAL | 0.0 | Limite mínimo do SP da escrava |
| `JSP_SL_MAX` | REAL | 0.0 | Limite máximo do SP da escrava |
| `JSP_SL` | REAL | 0.0 | Retorno do SP atual da escrava (bumpless ao entrar em cascata) |
| `BUMPL_SL_S` | BOOL | 0 | Habilita bumpless com SP da escrava |
| `AWI_H` | BOOL | 0 | Anti-windup entrada — limite superior (da malha escrava) |
| `AWI_L` | BOOL | 0 | Anti-windup entrada — limite inferior (da malha escrava) |

> Exemplo: malha mestre de nível cuja saída é o SP de vazão da escrava. Se a válvula (escrava) satura em 100%, aciona `AWI_H` na mestre; mestre congela integral. `JSP_SL` devolve SP real da escrava.

### Feedforward e Output Tracking

| Parâmetro | Tipo | Default | Descrição |
|-----------|------|---------|-----------|
| `JFF` | REAL | 0.0 | Feedforward somado à saída do PID |
| `TR_I` | REAL | 0.0 | Valor para output tracking |
| `TR_S` | BOOL | 0 | Habilita output tracking (`JSD` segue `TR_I`) |
| `TR_MODE` | BOOL | 0 | *(oculto)* Habilita tracking em Manual |
| `REALIM` | REAL | 0.0 | Realimentação da saída (posição real do atuador) — bumpless/anti-windup |

### Filtro e status auxiliares

| Parâmetro | Tipo | Default | Descrição |
|-----------|------|---------|-----------|
| `LAG_PV` | REAL | 0.0 | *(oculto)* Constante de tempo lead/lag da PV, segundos. `0`=sem filtro |
| `XEST` | INT | 0 | Estados auxiliares |
| `STS` | BOOL | 0 | Status geral da malha (habilitação/validade) |
| `CMD_TEMP_RESET` | DINT | 0 | *(oculto)* Tempo de reset dos comandos, ms (comando por pulso) |

## Parâmetros de saída (`Output`)

### Saídas de processo

| Parâmetro | Tipo | Descrição |
|-----------|------|-----------|
| `JSPY_SL` | REAL | SP enviado à malha escrava (cascata) |
| `XPV` | REAL | PV filtrada (saída do `LEAD_LAG`) |
| `RSD` | REAL | Retorno da saída do controlador (aplicada após limites/override) |

### Estados (bits)

| Parâmetro | Tipo | Descrição |
|-----------|------|-----------|
| `EMA` | BOOL | Manual(0)/Automático(1) |
| `ESPC` | BOOL | SP calculado/cascata (1) ou local (0) |
| `ECA` | BOOL | Controle avançado ativo |
| `ESAT` | BOOL | *(oculto)* Malha saturada |
| `AWO_H` | BOOL | Anti-windup saída — limite superior (encadeável como `AWI_H` de malha mestre) |
| `AWO_L` | BOOL | Anti-windup saída — limite inferior (encadeável como `AWI_L`) |

### Retornos de sintonia e cálculo (ocultos)

| Parâmetro | Tipo | Descrição |
|-----------|------|-----------|
| `RERRO` | REAL | Erro do PID (SP − PV) |
| `RFF` | REAL | Retorno da contribuição feedforward |
| `RGP` | REAL | Retorno do ganho proporcional aplicado |
| `RTI` | REAL | Retorno do termo/ganho integral aplicado |
| `RTD` | REAL | Retorno do termo/ganho derivativo aplicado |
| `RSPY` | REAL | Retorno do SP calculado usado |

## Tags locais (internos)

| Tag local | Tipo de instrução | Função |
|-----------|-------------------|--------|
| `SETD_01`, `SETD_02` | `DOMINANT_SET` | Latches set-dominante dos comandos |
| `BOR_03` | `FBD_BOOLEAN_OR` | Combinação OR de condições de estado |
| `BAND_01` | `FBD_BOOLEAN_AND` | Combinação AND de condições de habilitação |
| `LDLG_01` | `LEAD_LAG` | Filtro lead/lag na PV (`LAG_PV` → `XPV`) |
| `SCL_01` | `SCALE` | Escalonamento (saída mestre → faixa SP escrava) |
| *(temporizadores)* | `TON` | Reset temporizado dos comandos (`CMD_TEMP_RESET`) |

## Palavras de bits (UDTs)

### `CMD` — `PID_STD_CMD_02`

| Bit | Membro | Descrição |
|-----|--------|-----------|
| 0–9 | `RES0`…`RES9` | Reservados |
| 10 | `CMAN` | Comando Manual |
| 11 | `CAUTO` | Comando Automático |
| 12–13 | `RES12`, `RES13` | Reservados |
| 14 | `CAVANC` | Comando de controle avançado |
| 15 | `CSPC` | Comando SP calculado/cascata (habilita `JSPY`) |

> Comandos tipicamente pulsados pela IHM; temporizadores internos resetam após `CMD_TEMP_RESET` ms.

### `EST` — `PID_STD_EST_02`

| Bit | Membro | Descrição |
|-----|--------|-----------|
| 0–5 | `RES0`…`RES5` | Reservados |
| 6 | `STS` | Status da malha |
| 7–8 | `RES7`, `RES8` | Reservados |
| 9 | `ESAT` | Malha saturada |
| 10 | `EMA` | Manual(0)/Automático(1) |
| 11 | `ESPC` | SP calculado/cascata |
| 12 | `ECA` | Controle avançado |
| 13 | `RES13` | Reservado |
| 14 | `EOVER` | Override ativo |
| 15 | `ETRCK` | Output tracking ativo |

### `DIAG` — `PID_STD_DIAG_02`

| Bit | Membro | Descrição |
|-----|--------|-----------|
| 0 | `JSD_MODE` | Modo de limitação de saída em Manual ativo |
| 1 | `PV_DCOM` | PV descomissionada/fora de faixa/falha de medição |
| 2 | `ICA` | Diagnóstico de controle avançado |
| 3–15 | `RES3`…`RES15` | Reservados |

## Fluxo funcional (resumo operacional)

1. **Aquisição da PV:** `PV` filtrada pelo `LEAD_LAG` (`LAG_PV`) → `XPV`. Fora de faixa (`PV_MIN`/`PV_MAX`) sinaliza `DIAG.PV_DCOM`.
2. **Seleção do SP:** conforme `CMD.CSPC`/`ESPC`, SP ativo é local (`JSP`) ou calculado/cascata (`JSPY`), limitado por `JSP_MIN`/`JSP_MAX`.
3. **Erro:** `RERRO = SP − XPV` (invertido se `SREV=1`).
4. **PID:** aplica `JGP`/`JTI`/`JTD` + feedforward `JFF`. Retornos em `RGP`/`RTI`/`RTD`/`RFF`.
5. **Manual/Tracking:** em Manual (`EMA=0`) ou `TR_S=1`, saída segue valor manual/`TR_I`; integral acompanha `REALIM` p/ bumpless ao voltar Automático.
6. **Limitação/saturação:** saída limitada por `JSD_MIN/MAX` (ou override); saturação aciona `ESAT` e anti-windup (`AWO_H`/`AWO_L`).
7. **Cascata:** saída da mestre escalonada (`SCALE`) p/ faixa da escrava (`JSP_SL_MIN/MAX`), publicada em `JSPY_SL`; `AWI_H`/`AWI_L` recebem saturação da escrava; `JSP_SL`+`BUMPL_SL_S` garantem bumpless.
8. **Saída final:** `JSD`/`RSD` entregam MV ao atuador; `EST`/`DIAG` reportam à IHM.

## Notas de aplicação

- Configurar sempre `JSP_MIN/MAX`, `PV_MIN/MAX`, `JSD_MIN/MAX` coerentes com faixa de engenharia — clamp/saturação/escala de cascata dependem deles.
- Bumpless: `REALIM` deve refletir posição real do atuador; em cascata, `JSP_SL` deve trazer SP real da escrava.
- Comando por pulso: ajustar `CMD_TEMP_RESET` conforme scan da IHM (ms a ~1s).
- `SREV`: confirmar sentido físico da malha antes de energizar — ação errada causa realimentação positiva.

## Related

- [PID (instrução base)](/instructions/pid.md)
- [SCALE](/instructions/scale.md)

# Citations

[1] `MALHA_03_AOI_R2-DOC.md` (gerado a partir da leitura de `MALHA_03_AOI_R2.L5X` via MCP `studio5000-ai-assistant`)
