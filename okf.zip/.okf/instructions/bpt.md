---
type: Instruction
title: "Pontos de Interrupção (BPT)"
description: "Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L21724-L21821"
---

## Pontos de Interrupção (BPT)

Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate.

Use as instruções de depuração para monitorar o estado da sua lógica, quando ela estiver em condições que você determina.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados.

## Diagrama ladder

| Operando Tipo     | Operando Tipo                |     | Formato Descrição                                                                                                 |
|-------------------|------------------------------|-----|-------------------------------------------------------------------------------------------------------------------|
| Format String Tag |                              |     | Uma string define a formatação  para o texto que aparece na  janela de rastreamento para o  ponto de interrupção. |
| Trace This        | BOOL, SINT, INT,  DINT, REAL | Tag | A tag tem um valor que você  deseja exibir em uma janela de  rastreamento.                                        |

## Descrição

Pontos de interrupção são programados com a instrução de saída de ponto de interrupção (BPT). Quando as entradas em um degrau contendo uma instrução BPT forem verdadeiras, a instrução BPT para a execução do programa. O software exibe uma janela indicando o ponto de interrupção disparado e os valores que o dispararam.

<!-- image -->

Quando um ponto de interrupção é disparado, o emulador exibe uma janela informando que ocorreu um ponto de interrupção. A barra de título da janela mostra o slot contendo o emulador que encontrou o ponto de interrupção.

Quando você clica em OK, o emulador retoma a execução do programa. Se as condições que dispararam o ponto de interrupção persistirem, o ponto de interrupção ocorrerá novamente.

Além disso, o emulador abre uma janela de rastreamento para o ponto de interrupção. A janela de rastreamento exibe informações sobre o ponto de interrupção e os valores.

## Importante:

Quando um ponto de interrupção é disparado, você não poderá editar o projeto até que você permita que a execução continue. Você pode conectar o emulador online para observar o estado do projeto, mas você não poderá editá-lo. Se você tentar aceitar uma edição de degrau enquanto um ponto de interrupção é disparado, você verá uma caixa de diálogo dizendo que o controlador não está no modo correto.

## Formato de string

Quando a string de formato nas instruções de ponto de rastreamento e ponto de interrupção, você pode controlar como as tags rastreadas aparecem nos rastreamentos ou nas janelas de ponto de interrupção. O formato da string é:

-  título:(texto)%(tipo)

Onde título é uma string de texto identificado o ponto de rastreamento ou ponto de interrupção, texto é uma string descrevendo a tag (ou qualquer outro texto da sua escolha) e %(tipo) indica o formato da tag. Você precisa de um indicador de tipo para cada tag que você está rastreando com a instrução de ponto de rastreamento ou ponto de interrupção.

Por exemplo, você poderia formatar uma string de ponto de rastreamento conforme a seguir.

-  Meu ponto de rastreamento (my tracepoint):Tag 1 = %e and Tag 2 = %d

O %e formata a primeira tag rastreada como flutuação de precisão dobrada com um expoente e o %d formata a segunda tag rastreada como um inteiro decimal assinalado.

Neste caso, você teria uma instrução de ponto de rastreamento que possui dois operandos Trace This (um para um REAL e um para um INT, embora o valor de qualquer tag possa ser formatado com qualquer sinalizador).

A janela de ponto de rastreamento resultante que apareceria quando o ponto de rastreamento é disparado ficaria conforme no exemplo.

<!-- image -->

## Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

| Condição A                                         | ção realizada                                                                                                                 |
|----------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                                      | O degrau se torna falso.                                                                                                      |
| Rung-condition-in é falsa O degrau se torna falso. |                                                                                                                               |
| Rung-condition-in é  verdadeira                    | O degrau se torna verdadeiro.  A execução salta para o degrau que  contém a instrução LBL com o nome de  rótulo referenciado. |
| Pós-varredura                                      | O degrau se torna falso.                                                                                                      |

## Exemplos

Você pode rastrear muitos valores de tag com a instrução BPT. Entretanto, a string de formatação pode conter apenas 82 caracteres. Como a string de formatação requer dois caracteres para cada tag que você desejar no ponto de interrupção, você não pode rastrear mais de 41 tags com uma única instrução BPT. Contudo, para separar dados de tag nos rastreamentos, você precisará incluir espaços e outros elementos de formação, reduzindo, assim, o número de valores de tag que uma instrução BPT pode efetivamente exibir para menos de 41.

Este degrau mostra um ponto de interrupção que interrompe a execução do programa quando um valor analógico é maior que 3.02 ou menor que 2.01.

<!-- image -->

Exiba as informações do ponto de interrupção na string de Formato (myformat). Neste caso, a string de formato contém o texto a seguir:

-  Breakpoint:The input value is %f

Quando o ponto de interrupção é disparado, a janela de rastreamento de ponto de interrupção mostra os caracteres antes dos dois-pontos ('') na barra de título da janela de rastreamento. Os outros caracteres compõem os rastreamentos. Neste exemplo, %f representa a primeira (e, neste caso, a única) tag a ser rastreada ('analogvalue').
