---
type: Instruction
title: "Um pulso descendente com entrada (OSFI)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L1720-L1810"
---

## Um pulso descendente com entrada (OSFI)

## Exemplo

## Diagrama ladder

<!-- image -->

Esse exemplo mostra como um OSF pode ser usado para fazer uma ou mais instruções de disparo da borda de subida. Todas as vezes que Limit\_Switch\_01 realiza a transição de verdadeiro para falso, OSF será definido como Output\_bit\_02 para verdadeiro. Qualquer instrução condicionada pela Output\_bit\_02 será ativada e, uma vez que Output\_bit\_02 é verdadeira somente para uma varredura, será executada uma vez por transição.

## Consulte também

Instruções de bit na página 75

Endereçamento de bit na página 894

Indexação por meio de matrizes na página 893

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução OSFI define OutputBit para um ciclo de execução quando InputBit alterna de falso para verdadeiro.

## Idiomas disponíveis

## Diagrama ladder

Esta instrução não está disponível no diagrama ladder.

## Bloco de funções

<!-- image -->

## Texto estruturado

OSFI(OSFI\_tag)

## Operandos

## Texto estruturado

| Operando Tipo    | Operando Tipo                  | Formato Descrição    |
|------------------|--------------------------------|----------------------|
|                  | OSFI tag FBD_ONESHOT Estrutura | Estrutura de  OSFI   |

Consulte Sintaxe de texto estruturado para as falhas relacionadas ao operando

## Bloco de funções

| Operando Tipo    | Operando Tipo                  | Formato Descrição    |
|------------------|--------------------------------|----------------------|
|                  | OSFI tag FBD_ONESHOT Estrutura | Estrutura de  OSFI   |

## Estrutura de FBD\_ONESHOT

| Parâmetro  de entrada    | Tipo de  dados    | Descrição                                                                                                               |
|--------------------------|-------------------|-------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                   | Entrada Habilitar. Se eliminado, a  instrução não será executada, e as  saídas não são atualizadas.  Padrão é definido. |
|                          |                   | InputBit BOOL Bit de entrada.                                                                                           |

| Parâmetro  de saída    | Tipo de  dados    | Descrição                                           |
|------------------------|-------------------|-----------------------------------------------------|
|                        |                   | EnableOut BOOL Indica se instrução está habilitada. |
|                        |                   | OutputBit BOOL Bit de saída                         |

## Descrição

Se InputBit for falso e tiver sido verdadeiro da última vez, a instrução foi escaneada então OutputBit será definido, caso contrário, OutputBit será eliminado.

<!-- image -->

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                              |
|------------------------------------|--------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | Os bits EnableIn e EnableOut são eliminados  para falso.                                                     |
| Tag.EnableIn é falso               | Os bits EnableIn e EnableOut são eliminados  para falso.                                                     |
| Tag.EnableIn é  verdadeiro         | Os bits EnableIn e EnableOut são definidos  para verdadeiro.  A instrução executa                            |
| Primeira  execução da  instrução   | N/A                                                                                                          |
| Primeira  varredura da  instrução  | O histórico de InputBit anterior é eliminado  para exigir a transição de Verdadeiro para  Falso de InputBit. |
| Pós-varredura                      | Os bits EnableIn e EnableOut são eliminados  para falso.                                                     |
