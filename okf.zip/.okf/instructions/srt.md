---
type: Instruction
title: "Classificação de arquivo (SRT)"
description: "CMP na página 294"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L12967-L13101"
---

## Classificação de arquivo (SRT)

CMP na página 294

```
FAL na página 503 Índice por meio de matrizes na página 893
```

Operadores válidos na página 366

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução SRT classifica um conjunto de valores em uma dimensão (Dim to vary) de Array em ordem crescente.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

SRT(Array,Dimtovary,Control);

## Operandos

## Diagrama ladder

| Operando                      |                                              | Tipo (Type) Format Descrição (Description)                                                |
|-------------------------------|----------------------------------------------|-------------------------------------------------------------------------------------------|
| Matriz SINT  INT:  DINT  REAL | Tag de  Matriz                               | matriz a classificar  especifica o primeiro elemento do  grupo de elementos a classificar |
|                               | Dimensão para variar DINT Somente  (0, 1, 2) | quais dimensões usar  a ordem das dimensões é: matriz[0,1,2]                              |
| Controle CONTROL              |                                              | Tag estrutura de controle da operação                                                     |

| Comprimento  (Length)    | DINT Somente    | número de elementos da matriz para  classificar                              |
|--------------------------|-----------------|------------------------------------------------------------------------------|
|                          |                 | Somente DINT Somente elemento atual na matriz  o valor inicial costuma ser 0 |

## Texto estruturado

| Operando                          |                  |                | Tipo (Type) Format Descrição (Description)                                                                                                                                                    |
|-----------------------------------|------------------|----------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Matriz SINT                       | INT:  DINT  REAL | Tag de  Matriz | matriz a classificar  especifica o primeiro elemento do  grupo de elementos a classificar                                                                                                     |
| Dimensão para variar DINT Somente |                  | (0, 1, 2)      | quais dimensões usar  a ordem das dimensões é: matriz[0,1,2]                                                                                                                                  |
|                                   | Controle CONTROL |                | Tag estrutura de controle da operação                                                                                                                                                         |
| Comprimento  (Length)             |                  | DINT Somente   | Número de elementos da matriz para  classificar.  Os valores especificados de Length e  Position são acessados dos membros  .LEN e .POS da estrutura de  CONTROL.                             |
|                                   |                  |                | Somente DINT Somente elemento atual na matriz  o valor inicial costuma ser 0  Os valores especificados de Length e  Position são acessados dos membros  .LEN e .POS da estrutura de  CONTROL. |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Estrutura de CONTROL

| Mnemônico  Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                                                                      |
|------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                          | .EN BOOL O bit habilitar indica que a instrução SRT está habilitada.                                                                                                         |
| .DN BOOL                                 | O bit executado é definido quando a instrução operou no  último elemento em Array.                                                                                           |
| .ER BOOL                                 | Um bit de erro é definido quando .LEN <0 ou .POS <0.  Qualquer uma dessas condições também gera uma falha  grave.  Quando o bit .ER é definido, a instrução não é executada. |
| .LEN DINT                                | A palavra de comprimento especifica o número de  elementos na matriz em que a instrução opera.                                                                               |
| .POS DINT                                | A palavra de posição identifica o elemento atual que a  instrução está acessando.                                                                                            |

## Descrição (Description)

A instrução SRT classifica um conjunto de valores em uma dimensão (Dim to vary) de Array em ordem crescente.

| Importante:    | Você deve testar e confirmar que a instrução não  altera os dados que você não deseja alterar.    |
|----------------|---------------------------------------------------------------------------------------------------|

A instrução SRT opera em memória contígua de dados. Somente paraControladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370 e GuardLogix 5570, o escopo da instrução é restringido à tag base. A instrução SRT não gravará dados fora da tag base, mas pode cruzar limites de membro. Se você especificar uma matriz que seja membro de uma estrutura, o comprimento excederá o tamanho da matriz; é preciso testar e confirmar que a instrução SRT não altere os dados que você não deseja alterar.

EmControladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580, os dados são restringidos pelo membro especificado.

Nessa instrução de transição, a lógica ladder de relé alterna rung-condition-in de falso para verdadeiro para a instrução ser executada.

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                       | Afeta sinalizadores de status  de operações matemáticas    |
|---------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix 5580,  Compact GuardLogix 5380 e GuardLogix  5580 | Não                                                        |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact GuardLogix  5370 e GuardLogix 5570                     | Sim                                                        |

## Falhas maiores/menores

| Uma falha maior ocorrerá se: Tipo de falha Código de falha    |    |      |
|---------------------------------------------------------------|----|------|
| .POS <0 ou .LEN <0                                            |  4 | 21   |
| Dimension to vary > número de  dimensões                      |    | 4 20 |
| Length > fim da matriz                                        |  4 | 20   |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                                                                |
|--------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A.                                                                                                             |
| Rung-condition-in é falsa O bit .EN é eliminado para falso  O bit .EN é eliminado para falso  O bit .DN é eliminado para falso |
| Rung-condition-in é  A instrução executa                                                                                       |
| Pós-varredura N/A.                                                                                                             |

## Texto estruturado

| Condição/estado A ção realizada    |                                                                                                                                                                                |
|------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | Consulte Pré-varredura na tabela do  Diagrama ladder                                                                                                                           |
| Execução normal                    | Uma vez que essa instrução requer uma  transição para ser executada, ela é  executada como falsa e então verdadeira.  Consulte tabela de Diagrama ladder para  obter detalhes. |
| Pós-varredura                      | Consulte Pós-varredura na tabela de  Diagrama ladder.                                                                                                                          |

## Exemplos

## Exemplo 1

Classificar DINT\_array, que é DINT[4,5].

<!-- image -->

## Diagrama ladder

<!-- image -->

## Texto estruturado

<!-- formula-not-decoded -->

## Exemplo 2

Classificar DINT\_array, que é DINT[4,5].

<!-- image -->
