---
type: Instruction
title: "OU booliano (BOR)"
description: "Não bit a bit (NOT) na página 447"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L11235-L11397"
---

## OU booliano (BOR)

## Consulte também

Não bit a bit (NOT) na página 447

## Funções FBD na página 425

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução BOR aplica uma operação ORs de maneira lógica com oito entradas boolianas no máximo. Para realizar um OU bit a bit, consulte Ou bit a bit (OR) .

## Idiomas disponíveis

## Diagrama ladder

Esta instrução não está disponível no diagrama ladder.

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

<!-- image -->

## Função FBD

Dica:

Função FBD suporta apenas duas entradas e é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Diagrama de bloco da função

## Bloco FBD

| Operando    | Tipo de dados (Data  Type)       | Format    | Descrição  (Description)    |
|-------------|----------------------------------|-----------|-----------------------------|
|             | BOR tag FBD_BOOLEAN_OR estrutura |           | Estrutura de BOR            |

## Estrutura de FBD\_BOOLEAN\_OR

| Membros de  entradas  Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                                  |
|-----------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL                                       | Entrada Habilitar. Se  eliminado, a instrução não é  executada e as saídas não são  atualizadas.  Definida como 0 no primeiro  download. |
| In1 BOOL                                            | Primeira entrada booliana.  Definida como 0 no primeiro  download.                                                                       |
| In2 BOOL                                            | Segunda entrada booliana.  Definida como 0 no primeiro  download.                                                                        |
| In3 BOOL                                            | Terceira entrada booliana.  Definida como 0 no primeiro  download.                                                                       |
| In4 BOOL                                            | Quarta entrada booliana.  Definida como 0 no primeiro  download.                                                                         |
| In5 BOOL                                            | Quinta entrada booliana.  Definida como 0 no primeiro  download.                                                                         |
| In6 BOOL                                            | Sexta entrada booliana.  Definida como 0 no primeiro  download.                                                                          |
| In7 BOOL                                            | Sétima entrada booliana.  Definida como 0 no primeiro  download.                                                                         |
| In8 BOOL                                            | Oitava entrada booliana.  Definida como 0 no primeiro  download.                                                                         |

| Membros de  saída    | Tipo de dados  (Data Type)    | Descrição (Description)               |
|----------------------|-------------------------------|---------------------------------------|
| EnableOut BOOL       |                               | Indica se instrução está  habilitada. |
|                      |                               | Saída BOOL A saída da instrução.      |

## Função FBD

Dica:

Função FBD suporta apenas duas entradas e é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operandos de  entrada (pinos  esquerdos)    | Tipo de dados (Data Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix 5380  e GuardLogix 5580    | Descrição  (Description)    |
|---------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
|                                             | In1 BOOL                                                                                                                                            | Primeira entrada  booliana. |
|                                             | In2 BOOL                                                                                                                                            | Segunda  entrada  booliana. |

| Operando de  saída (Pino  direito)    | Tipo de dados (Data Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix 5380  e GuardLogix 5580    | Descrição  (Description)    |
|---------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
|                                       | Saída BOOL                                                                                                                                          | A saída da  instrução.      |

Consulte Funções FBD.

## Operação

## Bloco FBD

A instrução BOR aplica uma operação ORs com oito entradas boolianas no máximo. Se uma entrada não for usada, ela será eliminada como padrão (0).

Out = In1 OR In2 OR In3 OR In4 OR In5 OR In6 OR In7 OR In8

| Importante:    | Ao remover um fio de entrada da instrução BOR durante uma  edição, certifique-se de que a entrada esteja eliminada (0).    |
|----------------|----------------------------------------------------------------------------------------------------------------------------|

## Função FBD

Dica:

Função FBD suporta apenas duas entradas e é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

A função FBD aplica uma operação ORs com duas entradas boolianas.

Out = In1 OR In2

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução.

Execução

Diagrama de bloco da função

## Bloco FBD

| Condição/estado A ção realizada    |                                                                                                                                |
|------------------------------------|--------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                       |
| Tag.EnableIn é falso               | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                       |
| Tag.EnableIn é  verdadeiro         | Os bits EnableIn e EnableOut são  definidos para verdadeiro. A instrução é  executada conforme descrito na seção de  operação. |
| Primeira  execução da  instrução   | N/D                                                                                                                            |
| Primeira  varredura da  instrução  | N/D                                                                                                                            |
| Pós-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                       |

## Função FBD

Dica:

Função FBD suporta apenas duas entradas e é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A ção realizada    |                                   |
|------------------------------------|-----------------------------------|
| Pré-varredura N/D                  |                                   |
|                                    | Varredura normal Out = In1 OR In2 |
| Primeira execução  da instrução    | N/D                               |
| Primeira varredura  da instrução   | N/D                               |
| Pós-varredura N/D                  |                                   |

## Exemplo

## Diagrama de bloco da função

## Bloco FBD

Neste exemplo, bool\_in1 é copiado em BOR\_02.In1, bool\_in2 é copiado em BOR\_02.In2, o resultado de OR em execução de todas as entradas BOR\_02 é colocado em BOR\_02.Out, e BOR\_02.Out é então copiado em value\_result\_or.

| Se bool_in1 for:  Se bool_in2  for:  Então value_result_or  será:    |
|----------------------------------------------------------------------|
| 0 0 0                                                                |
| 0 1 1                                                                |
| 1 0 1                                                                |
| 1 1 1                                                                |

<!-- image -->

## Consulte também

Ou bit a bit (OR) na página 451
