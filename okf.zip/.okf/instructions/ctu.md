---
type: Instruction
title: "Contagem crescente (CTU)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L2398-L2495"
---

## Contagem crescente (CTU)

## Exemplo

## Diagrama ladder

<!-- image -->

Uma esteira transportadora leva as peças até a zona de buffer. Todas as vezes que uma peça entra, limit\_switch\_3 é habilitado e o counter\_2 incrementa em 1. Todas as vezes que uma peça sai, limit\_switch\_4 é habilitado e o counter\_2 diminui em 1. Se houver 100 peças na zona do buffer (counter\_2.dn é verdadeiro) a esteira conveyor\_A liga e impede o transportador de trazer qualquer peça até que o buffer tenha espaço para mais peças.

## Consulte também

Indexação por meio de matrizes na página 893

Instruções do contador na página 103

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução CTU faz a contagem crescente todas as vezes que a rung-condition-in realiza a transição de falso para verdadeiro.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

## Diagrama ladder

| Tipo de  dados    | Operando  Formato Des crição               |
|-------------------|--------------------------------------------|
|                   | Counter COUNTER tag Estrutura de Counter   |
|                   | Preset DINT imediato Valor do Counter.PRE. |
|                   | Accum DINT imediato Valor do Counter.ACC.  |

## Estrutura de COUNTER

| Mnemônico  Tipo de  dados    | Descrição                                                                                                          |
|------------------------------|--------------------------------------------------------------------------------------------------------------------|
| .CU BOOL                     | A habilitação da contagem crescente  contém rung-condition-in quando a  instrução foi executada pela última vez.   |
| .DN BOOL                     | O bit executado quando definido indica que  a operação de contagem está completa.                                  |
| .OV BOOL                     | O bit de transbordamento quando definido  indica o contador incrementado após o  limite superior de 2.147.483.647. |

| .UN BOOL    | O estouro negativo quando definido indica  o contador diminuído após o limite inferior  de -2.147.483.648.                      |
|-------------|---------------------------------------------------------------------------------------------------------------------------------|
| .PRE DINT   | O valor predefinido especifica o valor que o  valor acumulado precisa alcançar antes de  a instrução indicar que foi executado. |
| .ACC DINT   | O valor acumulado especifica o número de  transições que a instrução contou.                                                    |

## Descrição

Quando rung-condition-in é definida como verdadeira e .CU é falso, .ACC será incrementado em um. Quando rung-condition-in for falsa, .CU será eliminado para falso.

<!-- image -->

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                    |
|------------------------------------|--------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | O bit .CU é definido como verdadeiro para evitar  incrementos inválidos durante a primeira varredura do  programa. |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como Rung-condition-in  Consulte o fluxograma CTU (Falso)                               |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como Rung-condition-in  Consulte o fluxograma CTU (Verdadeiro)                          |
| Pós-varredura N/A                  |                                                                                                                    |

## Fluxograma CTU (Falso)

<!-- image -->

## Fluxograma CTU (Verdadeiro)

<!-- image -->
