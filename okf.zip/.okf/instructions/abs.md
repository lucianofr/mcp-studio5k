---
type: Instruction
title: "Valor absoluto (ABS)"
description: "Você pode misturar tipos de dados, mas a perda de precisão e o erro de arredondamento podem ocorrer e a instrução levará mais tempo para ser executada."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L8303-L8460"
---

## Valor absoluto (ABS)

| Tomar o sinal oposto de um valor NEG    |
|-----------------------------------------|
| Tomar o valor absoluto de um valor ABS  |

Você pode misturar tipos de dados, mas a perda de precisão e o erro de arredondamento podem ocorrer e a instrução levará mais tempo para ser executada. Verifique o bit S:V para ver se o resultado foi truncado.

Os tipos de dados em negrito indicam ótimos tipos de dados. Uma instrução é executada mais rápido e requer menos memória se todos os operandos da instrução usarem o mesmo tipo de dados otimizado, geralmente DINT ou REAL.

Uma instrução de cálculo/matemática é executada a cada vez que ela passa por varredura assim como quando rung-condition-in for verdadeira. Se desejar que a expressão seja avaliada apejas uma vez, use qualquer instrução do tipo um pulso para disparar a instrução.

## Consulte também

## Instruções de comparação na página 293

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

Ao ser habilitada, a instrução ABS e o operador recebem o valor absoluto de Source; A instrução armazena o resultado em Dest enquanto o operador retorna o resultado. Um transbordamento é indicado quando o resultado é o valor do inteiro negativo máximo, por exemplo, -128 para SINT, -32.768 para INT e -2.147.483.648 para DINT.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

<!-- image -->

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

Dica:

Use ABS como um operador em uma expressão para obter o mesmo resultado. Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões e atribuições no texto estruturado.

## Operandos

Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

| Operando  Tipo de dados  (Data Type)  Controladores  CompactLogix  5370,  ControlLogix  5570, Compact  GuardLogix  5370 e  GuardLogix    | Tipo de dados  (Data Type)  Controladores  CompactLogix  5380,  CompactLogix  5480, ControlLogix  5580, Compact  GuardLogix 5380 e  GuardLogix 5580    | Format         | Descrição  (Description)                     |
|------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|----------------------------------------------|
| Origem SINT  INT  DINT  REAL                                                                                                             | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                          | immediate  tag | Valor do qual  se toma o  valor absoluto.    |
| Dest SINT  INT  DINT  REAL                                                                                                               | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                          | tag            | Tag a  armazenar o  resultado da  instrução. |

## Diagrama de bloco da função

## Bloco FBD

| Operando    | Tipo de dados (Data  Type)                 | Format    | Descrição  (Description)    |
|-------------|--------------------------------------------|-----------|-----------------------------|
|             | ABS FBD_MATH_ADVANCED tag Estrutura de ABS |           |                             |

## Estrutura de FBD\_MATH\_ADVANCED

| Membros de  entradas    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                 |
|-------------------------|-------------------------------|-------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL           |                               | Entrada Habilitar. Se falso, a  instrução não será executada  e as saídas não serão  atualizadas.  Padrão é verdadeiro. |
| Origem REAL             |                               | Valor do qual se toma o valor  absoluto.                                                                                |

| Membros de  saída    | Tipo de dados  (Data Type)    | Descrição (Description)                                             |
|----------------------|-------------------------------|---------------------------------------------------------------------|
| EnableOut BOOL       |                               | Indica se a instrução foi  executada sem falhas ao ser  habilitada. |
|                      |                               | Dest REAL Resultado da instrução.                                   |

## Função FBD

Dica: A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operando  de entrada  (pino  esquerdo)    | Tipo de dados (Data Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix 5380  e GuardLogix 5580    | Descrição  (Description)                  |
|-------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------|
| Origem SINT                               | USINT  INT  UINT  DINT  UDINT  LINT  ULINT  REAL  LREAL                                                                                             | Valor do qual se  toma o valor  absoluto. |

| Operando  de saída  (Pino  direito)    | Tipo de dados (Data Type)  Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e  GuardLogix 5580    | Descrição  (Description)    |
|----------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
|                                        | Dest SINT  USINT  INT  UINT  DINT  UDINT  LINT  ULINT  REAL  LREAL                                                                                 | Resultado da  função.       |

Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                        | Afeta sinalizadores de status  de operações matemáticas    |
|----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e  GuardLogix 5580 | Condicional                                                |
| Controladores CompactLogix  5370, ControlLogix 5570,  Compact GuardLogix 5370 e  GuardLogix 5570                     | Sim                                                        |

Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                       |
|------------------------------------|---------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                       |
| Rung-condition-in é falsa          | Definir Rung-condition-out como  Rung-condition-in.                                   |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como  Rung-condition-in.  Dest = valor absoluto de Source. |
| Pós-varredura N/D                  |                                                                                       |

## Diagrama de bloco da função

Bloco FBD

| Condição/estado A ção realizada    |                                                                                                                                                                           |
|------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                           |
| EnableIn é falso.                  | Defina EnableOut como  EnableIn.                                                                                                                                          |
|                                    | EnableIn é verdadeiro Dest = valor absoluto de Source.  Se um transbordamento ocorrer  Elimina EnableOut para falso.  Caso contrário  Definir EnableOut como  verdadeiro. |
| Primeira execução da  instrução    | N/D                                                                                                                                                                       |
| Primeira varredura da  instrução   | N/D                                                                                                                                                                       |
| Pós-varredura N/D                  |                                                                                                                                                                           |

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A ção realizada    |                                                  |
|------------------------------------|--------------------------------------------------|
| Pré-varredura N/D                  |                                                  |
|                                    | Varredura normal Dest = valor absoluto de Source |
| Primeira execução da  instrução    | N/D                                              |
| Primeira varredura da  instrução   | N/D                                              |
| Pós-varredura N/D                  |                                                  |

## Exemplos

## Diagrama ladder

<!-- image -->
