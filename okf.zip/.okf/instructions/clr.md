---
type: Instruction
title: "Limpar (CLR)"
description: "A instrução CLR elimina todos os bits do Dest."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L11398-L11471"
---

## Limpar (CLR)

## Funções FBD na página 425

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução CLR elimina todos os bits do Dest.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

A instrução CLR dá suporte a tipos de dados elementares. Consulte Tipos de dados elementares .

## Diagrama ladder

| Operando    | Tipo de  dados (Data  Type)    | Format    | Descrição  (Description)    |
|-------------|--------------------------------|-----------|-----------------------------|
|             | Dest SINT  INT:  DINT  REAL    |           | tag Tag a eliminar.         |

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                         | Afeta sinalizadores de status de  operações matemáticas    |
|-----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580 | Condicional                                                |
| Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix 5570                     | Sim                                                        |

Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                            |
|------------------------------------|----------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                            |
| Rung-condition-in é falsa          | Definir Rung-condition-out  como Rung-condition-in.                        |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out  como Rung-condition-in.  Eliminar Dest para 0. |
| Pós-varredura N/D                  |                                                                            |

## Exemplo

## Diagrama ladder

<!-- image -->

## Consulte também

Instruções de movimento na página 429
