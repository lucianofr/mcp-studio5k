---
type: Instruction
title: "Linhas de handshake ASCII (AHL)"
description: "Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L19526-L19708"
---

## Linhas de handshake ASCII (AHL)

## Conversões de dados na página 883

Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate.

A instrução AHL obtém o status de linhas de controle e ativa ou destiva os sinais DTR e RTS.

Dica:

Instruções de Porta serial ASCII (AWT, AWA, ARD, ARL, ABL, ACB, AHL, ACL) não estão disponíveis para controladores que não têm portas seriais.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

AHL(Channel,ANDMask,ORMask,SerialPortControl);

## Operandos

## Diagrama ladder

| Operando Tipo             |                | Formato Descrição                                                      |                                                                        |
|---------------------------|----------------|------------------------------------------------------------------------|------------------------------------------------------------------------|
| Channel DINT              | imediato tag 0 |                                                                        |                                                                        |
| ANDMask DINT              | imediato tag   |                                                                        |                                                                        |
| ORMask DINT               | imediato tag   | Consulte a descrição                                                   | Consulte a descrição                                                   |
|                           |                | SerialPort Control SERIAL_PORT_CONTROL tag Tag que controla a operação | SerialPort Control SERIAL_PORT_CONTROL tag Tag que controla a operação |
| Channel Status  (Decimal) | DINT imediato  | 0  Durante a execução, exibe o status das linhas  de controle.         | 0  Durante a execução, exibe o status das linhas  de controle.         |
| Channel Status  (Decimal) | DINT imediato  | Para o status desta linha de  controle.                                | Examine este  bit:                                                     |
| Channel Status  (Decimal) | DINT imediato  | CTS 0                                                                  |                                                                        |

| RTS 1                      |
|----------------------------|
| DSR 2                      |
| DCD 3                      |
| DTR 4                      |
| Recebeu o caractere XOFF 5 |

## Texto estruturado

| Operando Tipo             |                | Formato Descrição                                                      |                                                                        |
|---------------------------|----------------|------------------------------------------------------------------------|------------------------------------------------------------------------|
| Channel DINT              | imediato tag 0 |                                                                        |                                                                        |
| ANDMask DINT              | imediato tag   |                                                                        |                                                                        |
| ORMask DINT               | imediato tag   | Consulte a descrição                                                   | Consulte a descrição                                                   |
|                           |                | SerialPort Control SERIAL_PORT_CONTROL tag Tag que controla a operação | SerialPort Control SERIAL_PORT_CONTROL tag Tag que controla a operação |
| Channel Status  (Decimal) | DINT imediato  | 0  Durante a execução, exibe o status das linhas  de controle.         | 0  Durante a execução, exibe o status das linhas  de controle.         |
| Channel Status  (Decimal) | DINT imediato  | Para o status desta linha de  controle.                                | Examine este  bit:                                                     |
| Channel Status  (Decimal) | DINT imediato  | CTS 0                                                                  |                                                                        |
| Channel Status  (Decimal) | DINT imediato  | RTS 1                                                                  |                                                                        |
| Channel Status  (Decimal) | DINT imediato  | DSR 2                                                                  |                                                                        |
| Channel Status  (Decimal) | DINT imediato  | DCD 3                                                                  |                                                                        |
| Channel Status  (Decimal) | DINT imediato  | DTR 4                                                                  |                                                                        |
| Channel Status  (Decimal) | DINT imediato  | Recebeu o caractere XOFF 5                                             |                                                                        |

Você pode especificar o valor de Channel Status acessando o membro .POS da estrutura SERIAL\_PORT\_CONTROL, em vez de incluir o valor na lista de operandos.

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Estrutura de SERIAL\_PORT\_CONTROL

| Mnemônico  Tipo de  dados    | Descrição                                                                                          |
|------------------------------|----------------------------------------------------------------------------------------------------|
| .EN BOOL                     | O bite de habilitação indica que a instrução está  habilitada.                                     |
| .EU BOOL                     | O bit de fila indica que a instrução é digitada na  fila ASCII.                                    |
| .DN BOOL                     | O bit executado indica que a instrução foi  executada, mas está assíncrona à varredura de  lógica. |
| .RN BOOL                     | O bit de execução indica que a instrução está  sendo executada.                                    |

| .EM BOOL    | O bit vazio indica quando a instrução foi  executada, mas está síncrona com a varredura  da lógica.                      |
|-------------|--------------------------------------------------------------------------------------------------------------------------|
| .ER BOOL    | O bit de erro indica quando a instrução falha  (erros).                                                                  |
|             | .FD BOOL O bit encontrado não se aplica a esta instrução.                                                                |
| .POS DINT   | A posição determina o número de caracteres no  buffer, até e incluindo o primeiro conjunto de  caracteres de terminação. |
| .ERROR DINT | O erro contém um valor hexadecimal que indica  a causa de um erro.                                                       |

## Descrição

A instrução AHL pode:

-  Obter o status das linhas de controle da porta serial
-  Ativar ou desativar o sinal Terminal de dados pronto (DTR)
-  Ativar ou desativar o sinal Solicitação de envio (RTS)

Para programar a instrução AHL, siga estas diretrizes:

Configure a porta serial do controlador.

| Se seu aplicativo:                                  | Então:                              |
|-----------------------------------------------------|-------------------------------------|
| Usa a instrução ARD ou ARL Selecione o modo Usuário |                                     |
| Não usa as instruções ARD ou  ARL                   | Selecione o modo Usuário ou Sistema |

Use a tabela a seguir para selecionar os valores corretos para os operandos ANDMask e ORMask:

| Para se tornar  DTR:    | E se tornar  RTS:         | Digite este valor ANDMask:  E digite este  valor    |
|-------------------------|---------------------------|-----------------------------------------------------|
|                         | Desativado Desativado 3   | 0                                                   |
|                         |                           | ativado 1                                           |
|                         |                           | inalterado 1                                        |
|                         | Ativado Desativado 2 1    |                                                     |
|                         |                           | ativado 0                                           |
|                         |                           | inalterado 0                                        |
|                         | Inalterado Desativado 2 0 |                                                     |
|                         |                           | ativado 0                                           |
|                         |                           | inalterado 0                                        |

Isso é uma instrução de transição:

-  No diagrama ladder, alterne EnableIn de eliminado para definido toda vez que a instrução deve ser executada.
-  No texto estruturado, condicione a instrução para que ela apenas execute em uma transição

## Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

| Tipo Code Causa    |                                                                                                   | Método de recuperação                                                                    |
|--------------------|---------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|
| 4 57               | A instrução AHL não  foi executada  porque a porta serial  é definida para  nenhum  "handshaking" | Altere a configuração de Linha  de Controle da porta serial.  ou  Exclua a instrução AHL |

## Execução

## Diagrama ladder

| Condição                        | Ação do Diagrama ladder                                                              |
|---------------------------------|--------------------------------------------------------------------------------------|
| Pré-varredura N/A               |                                                                                      |
| Rung-condition-in é  falsa      | N/A                                                                                  |
| Rung-condition-in é  verdadeira | A instrução executa quando o  rung-condition-in alterna de  eliminado para definido. |
| Pós-varredura N/A               |                                                                                      |

## Texto estruturado

| Condição          | Ação de texto estruturado                                                            |
|-------------------|--------------------------------------------------------------------------------------|
| Pré-varredura N/A |                                                                                      |
| Execução normal   | A instrução executa quando o  rung-condition-in alterna de  eliminado para definido. |
| Pós-varredura N/A |                                                                                      |

## Exemplo

## Diagrama ladder

<!-- image -->

## Texto estruturado

osri\_1.InputBit := get\_control\_line\_status;

```
OSRI(osri_1); IF (osri_1.OutputBit) THEN AHL(0,0,0,serial_port); END_IF;
```

## Consulte também

Instruções de porta serial ASCII na página 783

Teste ASCII para Linha do Buffer (ABL) na página 807

Caracteres ASCII no buffer (ACB) na página 785

Buffer limpo ASCII (ACL) na página 788

Leitura ASCII (ARD) na página 797

Linhas de leitura ASCII (ARL) na página 801

Acréscimo de Gravação ASCII (AWA) na página 816

Gravação ASCII (AWT) na página 810

Atributos comuns na página 879
