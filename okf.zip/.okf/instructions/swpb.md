---
type: Instruction
title: "Trocar byte (SWPB)"
description: "Índice por meio de matrizes na página 893"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L11817-L12248"
---

## Trocar byte (SWPB)

Índice por meio de matrizes na página 893

Instruções de movimento na página 429

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução SWPB reorganiza a ordem dos bytes de Source. Coloca o resultado em Destination.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

SWPB(Source, Order Mode, Dest);

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                    |
|----------------|---------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                        |
|                |   Membros de um operando de estrutura estão  substituídos.                                             |
|                |   Exceto quanto especificado, os operandos da  estrutura são compartilhados por múltiplas  instruções. |

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversão de dados .

## Diagrama ladder e Texto estruturado

| Operando                    | Tipo de dados  (Data Type)    |                 | Format Des crição (Description)                                                |
|-----------------------------|-------------------------------|-----------------|--------------------------------------------------------------------------------|
| Origem INT:                 | DINT                          | tag             | Tag que contém os bytes a  reorganizar.                                        |
| Modo de ordem  (Order Mode) |                               | item de  listas | Esse operando especifica como  reordenar. Consulte a tabela de  Modo de ordem. |
|                             | Dest INT:  DINT               | tag             | Tag para armazenar os bytes em  uma nova ordem. Consulte a tabela  de Dest.    |

Se estiver selecionando o modo de ordem HIGH/LOW, insira-o como HIGHLOW (sem a barra). Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Modo de ordem (Order Mode)

| Se a Source for    | E você deseja alterar os  bytes para esse padrão  (cada letra representa um  byte diferente)    | Então seleciona    |
|--------------------|-------------------------------------------------------------------------------------------------|--------------------|
| INT:               | AB => BA                                                                                        | Qualquer opção     |
| DINT               | ABCD => DCBA                                                                                    | REVERSE            |
|                    | ABCD =>CDAB WORD                                                                                |                    |
|                    | ABCD => BADC HIGH/LOW                                                                           |                    |

## Dest

| Se a Source for Então o Destination deve ser                                                          |
|-------------------------------------------------------------------------------------------------------|
| INT: INT, DINT  Se o destino for um DINT, o resultado terá o sinal  estendido após a troca dos bytes. |
| DINT DINT                                                                                             |

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                  |
|----------------------------------------------------------------------------------|
| Pré-varredura N/D                                                                |
| Rung-condition-in é falsa N/D                                                    |
| Rung-condition-in é  verdadeira  A instrução reorganiza os bytes  especificados. |
| Pós-varredura N/D                                                                |

## Texto estruturado

| Condição/estado A ção realizada    |                                                                        |
|------------------------------------|------------------------------------------------------------------------|
| Pré-varredura                      | Consulte Pré-varredura na tabela de  Diagrama ladder.                  |
| Execução normal                    | Consulte Rung-condition-in é verdadeira  na tabela de Diagrama ladder. |
| Pós-varredura                      | Consulte Pós-varredura na tabela de  Diagrama ladder.                  |

## Exemplos

## Exemplo 1 - trocar os bytes de DINT tag

As três instruções SWPB reordenam os bytes de DINT\_1 de acordo com um modo de ordem diferente. O estilo de exibição é ASCII, e cada caractere representa um byte. Cada instrução coloca os bytes, na nova ordem, em um Destination diferente.

## Diagrama ladder

<!-- image -->

Exemplo 2 - trocar os bytes em todos os elementos de uma matriz

## Diagrama ladder

Exemplo 3: SWPB em texto estruturado

<!-- image -->

## Texto estruturado

```
índice := 0; SIZE (array[0],0,array_length); REPEAT index := index + 1;
```

```
SWPB(array[index],REVERSE,array_bytes_reverse[index]); UNTIL(index >= array_length)END_REPEAT; Consulte também
```

```
Instruções de movimento na página 429 Índice por meio de matrizes na página 893 Conversões de dados na página 883
```

Sintaxe de texto estruturado na página 912

## Instruções de matriz (Arquivo)/Instruções diversas

## Instruções de matriz (Arquivo)/Instruções diversas

As instruções de arquivo/diversas operam em matrizes de dados.

Instruções disponíveis

Diagrama ladder

FAL

FSC

Bloco de funções

Indisponível

Texto estruturado

SIZE

FSC

COP

COP

CPS

CPS

| Se você desejar:                                                                          | Use esta instrução:    |
|-------------------------------------------------------------------------------------------|------------------------|
| Realize operações aritméticas, lógicas, de  deslocamento e função em valores em  matrizes | FAL                    |
| Pesquisar e comparar valores em matrizes FSC                                              |                        |
| Copiar os conteúdos de uma matriz para  outra                                             | COP                    |
| Copiar os valores na Source para o  Destination                                           | CPS                    |
| Preencher uma matriz com dados  específicos                                               | FLL                    |
| Calcular a média de uma matriz de valores AVE                                             |                        |
| Classificar uma dimensão de dados de  matriz em ordem crescente                           | SRT                    |
| Calcular o desvio padrão de uma matriz de  valores                                        | STD                    |
| Encontrar o tamanho de uma dimensão de  uma matriz                                        | SIZE                   |

FLL

AVE

Copiar arquivo (COP), Copiar arquivo de forma síncrona (CPS)

Você pode misturar tipos de dados, mas a perda de precisão e o erro de arredondamento podem ocorrer e a instrução levará mais tempo para ser executada. Verifique o bit S:V para ver se o resultado foi truncado.

Os tipos de dados em negrito indicam ótimos tipos de dados. Uma instrução é executada mais rápido e requer menos memória se todos os operandos da instrução usarem o mesmo tipo de dados otimizado, geralmente DINT ou REAL.

## Selecionando o modo de operação

Para instruções FAL e FSC, o modo diz ao controlador como distribuir a operação da matriz.

| Se você desejar:                                                                                                                          | Selecione este modo:    |
|-------------------------------------------------------------------------------------------------------------------------------------------|-------------------------|
| operar em todos os elementos  especificados em uma matriz antes de  continuar para a instrução seguinte                                   | Modo Tudo               |
| distribuir a operação da matriz em diversas  varreduras  inserir o número de elementos para  operação segundo a varredura  (1-2147483647) | Modo Numérico           |
| manipular um elemento da matriz cada vez  que a rung-condition-in passar de falso para  verdadeiro                                        | Modo Incremental        |

## Consulte também

Modo Tudo na página 557

Modo Numérico na página 558

Modo Incremental na página 561

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

As instruções COP e CPS copiam o(s) valor(es) de Source para os valores no Dest. A Source permanece inalterada.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

COP(Source,Dest,Length);

CPS(Source,Dest,Length);

## Operandos

Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

## Diagrama ladder

| Operando Tipo de dados Formato Descrição                      |                               |
|---------------------------------------------------------------|-------------------------------|
| Source SINT  INT  DINT  LINT  REAL  Tipo de string  estrutura | tag Elemento inicial a copiar |

| Dest SINT  INT  DINT  LINT  REAL  Tipo de string  estrutura    | tag           | Elemento inicial a ser  substituído por Source    |
|----------------------------------------------------------------|---------------|---------------------------------------------------|
| Length SINT  INT  DINT                                         | imediato  tag | Número de elementos de  Destination a copiar      |

## Texto estruturado

| Operando Tipo de dados Formato Descrição                      |               |                                                |
|---------------------------------------------------------------|---------------|------------------------------------------------|
| Source SINT  INT  DINT  LINT  REAL  Tipo de string  estrutura |               | tag Elemento inicial a copiar                  |
| Dest SINT  INT  DINT  LINT  REAL  Tipo de string  estrutura   | tag           | Elemento inicial a ser  substituído por Source |
| Length SINT  INT  DINT                                        | imediato  tag | Número de elementos de  Destination a copiar   |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                 |
|------------------------------------|---------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                 |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como Rung-condition-in.                              |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como Rung-condition-in.  A instrução copia os dados. |
| Pós-varredura N/A                  |                                                                                 |

## Texto estruturado

| Condição/estado A ção realizada                                                         |
|-----------------------------------------------------------------------------------------|
| Pré-varredura Consulte Pré-varredura na tabela do Diagrama ladder                       |
| Execução normal  Consulte Rung-condition-in é verdadeira na tabela de  Diagrama ladder. |
| Pós-varredura Consulte Pós-varredura na tabela de Diagrama ladder.                      |

Durante a execução das instruções COP e CPS, outras ações do controlador podem tentar interromper a operação de cópia e alterar a origem:

| Se a origem ou o  destino for:                                                                               | e você precisar:                                                               | Selecione :    | Notas                                                                                                                                                                                                                                                      |
|--------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------|----------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|   tag produzida    tag consumida    dados de E/S    dados que  podem ser  substituídos por  outra tarefa | Impedir que os dados  da origem sejam  alterados durante a  operação de cópia  | CPS            | Tarefas que tentam  interromper uma  instrução CPS são  suspensas até que a  instrução tenha sido  concluída.  Para uma estimativa  do tempo de  execução da  instrução CPS,  consulte o Manual  do usuário  ControlLogix  System, publicação  1756-UM001. |
|   tag produzida    tag consumida    dados de E/S    dados que  podem ser  substituídos por  outra tarefa | Permitir que os dados  da origem sejam  alterados durante a  operação de cópia | COP            |                                                                                                                                                                                                                                                            |
| Nenhuma das  opções acima                                                                                    | ---------------> COP                                                           |                |                                                                                                                                                                                                                                                            |

As instruções COP e CPS operam na memória contígua e realizam uma cópia de memória direta byte a byte.

Quando Source e Dest forem tipos de dados diferentes, o número de bytes copiados será igual ao menor valor de:

-  Valor solicitado é igual a Length X (o número de bytes em um elemento de destino)
-  O número de bytes na tag de destino
-  Para Controlador Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 ou GuardLogix 5580s: O número de bytes da tag de origem

Dica:

O final da tag de destino ou origem é definido como o último byte da tag base. Se a tag for uma estrutura, o final da tag será o último byte do último elemento da estrutura. Isso significa que as instruções COP e CPS poderia gravar além do fim de uma matriz do membro, mas não nunca gravaria o além da tag base.

Importante:

Teste e confirme que a instrução não altera dados que não devem ser alterados

## Exemplos

## Exemplo 1

Copiar uma matriz.

Quando habilitada, a instrução COP copia 40 bytes de array\_4 para o array\_5.

array\_4 é um DINT (4 bytes por elemento) e contém 10 elementos (tamanho total = 40 bytes)

array\_5 é um DINT (4 bytes por elemento) e contém 10 elementos (tamanho total = 40 bytes).

O Length significa que 10 elementos de destino devem ser copiados para que 40 bytes também sejam copiados.

## Diagrama ladder

<!-- image -->

## Texto estruturado

COP(array\_4[0],array\_5[0],10);

## Exemplo 2

Copiar uma estrutura.

Quando habilitada, a instrução COP copia a estrutura de timer\_1 no elemento 5 de array\_timer.

timer\_1 é um TIMER (tamanho total = 12 bytes).

array\_timer é um TIMER (12 bytes por elemento) e contém 10 elementos (tamanho total = 120 bytes).

O Length significa que 1 elemento de destino deve ser copiado para que 12 bytes também sejam copiados.

## Diagrama ladder

<!-- image -->

## Texto estruturado

COP(timer\_1,array\_timer[5],1);

## Exemplo 3

Copiar dados de matriz e impedir que os dados sejam alterados até que a cópia tenha sido concluída.

A matriz project\_data (100 elementos) armazena vários valores que se alteram em momentos diferentes na aplicação. Para enviar uma imagem completa do project\_data em uma instância no momento adequado para outro controlador, a instrução CPS copia project\_data para produced\_array. Enquanto a instrução CPS copia os dados, eles não podem ser alterados por atualizações de E/S nem por outras tarefas. A tag produced\_array cria os dados em uma rede ControlNet para uso por outros controladores.

project\_data é um DINT (4 bytes por elemento) e contém 100 elementos (tamanho total = 400 bytes)

produced\_array é um DINT (4 bytes por elemento) e contém 100 elementos (tamanho total = 400 bytes).

O Length significa que 100 elementos de destino devem ser copiados para que 400 bytes também sejam copiados.

## Diagrama ladder

<!-- image -->

## Texto estruturado

CPS(project\_data[0],produced\_array[0],100);

## Exemplo 4

Copiar dados para uma tag produzida e impedir que dados sejam enviados até que a cópia tenha sido concluída.

Local:0:I.Data armazena os dados de entrada na rede DeviceNet conectada ao módulo 1756-DNB no slot 0. Para sincronizar as entradas com a aplicação, a instrução CPS copia os dados de entrada para input\_buffer. Enquanto a instrução CPS copia os dados, eles não podem ser alterados por atualizações de E/S. Durante sua execução, a aplicação usa os dados de entrada em input\_buffer.

Local:O:I.Data é um DINT (4 bytes por elemento) e contém 2 elementos (tamanho total = 8 bytes)

input\_buffer é um DINT (4 bytes por elemento) e contém 20 elementos (tamanho total = 80 bytes).

O Length significa que 20 elementos de destino devem ser copiados (4 X 20 = 80 bytes). No entanto, a origem só pode fornecer 8 bytes para que 8 bytes sejam copiados.

## Diagrama ladder

<!-- image -->

## Texto estruturado

CPS(Local:0:I.Data[0], input\_buffer[0], 20);

## Exemplo 5

Inicializa uma estrutura de matriz, inicializa o primeiro elemento e usa COP para replicá-lo no restante da matriz.

<!-- image -->

Esse exemplo inicializa uma matriz ou estruturas do temporizador. Quando habilitadas, as instruções MOV inicializam os valores .PRE e .ACC do primeiro elemento array\_timer. Quando habilitada, a instrução COP copia um bloco contíguo de bytes, iniciando em array\_timer[0]. O comprimento é composto por nove estruturas do temporizador.

array\_timer é um TIMER (12 bytes por elemento) e contém 15 elementos (tamanho total = 180 bytes).

O Length significa que 10 elemento de destino deve ser copiado para que 120 bytes também sejam copiados.

## Diagrama ladder

<!-- image -->

## Texto estruturado

IF S:FS THEN

array\_timer[0].pre := 500;

array\_timer[0].acc := 0;

COP(array\_timer[0],array\_timer[1],10);

END\_IF;

## Exemplo 6

Copiar matrizes de tamanhos diferentes.

Quando habiitada, a instrução COP copia bytes de SINT array\_6 para DNT array\_7.

array\_6 é um SINT (1 byte por elemento) e contém 5 elementos (tamanho total = 5 bytes)

array\_7 é um DINT (4 bytes por elemento) e contém 10 elementos (tamanho total = 40 bytes).

O Length significa que 20 elementos de destino devem ser copiados (4 X 20 = 80 bytes). No entanto, o dest só pode aceitar 40 bytes e a origem só pode fornecer 5 bytes para que 5 bytes sejam copiados.

## Diagrama ladder

<!-- image -->

## Texto estruturado

COP(array\_4[0],array\_5[0],10);

## Consulte também

Indexação por meio de matrizes na página 893

Instruções de arquivo/diversas na página 493

Instruções lógicas/de movimento na página 429
