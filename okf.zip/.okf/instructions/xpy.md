---
type: Instruction
title: "X elevado à potência de Y (XPY)"
description: "Instruções matemáticas avançadas na página 749"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L18413-L18601"
---

## X elevado à potência de Y (XPY)

## Consulte também

Instruções matemáticas avançadas na página 749

Atributos comuns na página 879

Sinalizadores de status de operações matemáticas na página 879

Conversões de dados na página 883

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução XPY leva a Source A (X) à energia de Source B (Y) e armazena o resultado no Destination.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

dest := sourceX ** sourceY;

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

## Diagrama ladder

|                                 |                | Operando Tipo (Type) Format Descrição (Description)    |
|---------------------------------|----------------|--------------------------------------------------------|
| Source X SINT  INT:  DINT  REAL | immediate  tag | valor para exponenciação                               |
| Source Y SINT  INT:  DINT  REAL | immediate  tag | expoente                                               |
| Dest SINT  INT:  DINT  REAL     | tag            | tag a armazenar o resultado                            |

## Texto estruturado

Use dois sinais de multiplicar adjacentes "**" como um operador dentro de uma expressão.

Consulte Sintax de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Bloco de funções

| Operando Tipo (Type) Format    | Descrição  (Description)    |
|--------------------------------|-----------------------------|
| XPY tag FBD_MATH Structure     | Estrutura de  XPY           |

## Estrutura de FBD\_MATH

| Parâmetro  de entrada    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                               |
|--------------------------|-------------------------------|-----------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                               | Entrada Habilitar. Se eliminado, a  instrução não é executada e as saídas  não são atualizadas.  O padrão é definido. |
| SourceA REAL             |                               | Valor base                                                                                                            |
| SourceB REAL             |                               | Expoente.                                                                                                             |

| Parâmetro  de saída    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                               |
|------------------------|-------------------------------|-----------------------------------------------------------------------------------------------------------------------|
|                        |                               | EnableOut BOOL Saída Habilitar.                                                                                       |
|                        | Dest REAL                     | Resultado da instrução matemática. Os  sinalizadores de status de operações  matemáticas são ajustados para a  saída. |

## Descrição (Description)

A instrução XPY eleva a Source A (X) à energia de Source B (Y) e armazena o resultado no Destination.

Se Source A (X) for negativo, Source B (Y) deve ser um valor não fracionário ou uma falha menor será gerada.

Para controladores CompactLogix 5370 e ControlLogix 5570, se a base for negativa e o expoente for real, o valor absoluto da base é usado.

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                       | Afeta sinalizadores de status de  operações matemáticas                    |
|---------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580 | Condicional, consulte Sinalizadores  de status de operações  matemáticas . |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact  GuardLogix 5370 e GuardLogix 5570                     | Sim                                                                        |

## Falhas maiores/menores

| Controladores                                                                                                          | Uma falha maior  ocorrerá se:                            | Tipo de falha Código de  falha    |
|------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------|-----------------------------------|
| Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix  5580 |                                                          | N/D N/D N/D                       |
| Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix  5570                     | Source X é  negativo e Source  Y não é um valor  inteiro | 4 4                               |

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                           |
|------------------------------------|-------------------------------------------------------------------------------------------|
| Pré-varredura N/A.                 |                                                                                           |
| Rung-condition-in é  falsa.        | N/A.                                                                                      |
| Rung-condition-in é  verdadeira.   | O controlador leva a Source X à energia de  Source Y e coloca o resultado no Destination. |
| Pós-varredura N/A.                 |                                                                                           |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                   |
|                                    | Tag.EnableIn é falso. EnableOut é eliminado como falso                                                            |
| Tag.EnableIn é  verdadeiro         | EnableOut é definido como verdadeiro. Se o  bloco gerar um transbordamento, EnableOut  será eliminado como falso. |
| Primeira varredura da  instrução   | N/D                                                                                                               |
| Primeira execução da  instrução    | N/D                                                                                                               |
| Pós-varredura N/D                  |                                                                                                                   |

## Texto estruturado

| Condição/estado A ção realizada                          |
|----------------------------------------------------------|
| Pré-varredura N/A.                                       |
| Execução normal Consulte Rung-condition-in é verdadeira. |
| Pós-varredura N/A.                                       |

## Exemplo

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

result := (value\_1 ** value\_2);

## Consulte também

Sintaxe de texto estruturado na página 912

Instruções matemáticas avançadas na página 749

Sinalizadores de status de operações matemáticas na página 879

Atributos comuns na página 879

## Instruções de conversão matemática

## Instruções de conversão matemática

As instruções de conversão matemática convertem valores.

## Instruções disponíveis

Diagrama ladder e Bloco de funções

DEG

RAD

TOD

## Texto estruturado

DEG

RAD

TRN

| Se você deseja                                   | Use esta instrução    |
|--------------------------------------------------|-----------------------|
| Converter radianos em graus. DEG                 |                       |
| Converter graus em radianos. RAD                 |                       |
| Converter um valor integral em  um valor de BCD. | TOD                   |
| Converter um valor de BCD em  um valor inteiro.  | FRD                   |
| Remover a porção fracionária de  um valor.       | TRN                   |

Você pode misturar tipos de dados, mas a perda de precisão e o erro de arredondamento podem ocorrer e a instrução levará mais tempo para ser executada. Verifique o bit S:V para ver se o resultado foi truncado.

Os tipos de dados em negrito indicam ótimos tipos de dados. Uma instrução é executada mais rápido e requer menos memória se todos os operandos da instrução usarem o mesmo tipo de dados otimizado, geralmente DINT ou REAL.

Uma instrução de conversão matemática é executada uma vez sempre que a instrução passa por varredura, desde que rung-condition-in seja verdadeira. Se você desejar que a instrução seja avaliada apenas uma vez, use uma instrução ONS para disparar a instrução de conversão.

FRD

TRN
