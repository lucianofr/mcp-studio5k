---
type: Instruction
title: "Movimentação (MOV)"
description: "value\_masked := MVMT\_01.Dest;"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L11709-L11816"
---

## Movimentação (MOV)

value\_masked := MVMT\_01.Dest;

## Consulte também

Movimentação mascarada (MVM) na página 476

Conversões de dados na página 883

Sintaxe de texto estruturado na página 912

Atributos comuns na página 879

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução MOV move uma cópia de Source para Dest. A Source permanece inalterada.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

Dica:

Use uma atribuição ':=' com uma expressão para obter o mesmo resultado. Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões e atribuições no texto estruturado.

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                    |
|----------------|---------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                        |
|                |   Membros de um operando de estrutura estão  substituídos.                                             |
|                |   Exceto quanto especificado, os operandos da  estrutura são compartilhados por múltiplas  instruções. |

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

## Numérico

| Operando  Tipo de dados  (Data Type)  Controladores  CompactLogix  5370,  ControlLogix  5570, Compact  GuardLogix 5370 e  GuardLogix 5570    | Tipo de dados (Data  Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact  GuardLogix 5380 e  GuardLogix 5580    | Format         | Descrição  (Description)      |
|----------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|-------------------------------|
| Origem SINT  INT:  DINT  REAL                                                                                                                | SINT  INT:  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                        | immediate  tag | Valor a mover                 |
| Dest SINT  INT:  DINT  REAL                                                                                                                  | SINT  INT:  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                        | tag            | Tag a  armazenar o  resultado |

## String (somente para Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580)

| Operando  Tipo de dados  (Data Type)    | Format    | Descrição  (Description)     |
|-----------------------------------------|-----------|------------------------------|
| Origem Tipo de string immediate         | tag       | String a mover               |
| Dest Tipo de string tag                 |           | Tag a armazenar o  resultado |

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                         | Afeta sinalizadores de status  de operações matemáticas    |
|-----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580 | Condicional                                                |
| Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix 5570                     | Sim                                                        |

Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

| Uma falha menor  ocorrerá se:                                                                                    | Tipo de  falha    | Código de  falha    |
|------------------------------------------------------------------------------------------------------------------|-------------------|---------------------|
| Recurso de detecção de  transbordamento é  habilitado e o valor de  Source está fora do  intervalo do tipo Dest. |                   | 4 4                 |

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                                                                             |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                                                             |
| Rung-condition-in é falsa          | Definir Rung-condition-out como  Rung-condition-in.                                                                                                                                                         |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como  Rung-condition-in.  A instrução copia a Source para o Dest.  Operandos da string: Se Source.LEN > SIZE( Dest.DATA)  A string é truncada para o que couber  S:V é definido. |
| Pós-varredura N/D                  |                                                                                                                                                                                                             |

## Exemplos

## Diagrama ladder

<!-- image -->

## Texto estruturado

<!-- formula-not-decoded -->

value\_3 := 'Test PASSED';

## Consulte também

Sintaxe de texto estruturado na página 912

Conversões de dados na página 883

Sinalizadores de status de operações matemáticas na página 879
