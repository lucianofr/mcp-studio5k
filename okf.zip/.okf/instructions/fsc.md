---
type: Instruction
title: "Fluxograma do modo Tudo (FSC)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L13390-L13489"
---

## Fluxograma do modo Tudo (FSC)

## Modo Numérico

<!-- image -->

O modo Numérico distribui a operação de matriz em diversas varreduras. Esse modo é útil ao trabalhar com dados não urgentes ou grandes quantidades de dados. Você insere o número de elementos para operar em cada varredura, o que mantém o tempo de varredura mais curto.

A execução é disparada quando a rung-condition-in passa de falso para verdadeiro. Depois de disparada, a instrução é executada sempre que passa por varredura para o número de varreduras necessárias para concluir a operação em toda a matriz. Depois de disparada, a rung-condition-in pode mudar repetidamente sem interromper a execução da instrução.

<!-- image -->

Evite usar os resultados em uma instrução de arquivo que opera no modo numérico até o bit .DN ser definido.

O seguinte diagrama de tempo mostra a relação entre bits de status e a operação de instrução. Quando a execução da instrução é concluída, o bit .DN é definido.

<!-- image -->

Se a rung-condition-in for verdadeira à conclusão, os bits .EN e .DN serão verdadeiros até a rung-condition-in passar a ser falsa. Quando a rung-condition-in passa a ser falsa, esses bits são eliminados e o valor .POS é eliminado.

## Fluxograma do modo Numérico (FSC)

Se a rung-condition-in for falsa à conclusão, o bit .EN será eliminado imediatamente. Uma varredura depois de o bit .EN ser eliminado, o bit .DN e o valor .POS são eliminados.

<!-- image -->

## Modo Incremental

O modo incremental manipula um elemento da matriz sempre que rung-condition-in da instrução passa de falso para verdadeiro.

<!-- image -->

O seguinte diagrama de tempo mostra a relação entre bits de status e a operação de instrução. A execução ocorre somente em uma varredura em que a rung-condition-in passa de falso para verdadeiro. Sempre que isso ocorre, somente um elemento da matriz é manipulado. Se a rung-condition-in permanecer verdadeira por mais de uma varredura, a instrução será executada durante a primeira varredura

<!-- image -->

O bit .EN é definido quando rung-condition-in é verdadeira. O bit .DN é definido quando o último elemento na matriz tiver sido manipulado. Quando o último elemento tiver sido manipulado e a rung-condition-in passar para falso, o bit .EN, o bit .DN e o valor .POS serão eliminados.

A diferença entre o modo incremental e o modo numérico a uma taxa de um elemento por varredura é:

## Fluxograma do modo Incremental (FSC)

## Tag de matriz

-  Modo numérico com qualquer número de elementos por varredura requer somente uma transição de falso para verdadeiro de rung-condition-in para iniciar a execução. A instrução continua a executar o número especificado de elementos a cada varredura até a conclusão, não importa o estado de rung-condition-in.
-  O modo incremental exige que a rung-condition-in mude de falso para verdadeiro para manipular um elemento na matriz.

<!-- image -->

Ao inserir uma tag de matriz, certifique-se de especificar o primeiro elemento da matriz a manipular. Não use CONTROL.POS para identificar o elemento inicial, pois a instrução modifica o valor de .POS conforme ela opera, o que pode corromper o resultado.

## Desvio padrão

- O desvio padrão é calculado de acordo com esta fórmula:

## Onde:

-  start = subscrito da dimensão para variar do operando da matriz
-  xi = elemento variável na matriz
-  N = número de elementos especificados na matriz
- 

<!-- formula-not-decoded -->

## Instruções de deslocamento/matriz (arquivo)

## Instruções de deslocamento/matriz (arquivo)

Use as instruções de deslocamento/matriz (arquivo) para modificar o local de dados dentro de matrizes.

Instruções disponíveis

Diagrama ladder

<!-- image -->

## Bloco de funções

Indisponível

## Texto estruturado

Indisponível

| Se você desejar:                                                                    | Use esta instrução:    |
|-------------------------------------------------------------------------------------|------------------------|
| Carregar bits, mudar bits e descarregar bits de  uma matriz de bits um bit por vez. | BSL  BSR               |
| Carregar e descarregar valores na mesma  ordem.                                     | FFL  FFU               |
| Carregar e descarregar valores na ordem  inversa.                                   | LFL  LFU               |

É possível misturar tipos de dados, mas a perda de precisão e erro de arredondamento podem ocorrer.

Os tipos de dados em negrito indicam ótimos tipos de dados. Uma instrução é executada mais rápido e requer menos memória se todos os operandos da instrução usarem o mesmo tipo de dados otimizado, geralmente DINT ou REAL.

## Consulte também

Instruções de conversão ASCII na página 845

Instruções de porta serial ASCII na página 825
