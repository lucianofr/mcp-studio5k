---
type: Instruction
title: "Graus (DEG)"
description: "Atributos comuns na página 879"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L18835-L18936"
---

## Graus (DEG)

Atributos comuns na página 879

Sinalizadores de status de operações matemáticas na página 879

Conversões de dados na página 883

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução DEG converte Source (em radianos) em graus e armazena o resultado no Destination.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

dest := DEG(source);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

## Diagrama ladder

|                                   | Operando Tipo Formato Descrição    |                                 |
|-----------------------------------|------------------------------------|---------------------------------|
| Source SINT  INT  DINT  REA       | Imediato  tag                      | valor para converter em  graus  |
| Destination SINT  INT  DINT  REAL |                                    | tag tag a armazenar o resultado |

## Texto estruturado

Use DEG como uma função. Consulte Sintax de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Bloco de funções

| Operando Tipo    | Operando Tipo                       | Formato Descrição    |
|------------------|-------------------------------------|----------------------|
|                  | DEG tag FBD_MATH_ADVANCED Estrutura | Estrutura de  DEG    |

## Estrutura de FBD\_MATH\_ADVANCED

| Parâmetro de entrada Tipo de dados Descrição    |                                                                                                                        |
|-------------------------------------------------|------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL                                   | Entrada Habilitar. Se falso, a instrução não  será executada e as saídas não serão  atualizadas.  Padrão é verdadeiro. |
| Source                                          | REAL Entrada para a instrução de conversão.                                                                            |

| Parâmetro de saída Tipo de dados Descrição    |                                             |
|-----------------------------------------------|---------------------------------------------|
| EnableOut                                     | BOOL Indica se a instrução está habilitada. |
| Dest                                          | REAL Resultado da instrução de conversão.   |

## Descrição

A instrução DEG usa este algoritmo:

Source*180/pi = Source*57.29578

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                       | Sinalizadores de status de  operações matemáticas afetados                 |
|---------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580 | Condicional, consulte Sinalizadores  de status de operações  matemáticas . |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact  GuardLogix 5370 e GuardLogix 5570                     | Sim                                                                        |

## Falhas maiores/menores

| Uma falha menor ocorrerá se: Tipo de falha Código de falha    |    |
|---------------------------------------------------------------|----|
| Um transbordamento é detectado 4                              |  4 |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                                                  |
|------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                                                                                                |
| Rung-condition-in é falsa N/A                                                                                    |
| Rung-condition-in é  verdadeira  O controlador converte Source em radianos e  coloca o resultado no Destination. |
| Pós-varredura N/A                                                                                                |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                                   |
|                                    | Tag.EnableIn é falso. EnableOut é eliminado como falso                                                            |
| Tag.EnableIn é  verdadeiro         | EnableOut é definido como verdadeiro. Se o  bloco gerar um transbordamento, EnableOut  será eliminado como falso. |
| Primeira varredura da  instrução   | N/A                                                                                                               |
| Primeira execução da  instrução    | N/A                                                                                                               |
| Pós-varredura N/A                  |                                                                                                                   |
