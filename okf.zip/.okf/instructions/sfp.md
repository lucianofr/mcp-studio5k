---
type: Instruction
title: "Pausar SFC (SFP)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L15377-L15490"
---

## Pausar SFC (SFP)

## Execução

## Diagrama ladder

| Condição/estado A ção realizada      |
|--------------------------------------|
| Pré-varredura N/A                    |
| Rung-condition-in é falsa N/A        |
| Rung-condition-in é  verdadeira  N/A |
| Pós-varredura N/A                    |

## Exemplos

## Diagrama ladder

<!-- image -->

## Consulte também

Instruções de controle do programa na página 620

Sempre falso (AFI) na página 622

Controle de restauração principal (MCR) na página 642

Fim temporário (TND) na página 652

Atributos comuns na página 879

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução SFP pausa uma rotina SFC.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

SFP(SFCRoutineName,TargetState);

## Operandos

## Diagrama ladder

| Operando Tipo               |          | Formato Descrição                                                      |
|-----------------------------|----------|------------------------------------------------------------------------|
| SFCRoutineName ROUTINE nome |          | Rotina SFC a  pausar                                                   |
| TargetState DINT            | imediato | Selecione um:    Executando (ou  digite 0)    Pausado (ou  digite 1) |

## Texto estruturado

| Operando Tipo               |          | Formato Descrição                                                      |
|-----------------------------|----------|------------------------------------------------------------------------|
| SFCRoutineName ROUTINE nome |          | Rotina SFC a  pausar                                                   |
| TargetState DINT            | imediato | Selecione um:    Executando (ou  digite 0)    Pausado (ou  digite 1) |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Descrição

A instrução SFP permite que você pause uma rotina SFC em execução.

## Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

| Uma falha maior ocorrerá se:            | Tipo de  falha    |   Código de  falha  |
|-----------------------------------------|-------------------|---------------------|
| O tipo de rotina não é uma rotina SFC 4 |                   |                  85 |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                                      |
|------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                                                                                    |
| Rung-condition-in é falsa. N/A                                                                       |
| Rung-condition-in é  verdadeira  A instrução pausa ou retoma a execução  da rotina SFC especificada. |
| Pós-varredura N/A                                                                                    |

## Texto estruturado

| Condição/estado A ção realizada                                                      |
|--------------------------------------------------------------------------------------|
| Pré-varredura N/A                                                                    |
| Execução normal  A instrução pausa ou retoma a execução  da rotina SFC especificada. |
| Pós-varredura N/A                                                                    |

## Exemplo

## Diagrama ladder

<!-- image -->

## Consulte também

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912
