---
type: Instruction
title: "Acréscimo de Gravação ASCII (AWA)"
description: "Linhas de handshake ASCII (AHL) na página 792"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L20304-L20605"
---

## Acréscimo de Gravação ASCII (AWA)

Linhas de handshake ASCII (AHL) na página 792

Leitura ASCII (ARD) na página 797

Linhas de leitura ASCII (ARL) na página 801

Acréscimo de Gravação ASCII (AWA) na página 816

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate.

A instrução AWA envia caracteres da matriz da Source a um dispositivo serial e anexa um ou dois caracteres predefinidos.

Dica:

Instruções de Porta serial ASCII (AWT, AWA, ARD, ARL, ABL, ACB, AHL, ACL) não estão disponíveis para controladores que não têm portas seriais.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

AWA(Channel,Source,SerialPortControl);

## Operandos

## Diagrama ladder

| Operando Tipo                | Operando Tipo                   |                 | Formato Descrição                                                                                                                                                 | Notas                                                                                                                                                                                                   |
|------------------------------|---------------------------------|-----------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Channel DINT                 |                                 | imediato  tag   | 0                                                                                                                                                                 |                                                                                                                                                                                                         |
| Source                       | Tipo de string  SINT  INT  DINT | tag             | tag que contém os caracteres a  enviar  Para um tipo de string, digite o  nome da tag  Para uma matriz SINT, INT ou  DINT, digita o primeiro  elemento da matriz. | Se você desejar comparar,  converter ou manipular os  caracteres, digite uma tag de tipo  de string.  Tipos de strings são:  tipo de dado de STRING padrão  qualquer tipo de string novo que  você cria |
| Serial Port  Control         | SERIAL_PORT_ CONTROL            |                 | tag tag que controla a operação                                                                                                                                   |                                                                                                                                                                                                         |
| Serial Port  Control  Length |                                 |                 | DINT imediato número de caracteres a enviar                                                                                                                       | A extensão do controle de porta  serial deve ser menor ou igual ao  tamanho da Source.  Se você desejar ajustar o Serial  Port Control Length igual ao  número de caracteres na Source,  digite 0.      |
| Characters  Sent             |                                 | DINT imediato 0 |                                                                                                                                                                   | Durante a execução, exibe o  número de caracteres que foram  enviados.                                                                                                                                  |

## Texto estruturado

| Operando Tipo                | Operando Tipo                   |                 | Formato Descrição                                                                                                                                                 | Notas                                                                                                                                                                                                   |
|------------------------------|---------------------------------|-----------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Channel DINT                 |                                 | imediato  tag   | 0                                                                                                                                                                 |                                                                                                                                                                                                         |
| Source                       | Tipo de string  SINT  INT  DINT | tag             | tag que contém os caracteres a  enviar  Para um tipo de string, digite o  nome da tag  Para uma matriz SINT, INT ou  DINT, digita o primeiro  elemento da matriz. | Se você desejar comparar,  converter ou manipular os  caracteres, digite uma tag de tipo  de string.  Tipos de strings são:  tipo de dado de STRING padrão  qualquer tipo de string novo que  você cria |
| Serial Port  Control         | SERIAL_PORT_ CONTROL            |                 | tag tag que controla a operação                                                                                                                                   |                                                                                                                                                                                                         |
| Serial Port  Control  Length |                                 |                 | DINT imediato número de caracteres a enviar                                                                                                                       | A extensão do controle de porta  serial deve ser menor ou igual ao  tamanho da Source.  Se você desejar ajustar o Serial  Port Control Length igual ao  número de caracteres na Source,  digite 0.      |
| Characters  Sent             |                                 | DINT imediato 0 |                                                                                                                                                                   | Durante a execução, exibe o  número de caracteres que foram  enviados.                                                                                                                                  |

Você pode especificar os valores de Serial Port Control Length e Characters Sent acessando os membros .LEN e .POS da estrutura SERIAL\_PORT\_CONTROL, em vez de incluir os valores na lista de operandos.

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Estrutura de SERIAL\_PORT\_CONTROL

| Mnemônico Tipo de dados Descrição    |                                                                                                    |
|--------------------------------------|----------------------------------------------------------------------------------------------------|
|                                      | .EN BOOL O bite de habilitação indica que a instrução está habilitada.                             |
|                                      | .EU BOOL O bit de fila indica que a instrução foi digitada na fila ASCII.                          |
| .DN BOOL                             | O bit executado indica que a instrução foi executada, mas está assíncrona à  varredura de lógica.  |
|                                      | .RN BOOL O bit de execução indica que a instrução está sendo executada.                            |
| .EM BOOL                             | O bit vazio indica quando a instrução foi executada, mas está síncrona com a  varredura da lógica. |
|                                      | .ER BOOL O bit de erro indica quando a instrução falha (erros).                                    |
|                                      | .FD BOOL O bit encontrado não se aplica a esta instrução.                                          |
| .LEN DINT                            | A extensão indica o número de caracteres a enviar.                                                 |
| .POS DINT                            | A posição exibe o número de caracteres que foram enviados.                                         |
| .ERROR DINT                          | O erro contém um valor hexadecimal que indica a causa de um erro.                                  |

## Descrição

## A instrução AWA:

-  Envia o número especificado de caracteres (isto é, extensão de controle de portal serial) da tag Source ao dispositivo que está conectado à porta serial do controlador
-  Adiciona ao fim dos caracteres (isto é, anexa) um ou dois caracteres que são definidos na guia Protocolo de Usuário do diálogo Propriedades do Controlador.

Para programar a instrução AWA, siga estas diretrizes:

1. Configure a porta serial do controlador.
2. Isso é uma instrução de transição: No diagrama ladder, alterne EnableIn de eliminado para definido toda vez que a instrução deve ser executada.

| Se seu aplicativo:               | Então:                               |
|----------------------------------|--------------------------------------|
| Usa a instrução ARD ou ARL       | Selecione o modo Usuário             |
| Não usa as instruções ARD ou ARL | Selecione o modo Usuário ou  Sistema |

No texto estruturado, condicione a instrução para que ela apenas execute em uma transição

3. Cada vez que a instrução é executada, você sempre envia o mesmo número de caracteres?

| Se: Então:    |                                                                                                                                                     |
|---------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|
| Sim           | Em Serial Port Control Length, digite o número de caracteres a  enviar.                                                                             |
| Não           | Antes da instrução ser executada, mova o membro LEN da tag de  Source para o membro LEN da tag Serial Port Control. (Consulte o  exemplo 2 abaixo). |

## Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição                        | Ação do Diagrama ladder                                                |
|---------------------------------|------------------------------------------------------------------------|
| Pré-varredura N/A               |                                                                        |
| Rung-condition-in é  falsa      | N/A                                                                    |
| Rung-condition-in é  verdadeira | A instrução é executada.  EnableIn altera de eliminado  para definido. |
| Pós-varredura N/A               |                                                                        |

## Texto estruturado

| Condição          | Ação de texto estruturado                                              |
|-------------------|------------------------------------------------------------------------|
| Pré-varredura N/A |                                                                        |
| Execução normal   | A instrução é executada.  EnableIn altera de eliminado  para definido. |
| Pós-varredura N/A |                                                                        |

## Exemplos

## Exemplo 1

Quando a temperatura exceder o limite alto (temp\_high está ativado), a instrução AWA envia uma mensagem ao terminal MessageView que está conectado à porta serial do controlador.

A mensagem contém cinco caracteres do membro DATA da tag string[1], que é um tipo de string. (O $14 conta como um caractere; ele é hexadecimal para o caractere Ctrl-T.)

A instrução também envia (anexa) os caracteres definidos nas propriedades do controlador. Neste exemplo, a instrução AWA envia um retorno de carro ($0D), que marca o fim da mensagem.

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
IF temp_high THEN temp_high_write.LEN := 5; AWA(o,string[1],temp_high_write); temp_high := 0; END_IF;
```

## Exemplo 2

Quando os alarmes estão ativados, a instrução AWA envia o número especificado de caracteres em alarm\_msg e anexa um caractere ou caracteres de terminação. Como o número de caracteres em alarm\_msg varia, o degrau move primeiro a extensão da string (alarm\_msg.LEN)

para o Serial Port Control Length da instrução AWA (alarm\_write.LEN). Em alarm\_msg, o $14 conta como um caractere; ele é um código hexadecimal para o caractere Ctrl-T.

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
osri_1.InputBit := alarm; OSRI(osri_1); IF (osri_1.OutputBit) THEN alarm_write.LEN := alarm_msg.LEN; AWA(0,alarm_msg,alarm_write); END_IF;
```

## Consulte também

Instruções de porta serial ASCII na página 783

Teste ASCII para Linha do Buffer (ABL) na página 807

Caracteres ASCII no buffer (ACB) na página 785

Buffer limpo ASCII (ACL) na página 788

Linhas de handshake ASCII (AHL) na página 792

Leitura ASCII (ARD) na página 797

Linhas de leitura ASCII (ARL) na página 801

Gravação ASCII (AWT) na página 810

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

## Tipos de string

Armazene caracteres ASCII em tags que usem um tipo de dados de tipo de string para:

-  Usar o tipo de dados STRING padrão, que armazena até 82 caracteres
-  Criar um novo tipo de string que armazene menos ou mais caracteres

Para criar um novo tipo de string, consulte o Manual de Programação LOGIX 5000 Controllers ASCII Strings publicação 1756-PM013 .

Cada tipo de string contém os seguintes membros:

| Nome  (Name)    | Tipo de dados  (Data Type)    | Descrição  (Description)         | Notas                                                                                                                                                                                                                                                                                                                                        |
|-----------------|-------------------------------|----------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                 | LEN DINT                      | número de  caracteres na  string | O LEN atualiza automaticamente a nova contagem de  caracteres sempre que usar:    O Navegador de String para inserir caracteres    Instruções que leem, convertem ou manipulam uma string  O LEN mostra o comprimento da string atual. O membro  DATA pode conter caracteres antigos adicionais, que não  estão incluídos na contagem LEN. |
|                 | DATA Matriz SINT              | Caracteres  ASCII da string      | Para acessar os caracteres da string, insira o nome da tag.  Por exemplo, para acessar os caracteres da tag string_1,  insira string_1.  Cada elemento da matriz DATA contém um caractere.  Crie novos tipos de string que armazenem menos ou mais  caracteres.                                                                              |

Consulte também

Literais de string de caracteres na página 925

## Códigos de erro de ASCII

Se uma instrução de porta serial ASCII falhar ao executar, o membro ERROR de sua estrutura SERIAL\_PORT\_CONTROL conterá um dos códigos de erro hexadecimais a seguir:

| Código  hexadecimal    | Indica que:                                                                                                                                                                                                                                 |
|------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 16#2                   | O modem foi desconectado:                                                                                                                                                                                                                   |
| 16#3                   | O sinal CTS foi perdido durante a comunicação.                                                                                                                                                                                              |
| 16#4                   | A porta serial estava em modo Sistema.                                                                                                                                                                                                      |
| 16#5                   | Não foi possível enviar ou receber instruções porque a configuração do canal foi  encerrada através do menu de configuração de canal.                                                                                                       |
|                        | 16#6 Parâmetros inválidos passaram pelo inversor ASCII.                                                                                                                                                                                     |
| 16#7                   | Não foi possível enviar ou receber instruções porque a configuração do canal foi  encerrada através do menu de configuração de canal.                                                                                                       |
|                        | 16#8 Transmissão já em andamento. Isto causará um erro na instrução em andamento.                                                                                                                                                           |
|                        | 16#9 A comunicação ASCII solicitada não é compatível com a configuração de canal atual.                                                                                                                                                     |
| 16#10                  | Houve uma tentativa de executar uma instrução AHL enquanto o canal estava em modo  Sistema.                                                                                                                                                 |
| 16#A                   | Antes da instrução ser executada, o bit UL foi definido. Isso interrompe a execução da  instrução.                                                                                                                                          |
| 16#B                   | A porta na qual foi solicitado que essa instrução operasse não existe.                                                                                                                                                                      |
| 16#C                   | O controlador mudou do modo de execução para o modo de programa. Isso interrompe a  execução de uma instrução de porta serial ASCII e elimina a fila.                                                                                       |
| 16#D                   | Na guia Protocolo de usuário do diálogo Propriedades do controlador, o tamanho do  buffer ou os parâmetros do modo de eco foram alterados e aplicados. Isso interrompe a  execução de uma instrução de porta serial ASCII e elimina a fila. |
| 16#E                   | Este tipo de instrução foi executada e interrompida ou removida pela instrução ACL..                                                                                                                                                        |
| 16#F                   | A configuração de porta serial mudou do modo Usuário para o modo Sistema Isso  interrompe a execução de uma instrução de porta serial ASCII e elimina a fila.                                                                               |
| 16#51                  | O valor de LEN da tag de string é negativo ou maior que o tamanho de DATA da tag de  string.                                                                                                                                                |
| 16#54                  | A extensão de Serial Port Control deve ser maior que o tamanho do buffer.                                                                                                                                                                   |
| 16#55                  | A extensão de Serial Port Control é negativa ou maior que o tamanho da Source ou do  Destination.                                                                                                                                           |

## Instruções de string ASCII

## Instruções de string ASCII

Use as instruções de string ASCII para modificar e criar strings de caracteres ASCII.

Instruções disponíveis

## Diagrama ladder e Texto estruturado

| FIND    | INSERT    | MID    | CONCAT    | DELET E   |
|---------|-----------|--------|-----------|-----------|

## Bloco de funções

Indisponível

| Se você desejar:                                                                                             | Use esta instrução:    |
|--------------------------------------------------------------------------------------------------------------|------------------------|
| Adicionar caracteres de terminação ou delimitadores a  uma string                                            | CONCAT                 |
| Excluir caracteres de uma string (por exemplo, remova  caracteres de cabeçalho ou de controle de uma string) | DELETE                 |
| Determinar o caractere inicial de uma sub-string FIND                                                        |                        |
| Inserir caracteres em uma string                                                                             | INSERT                 |
| Extrair caracteres de uma string                                                                             | MID                    |

Você também pode usar as instruções a seguir para comparar ou converter caracteres ASCII:

| Se você desejar:                                                             | Use esta instrução:    |
|------------------------------------------------------------------------------|------------------------|
| Comparar uma string a outra string                                           | CMP                    |
| Consultar se os caracteres são iguais a caracteres  específicos              | EQU                    |
| Consultar se os caracteres não são iguais a caracteres  específicos          | NEQ                    |
| Consultar se os caracteres são iguais ou maiores que  caracteres específicos | GEQ                    |
| Consultar se os caracteres são maiores que caracteres  específicos           | GRT                    |
| Consultar se os caracteres são iguais ou menores que  caracteres específicos | LEQ                    |

| Consultar se os caracteres são menores que caracteres  específicos                | LES    |
|-----------------------------------------------------------------------------------|--------|
| Reorganizar os bytes de uma tag INT, DINT ou REAL SWPB                            |        |
| Encontrar uma string em uma matriz de strings. FSC                                |        |
| Converter os caracteres em um valor de SINT, INT,  DINT ou REAL.                  | STOD   |
| Converter os caracteres em um valor de REAL STOR                                  |        |
| Converter um valor de SINT, INT, DINT ou REAL em  uma string de caracteres ASCII. | DTOS   |
| Converter um valor de REAL em uma string de  caracteres ASCII.                    | RTOS   |

## Consulte também

Códigos de erro de ASCII na página 823

Tipos de string na página 822

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução FIND localiza a posição inicial de uma string especificada dentro de outra string.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

FIND(Source,Search,Start,Result);
