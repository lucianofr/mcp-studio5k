---
type: Instruction
title: "NÃO Booliano (BNOT)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L11091-L11234"
---

## NÃO Booliano (BNOT)

## Função FBD

<!-- image -->

## Consulte também

Ou bit a bit exclusivo (XOR) na página 443

Funções FBD na página 425

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução BNOT complementa uma entrada booliana. Para realizar um NÃO bit a bit, consulte "NÃO bit a bit (NOT)". .

## Idiomas disponíveis

## Diagrama ladder

Esta instrução não está disponível no diagrama ladder.

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

<!-- image -->

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Diagrama de bloco da função

## Bloco FBD

| Operando    | Tipo de dados  (Data Type)    | Format    | Descrição  (Description)    |
|-------------|-------------------------------|-----------|-----------------------------|
| BNOT tag    | FBD_BOOLEAN_ NOT              | estrutura | Estrutura de  BNOT          |

## Estrutura de FBD\_BOOLEAN\_NOT

| Membros de  entradas    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                |
|-------------------------|-------------------------------|------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL           |                               | Entrada Habilitar. Se  eliminado, a instrução não é  executada e as saídas não  são atualizadas.  O padrão é definido. |
|                         | In BOOL                       | Entrada para a instrução.  Definida como 1 no primeiro  download                                                       |

| Membros de  saída    | Tipo de dados  (Data Type)    | Descrição (Description)               |
|----------------------|-------------------------------|---------------------------------------|
| EnableOut BOOL       |                               | Indica se instrução está  habilitada. |
|                      | Saída BOOL                    | A saída da instrução.                 |

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operandos de  entrada  (pinos  esquerdos)    | Tipo de dados (Data Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e  GuardLogix 5580    | Descrição  (Description)    |
|----------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
|                                              | In BOOL                                                                                                                                             | Entrada para a  instrução.  |

| Operando de  saída (Pino  direito)    | Tipo de dados (Data Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e  GuardLogix 5580    | Descrição  (Description)    |
|---------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
|                                       | Saída BOOL                                                                                                                                          | A saída da  instrução.      |

Consulte Funções FBD.

## Operação

A instrução BNOT complementa uma entrada booliana.

Out = NOT In

## Afeta sinalizadores de status de operações matemáticas

Não

Falhas maiores/menores

Nenhuma específica a esta instrução.

Execução

Diagrama de bloco da função

## Bloco FBD

| Condição/estado A ção realizada    |                                                                                                                                |
|------------------------------------|--------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                       |
| Tag.EnableIn é falso               | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                       |
| Tag.EnableIn é  verdadeiro         | Os bits EnableIn e EnableOut são  definidos para verdadeiro.  A instrução é executada conforme  descrito na seção de operação. |
| Primeira execução  da instrução    | N/D                                                                                                                            |
| Primeira varredura  da instrução   | N/D                                                                                                                            |
| Pós-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                       |

## Funções FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A ção realizada    |                                                                  |
|------------------------------------|------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                  |
| Varredura normal                   | A instrução é executada conforme  descrito na seção de operação. |
| Primeira execução da  instrução    | N/D                                                              |
| Primeira varredura da  instrução   | N/D                                                              |
| Pós-varredura N/D                  |                                                                  |

## Exemplo

## Diagrama de bloco da função

## Bloco FBD

Neste exemplo, bool\_in1 é copiado em BNOT\_02.In, o resultado do complemento de BNOT\_02.In é colocado em BNOT\_02.Out e BNOT\_02.Out é copiado em value\_result\_not.

| Se bool_in1 for: Então value_result_not será:    |
|--------------------------------------------------|
| 0 1                                              |
| 1 0                                              |

<!-- image -->

## Função FBD

Neste exemplo, o resultado do complemento de bool\_in1 é colocado em value\_result\_not.

<!-- image -->
