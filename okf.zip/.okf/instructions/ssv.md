---
type: Instruction
title: "Obter valor do sistema (GSV) e Definir valor do sistema (SSV)"
description: "As instruções GSV/SSV obtêm e definem dados do sistema do controlador que são armazenados em objetos."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L4382-L4492"
---

## Obter valor do sistema (GSV) e Definir valor do sistema (SSV)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

As instruções GSV/SSV obtêm e definem dados do sistema do controlador que são armazenados em objetos.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essas instruções não estão disponíveis em bloco de funções.

## Texto estruturado

GSV(ClassName,InstanceName,AttributeName,Dest)

SSV(ClassName,InstanceName,AttributeName,Source)

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

## Diagrama ladder e Texto estruturado

| Operando                           | Tipo  (Type)                | Format Des crição (Description)    | Format Des crição (Description)                                           |
|------------------------------------|-----------------------------|------------------------------------|---------------------------------------------------------------------------|
| Nome da classe                     |                             |                                    | nome O nome da classe de objeto                                           |
| Instance name                      |                             | nome                               | O nome do objeto específico quando esse  objeto exigir um nome            |
| Nome do atributo  (Attribute name) |                             |                                    | nome O atributo do objeto  O tipo de dados depende do atributo  escolhido |
| Destination (GSV) SINT             | INT:  DINT  REAL  estrutura |                                    | tag O destino dos dados de atributo                                       |
| Source (SSV) SINT                  | INT:  DINT  REAL  estrutura | tag                                | A tag contém dados que você deseja  copiar para o atributo                |

## Descrição (Description)

As instruções GSV/SSV obtêm e definem dados de status do controlador que são armazenados em objetos. O controlador armazena dados de status em objetos. Não existem arquivos de status como no processador PLC-5.

Quando for verdadeiro, a instrução GSV recupera a informação especificada e a coloca no destino especificado. Quando for verdadeiro, a instrução SSV define o atributo específico com dados da origem.

Ao inserir uma instrução GSV/SSV, o software de programação mostra as classes de objetos válidos, nomes de objetos e nomes de atributos para cada instrução. Para a instrução GSV, você pode obter valores para todos os atributos. Para a instrução SSV, o software mostra apenas os atributos que você pode definir (SSV).

<!-- image -->

ATENÇÃO: Use as instruções SSV com cuidado. Alterações em objetos podem causar operações não esperadas no controlador ou lesões ao pessoal.

Você deve testar e confirmar que as instruções não alteram dados que você não quer alterar.

As instruções SSV gravam e as instruções GSV leem além de um membro para dentro de outros membros de uma tag. Se a tag for muito pequena, as instruções não gravam nem leem os dados. Em vez disso, registram uma falha menor.

## Exemplo 1

<!-- image -->

Member\_A é muito pequeno para o atributo. A instrução GSV grava o último valor em Member\_B.

## Exemplo 2

<!-- image -->

Objetos GSV/SSV definem cada atributo de objeto e seus tipos de dados associados. Por exemplo, o atributo MajorFaultRecord do objeto do Programa requer um tipo de dados DINT[11].

## Afeta sinalizadores de status de operações matemáticas

N°

## Falhas maiores/menores

| Uma falha menor ocorrerá se:                                              |   Tipo de  falha  | Código de  falha    |
|---------------------------------------------------------------------------|-------------------|---------------------|
| Houver um endereço de objeto inválido                                     |                 4 | 5                   |
| O objeto específico não suporta GSV/SSV                                   |                 4 | 6                   |
| Houver um atributo inválido                                               |                 4 | 6                   |
| Não houver informações suficientes fornecidas paras  uma instrução SSV    |                   | 4 6                 |
| O destino GSV não for grande suficiente para receber  os dados requeridos |                   | 4 7                 |

Consulte Atributos comuns para falhas relacionadas ao operando

## Execução

## Diagrama ladder

| Condition A                     | ção realizada            |
|---------------------------------|--------------------------|
| Pré-varredura N/D               |                          |
| Rung-condition-in é  falsa      | N/D                      |
| Rung-condition-in é  verdadeira | A instrução é executada. |
| Pós-varredura N/D               |                          |

## Texto estruturado

| Condition A     | ção realizada                                                           |
|-----------------|-------------------------------------------------------------------------|
| Pré-varredura   | Consulte Prescan na tabela de Diagramas Ladder                          |
| Execução normal | Consulte rung-condition-in é verdadeira na tabela de  Diagramas ladder. |
|                 | Pós-varredura Consulte Pós-varredura na tabela de Diagrama ladder       |

## Exemplo

## Diagramas ladder

<!-- image -->

## Texto estruturado

GSV (Program,THIS,LASTSCANTIME,dest1);

SSV (Program, THIS, MinorFaultRecord, src[0]);
