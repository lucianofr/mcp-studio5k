---
type: Instruction
title: "Caracteres ASCII no buffer (ACB)"
description: "Os bits do operando de controle SerialPort fornecem informações de status:"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L19272-L19362"
---

## Caracteres ASCII no buffer (ACB)

Os bits do operando de controle SerialPort fornecem informações de status:

<!-- image -->

## Consulte também

Tipos de string na página 822

Códigos de erro de ASCII na página 823

Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate.

A instrução ACB conta os caracteres no buffer.

Dica:

Instruções de Porta serial ASCII (AWT, AWA, ARD, ARL, ABL, ACB, AHL, ACL) não estão disponíveis para controladores que não têm portas seriais.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

ACB(Channel,SerialPortControl);

## Operandos

## Diagrama ladder

| Operando Tipo       |                 | Formato Descrição                                                                                                          |
|---------------------|-----------------|----------------------------------------------------------------------------------------------------------------------------|
| Channel DINT        |                 | imediato tag 0                                                                                                             |
| SerialPort  Control |                 | SERIAL_PORT_CONTROL tag tag que controla a operação                                                                        |
| Character  Count    | DINT imediato 0 | Durante a execução, exibe o  número de caracteres no  buffer, incluindo o primeiro  conjunto de caracteres de  terminação. |

## Texto estruturado

| Operando Tipo       |                 | Formato Descrição                                                                                                          |
|---------------------|-----------------|----------------------------------------------------------------------------------------------------------------------------|
| Channel DINT        |                 | imediato tag 0                                                                                                             |
| SerialPort  Control |                 | SERIAL_PORT_CONTROL tag tag que controla a operação                                                                        |
| Character  Count    | DINT imediato 0 | Durante a execução, exibe o  número de caracteres no  buffer, incluindo o primeiro  conjunto de caracteres de  terminação. |

Você pode especificar o valor de Character Count ao acessar o membro .POS da estrutura SERIAL\_PORT\_CONTROL, em vez de ao incluir o valor na lista de operandos.

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Estrutura de SERIAL\_PORT\_CONTROL

| Mnemônico    | Tipo de  dados    | Descrição                                                                                                                |
|--------------|-------------------|--------------------------------------------------------------------------------------------------------------------------|
| .EN          |                   | BOOL O bite de habilitação indica que a instrução está habilitada.                                                       |
| .EU          |                   | BOOL A fila indica que a instrução entrou na fila ASCII.                                                                 |
|              | .DN BOOL          | O bit executado indica quando a instrução foi executada,  mas está assíncrona com a varredura da lógica.                 |
|              | .RN BOOL          | O bit de execução indica que a instrução está sendo  executada.                                                          |
|              | .EM BOOL          | O bit vazio indica quando a instrução foi executada, mas  está síncrona com a varredura da lógica.                       |
| .ER          |                   | BOOL O bit de erro indica quando a instrução falha (erros).                                                              |
|              | .FD BOOL          | O bit encontrado indica que a instrução encontrou um  caractere.                                                         |
|              | .POS DINT         | A posição determina o número de caracteres no buffer, até  e incluindo o primeiro conjunto de caracteres de  terminação. |
| .ERROR DINT  |                   | O erro contém um valor hexadecimal que indica a causa  de um erro.                                                       |

## Descrição

A instrução ACB conta os caracteres no buffer.

Para programar a instrução ACB, siga essas diretrizes:

-  Configure a porta serial do controlador para o modo Usuário.

Isso é uma instrução de transição:

-  No diagrama ladder, alterne EnableIn de eliminado para definido toda vez que a instrução deve ser executada.
-  No texto estruturado, condicione a instrução para que ela apenas execute em uma transição

## Sinalizadores de status de operações matemáticas

Não

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.
