---
type: Instruction
title: "Lógica e aritmética de arquivo (FAL)"
description: "A instrução FAL realiza operações de copiar, aritmética, lógica e função em dados armazenados em uma matriz."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L12249-L12508"
---

## Lógica e aritmética de arquivo (FAL)

## Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução FAL realiza operações de copiar, aritmética, lógica e função em dados armazenados em uma matriz. Quando rung-condition-in da instrução FAL realizar a transição de falso para verdadeiro, a expressão informada será executada no modo de iteração especificado.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados.

## Diagrama ladder

| Operando  Tipo de  dados  (Data Type)    |              | Format Des crição (Description)                                                                                                  |
|------------------------------------------|--------------|----------------------------------------------------------------------------------------------------------------------------------|
|                                          |              | Controle CONTROL Tag Estrutura de controle da operação                                                                           |
| Comprimento  (Length)                    | DINT Somente | Número de elementos na matriz a  serem manipulados                                                                               |
|                                          |              | Somente DINT Somente Deslocamento na matriz  O valor inicial costuma ser 0                                                       |
|                                          |              | Mode DINT Somente Mostra como distribuir a operação Selecionar INC ou ALL, ou inserir  um número dentro da faixa 1 -  2147483647 |
| Expression SINT  INT:  DINT  REAL        | Somente  Tag | Uma expressão consistindo em  tags e/ou valores imediatos  separados pelos operadores.                                           |
| Destination SINT  INT:  DINT  REAL       | Tag          | O valor da Expressão será  armazenado no destino.                                                                                |

## Estrutura de CONTROL

| Mnemônico  Tipo de  dados  (Data Type)   | Descrição (Description)                                                                                                                                                                                          |
|------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| .EN BOOL                                 | O bite de habilitação indica que a instrução FAL  está habilitada.                                                                                                                                               |
| .DN BOOL                                 | O bit executado é definido quando a instrução  operou no último elemento (.POS = .LEN).                                                                                                                          |
| .ER BOOL                                 | Quando ocorrer um transbordamento, ambas as  plataformas definirão .ER e deixarão de  executar a instrução.  Os seguintes controladores gerarão um  transbordamento:    CompactLogix 5370    ControlLogix 5570 |
| .LEN DINT                                | O comprimento especifica o número de  elementos na matriz em que a instrução FAL  opera.                                                                                                                         |
| .POS DINT                                | A posição contém a posição do elemento atual  que está sendo acessado pela instrução.                                                                                                                            |

Consulte a seção Sintaxe de texto estruturado[2] para obter mais informações sobre a sintaxe de expressões no texto estruturado.

O valor da expressão é armazenado na tag de destino especificada. Quando ocorrer um transbordamento, ele definirá o bit ER e interromperá a execução. Quando FAL concluir todas as iterações configuradas, o bit .DN será definido.

## Selecionar modo de operação

Para instruções FAL, o modo diz ao controlador como distribuir a operação da matriz.

| Se:                                                                                                                                        | Selecione este modo:    |
|--------------------------------------------------------------------------------------------------------------------------------------------|-------------------------|
| Operando em todos os elementos  especificados em uma matriz antes de  continuar para a instrução seguinte.                                 | Todos (All)             |
| Distribuindo operação da matriz em diversas  varreduras.  Inserir o número de elementos para operação  segundo a varredura (1-2147483647). | Numérico                |
| Manipulando um elemento da matriz cada vez  que EnableIn passa de falso para verdadeiro.                                                   | Incremental             |

## Modo Tudo

No Modo Tudo, a instrução opera em todos os elementos especificados da matriz antes de continuar para a instrução seguinte. A operação começa quando a instrução EnableIn passa de falso para verdadeiro. O valor de posição (.POS) na estrutura de controle aponta para o elemento na matriz que a instrução está usando no momento. A operação é interrompida quando o valor de .POS é igual ou superior ao valor de .LEN, e quando ocorre um transbordamento na expressão e o bit .ER está definido como verdadeiro.

<!-- image -->

O seguinte diagrama de tempo mostra a relação entre bits de status e a operação de instrução. Quando a execução da instrução é concluída, o bit .DN é verdadeiro. O bit .DN, o bit .EN e o valor de .POS são eliminados quando EnableIn é falso. Somente então outra execução da instrução pode ser disparada por uma transição de falso para verdadeiro de EnableIn.

<!-- image -->

## Modo Numérico

O modo Numérico distribui a operação de matriz em diversas varreduras. Use modo ao trabalhar com dados não urgentes ou grandes quantidades de dados. Insira o número de elementos para operar em cada varredura, o que mantém o tempo de varredura mais curto.

A execução é disparada quando EnableIn passa de falso para verdadeiro. Depois de disparada, a instrução é executada sempre que passa por varredura para o número de varreduras necessárias para concluir a operação em toda a matriz. Depois de disparado, EnableIn pode mudar repetidamente sem interromper a execução da instrução.

<!-- image -->

Evite usar os resultados em uma instrução de arquivo que opera no modo numérico até o bit .DN ser definido.

O seguinte diagrama de tempo mostra a relação entre bits de status e a operação de instrução. Quando a execução da instrução é concluída, o bit .DN é definido.

<!-- image -->

Se EnableIn for verdadeiro à conclusão, os bits .EN e .DN serão verdadeiro até EnableIn passar a ser falso. Quando EnableIn passa a ser falso, esses bits são eliminados e o valor .POS é eliminado.

Se EnableIn for falso à conclusão, o bit .EN será eliminado imediatamente. Uma varredura depois de o bit .EN ser eliminado, o bit .DN e o valor .POS são eliminados.

## Modo Incremental

O modo incremental manipula um elemento da matriz sempre que EnableIn da instrução passa de falso para verdadeiro.

<!-- image -->

O seguinte diagrama de tempo mostra a relação entre bits de status e a operação de instrução. A execução ocorre somente em uma varredura em que EnableIn passa de falso para verdadeiro. Sempre que isso ocorre, somente um elemento da matriz é manipulado. Se EnableIn permanecer verdadeiro por mais de uma varredura, a instrução será executada durante a primeira varredura

<!-- image -->

O bit .EN é definido quando EnableIn é verdadeiro. O bit .DN é definido quando o último elemento na matriz tiver sido manipulado. Quando o último elemento tiver sido manipulado e EnableIn passar para falso, o bit .EN, o bit .DN e o valor .POS serão eliminados.

A diferença entre o modo incremental e o modo numérico a uma taxa de um elemento por varredura é:

Modo numérico com qualquer número de elementos por varredura requer somente uma transição de falso para verdadeiro de EnableIn para iniciar a execução. A instrução continua a executar o número especificado de elementos a cada varredura até a conclusão, não importa o estado de EnableIn.

O modo incremental exige que EnableIn mude de falso para verdadeiro para manipular um elemento na matriz.

## Expressões de formato

Para cada operador que você usa em uma expressão, é preciso fornecer um ou dois operandos (tags ou valores imediatos). Use a tabela a seguir para formatar operadores e operandos dentro de uma expressão.

| Para operadores  que operam em:    | Use este formato: Exemplo               |                                                            |
|------------------------------------|-----------------------------------------|------------------------------------------------------------|
|                                    | Um operando operador(operando) ABS(tag) |                                                            |
| Dois operandos                     | operand_a operador  operand_b           | tag_b + 5  tag_c AND tag_d  (tag_e**2) MOD (tag_f / tag_g) |

## Determine a ordem da operação

As operações que você grava na expressão são executadas pela instrução na ordem prescrita, não necessariamente na ordem de gravação. Você pode substituir a ordem de operação agrupando termos dentro dos parênteses, forçando a instrução a executar uma operação dentro dos parênteses antes das outras operações.

As operações de igual ordem são realizadas da esquerda para a direita.

| Ordem Op eração                                                              |
|------------------------------------------------------------------------------|
| 1 ( )                                                                        |
| 2  ABS, ACS, ASN, ATN, COS, DEG, FRD, LN,  LOG, RAD, SIN, SQR, TAN, TOD, TRN |
| 3 **                                                                         |
| 4 - (negate), NOT                                                            |
| *, /, MOD                                                                    |
| 6 - (subtract), +                                                            |
| 7 AND                                                                        |
| 8 XOR                                                                        |
| 9 OR                                                                         |

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                        | Afeta sinalizadores de status  de operações matemáticas    |
|----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e GuardLogix  5580 | Não                                                        |
| Controladores CompactLogix  5370, ControlLogix 5570,  Compact GuardLogix 5370 e  GuardLogix 5570                     | Sim                                                        |

## Falhas maiores/menores

| Uma falha maior ocorrerá se:    |   Tipo de  falha  |   Código de  falha  |
|---------------------------------|-------------------|---------------------|
| .POS <0 ou .LEN <0              |                 4 |                  21 |

Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                              |
|------------------------------------|--------------------------------------------------------------|
| Pré-varredura N/D                  |                                                              |
| Rung-condition-in é falsa          | Consulte o fluxograma FAL (Rung-condition-out é  Falsa)      |
| Rung-condition-in é  verdadeira    | Consulte o fluxograma FAL (Rung-condition-out é  Verdadeira) |
| Pós-varredura N/D                  |                                                              |

## Fluxograma FAL (Rung-condition-out é Falsa)

<!-- image -->

## Fluxograma FAL (Rung-condition-out é Verdadeira)

<!-- image -->

## Fluxograma FAL (Modo Tudo)

<!-- image -->

## Fluxograma FAL (Modo Numérico)

<!-- image -->

## Fluxograma FAL (Modo Incremental)

<!-- image -->

## Exemplos

## Exemplo 1

Matriz a matriz.

## Diagrama ladder

<!-- image -->

Quando habilitada, a instrução FAL copia cada elemento de array\_2 para a mesma posição em array\_1.

<!-- image -->

## Exemplo 2

Cópia do elemento à matriz.

## Diagrama ladder

<!-- image -->

Quando habilitada, a instrução FAL copia value\_1 para as 10 primeiras posições da segunda dimensão de array\_2.

<!-- image -->

## Exemplo 3:

Copia da matriz para o elemento.

<!-- image -->

Cada vez que a instrução FAL é habilitada, ela copia o valor atual de array\_1 para value\_1. A instrução FAL usa o modo incremental, de modo que somente um valor de matriz é copiado cada vez que a instrução é habilitada. Na próxima vez que a instrução for habilitada, a instrução substitui value\_1 pelo valor seguinte em array\_1.

<!-- image -->

## Exemplo 4:

Operação aritmética: matriz / matriz a matriz Quando habilitada, a instrução FAL divide o valor na posição atual de array\_2 pelo valor na posição atual de array\_3 e armazena o resultado na posição atual de array\_1.

<!-- image -->

<!-- image -->

## Exemplo 5:

Operação aritmética: matriz / matriz a matriz

<!-- image -->

Quando habilitada, a instrução FAL adiciona value\_1 e value\_2 e armazena o resultado na posição atual de array\_1.

<!-- image -->

## Exemplo 6:

Operação aritmética: matriz + elemento a matriz Quando habilitada, a instrução FAL adiciona o valor na posição atual em array\_1 ao value\_1 e armazena o resultado na posição atual em array\_3. A instrução deve ser executada 10 vezes para toda a array\_1 e a array\_3 para ser manipulada.

<!-- image -->

Exemplo 7:

<!-- image -->

Operação aritmética: (elemento + matriz) para elemento

<!-- image -->

Cada vez que a instrução FAL é habilitada, ela adiciona value\_1 ao valor atual de array\_1 e armazena o resultado em value\_2. A instrução FAL usa o modo incremental, de modo que somente um valor de matriz é adicionado a value\_1 cada vez que a instrução é habilitada. Na próxima vez que a instrução for habilitada, ela substituirá value\_2.

<!-- image -->
