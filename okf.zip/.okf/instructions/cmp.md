---
type: Instruction
title: "Comparar (CMP)"
description: "Comparar valores de tipos de dados diferentes, como ponto flutuante e inteiro."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L6548-L6682"
---

## Comparar (CMP)

Comparar valores de tipos de dados diferentes, como ponto flutuante e inteiro.

Os tipos de dados em negrito indicam ótimos tipos de dados. Uma instrução é executada o mais rápido e com a menor quantidade de memória possível se todos os parâmetros da instrução usarem o mesmo tipo de dados otimizado, geralmente DINT ou REAL.

## Consulte também

## Instruções de cálculo/matemáticas na página 369

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

Defina a expressão CMP usando operadores, tags e valores imediados. Use parênteses ( ) para definir as seções com expressões mais complexas.

A vantagem da instrução CMP é que ela permite expressões complexas em uma instrução.

Ao avaliar a expressão, todos os operandos não REAL serão convertidos em REAL antes dos cálculos serem realizados se qualquer uma das condições for verdadeira.

-  Qualquer operando na expressão é REAL.
-  A expressão contém SIN, COS, TAN, ASN, ACS, ATN, LN, LOG, DEG ou RAD.

Há regras para os operadores permitidos nas aplicações de segurança. Consulte Operadores válidos.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Esses são os operandos para a instrução CMP.

## Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

O seguinte é o operando do Diagrama ladder.

| Operando Tipo de dados Formato Descrição         |               |                                                                                         |
|--------------------------------------------------|---------------|-----------------------------------------------------------------------------------------|
| Expression SINT  INT  DINT  REAL  Tipo de string | imediato  tag | Uma expressão  consistindo de tags e/ou  valores imediatos,  separada pelos  operadores |

## Expressões de formatação

Para cada operador usado em uma expressão, um ou dois operandos (tags ou valores imediados) devem ser fornecidos. Use a tabela a seguir para formatar operadores e operandos dentro de uma expressão.

| Para operadores  que operam em:    | Use este formato: Exemplo               |                                                            |
|------------------------------------|-----------------------------------------|------------------------------------------------------------|
|                                    | Um operando operador(operando) ABS(tag) |                                                            |
| Dois operandos                     | operand_a operador  operand_b           | tag_b + 5  tag_c AND tag_d  (tag_e**2) MOD (tag_f / tag_g) |

## Determine a ordem da operação

As operações na expressão são realizadas pela instrução em uma ordem prescrita, não necessariamente na ordem em que aparecem. A ordem de operação pode ser especificada agrupando termos dentro dos parênteses, forçando a instrução a realizar uma operação dentro dos parênteses antes das suas operações.

As operações de igual ordem são realizadas da esquerda para a direita.

| Ordem Op eração                                                              |
|------------------------------------------------------------------------------|
| 1 ( )                                                                        |
| 2  ABS, ACS, ASN, ATN, COS, DEG, FRD, LN,  LOG, RAD, SIN, SQR, TAN, TOD, TRN |
| 3 **                                                                         |
| 4 - (negate), NOT                                                            |
| 5 *, /, MOD                                                                  |
| 6 - (subtract), +                                                            |
| 7 AND                                                                        |
| 8 XOR                                                                        |
| 9 OR                                                                         |
| 10 <, <=, >, >=, =, <>                                                       |

## Usar strings em uma expressão

Para usar strings dos caracteres ASCII em uma expressão, siga estas diretrizes:

-  Uma expressão pode comparar duas tags de string
-  Os caracteres ASCII não podem ser inseridos diretamente na expressão.
-  Os operadores a seguir são permitidos:
-  As strings serão iguais se seus caracteres combinarem.
-  Os caracteres ASCII diferenciam maiúsculas e minúsculas.. A letra maiúscula "A" ($41) não é igual à letra minúscula "a" ($61).
-  Os valores hexadecimais dos caracteres determinam se uma string é menor do que ou maior do que outra string.

| Operador Des crição    |
|------------------------|
| = Igual                |
| < Menor que            |
| <=  Menor que ou igual |
| > Maior que            |
| >=  Maior que ou igual |
| <> Não igual           |

-  Quando as duas strings forem classificadas como em uma lista telefônica, a ordem das strings determina qual é maior.

<!-- image -->

Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                        | Afeta sinalizadores de status de  operações matemáticas                                                                                                                                                        |
|----------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e  GuardLogix 5580 | Não                                                                                                                                                                                                            |
| Controladores CompactLogix  5370, ControlLogix 5570,  Compact GuardLogix 5370 e  GuardLogix 5570                     | A instrução CMP afeta os sinalizadores  de status de operações matemáticas se a  expressão contiver um operador (por  exemplo,, +,  − , *, /) que afeta os  sinalizadores de status de operações  matemáticas. |

Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A               | ção realizada                                                                                                                           |
|---------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A.              |                                                                                                                                         |
| Rung-condition-in é falsa       | Definir Rung-condition-out como  Rung-condition-in                                                                                      |
| Rung-condition-in é  verdadeira | Definir Rung-condition-out como  Rung-condition-in  se a expressão é avaliada como falsa  Rung-condition-out será eliminada para  falso |
| Pós-varredura N/A.              |                                                                                                                                         |
