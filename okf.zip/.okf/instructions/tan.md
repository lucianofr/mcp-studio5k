---
type: Instruction
title: "Tangente (TAN)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L17974-L18165"
---

## Tangente (TAN)

## Texto estruturado

| Condição/estado A ção realizada                                                               |
|-----------------------------------------------------------------------------------------------|
| Pré-varredura N/A.                                                                            |
| Execução normal  O controlador calcula o seno da Source e  coloca o resultado no Destination. |
| Pós-varredura N/D                                                                             |

## Exemplo

## Diagrama ladder

<!-- image -->

## Texto estruturado

result := SIN(value);

## Consulte também

Instruções de trigonometria na página 724

Atributos comuns na página 879

Sinalizadores de status de operações matemáticas na página 879

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução TAN pega a tangente do valor de Source (em radianos) e armazena o resultado no Destination.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

dest := TAN(source);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

## Diagrama ladder

|                                   | Operando Tipo Formato Descrição    |                                 |
|-----------------------------------|------------------------------------|---------------------------------|
| Source SINT  INT  DINT  REAL      | Imediato  tag                      | encontre o cosseno desse  valor |
| Destination SINT  INT  DINT  REAL |                                    | tag tag a armazenar o resultado |

## Texto estruturado

|                              | Operando Tipo Formato Descrição    |                                  |
|------------------------------|------------------------------------|----------------------------------|
| Source SINT  INT  DINT  REAL | imediato  tag                      | encontra a tangente desse  valor |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Bloco de funções

| Operando Tipo    |                                     | Formato Descrição    |
|------------------|-------------------------------------|----------------------|
|                  | TAN tag FBD_MATH_ADVANCED Estrutura | Estrutura de  TAN    |

## Estrutura de FBD\_MATH\_ADVANCED

| Parâmetro de  entrada    | Tipo de dados Descrição                                                                                                 |
|--------------------------|-------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            | Entrada Habilitar. Se eliminado, a  instrução não será executada, e as  saídas não são atualizadas.  Padrão é definido. |
|                          | Source REAL Entrada para a instrução matemática.                                                                        |

| Parâmetro de  saída    | Tipo de dados Descrição                             |
|------------------------|-----------------------------------------------------|
|                        | EnableOut BOOL Indica se instrução está habilitada. |
| Dest                   | REAL Resultado da instrução matemática.             |

## Descrição

A instrução TAN pega a tangente do valor de Source (em radianos) e armazena o resultado no Destination.

A instrução calcula a tangente da Source e retorna o resultado REAL.

É possível usar TAN como um operador em expressões ladder e como um operador em declarações de Texto estruturado.

A instrução oferece maior precisão com relação a controladores legados para melhores resultados.

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                       | Afeta o sinalizador de status  de operações matemáticas                   |
|---------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580 | Condicional, consulte  Sinalizadores de status de  operações matemáticas. |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact  GuardLogix 5370 e GuardLogix  5570                    | Sim                                                                       |

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                                                   |
|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                                                                                                 |
| Rung-condition-in é falsa N/A                                                                                     |
| Rung-condition-in é  verdadeira  O controlador calcula a tangente da Source  e coloca o resultado no Destination. |
| Pós-varredura N/A                                                                                                 |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                                   |
|                                    | Tag.EnableIn é falso. EnableOut é eliminado como falso                                                            |
| Tag.EnableIn é  verdadeiro         | EnableOut é definido como verdadeiro. Se o  bloco gerar um transbordamento, EnableOut  será eliminado como falso. |
| Primeira varredura da  instrução   | N/A                                                                                                               |
| Primeira execução da  instrução    | N/A                                                                                                               |
| Pós-varredura N/A                  |                                                                                                                   |

## Texto estruturado

| Condição/estado A ção realizada                                                                   |
|---------------------------------------------------------------------------------------------------|
| Pré-varredura N/A.                                                                                |
| Execução normal  O controlador calcula a tangente da Source e  coloca o resultado no Destination. |
| Pós-varredura N/A                                                                                 |

## Exemplo

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

result := TAN(value);

## Consulte também

Instruções de trigonometria na página 724

Atributos comuns na página 879

Sinalizadores de status de operações matemáticas na página 879

Sintaxe de texto estruturado na página 912

## Instruções matemáticas avançadas

## Matemática avançada

As instruções matemáticas avançadas incluem estas instruções:

Diagrama ladder e Bloco de funções

<!-- image -->

## Texto estruturado

<!-- image -->

| Se você desejar:                             | Use esta instrução:    |
|----------------------------------------------|------------------------|
| Obter o logaritmo natural de  um valor       | LN                     |
| Obter o logaritmo de base 10  de um valor    | LOG                    |
| Aumentar um valor à  potência de outro valor | XPY                    |

Misturar tipos de dados pode provocar erros de precisão e de arredondamento e fazer com que a instrução leve mais tempo para ser executada. Verifique o bit S:V para ver se o resultado foi truncado.

Os tipos de dados em negrito indicam os tipos de dados ideais. Uma instrução é executada mais rápido e requer menos memória se todos os operandos da instrução usarem o mesmo tipo de dados otimizado, geralmente DINT ou REAL.

Uma instrução matemática avançada é executada uma vez sempre que a instrução passa por varredura, desde que rung-condition-in seja verdadeira. Se você desejar que a instrução seja avaliada apenas uma vez, use uma instrução ONS para disparar a instrução matemática.

## Consulte também

Instruções de matriz (Arquivo)/Instruções diversas na página 493

Instruções de conversão ASCII na página 845
