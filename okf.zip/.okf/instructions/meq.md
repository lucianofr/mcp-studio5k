---
type: Instruction
title: "Mask igual a (MEQ)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L7779-L7999"
---

## Mask igual a (MEQ)

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

## Bloco FBD

<!-- image -->

Função FBD

<!-- image -->

## Consulte também

Instruções de comparação na página 293

Conversões de dados na página 883

Índice por meio de matrizes na página 893

Valores imediatos na página 882

Funções FBD na página 425

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução MEQ passa os valores de Source e Compare através de uma máscara e compara os resultados.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

Função FBD

<!-- image -->

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

| Operando  Tipo de dados  (Data Type)  Controladores  CompactLogix  5370,  ControlLogix  5570, Compact  GuardLogix  5370 e  GuardLogix  5570    | Tipo de dados  (Data Type)  Controladores  CompactLogix  5380,  CompactLogix  5480,  ControlLogix  5580, Compact  GuardLogix 5380  e GuardLogix  5580    | Format         | Descrição  (Description)              |
|------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|---------------------------------------|
| Origem SINT  INT  DINT                                                                                                                         | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT                                                                                                         | immediate  tag | Valor para  testar contra  Compare.   |
| Máscara SINT  INT  DINT                                                                                                                        | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT                                                                                                         | immediate  tag | Quais bits  para bloquear  ou passar. |
| Compare SINT  INT  DINT                                                                                                                        | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT                                                                                                         | immediate  tag | Valor para  testar contra  Source.    |

## Diagrama de bloco da função

## Bloco FBD

| Operando    | Tipo de dados (Data  Type)           | Format    | Descrição  (Description)    |
|-------------|--------------------------------------|-----------|-----------------------------|
|             | MEQ FBD_MASK_EQUAL tag Estrutura MEQ |           |                             |

## Estrutura de FBD\_MASK\_EQUAL

Função FBD

| Membros  de entradas Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                 |
|----------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL                                      | Entrada Habilitar. Se falso, a  instrução não será  executada e as saídas não  serão atualizadas.  Padrão é verdadeiro. |
| Origem DINT                                        | Valor para testar contra  Compare.                                                                                      |
| Máscara DINT                                       | Define quais bits para  bloquear, como uma  máscara.                                                                    |
| Compare DINT                                       | Valor para testar contra  Source.                                                                                       |

| Membros  de saída    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                        |
|----------------------|-------------------------------|----------------------------------------------------------------------------------------------------------------|
| EnableOut BOOL       |                               | Indica se a instrução foi  executada sem falhas ao ser  habilitada.                                            |
|                      | Dest BOOL                     | Definido como verdadeiro  quando o resultado é  verdadeiro. Eliminado como  falso quando o resultado é  falso. |

Dica: A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operandos de  entrada (pinos  esquerdos)    | Tipo de dados (Data Type)  Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e  GuardLogix 5580    | Descrição  (Description)           |
|---------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------|
| Origem SINT                                 | INT  DINT  LINT  USINT  UINT  UDINT  ULINT                                                                                                         | Valor para testar  contra Compare. |

| Máscara SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT                        | Quais bits para  bloquear ou  passar.                                           |
|---------------------------------------------------------------------------------|---------------------------------------------------------------------------------|
| Compare SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT                        | Valor para testar  contra Source.                                               |
| Uma tag SINT ou INT é convertido em um valor  DINT pelo preenchimento de zeros. | Uma tag SINT ou INT é convertido em um valor  DINT pelo preenchimento de zeros. |

| Operando de  saída (Pino  direito)    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                       |
|---------------------------------------|-------------------------------|---------------------------------------------------------------------------------------------------------------|
|                                       | Dest BOOL                     | Definido como verdadeiro quando  o resultado é verdadeiro. Eliminado  como falso quando o resultado é  falso. |

Consulte Funções FBD.

## Operação

Um "1" na máscara significa que o bit de dados passa. Um "0" na máscara significa que o bit de dados será bloqueado. Tipicamente, os valores de Source, Mask e Compare são do mesmo tipo de dados.

Se usar o tipo de dados SINT ou INT, as instruções preenchem os bits superiores destes valores com 0s de forma a ter o mesmo tamanho que o tipo do dados DINT.

## Insira um valor imediato de máscara

Ao inserir uma máscara, o software de programação predefine como valores decimais. Para inserir uma máscara usando outro formato, preceda o valor com o prefixo correto.

| Prefixo Des crição (Description)    |
|-------------------------------------|
| 16# hexadecimal, como 16#0F0F       |
| 8# octal, como 8#16                 |
| 2# binário, como 2#00110011         |

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                                        |
|------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                        |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como  Rung-condition-in.                                                                                                                    |
| Rung-condition-in é  verdadeira    | Consulte Fluxograma MEQ  (Verdadeiro).  Se a saída for verdadeira  Defina Rung-condition-out como  verdadeira  Caso contrário  Eliminar Rung-condition-out para  falso |
| Pós-varredura N/D                  |                                                                                                                                                                        |

Diagrama de bloco da função

Bloco FBD

| Condição/estado A ção realizada    |                                                                                                                                                                            |
|------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                            |
| EnableIn é falso                   | Defina EnableOut como  EnableIn.                                                                                                                                           |
| EnableIn é verdadeiro              | Defina EnableOut como  EnableIn.  Consulte Fluxograma MEQ  (Verdadeiro) .  Se a saída for verdadeira  Defina Dest como verdadeiro  Caso contrário  Elimina Dest como falso |
| Primeira execução da  instrução    | N/D                                                                                                                                                                        |
| Primeira varredura da  instrução   | N/D                                                                                                                                                                        |
| Pós-varredura N/D                  |                                                                                                                                                                            |

## Função FBD

Dica: A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A ção realizada    |                                                                                                                                          |
|------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                          |
| Varredura normal                   | Consulte Fluxograma MEQ  (Verdadeiro) .  Se a saída for verdadeira  Defina Dest como verdadeiro  Caso contrário  Elimina Dest como falso |
| Primeira execução da  instrução    | N/D                                                                                                                                      |
| Primeira varredura da  instrução   | N/D                                                                                                                                      |
| Pós-varredura N/D                  |                                                                                                                                          |

## Fluxograma MEQ (verdadeiro)

<!-- image -->

## Exemplos

## Exemplo 1

Se o value\_1 com máscara for igual ao value\_2 com máscara, defina light\_1 como verdadeiro. Se o value\_1 com máscara não for igual ao value\_2 com máscara, elimina light\_1 para falso.

Este exemplo mostra que os valores com máscara são iguais. Um 0 na máscara impede que a instrução compare o bit (indicado por um x no exemplo).

## Diagrama ladder

Diagrama de bloco da função

<!-- image -->

## Bloco FBD

Exemplo 2

<!-- image -->

Se o value\_1 com máscara for igual ao value\_2 com máscara, defina light\_1 como verdadeiro. Se o value\_1 com máscara não for igual ao value\_2 com máscara, elimina light\_1 para falso.

Este exemplo mostra que os valores com máscara não são iguais. Um 0 na máscara impede que a instrução compare o bit (indicado por um x no exemplo).

## Diagrama ladder

Diagrama de bloco da função

<!-- image -->

## Bloco FBD

<!-- image -->

## Consulte também

Índice por meio de matrizes na página 893

Valores imediatos na página 882

Conversões de dados na página 883

O que é preenchimento de zeros? na página 367

Funções FBD na página 425
