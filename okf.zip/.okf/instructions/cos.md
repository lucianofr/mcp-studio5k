---
type: Instruction
title: "Cosseno (COS)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L17708-L17837"
---

## Cosseno (COS)

## Texto estruturado

| Condição/estado A ção realizada                                                                        |
|--------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                                                                                      |
| Execução normal  O controlador calcula o arco tangente da  Source e coloca o resultado no Destination. |
| Pós-varredura N/A                                                                                      |

## Exemplo

## Diagrama ladder

<!-- image -->

## Texto estruturado

result := ATAN(value);.

## Consulte também

Instruções de trigonometria na página 724

Atributos comuns na página 879

Conversões de dados na página 883

Sinalizadores de status de operações matemáticas na página 879

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução COS pega o cosseno do valor da Source (em radianos) e armazena o resultado no Destination.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

dest := COS(source);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

## Diagrama ladder

|                                   | Operando Tipo Formato Descrição    |                                 |
|-----------------------------------|------------------------------------|---------------------------------|
| Source SINT  INT  DINT  REAL      | Imediato  tag                      | encontre o cosseno desse  valor |
| Destination SINT  INT  DINT  REAL |                                    | tag tag a armazenar o resultado |

## Texto estruturado

|                              | Operando Tipo Formato Descrição    |                                 |
|------------------------------|------------------------------------|---------------------------------|
| Source SINT  INT  DINT  REAL | imediato  tag                      | encontre o cosseno desse  valor |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Bloco de funções

| Operando Tipo    |                                     | Formato Descrição    |
|------------------|-------------------------------------|----------------------|
|                  | COS tag FBD_MATH_ADVANCED Estrutura | Estrutura de  COS    |

## Estrutura de FBD\_MATH\_ADVANCED

| Parâmetro de  entrada    | Tipo de dados Descrição                                                                                                |
|--------------------------|------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            | Entrada Habilitar. Se eliminado, a instrução não  será executada, e as saídas não são atualizadas.  Padrão é definido. |
|                          | Source REAL Entrada para a instrução matemática.                                                                       |

| Parâmetro de  saída    | Tipo de dados Descrição                             |
|------------------------|-----------------------------------------------------|
|                        | EnableOut BOOL Indica se instrução está habilitada. |
| Dest                   | REAL Resultado da instrução matemática.             |

## Descrição

A instrução COS calcula o cosseno do valor da Source (em radianos) e armazena o resultado no Destination.

A instrução calcula o cosseno da Source e retorna o resultado REAL. O valor resultante é sempre maior ou igual a -1 e menor ou igual a 1.

Você pode usar COS como um operador em expressões ladder e como um operador em declarações de Texto estruturado.

A instrução oferece maior precisão com relação a controladores legados para melhores resultados.

## Afeta sinalizadores de status de operações matemáticas

| controladores                                                                                                       | Afeta o sinalizador de status  de operações matemáticas                   |
|---------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580 | Condicional, consulte  Sinalizadores de status de  operações matemáticas. |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact  GuardLogix 5370 e GuardLogix  5570                    | Sim                                                                       |

## Falhas maiores/menores

Nenhum. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                                                  |
|------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A.                                                                                               |
| Rung-condition-in é falsa N/A                                                                                    |
| Rung-condition-in é  verdadeira  O controlador calcula o cosseno da Source e  coloca o resultado no Destination. |
| Pós-varredura N/A                                                                                                |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                                   |
|                                    | Tag.EnableIn é falso. EnableOut é eliminado como falso                                                            |
| Tag.EnableIn é  verdadeiro         | EnableOut é definido como verdadeiro. Se o  bloco gerar um transbordamento, EnableOut  será eliminado como falso. |
| Primeira varredura da  instrução   | N/A                                                                                                               |
| Primeira execução da  instrução    | N/A                                                                                                               |
| Pós-varredura N/A                  |                                                                                                                   |
