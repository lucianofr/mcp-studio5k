---
type: Instruction
title: "Não bit a bit (NOT)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L10498-L10632"
---

## Não bit a bit (NOT)

## Bloco de funções

<!-- image -->

## Texto estruturado

value\_result\_XOR := value\_1 XOR value\_2;

## Consulte também

Sintaxe de texto estruturado na página 912

Indexação por meio de matrizes na página 893

Sinalizadores de status de operações matemáticas na página 879

Instruções de movimento na página 429

Conversões de dados na página 883

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução NOT realiza uma inversão bit a bit da Source e coloca o resultado em Dest.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

Dica:

Use NOT como um operador em uma expressão para obter o mesmo resultado. Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões e atribuições no texto estruturado.

## Operandos

## Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

| Operando  Tipo de dados  (Data Type)    | Format         | Descrição  (Description)                                                                                                      |
|-----------------------------------------|----------------|-------------------------------------------------------------------------------------------------------------------------------|
| Origem SINT  INT:  DINT  REAL           | immediate  tag | Valor para NOT  Dica: Se o tipo for REAL  valor de entrada será  convertido em DINT (o  que pode causar um  transbordamento). |
| Dest SINT  INT:  DINT  REAL             | tag            | Tag a armazenar o  resultado da instrução.  Dica: Se o tipo for  REAL, o valor DINT  resultante será  convertido em REAL.     |

Dica: A instrução NOT opera em DINTs. Operandos de origem INT ou SINT são convertidos em DINT preenchendo os bits superiores com 0s.

## Bloco de funções

| Operando    | Tipo de dados  (Data Type)           | Format Des crição (Description)   |
|-------------|--------------------------------------|-----------------------------------|
|             | NOT FBD_CONVERT tag Estrutura de NOT |                                   |

## Estrutura de FBD\_CONVERT

| Membros  de entradas   | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                |
|------------------------|-------------------------------|------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL          |                               | Entrada Habilitar. Se falso, a instrução  não será executada e as saídas não  serão atualizadas.  Padrão é verdadeiro. |
| Origem DINT            |                               | Valor para NOT                                                                                                         |

| Membros  de saída    | Tipo de dados  (Data Type)    | Descrição (Description)                                            |
|----------------------|-------------------------------|--------------------------------------------------------------------|
| EnableOut BOOL       |                               | Indica se a instrução foi executada  sem falhas ao ser habilitada. |
|                      |                               | Dest DINT Resultado da instrução                                   |

## Descrição (Description)

Quando habilitada, a instrução avalia a operação NÃO bit a bit:

Dest = NOT Source

| Se o bit em Source for: O bit no Dest será:    |
|------------------------------------------------|
| 0 1                                            |
| 1 0                                            |

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                        | Afeta sinalizadores de status  de operações matemáticas    |
|----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e  GuardLogix 5580 | Condicional                                                |
| Controladores CompactLogix  5370, ControlLogix 5570,  Compact GuardLogix 5370 e  GuardLogix 5570                     | Sim                                                        |

Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                            |
|------------------------------------|------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                            |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como  Rung-condition-in                                                         |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como  Rung-condition-in  Dest é definido conforme descrito na  seção Descrição. |
| Pós-varredura N/D                  |                                                                                                            |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                         |
|------------------------------------|-----------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                         |
|                                    | EnableIn é falso Defina EnableOut como EnableIn                                         |
| EnableIn é verdadeiro              | Definir EnableOut como EnableIn  Dest é definido conforme descrito na  seção Descrição. |
| Primeira execução da  instrução    | N/D                                                                                     |
| Primeira varredura da  instrução   | N/D                                                                                     |
| Pós-varredura N/D                  |                                                                                         |

## Exemplos

## Diagrama ladder

<!-- image -->
