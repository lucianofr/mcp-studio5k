---
type: Instruction
title: "Temporizador de atraso desativado com restauração (TOFR)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L3078-L3218"
---

## Temporizador de atraso desativado com restauração (TOFR)

## Exemplo

## Diagrama ladder

<!-- image -->

Quando limit\_switch\_9 é eliminado, light\_8 fica acesa por 180 milissegundos (timer\_2 está sincronizando). Quando timer\_2.acc alcança 180, light\_8 apaga e light\_4 acende. Light\_4 permanece até que a instrução TOF seja habilitada. Se limit\_switch\_9 for verdadeiro enquanto timer\_2 estiver sincronizando, light\_8 apaga.

## Consulte também

Instruções do temporizador e do contador na página 103

Indexação por meio de matrizes na página 893

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução TOFR é um temporizador não retentivo que acumula tempo quando TimerEnable é eliminada.

## Idiomas disponíveis

## Diagrama ladder

Esta instrução não está disponível no diagrama ladder.

## Bloco de funções

<!-- image -->

## Texto estruturado

TOFR(TOFR\_tag)

## Operandos

## Texto estruturado

| Variável Tipo                | Formato Descrição    |
|------------------------------|----------------------|
| TOFR tag FBD_TIMER Estrutura | Estrutura de  TOFR   |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Bloco de funções

| Operando Tipo Formato Descrição    | Operando Tipo Formato Descrição    |
|------------------------------------|------------------------------------|
| TOFR tag FBD_TIMER Estrutura       | Estrutura de  TOFR                 |

## Estrutura de FBD\_TIMER

| Parâmetros  de entrada    | Tipo de dados Descrição    |                                                                                                                                                                                                                                                                                   |
|---------------------------|----------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL             |                            | Se eliminado, a instrução não é executada e  as saídas não são atualizadas. Se definido, a  instrução é executada.  Padrão é definido.                                                                                                                                            |
| TimerEnable BOOL          |                            | Se eliminado, isso permite que o temporizador  opere e acumule tempo.  Padrão é eliminado.                                                                                                                                                                                        |
|                           | PRE DINT                   | Valor predefinido do temporizador. Esse é o  valor em unidade de 1 milissegundo que o  ACC precisa alcançar antes da sincronização  terminar. Se inválido, a instrução define o bit  correto em Status e o temporizador não é  executado.  Válido = 0 até inteiro positivo máximo |

| Reset BOOL    | Solicitar para restaurar o temporizador.  Quando definido, o temporizador é restaurado. Padrão é eliminado.  Quando o parâmetro de entrada Reset é  definido, a instrução elimina EN, TT e DN e  define ACC = PRE. Observe que isso é  diferente de usar uma instrução RES em uma  instrução TOF.    |
|---------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Parâmetros  de saída      | Tipo de dados Descrição    |                                                                                                                                                                                  |
|---------------------------|----------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                           |                            | EnableOut BOOL A instrução produziu um resultado válido.                                                                                                                         |
|                           |                            | ACC BOOL O tempo acumulado em milissegundos.                                                                                                                                     |
|                           | EN BOOL                    | Saída habilitada pelo temporizador. Indica que  a instrução do temporizador está habilitada.                                                                                     |
|                           | TT BOOL                    | Saída de sincronização do temporizador.  Quando definida, a operação de sincronização  está em andamento.                                                                        |
|                           | DN BOOL                    | Saída da sincronização executada. Indica que  o tempo acumulado é maior ou igual à  pré-configuração.                                                                            |
|                           |                            | Status DINT Status do bloco de funções.                                                                                                                                          |
| InstructFault  (Status.0) | BOOL                       | A instrução detectou um dos seguintes erros  de execução. Esse não é um erro de controlar  maior ou menor. Verifique os bits de status  restantes para determinar o que ocorreu. |
| PresetInv  (Status.1)     |                            | BOOL O valor predefinido é inválido.                                                                                                                                             |

## Descrição

Quando verdadeira, a instrução TOFR acumula tempo até que a:

-  Instrução TOFR está desabilitada
-  ACC PRE

A base de tempo é sempre em 1 milissegundo. Por exemplo, para um temporizador de 2 segundos, insira 2.000 para o valor PRE.

<!-- image -->

Defina o parâmetro de entrada Reset para restaurar a instrução. Se TimerEnable for falso quando Reset for verdadeiro, a instrução TOFR não começará a sincronização novamente quando Reset for falso.

## Como o temporizador opera

Um temporizador é executado subtraindo-se o horário da sua última varredura do horário atual:

ACC = ACC + (current\_time - last\_time\_scanned)

Após isso atualizar o ACC, o temporizador define last\_time\_scanned= current\_time. Isso torna o temporizador pronto para a próxima varredura.

Importante:

Assegure-s de escanear o temporizador pelo menos a cada 69 minutos enquanto ele estiver em operação. Do contrário, o valor ACC não será correto.

O valor last\_time\_scanned tem uma faixa de tempo de até 69 minutos. O cálculo do temporizador será sobrescrito se você não escanear o temporizador dentro de 69 minutos. O valor ACC não será corrigido se isso acontecer.

Enquanto o temporizador estiver em execução, faça a varredura dele dentro de 69 minutos se você o colocar em uma:

-  Subrotina
-  Seção de código que está entre as instruções JMP e LBL
-  Gráfico de função sequencial (SFC)
-  Evento ou tarefa periódica

-  Rotina do estado de uma fase

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                                                 |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | Os bits EnableIn e EnableOut são eliminados  para falso.                                                                                        |
| Tag. EnableIn é falso              | Os bits EnableIn e EnableOut são eliminados  para falso.                                                                                        |
| Tag. EnableIn é  verdadeiro        | Os bits EnableIn e EnableOut são definidos  para verdadeiro.  O algoritmo principal da instrução será  executado e as saídas serão atualizadas. |
| Primeira execução  da instrução    | N/A                                                                                                                                             |
| Primeira varredura  da instrução   | EN, TT e DN são restaurados e o valor ACC  não é modificado.                                                                                    |
| Pós-varredura                      | Os bits EnableIn e EnableOut são eliminados  para falso.                                                                                        |

## Texto estruturado

| Condição/estado A ção realizada    |                                                                    |
|------------------------------------|--------------------------------------------------------------------|
| Pré-varredura                      | Consulte Pré-varredura na tabela de Bloco de  funções.             |
| Execução normal                    | Consulte Tag.EnableIn é verdadeiro na tabela  de Bloco de funções. |
| Pós-varredura                      | Consulte Pós-varredura na tabela de Bloco de  funções.             |

## Exemplo

Cada varredura após limit\_switch1 é eliminada, a instrução TOFR incrementa o valor ACC pelo tempo transcorrido até que o valor ACC alcance o valor PRE Quando ACC PRE, o parâmetro DN é eliminado e o timer\_state2 é definido.
