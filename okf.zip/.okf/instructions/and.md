---
type: Instruction
title: "And bit a bit (AND)"
description: "Sinalizadores de status de operações matemáticas na página 879"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L10240-L10376"
---

## And bit a bit (AND)

Sinalizadores de status de operações matemáticas na página 879

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução AND executa uma operação AND bit a bit usando os bits em Source A e em Source B e coloca o resultado em Dest.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

Dica:

Use o operador AND (ou '&amp;') em uma expressão para obter o mesmo resultado. Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões e atribuições no texto estruturado.

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                    |
|----------------|---------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                        |
|                |   Membros de um operando de estrutura estão  substituídos.                                             |
|                |   Exceto quanto especificado, os operandos da  estrutura são compartilhados por múltiplas  instruções. |

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

| Operando  Tipo de  dados       |               | Formato Descrição                                                                                                                                    |
|--------------------------------|---------------|------------------------------------------------------------------------------------------------------------------------------------------------------|
| Source A SINT  INT  DINT  REAL | imediato  tag | Valor para AND com Source B.  Dica: Se o tipo de dado for  REAL, o valor de entrada será  convertido em DINT, o que pode  causar um transbordamento. |
| Source B SINT  INT  DINT  REAL | imediato  tag | Valor para AND com Source A.  Dica: Se o tipo de dado for  REAL, o valor de entrada será  convertido em DINT, o que pode  causar um transbordamento. |
| Dest SINT  INT  DINT  REAL     | tag           | Tag a armazenar o resultado da  instrução.  Dica: Se o tipo de dado for  REAL, o valor DINT resultante  será convertido em REAL.                     |

Dica:

A instrução AND opera em DINTs. Operandos de origem INT ou SINT são convertidos em DINT preenchendo os bits superiores com 0s.

## Bloco de funções

| Operando Tipo de dados Formato Descrição    |                                      |
|---------------------------------------------|--------------------------------------|
|                                             | AND FBD_LOGICAL tag Estrutura de AND |

## Estrutura de FBD\_LOGICAL

| Membros de  entradas    | Tipo de dados Descrição    |                                                                                                                        |
|-------------------------|----------------------------|------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL           |                            | Entrada Habilitar. Se falso, a  instrução não será executada e as  saídas não serão atualizadas.  Padrão é verdadeiro. |
| SourceA DINT            |                            | Valor para AND com SourceB.                                                                                            |
| SourceB DINT            |                            | Valor para AND com SourceA.                                                                                            |

| Membros de  saída    | Tipo de dados Descrição                                               |
|----------------------|-----------------------------------------------------------------------|
| EnableOut BOOL       | Indica se a instrução foi executada  sem falha quando foi habilitada. |
|                      | Dest DINT Resultado da instrução.                                     |

## Descrição

Quando habilitada, a instrução avalia a operação AND bit a bit: Dest = A AND B

| Se o bit na  Source A for:  E o bit na  Source B for:  O bit no  Dest será:    |
|--------------------------------------------------------------------------------|
| 0 0 0                                                                          |
| 0 1 0                                                                          |
| 1 0 0                                                                          |
| 1 1 1                                                                          |

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                       | Afeta sinalizadores de status  de operações matemáticas    |
|---------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580 | Condicional                                                |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact  GuardLogix 5370 e GuardLogix 5570                     | Sim                                                        |

Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                            |
|------------------------------------|------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                            |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como  Rung-condition-in                                                         |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como  Rung-condition-in  Dest é definido conforme descrito na seção  Descrição. |
| Pós-varredura N/A                  |                                                                                                            |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                         |
|------------------------------------|-----------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                         |
|                                    | EnableIn é falso Defina EnableOut como EnableIn                                         |
| EnableIn é verdadeiro              | Definir EnableOut como EnableIn  Dest é definido conforme descrito na seção  Descrição. |
| Primeira execução da  instrução    | N/A                                                                                     |
| Primeira varredura da  instrução   | N/A                                                                                     |
| Pós-varredura N/A                  |                                                                                         |

## Exemplos

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

value\_result\_and := value\_1 AND value\_2;

## Consulte também

Sintaxe de texto estruturado na página 912

Indexação por meio de matrizes na página 893

Sinalizadores de status de operações matemáticas na página 879
