---
type: Instruction
title: "Derivativa proporcional integral (PID)"
description: "A instrução PID controla uma variável de processo como fluxo, pressão, temperatura ou nível."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L16724-L17707"
---

## Derivativa proporcional integral (PID)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução PID controla uma variável de processo como fluxo, pressão, temperatura ou nível.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

PID(PID,ProcessVariable,Tieback,ControlVariable,PIDMasterLoop,InHoldBit,I nHoldValue);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados.

## Diagrama ladder

|                       |                   | Operando Tipo (Type) Format Descrição (Description)    |
|-----------------------|-------------------|--------------------------------------------------------|
|                       | PID PID estrutura | Estrutura de PID                                       |
| Variável de  processo |                   | SINT tag Valor que você deseja controlar               |
| Variável de  processo | INT:              |                                                        |
| Variável de  processo | DINT              |                                                        |
| Variável de  processo | REAL              |                                                        |

|                                        |          | Tieback SINT immediate (opcional)                                                                                                                   |
|----------------------------------------|----------|-----------------------------------------------------------------------------------------------------------------------------------------------------|
|                                        | INT: tag |                                                                                                                                                     |
|                                        | DINT     | Saída de uma estação  automática/manual de hardware que  está ignorando a saída do controlador. Digite 0 se você não deseja usar esse  parâmetro    |
|                                        | REAL     |                                                                                                                                                     |
| Control variable SINT tag              |          | Valor que vai para o dispositivo de  controle final (válvula, amortecedor,  etc.)                                                                   |
| Control variable SINT tag              | INT:     |                                                                                                                                                     |
| Control variable SINT tag              | DINT     | Se você estiver usando a zona morta,  a variável de controle deve ser REAL  ou ela será forçada para 0 quando o  erro estiver dentro da zona morta. |
| Control variable SINT tag              | REAL     |                                                                                                                                                     |
| PID master loop PID Structure Opcional |          |                                                                                                                                                     |
| PID master loop PID Structure Opcional |          | Tag PID para o PID mestre                                                                                                                           |
| PID master loop PID Structure Opcional |          | Se você estiver realizando controle  em cascata e esse PID é um  circuito-escravo, digite o nome do PID  mestre.                                    |
| PID master loop PID Structure Opcional |          | Digite 0 se você não deseja usar esse  parâmetro                                                                                                    |
| Inhold bit BOOL tag Opcional           |          |                                                                                                                                                     |
| Inhold bit BOOL tag Opcional           |          | Status atual do bit inhold de um 1756  analógico                                                                                                    |
| Inhold bit BOOL tag Opcional           |          | Canal de saída para suportar reinício  ininterrupto                                                                                                 |
| Inhold value SINT tag Opcional         |          |                                                                                                                                                     |
| Inhold value SINT tag Opcional         | INT:     | Valor de leitura retroativa de dados a  partir de uma saída analógica 1756                                                                          |
| Inhold value SINT tag Opcional         | DINT     | Canal para suportar reinício  ininterrupto                                                                                                          |
| Inhold value SINT tag Opcional         | REAL     | Digite 0 se você não deseja usar esse  parâmetro                                                                                                    |
| Ponto de ajuste                        |          | Apenas exibir                                                                                                                                       |
| Ponto de ajuste                        |          | Valor atual do ponto de ajuste                                                                                                                      |
| Variável de  processo                  |          | Apenas exibir                                                                                                                                       |
| Variável de  processo                  |          | Valor atual da Process_Variable  dimensionada                                                                                                       |
| Output %                               |          | Apenas exibir                                                                                                                                       |
| Output %                               |          | Valor de porcentagem de saída atual                                                                                                                 |

## Texto estruturado

| Operando                  | Tipo  (Type)    |                   | Format Des crição (Description)                                                                                                                     |
|---------------------------|-----------------|-------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|
|                           |                 | PID PID estrutura | Estrutura de PID                                                                                                                                    |
| Variável de  processo     | SINT tag        |                   | Valor que você deseja controlar                                                                                                                     |
| Variável de  processo     | INT:            |                   | Valor que você deseja controlar                                                                                                                     |
| Variável de  processo     | DINT            |                   | Valor que você deseja controlar                                                                                                                     |
| Variável de  processo     | REAL            |                   | Valor que você deseja controlar                                                                                                                     |
|                           |                 |                   | Tieback SINT immediate (opcional)                                                                                                                   |
|                           | INT: tag        |                   |                                                                                                                                                     |
|                           | DINT            |                   | Saída de uma estação  automática/manual de hardware que  está ignorando a saída do controlador.  Digite 0 se você não deseja usar esse  parâmetro   |
|                           | REAL            |                   |                                                                                                                                                     |
| Control variable SINT tag |                 |                   | Valor que vai para o dispositivo de  controle final (válvula, amortecedor, etc.)                                                                    |
| Control variable SINT tag | INT:            |                   |                                                                                                                                                     |
| Control variable SINT tag | DINT            |                   | Se você estiver usando a zona morta, a  variável de controle deve ser REAL ou  ela será forçada para 0 quando o erro  estiver dentro da zona morta. |
| Control variable SINT tag | REAL            |                   |                                                                                                                                                     |
| PID master loop           | PID             | Structure         | Opcional                                                                                                                                            |
| PID master loop           | PID             | Structure         | Tag PID para o PID mestre                                                                                                                           |
| PID master loop           | PID             | Structure         | Se você estiver realizando controle em  cascata e esse PID é um  circuito-escravo, digite o nome do PID  mestre                                     |
| PID master loop           | PID             | Structure         | Digite 0 se você não deseja usar esse  parâmetro                                                                                                    |
| Inhold bit                |                 |                   | BOOL tag Opcional                                                                                                                                   |
| Inhold bit                |                 |                   | Status atual do bit inhold de um 1756  analógico                                                                                                    |
| Inhold bit                |                 |                   | Canal de saída para suportar reinício  ininterrupto                                                                                                 |
| Inhold value              | SINT tag        |                   | Opcional                                                                                                                                            |
| Inhold value              | INT:            |                   | Valor de leitura retroativa de dados a  partir de uma saída analógica 1756                                                                          |
| Inhold value              | DINT            |                   | Canal para suportar reinício ininterrupto                                                                                                           |
| Inhold value              | REAL            |                   | Digite 0 se você não deseja usar esse  parâmetro                                                                                                    |
| Ponto de ajuste           |                 |                   | Apenas exibir                                                                                                                                       |
| Ponto de ajuste           |                 |                   | Valor atual do ponto de ajuste                                                                                                                      |

| Variável de  processo    | Apenas exibir  Valor atual da Process_Variable  dimensionada    |
|--------------------------|-----------------------------------------------------------------|
| Output %                 | Apenas exibir  Valor de porcentagem de saída atual              |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Estrutura de PID

Especifique uma estrutura de PID única para cada instrução PID.

| Mnemônico    | Tipo de  dados  (Data Type)   | Descrição (Description)                                                                                                            | Descrição (Description)                                                                                                            | Descrição (Description)                                                                                                            |
|--------------|-------------------------------|------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------|
|              | .CTL DINT                     | O membro .CTL fornece acesso aos membros de  status (bits) em uma palavra de 32 bits.  Bits 07-15 são definidos pela instrução PID | O membro .CTL fornece acesso aos membros de  status (bits) em uma palavra de 32 bits.  Bits 07-15 são definidos pela instrução PID | O membro .CTL fornece acesso aos membros de  status (bits) em uma palavra de 32 bits.  Bits 07-15 são definidos pela instrução PID |
|              | .CTL DINT                     |                                                                                                                                    | Bit Número Descrição (Description)                                                                                                 |                                                                                                                                    |
|              | .CTL DINT                     | .EN 31                                                                                                                             |                                                                                                                                    |                                                                                                                                    |
|              | .CTL DINT                     | .CT 30                                                                                                                             | tipo em cascata (0=escravo;  1=mestre)                                                                                             |                                                                                                                                    |
|              | .CTL DINT                     | .CL 29                                                                                                                             | circuito em cascata (0=não;  1=sim)                                                                                                |                                                                                                                                    |
|              | .CTL DINT                     | .PVT 28                                                                                                                            | acompanhamento de variável  de processo (0=não; 1=sim)                                                                             |                                                                                                                                    |
|              | .CTL DINT                     |                                                                                                                                    | .DOE 27 derivativo de (0=PV; 1=erro)                                                                                               |                                                                                                                                    |
|              | .CTL DINT                     | .SWM 26                                                                                                                            | modo de software  (0=no-auto); 1=sim- sw  manual)                                                                                  |                                                                                                                                    |
|              | .CTL DINT                     | .CA 25                                                                                                                             | ação de controle (0=reverso  (SP-PV); 1=direto (PV- SP))                                                                           |                                                                                                                                    |
|              | .CTL DINT                     | .MO 24                                                                                                                             | modo de estação  (0=automático; 1=manual)                                                                                          |                                                                                                                                    |
|              | .CTL DINT                     | .PE 23                                                                                                                             | equação PID  (0=independente;  1=dependente)                                                                                       |                                                                                                                                    |
|              | .CTL DINT                     | .NDF 22                                                                                                                            | harmonia derivativa (0=não;  1=sim)                                                                                                |                                                                                                                                    |
|              | .CTL DINT                     |                                                                                                                                    | .NOBC 21 cálculo de bias (0=não; 1=sim)                                                                                            |                                                                                                                                    |
|              | .CTL DINT                     | .NOZC 20                                                                                                                           | cruzamento zero (0=não;  1=para zona morta)                                                                                        |                                                                                                                                    |
|              | .CTL DINT                     | .INI 15                                                                                                                            | PID inicializado (0=não;  1=sim)                                                                                                   |                                                                                                                                    |
|              | .CTL DINT                     | .SPOR 14                                                                                                                           | ponto de ajuste fora da faixa  (0=não; 1=sim)                                                                                      |                                                                                                                                    |
|              | .CTL DINT                     | .OLL 13                                                                                                                            | CV está abaixo do valor  mínimo de saída (0=não;  1=sim)                                                                           |                                                                                                                                    |

| Mnemônico  Tipo de    | Descrição (Description)                                    | Descrição (Description)                                    | Descrição (Description)                                    |
|-----------------------|------------------------------------------------------------|------------------------------------------------------------|------------------------------------------------------------|
|                       | .OLH 12                                                    | CV está acima do valor  máximo de saída (0=não;  1=sim)    |                                                            |
|                       | .EWD 11                                                    | erro está dentro da zona  morta (0=não; 1=sim)             |                                                            |
|                       | .DVNA 10                                                   | erro está alarmado baixo  (0=não; 1=sim)                   |                                                            |
|                       | .DVPA 9                                                    | erro está alarmado alto  (0=não; 1=sim)                    |                                                            |
|                       | .PVLA 8                                                    | PV está alarmada baixo  (0=não; 1=sim)                     |                                                            |
|                       | .PVHA 7                                                    | PV está alarmada alto (0=não;  1=sim)                      |                                                            |
| .SP                   | REAL ponto de ajuste                                       | REAL ponto de ajuste                                       | REAL ponto de ajuste                                       |
| .KP                   | REAL Independente - ganho proporcional (sem unidade)       | REAL Independente - ganho proporcional (sem unidade)       | REAL Independente - ganho proporcional (sem unidade)       |
| .KP                   | Dependente - ganho de controlador (sem unidade)            | Dependente - ganho de controlador (sem unidade)            | Dependente - ganho de controlador (sem unidade)            |
| .KI                   | REAL Independente - ganho integral (1/segundo)             | REAL Independente - ganho integral (1/segundo)             | REAL Independente - ganho integral (1/segundo)             |
| .KI                   | Dependente - tempo de restauração (minutos por  repetição) | Dependente - tempo de restauração (minutos por  repetição) | Dependente - tempo de restauração (minutos por  repetição) |
| .KD                   | REAL Independente - ganho derivativo (segundos)            | REAL Independente - ganho derivativo (segundos)            | REAL Independente - ganho derivativo (segundos)            |
| .KD                   | Dependente - tempo de taxa (minutos)                       | Dependente - tempo de taxa (minutos)                       | Dependente - tempo de taxa (minutos)                       |
|                       | .BIAS REAL % de feedforward ou bias                        | .BIAS REAL % de feedforward ou bias                        | .BIAS REAL % de feedforward ou bias                        |
| .MAXS REAL            | valor máximo de dimensionamento de unidade de  engenharia  | valor máximo de dimensionamento de unidade de  engenharia  | valor máximo de dimensionamento de unidade de  engenharia  |
| .MINS REAL            | valor mínimo de dimensionamento de unidade de  engenharia  | valor mínimo de dimensionamento de unidade de  engenharia  | valor mínimo de dimensionamento de unidade de  engenharia  |
| .DB                   | REAL unidades de engenharia de zona morta                  | REAL unidades de engenharia de zona morta                  | REAL unidades de engenharia de zona morta                  |
| .SO                   | REAL ajustar % de saída                                    | REAL ajustar % de saída                                    | REAL ajustar % de saída                                    |
|                       | .MAXO REAL limite máximo de saída (% de saída)             | .MAXO REAL limite máximo de saída (% de saída)             | .MAXO REAL limite máximo de saída (% de saída)             |
|                       | .MINO REAL limite mínimo de saída (% de saída)             | .MINO REAL limite mínimo de saída (% de saída)             | .MINO REAL limite mínimo de saída (% de saída)             |
|                       | .UPD REAL tempo de atualização do circuito (segundos)      | .UPD REAL tempo de atualização do circuito (segundos)      | .UPD REAL tempo de atualização do circuito (segundos)      |
| .PV                   | REAL valor de PV dimensionado                              | REAL valor de PV dimensionado                              | REAL valor de PV dimensionado                              |
|                       | .ERR REAL valor de erro dimensionado                       | .ERR REAL valor de erro dimensionado                       | .ERR REAL valor de erro dimensionado                       |
|                       | .OUT REAL % de saída                                       | .OUT REAL % de saída                                       | .OUT REAL % de saída                                       |
|                       | .PVH REAL limite alto de alarme de variável de processo    | .PVH REAL limite alto de alarme de variável de processo    | .PVH REAL limite alto de alarme de variável de processo    |
|                       | .PVL REAL limite baixo de alarme de variável de processo   | .PVL REAL limite baixo de alarme de variável de processo   | .PVL REAL limite baixo de alarme de variável de processo   |
|                       | .DVP REAL limite de alarme de desvio positivo              | .DVP REAL limite de alarme de desvio positivo              | .DVP REAL limite de alarme de desvio positivo              |
|                       | .DVN REAL limite de alarme de desvio negativo              | .DVN REAL limite de alarme de desvio negativo              | .DVN REAL limite de alarme de desvio negativo              |
|                       | .PVDB REAL zona morta de alarme de variável de processo    | .PVDB REAL zona morta de alarme de variável de processo    | .PVDB REAL zona morta de alarme de variável de processo    |
|                       | .DVDB REAL zona morta de alarme de desvio                  | .DVDB REAL zona morta de alarme de desvio                  | .DVDB REAL zona morta de alarme de desvio                  |
|                       | .MAXI REAL valor máximo de PV (entrada não dimensionada)   | .MAXI REAL valor máximo de PV (entrada não dimensionada)   | .MAXI REAL valor máximo de PV (entrada não dimensionada)   |
|                       | .MINI REAL valor mínimo de PV (entrada não dimensionada)   | .MINI REAL valor mínimo de PV (entrada não dimensionada)   | .MINI REAL valor mínimo de PV (entrada não dimensionada)   |
|                       | .TIE REAL valor de tieback para controle manual            | .TIE REAL valor de tieback para controle manual            | .TIE REAL valor de tieback para controle manual            |

| Mnemônico  Tipo de  dados  (Data Type) Descrição (Description)    |                                                      |
|-------------------------------------------------------------------|------------------------------------------------------|
| .MAXCV REAL valor máximo de CV (correspondente a 100%)            |                                                      |
| .MINCV REAL valor mínimo de CV (correspondente a 0%)              |                                                      |
| .MINTIE REAL valor mínimo de tieback (correspondente a 100%)      |                                                      |
| .MAXTIE REAL valor máximo de tieback (correspondente a 0%)        |                                                      |
| .DATA[17] REAL                                                    |                                                      |
| .DATA[17] REAL                                                    | .DATA[0] acúmulo integral                            |
| .DATA[17] REAL                                                    | .DATA[1] valor temporário de harmonia derivativa     |
| .DATA[17] REAL                                                    | .DATA[2] valor de PV prévio                          |
| .DATA[17] REAL                                                    | .DATA[3] valor de .ERR prévio                        |
| .DATA[17] REAL                                                    | .DATA[4] valor de .SP prévio válido                  |
| .DATA[17] REAL                                                    | .DATA[5] constante de dimensionamento por cento      |
| .DATA[17] REAL                                                    | .DATA[6] constante de dimensionamento de .PV         |
| .DATA[17] REAL                                                    | .DATA[7] constante de dimensionamento derivativo     |
| .DATA[17] REAL                                                    | .DATA[8] valor .KP prévio                            |
| .DATA[17] REAL                                                    | .DATA[9] valor .KI prévio                            |
| .DATA[17] REAL                                                    | .DATA[10] valor de .KD prévio                        |
| .DATA[17] REAL                                                    | .DATA[11] .KP de ganho dependente                    |
| .DATA[17] REAL                                                    | .DATA[12] .KI de ganho dependente                    |
| .DATA[17] REAL                                                    | .DATA[13] .KD de ganho dependente                    |
| .DATA[17] REAL                                                    | .DATA[14] valor de .CV prévio                        |
| .DATA[15]                                                         | constante de anulação de  dimensionamento de .CV     |
| .DATA[16]                                                         | constante de anulação de  dimensionamento de tieback |
| .DATA[17] REAL                                                    |                                                      |

## Descrição (Description)

A instrução PID tipicamente recebe a variável de processo (PV) a partir de um módulo de entrada analógica e modula uma saída de variável de controle (CV) em um módulo de saída analógica para manter a variável de processo no ponto de ajuste desejado.

O bit .EN indica o status de execução. O bit .EN é definido quando EnableIn realiza a transição de falso para verdadeiro. O bit .EN é eliminado quando EnableIn se torna falso. A instrução PID não usa um bit .DN. A instrução PID é executada em toda varredura, contanto que EnableIn for verdadeiro.

<!-- image -->

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha menor ocorrerá se: Tipo de falha Código de falha    |    |
|---------------------------------------------------------------|----|
| UPD ≥ 0 4 35                                                  |    |
| ponto de adjuste fora da faixa 4                              | 36 |

Consulte Atributos comuns para falhas relacionadas ao operando

## Consulte também

Instruções especiais na página 679

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Conversões de dados na página 883

## Usando instruções PID

Após inserir a instrução PID e especificar a estrutura PID, use as guias de configuração para especificar como a instrução PID deve funcionar.

## Especificar ajuste

Selecione a guia de Ajuste (Tuning). As alterações entram em vigor assim que você clica em outro campo, clica em OK, em Aplicar (Apply) ou pressiona Enter .

| Neste campo:                                 | Faça o seguinte:                                                                                                                                                                           |
|----------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                              | Ponto de ajuste (Setpoint, SP) Digite um valor de ponto de ajuste (.SP).                                                                                                                   |
|                                              | Ajustar % de saída (Set output %) Digite uma porcentagem de saída (.SO).  No modo manual de software, este valor é usado para a saída. No  modo automático, este valor exibe a % de saída. |
|                                              | Bias de saída (Output bias) Digite uma porcentagem de bias de saída (.BIAS).                                                                                                               |
| Ganho proporcional (Proportional  gain) (Kp) | Digite o ganho proporcional (.KP).  Para ganhos independentes, é o ganho proporcional (sem unidade).  Para ganhos dependentes, é o ganho do controller (sem unidade).                      |
| Ganho integral (Integral gain) (Ki)          | Digite o ganho integral (.KI).  Para ganhos independentes, é o ganho integral (1/seg).  Para ganhos dependentes, é a hora de restauração (minutos por  repetição).                         |
| Tempo derivativo (Derivative time)  (Kd)     | Digite o ganho derivativo (.KD).  Para ganhos independentes, é o ganho derivativo (segundos). Para  ganhos dependentes, é o tempo da taxa (minutos).                                       |
|                                              | Modo manual (Manual mode) Selecione manual (.MO) ou manual de software (.SWM).  O modo manual cancela o modo manual de software, caso ambos  sejam selecionados.                           |

## Especificar configuração

Selecione a guia Configuração. Você deve clicar em OK ou Aplicar (Apply) para que as alterações surtam efeito.

| Neste campo:  Faça o seguinte:                                                                                                                                                                                                                                                                               |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Equação PID (PID equation) Selecione ganhos independentes ou dependentes (.PE).  Use independente quando desejar que os três ganhos (P, I e D)  operem de modo independente. Use Dependente quando desejar um  ganho do controlador geral que afete todos os três termos de ganho  (P, I e D).               |
| Ação de controle (Control action) Selecione E=PV-SP ou E=SP-PV para a ação de controle (.CA).                                                                                                                                                                                                                |
| Derivativo de (Derivative of) Selecione PV ou erro (.DOE).  Use o derivativo de PV para reduzir o risco de impulsos de saída  resultantes de alterações em pontos de ajuste. Use o derivativo de  erro para respostas rápidas a alterações em pontos de ajuste quando  o algoritmo puder tolerar excedentes. |
| Tempo de atualização do circuito  Digite o tempo de atualização (.UPD) para a instrução.                                                                                                                                                                                                                     |
| Limite alto de CV (CV high limit) Digite um limite alto para a variável de controle (.MAXO).(1)                                                                                                                                                                                                              |
| Limite baixo de CV (CV low limit) Digite um limite baixo para a variável de controle (.MINO).(1)                                                                                                                                                                                                             |

| Valor de zona morta (Deadband  value)                                | Digite um valor de zona morta (.DB).                                                           |
|----------------------------------------------------------------------|------------------------------------------------------------------------------------------------|
| Sem harmonia derivativa (No  derivative smoothing)                   | Habilite ou desabilite esta seleção (.NDF).                                                    |
| Sem cálculo de bias (No bias  calculation)                           | Habilite ou desabilite esta seleção (.NOBC).                                                   |
| Sem cruzamento zero para zona  morta (No zero crossing in  deadband) | Habilite ou desabilite esta seleção (.NOZC).                                                   |
|                                                                      | Rastreamento de PV (PV tracking) Habilite ou desabilite esta seleção (.PVT).                   |
| Circuito em cascata (Cascade  loop)                                  | Habilite ou desabilite esta seleção (.CL).                                                     |
| Colocar tipo em cascata (Cascade  type)                              | Se a opção colocar circuito em cascata estiver habilitada, selecione  escravo ou mestre (.CT). |

(1) Ao usar a instrução PID baseada na lógica de contatos, se você definir MAXO = MINO, a instrução PID restaure estes valores para o padrão. MAXO = 100.0 e MINO = 0.0

## Especificar alarmes

Selecione aguia Alarmes (Alarms). Clique em OK ou Aplicar (Apply) para que as alterações surtam efeito.

| Neste campo:                               | Faça o seguinte:                                                                      |
|--------------------------------------------|---------------------------------------------------------------------------------------|
|                                            | Limite alto de PV (PV high) Digite um valor alto de alarme de PV (.PVH).              |
|                                            | Limite baixo de PV (PV low) Digite um valor baixo de alarme de PV (.PVL).             |
|                                            | Zona morta de PV (PV deadband) Digite um valor de zona morta de alarme de PV (.PVDB). |
|                                            | Desvio positivo (Positive deviation) Digite um valor de desvio positivo (.DVP).       |
| Desvio negativo (Negative  deviation)      | Digite um valor de desvio negativo (.DVN).                                            |
| Zona morta de desvio (Deviation  deadband) | Digite um valor de zona morta de alarme de desvio (.DVDB).                            |

## Especificar conversão de escala

Selecione a guia Conversão de escala. Você deve clicar em OK ou Aplicar (Apply) para que as alterações surtam efeito.

| Neste campo:                                                          | Faça o seguinte:                                                                                                                           |
|-----------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------|
| PV máx. sem escala (PV unscaled  maximum)                             | Digite um valor máximo de PV (.MAXI) que se iguale ao valor máximo  sem escala recebido do canal de entrada analógica para o valor de  PV. |
| PV mín. sem escala (PV unscaled  minimum)                             | Digite um valor mínimo de PV (.MINI) que se iguale ao valor mínimo  sem escala recebido do canal de entrada analógica para o valor de  PV. |
| Unidades máximas de engenharia  de PV (PV engineering units  maximum) | Digite as unidades máximas de engenharia correspondentes a .MAXI  (.MAXS).                                                                 |

| Unidades mínimas de engenharia  de PV (PV engineering units  minimum)    | Digite as unidades mínimas de engenharia correspondentes a .MINI  (.MINS).                                                                                                     |
|--------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                                                          | CV máxima (CV maximum) Digite um valor de CV máximo correspondente a 100% (.MAXCV).                                                                                            |
|                                                                          | CV mínima (CV minimum) Digite um valor de CV mínimo correspondente a 0% (.MINCV).                                                                                              |
| Tieback máximo (Tieback  maximum)                                        | Digite um valor máximo de tieback (.MAXTIE) que se iguale ao valor  máximo sem escala recebido do canal de entrada analógica para o  valor de tieback.                         |
| Tieback mínimo (Tieback  minimum)                                        | Digite um valor mínimo de tieback (.MINTIE) que se iguale ao valor  mínimo sem escala recebido do canal de entrada analógica para o  valor de tieback.                         |
| PID inicializado (PID Initialized)                                       | Se você alterar as constantes de conversão de escala durante o  Modo de Execução, desative-o para reinicializar os valores de  anulação de conversão de escala interna (.INI). |

Dica: Ao usar a instrução PID baseada na lógica de contatos, se você definir MAXO = MINO, a instrução PID restaure estes valores para o padrão. MAXO = 100.0 e MINO = 0.0

## Usar instruções PID

O controle de circuito fechado PID mantém uma variável de processo em um ponto de ajuste desejado. A ilustração mostra um exemplo de um nível de taxa de fluxo/fluido.

<!-- image -->

No exemplo acima, o nível no tanque é comparado ao ponto de ajuste. Se o nível for maior que o ponto de ajuste, a equação PID aumenta a variável de controle e faz com que a válvula de saída do tanque se abra, diminuindo, assim, o nível no tanque.

A equação PID na instrução PID é uma equação de forma posicional com a opção de usar ganhos dependentes ou independentes. Ao usar ganhos independentes, os ganhos proporcionais, integrais e derivativos afetam apenas os termos específicos proporcionais, integrais ou derivativos respectivamente. Ao usar ganhos dependentes, o ganho proporcional é colocado com um ganho do controlador que afeta todos os três termos. Você pode usar ambas as formas de equação para realizar o mesmo tipo de controle. Os dois tipos de equação são meramente fornecidas para que você possa usar o tipo de equação com o qual você está mais familiarizado.

| Opção de ganhos Derivativo de    |                           |
|----------------------------------|---------------------------|
| Ganhos dependentes               | Erro (E)                  |
| (Padrão ISA)                     | Variável de processo (PV) |
| Ganhos independentes Erro (E)    |                           |
|                                  | Variável de processo (PV) |

## Onde:

| Variável Des crição    |                                                                                                                     |
|------------------------|---------------------------------------------------------------------------------------------------------------------|
| KP                     | Ganho proporcional (sem unidade) Kp = Kc sem unidade                                                                |
| Ki                     | Ganho integral (segundos -1)  Para converter entre Ki (ganho integral) e Ti (tempo de  restauração), use:           |
| Kd                     | Ganho derivativo (segundos)  Para converter entre Kd (ganho derivativo) e Td (tempo da taxa),  use: Kd = Kc (Td) 60 |
| KC                     | Ganho de controlador (sem unidade)                                                                                  |
| Ti                     | Tempo de restauração (minutos/repetição)                                                                            |
| Td                     | Tempo de taxa (minutos)                                                                                             |
|                        | SP Ponto de ajuste                                                                                                  |
|                        | PV Variável de processo                                                                                             |
| E                      | Erro [(SP-PV) ou (PV-SP)]                                                                                           |
|                        | BIAS Feedforward ou bias                                                                                            |
| CV                     | Variável de controle                                                                                                |
| dt                     | Tempo de atualização do circuito (Loop update time)                                                                 |

Se você não desejar usar um termo particular da equação PID, apenas ajuste seu ganho para zero. Por exemplo, se você não desejar nenhuma ação derivativa, ajuste o Kd ou Td igual a zero.

## Consulte também

Restauração ininterrupta na página 712

Harmonia derivativa na página 715

Definir a zona morta na página 720

Circuitos em cascata na página 713

Controlar uma relação na página 714

## Fechamento anti-restauração e transferência ininterrupta de manual para automático (PID)

## Restauração ininterrupta (PID)

A instrução PID evita automaticamente o fechamento de restauração prevenindo que o termo integral acumule-se sempre que a saída CV chegar ao valor máximo ou mínimo, conforme definido por .MAXO e .MINO. O termo integral acumulado permanece congelado até que a saída CV caia abaixo do limite máximo ou suba além do limite mínimo. Então, o acúmulo integral normal é reiniciado automaticamente.

A instrução PID tem suporte para dois modos de controle manual.

| Modo de controle manual Descrição    |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|--------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Manual de software (.SWM)            | Esse modo também é conhecido como o modo de saída definido e permite ao  usuário definir o % de saída do software.  O valor de saída definida (.SO) é usado como a saída do circuito. O valor de  saída definido costuma vir de uma entrada do operador de um dispositivo de  interface do operador.                                                                                                                                                                                                                                  |
| Manual (.MO)                         | Esse modo pega o valor de tieback, como uma entrada, e ajusta suas variáveis  internas para gerar o mesmo valor na saída. A entrada de tieback para a  instrução PID é escalada para 0–100% de acordo com os valores de .MINTIE e  .MAXTIE, e é usada como a saída do circuito. A entrada de tieback geralmente  vem da saída de uma estação de hardware manual/automática que está  contornando a saída do controlador.  Importante: O modo manual substitui o modo manual de software caso ambos  os bits de modo estejam ativados. |

A instrução PID fornece imediatamente transferências ininterruptas do modo manual de software para o modo automático ou do modo manual para o modo automático. A instrução PID faz o cálculo retroativo do valor do termo de acúmulo integral necessário para fazer a saída CV rastrear o valor de saída definida (.SO) no modo manual de software ou a entrada de tieback no modo manual. Dessa maneira, quando o circuito muda para o modo automático, a saída CV começa da saída definida ou do valor de tieback e não ocorre nenhuma "interrupção" no valor de saída.

A instrução PID também pode fornecer automaticamente uma transferência ininterrupta de manual para automático, mesmo que o controle integral não seja usado (ou seja, Ki = 0). Neste caso, a instrução modifica o termo .BIAS para fazer a saída CV rastrear a saída definida ou os valores de tieback. Quando o controle automático é retomado, o termo .BIAS mantém seu último valor. Desabilite o cálculo retroativo do termo .BIAS definindo o bit .NOBC na estrutura de dados de PID. Se você definir .NOBC como verdadeiro, a instrução PID não proporcionará mais uma transferência ininterrupta de manual para automático quando o controle integral não for usado.

A instrução PID pode interagir com os módulos de saída analógica 1756 para dar suporte a uma restauração ininterrupta quando o controlador mudar do modo de programa para execução ou quando o controlador for ligado.

Quando um módulo de saída analógica 1756 perde as comunicações com o controlador ou detecta que o controlador está no modo de Programa, o módulo de saída analógica define suas saídas para os valores de condição de falha especificados ao configurar o módulo. Quando o controlador então volta para o modo de execução ou restabelece comunicações com o módulo de saída analógica, é possível fazer com que a instrução PID restaura automaticamente sua saída de variável de controle igual à saída analógica usando os parâmetros de Inhold bit e Inhold value na instrução PID.

## Instruções para configurar uma restauração ininterrupta

| Faça isto                                                                                                 | Detalhes                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
|-----------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Configure o canal de módulo  da saída analógica 1756 que  receba a variável de controle  da instrução PID | Selecione a caixa Reter para inicialização (Hold for initialization) na  página de propriedades para o canal específico do módulo.  Isso diz ao módulo de saída analógica que, quando o controlador volta para  o modo de execução ou restabelece comunicações com o módulo, o  módulo deve reter a saída analógica no seu valor atual até o valor enviado  do controlador corresponder (dentro de 0,1% do span) ao valor atual usado  pelo canal de saída. A saída do canal vai para o valor de saída retido no  momento usando o termo .BIAS. Esse aumento é similar à transferência  ininterrupta automática.                                                                                                                                                                                                                                                                                                                     |
| Insira a tag Inhold bit e a tag  Inhold value na instrução PID                                            | O módulo de saída analógica 1756 retorna dois valores para cada canal na  sua estrutura de dados de entrada. O bit de status InHold (.Ch2InHold, por  exemplo), quando verdadeiro, indica que o canal de saída analógica está  retendo seu valor. O valor de leitura retroativa de Dados (.Ch2Data, por  exemplo) mostra o valor de saída atual em unidades de engenharia.  Insira a tag do bit de status InHold como o parâmetro InHold bit da instrução  PID. Insira a tag do valor de leitura retroativa de Dados como o parâmetro  de Inhold value.  Quando o Inhold bit é verdadeiro, a instrução PID move o Inhold value para  a saída de Control variable e reinicializa para dar suporte a uma  restauração ininterrupta naquele valor. Quando o módulo de saída  analógica recebe esse valor de volta do controlador, ele desativa o bit de  status InHold, o que permite a instrução PID começar a controlar  normalmente. |

## Circuitos em cascata (PID)

PID coloca dois circuitos em cascata ao atribuir a saída no percentual do circuito-mestre para o ponto de ajuste do circuito-escravo. O circuito-escravo automaticamente converte a saída do circuito-mestre nas unidades corretas de engenharia para o ponto de ajuste do circuito-escravo, com base nos valores do circuito-escravo para .MAXS e .MINS.

## Controlando uma relação (PID)

## Lógica ladder de relé

<!-- image -->

## Texto estruturado

PID(master,pv\_master,0,cv\_master,0,0,0); PID (slave,pv\_slave,0,cv\_slave,master,0,0);

Você pode manter dois valores em uma relação ao usar esses parâmetros:

-  Valor não controlado
-  Valor controlado (o ponto de ajuste resultante a ser usado pela instrução PID)
-  Relação entre esses dois valores

## Lógica ladder de relé

<!-- image -->

## Harmonia Derivativa (PID)

## Feedforward ou polarização de saída (PID)

Dica:

```
flutuação, assegure que PV não é INF ou NAN antes de invocar XIC (PC_timer.DN) MOV(Local:0:1.Ch0Data, Local:0:1.Ch0Data) XIO(S:V) PID(...)
```

Para evitar o bloqueio do PID com valores internos de ponto de a instrução como:

## Texto estruturado

```
pid_2.sp := uncontrolled_flow * ratio PID(pid_2,pv_2,tieback_2,cv_2,0,0,0);
```

Dica:

Para evitar o bloqueio do PID com valores internos de ponto de flutuação, assegure que PV não é INF ou NAN antes de invocar a instrução como:

```
XIC (PC_timer.DN) MOV(Local:0:1.Ch0Data, Local:0:1.Ch0Data) XIO(S:V)
```

PID(...)

| Para essa multiplicação Digite esse valor    |                              |
|----------------------------------------------|------------------------------|
|                                              | Destination Valor controlado |
| Source A                                     | Valor não controlado         |
| Source B                                     | Relação                      |

O cálculo derivativo é aperfeiçoado por um filtro de harmonia derivativa. Este primeiro filtro de ordem, de varredura baixa, e digital minimiza grandes impulsos de termo derivativo causados por ruído na PV. Esta harmonia se torna mais agressiva com valores mais altos de ganho derivativo. Você pode desabilitar a harmonia derivativa, se seu processo exigir valores muito altos de ganho derivativo (Kd &gt; 10, por exemplo).

## Para desabilitar a harmonia derivativa:

-  selecione a opçãoSem harmonia derivativa (No derivative smoothing) na guia Configuração (Configuration) ou ajuste o bit .NDF na estrutura de PID.

Faz o feedforward de uma perturbação do sistema enviando o valor de .BIAS para o valor de feedforward/polarização da instrução PID.

O valor de feedforward representa uma perturbação enviada à instrução PID antes que a perturbação tenha a oportunidade de mudar a variável de processo. O

## Temporização da instrução PID

feedforward costuma ser usado para controlar processos com um atraso de transporte. Por exemplo, um valor de feedforward representando "água fria despejada em uma mistura quente" impulsionaria o valor de saída com mais rapidez do que esperar a variável de processo mudar como resultado da mistura.

Um valor de polarização costuma ser usado quando é empregado controle não integral. Nesse caso, o valor de polarização pode ser ajustado para manter a saída no intervalo necessário para manter a PV perto do ponto de ajuste.

A instrução PID e a amostra da variável de processo precisam ser atualizadas em uma taxa periódica. Esse tempo de atualização está relacionado ao processo físico que você está controlando. Para circuitos muito lentos, como circuitos de temperatura, um tempo de atualização de uma vez por segundo ou até com mais duração é geralmente suficiente para obter bom controle. Circuitos mais rápidos, como circuitos de pressão ou fluxo, podem exigir um tempo de atualização como uma vez a cada 250 ms. Apenas casos raros, como controle de tensão ou um spool de desenrolamento, exigem atualizações de circuitos mais rápidas a cada 10 ms ou mais rápidas.

Como a instrução PID usa uma base de tempo em seu cálculo, você precisa sincronizar a execução dessa instrução com a amostra da variável de processo (PV).

A forma mais fácil de executar a instrução PID é colocar a instrução PID em uma tarefa periódica. Defina o tempo de atualização do circuito (.UPD) igual à taxa da tarefa periódica e assegure que a instrução PID seja executada a cada varredura da tarefa periódica.

## Lógica ladder de relé

<!-- image -->

## Dica:

Para evitar o bloqueio do PID com valores internos de ponto de flutuação, assegure que PV não é INF ou NAN antes de invocar a instrução como: XIC (PC\_timer.DN) MOV(Local:0:1.Ch0Data, Local:0:1.Ch0Data) XIO(S:V) PID(...)

## Texto estruturado

PID(TIC101,Local:0:I.Ch0Data,Local:0:I.Ch1Data, Local:1:O.Ch4Data,0,Local:1:I.Ch4InHold, Local:1:I.Ch4Data);

Ao usar uma tarefa periódica, assegure que a entrada analógica usada para a variável de processo seja atualizada ao processador em uma taxa que seja significativamente mais rápida do que a taxa da tarefa periódica. Idealmente, a variável de processo deve ser enviada ao processador pelo menos cinco a 10 vezes mais rápida do que a taxa da tarefa periódica. Isso minimiza a diferença de tempo entre amostras reais da variável de processo e a execução do circuito PID. Por exemplo, se o circuito PID estiver em uma tarefa periódica de 250 ms, use um tempo de atualização do circuito de 250 ms (.UPD = .25) e configure o módulo de entrada analógica para produzir dados pelo menos a cada 25 a 50 ms.

Outro método menos preciso de executar uma instrução PID é colocar a instrução em uma tarefa contínua e usar um bit executado do temporizador para disparar a execução da instrução PID.

## Lógica ladder de relé

<!-- image -->

Para evitar o bloqueio do PID com valores internos de ponto de flutuação, assegure que PV não é INF ou NAN antes de invocar a instrução como:

```
Dica: XIC (PC_timer.DN) MOV(Local:0:1.Ch0Data, Local:0:1.Ch0Data) XIO(S:V) PID(...)
```

## Texto estruturado

PID\_timer.pre := 1000

TONR(PID\_timer);

IF PID\_timer.DN THEN PID(TIC101,Local:0:I.Ch0Data,Local:0:I.Ch1Data,

Local:1:O.Ch0Data,0,Local:1:I.Ch0InHold,

Local:1:I.Ch0Data);

END\_IF;

## Dica:

```
Para evitar o bloqueio do PID com valores internos de ponto de flutuação, assegure que PV não é INF ou NAN antes de invocar a instrução como: XIC (PC_timer.DN) MOV(Local:0:1.Ch0Data, Local:0:1.Ch0Data) XIO(S:V) PID(...)
```

Nesse método, o tempo de atualização do circuito da instrução PID deve ser definido igual à pré-definição do temporizador. Como no caso de usar uma tarefa periódica, você deve definir o módulo de entrada analógica para produzir a variável de processo a uma taxa significativamente mais rápida do que o tempo de atualização do circuito. Você deve usar apenas o método do temporizador de execução PID para circuitos com tempos de atualização do circuito que sejam pelo menos diversas vezes maiores do que o tempo de execução de pior caso para a sua tarefa contínua.

A forma mais precisa de executar uma instrução PID é usar o recurso de amostra de tempo real (RTS) dos módulos de entrada analógica de 1756. O módulo de entrada analógica faz amostras das suas entradas na taxa de amostragem em tempo real que você configura ao definir o módulo. Quando o período de amostra em tempo real do módulo expirar, ela atualiza as suas entradas e atualiza uma data/hora em progresso (representada pelo membro .RollingTimestamp da estrutura de dados de entrada analógica) produzida pelo módulo.

A data/hora varia de 0 a 32.767 ms. Monitore a data/hora. Quando ela mudar, uma nova amostra de variável de processo foi recebida. Toda vez que uma data/hora mudar, execute a instrução PID uma vez. Como a amostra da variável de processo é impulsionada pelo modo de entrada analógica, o tempo de amostra de entrada é muito preciso e o tempo de atualização do circuito usado pela instrução PID deve ser definido igual ao tempo de RTS do módulo de entrada analógica.

Para assegurar que você não perdeu amostras da variável de processo, execute sua lógica a uma taxa mais rápida do que o tempo de RTS. Por exemplo, se o tempo de RTS for 250 ms, você poderia colocar a lógica de PID em uma tarefa periódica que é executa a cada

100 ms para assegurar que você nunca perca uma amostra. Você poderia até colocar a lógica de PID em uma tarefa contínua, contanto que você assegure que a lógica seja atualizada com mais frequência do que a cada 250 ms.

Um exemplo do método RTS de execução é mostrado abaixo. A execução da instrução PID depende do recebimento de novos dados de entrada analógica. Se o módulo de entrada analógica falhar ou for removido, o controlador para de receber data/hora em progresso e o circuito de PID para de ser executado. Você deve monitorar o bit de status da entrada analógica de PV e, se mostrar um status incorreto, force o circuito no modo manual de software, e execute o circuito em cada varredura. Isso permite que o operador ainda manualmente altere a saída do circuito PID.

## Lógica ladder de relé

<!-- image -->

## Texto estruturado

IF (Local:0:I.Ch0Fault) THEN TIC101.SWM [:=] 1;

ELSE TIC101.SWM := 0; END\_IF;

IF (Local:0:I.RollingTimestamp&lt;&gt;PreviousTimestamp) OR (Local:0:I.Ch0Fault) THEN

PreviousTimestamp := Local:0:I.RollingTimestamp; PID(TIC101,Local:0:I.Ch0Data,Local:0:I.Ch1Data,

Local:1:O.Ch0Data,0,Local:1:I.Ch0InHold,

## Definir a zona morta (PID)

Local:1:I.Ch0Data);

## END\_IF;

A zona morta ajustável permite a seleção de um erro acima e abaixo do ponto de ajuste onde a saída não sofre alteração, desde que o erro permaneça nesta faixa. Esta zona morta permite que você controle o nível de combinação entre a variável de processo e o ponto de ajuste sem alterar a saída. A zona morta também ajuda a minimizar o desgaste em seu dispositivo de controle final.

<!-- image -->

O cruzamento zero é o controle da zona morta que permite que a instrução use o erro para fins computacionais, à medida que a variável de processo cruza a zona morta até que a mesma variável de processo cruze o ponto de ajuste. Uma vez que a variável de processo cruza o ponto de ajuste (o erro cruza zero e muda sinal) e desde que a variável de processo permaneça na zona morta, a saída não é alterada.

A zona morta se estende acima e abaixo do ponto de ajuste no valor que você especificar. Digite zero para inibir a zona morta. A zona morta tem as mesmas unidades colocadas em escala que o ponto de ajuste. Use a zona morta sem o recurso de cruzamento zero selecionando Sem cruzamento zero para zona morta (No zero crossing for deadband) na guia Configuração (Configuration) ou defina o bit .NOZC na estrutura PID.

Se você estiver usando a zona morta, a variável de controle deve ser REAL ou ela é forçada a zero quando o erro estiver dentro da zona morta.

## Para inibir a zona morta:

-  Digite zero (0):

A zona morta tem as mesmas unidades colocadas em escala que o ponto de ajuste.

## Para usar a zona morta sem o recurso de cruzamento zero:

-  Selecione Sem cruzamento zero para a zona morta (No zero crossing for deadband) na guia Configuração (Configuration) ou defina o bit .NOZC na estrutura PID.

Se você estiver usando a zona morta, a variável de controle deve ser REAL ou ela é forçada a 0 quando o erro estiver dentro da zona morta.

## Usando a limitação de saída (PID)

Defina um limite de saída (percentagem de saída) na saída de controle. Quando a instrução detecta que a saída atingiu um limite, ela define um bit de alarme e impede que a saída exceda o limite inferior ou superior.

## Instruções trigonométricas

As instruções trigonométricas avaliam as operações aritméticas usando operações trigonométricas.

## Instruções disponíveis

## Diagrama ladder, Bloco de funções e Texto estruturado

| SIN    | ATN,  ATAN   | COS    | TAN    | ASN,  ASIN   | ACS/ASO S   |
|--------|--------------|--------|--------|--------------|-------------|

| Se você desejar:                    | Use esta instrução:    |
|-------------------------------------|------------------------|
| Obter o seno de um valor. SIN       |                        |
| Obter o cosseno de um  valor.       | COS                    |
| Obter a tangente de um  valor.      | TAN                    |
| Obter o arco-seno de um  valor.     | ASN                    |
| Obter o arco cosseno de um  valor.  | ACS                    |
| Obter o arco-tangente de  um valor. | ATN                    |

É possível misturar tipos de dados, mas a perda de precisão e erro de arredondamento podem ocorrer e a execução da instrução pode levar mais tempo. Verifique o bit S:V para ver se o resultado foi truncado.

Os tipos de dados em negrito indicam ótimos tipos de dados. Uma instrução é executada mais rápido e requer menos memória se todos os operandos da instrução usarem o mesmo tipo de dados otimizado, geralmente DINT ou REAL.

Uma instrução trigonométrica é executada uma vez sempre que a instrução passa por varredura, desde que rung-condition-in seja verdadeira. Se você quiser que a instrução seja avaliada apenas uma vez, use uma instrução ONS para disparar a instrução trigonométrica.

## Instruções trigonométricas

## Consulte também

Instruções do temporizador e do contador na página 103

Instruções especiais na página 679

Instruções do sequenciador na página 605

Instruções de controle do programa na página 620

Instruções lógicas/de movimento na página 429

As instruções trigonométricas avaliam as operações aritméticas usando operações trigonométricas.

## Instruções disponíveis

## Diagrama ladder, Bloco de funções e Texto estruturado

<!-- image -->

| SIN    | ATN,  ATAN   | COS    | TAN    | ASN,  ASIN   | ACS/ASO S   |
|--------|--------------|--------|--------|--------------|-------------|

| Se você desejar:                    | Use esta instrução:    |
|-------------------------------------|------------------------|
| Obter o seno de um valor. SIN       |                        |
| Obter o cosseno de um valor. COS    |                        |
| Obter a tangente de um valor. TAN   |                        |
| Obter o arco-seno de um  valor.     | ASN                    |
| Obter o arco cosseno de um  valor.  | ACS                    |
| Obter o arco-tangente de um  valor. | ATN                    |

É possível misturar tipos de dados, mas a perda de precisão e erro de arredondamento podem ocorrer e a execução da instrução pode levar mais tempo. Verifique o bit S:V para ver se o resultado foi truncado.

Os tipos de dados em negrito indicam ótimos tipos de dados. Uma instrução é executada mais rápido e requer menos memória se todos os operandos da instrução usarem o mesmo tipo de dados otimizado, geralmente DINT ou REAL.

Uma instrução trigonométrica é executada uma vez sempre que a instrução passa por varredura, desde que rung-condition-in seja verdadeira. Se você quiser que a instrução seja avaliada apenas uma vez, use uma instrução ONS para disparar a instrução trigonométrica.

## Cosseno do arco (ACS, ACOS)

## Consulte também

Instruções do temporizador e do contador na página 103

Instruções especiais na página 679

Instruções do sequenciador na página 605

Instruções de controle do programa na página 620

Instruções lógicas/de movimento na página 429

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução ACS pega o arco cosseno do valor de Source e armazena o resultado no Destination (em radianos).

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

dest := ACOS(source);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados.

## Diagrama ladder

|                                   | Operando Tipo Formato Descrição    |                                 |
|-----------------------------------|------------------------------------|---------------------------------|
| Source SINT  INT  DINT  REAL      | Imediato  tag                      | encontre o cosseno desse  valor |
| Destination SINT  INT  DINT  REAL |                                    | tag tag a armazenar o resultado |

## Texto estruturado

|                              | Operando Tipo Formato Descrição    |                                 |
|------------------------------|------------------------------------|---------------------------------|
| Source SINT  INT  DINT  REAL | imediato  tag                      | encontre o cosseno desse  valor |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

Use ACOS como uma função. Essa função calcula o arco cosseno de origem e retorna o resultado REAL.

## Bloco de funções

| Operando Tipo    | Formato Descrição                                    |
|------------------|------------------------------------------------------|
|                  | ACS tag FBD_MATH_ADVANCED Estrutura Estrutura de ACS |

## Estrutura de FBD\_MATH\_ADVANCED

| Parâmetro de  entrada    | Tipo de  dados    | Descrição                                                                                                               |
|--------------------------|-------------------|-------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                   | Entrada Habilitar. Se eliminado, a  instrução não será executada, e as saídas  não são atualizadas.  Padrão é definido. |
|                          |                   | Source REAL Entrada para a instrução matemática.                                                                        |

| Parâmetro de  saída    | Tipo de  dados    | Descrição                                           |
|------------------------|-------------------|-----------------------------------------------------|
|                        |                   | EnableOut BOOL Indica se instrução está habilitada. |
| Dest                   |                   | REAL Resultado da instrução matemática.             |

## Descrição

A instrução ACS pega o arco do valor de Source e armazena e retorna o resultado REAL no Destination (em radianos). Source deve ser maior do que ou igual a -1, e menor do que ou igual a 1. O valor resultante no Destination é maior do que ou igual a 0 ou menor do que ou igual a pi. Se Source for menor do que -1 ou maior do que 1, então Destination é definido para NAN.

É possível usar ACS como um operador em expressões ladder; você pode usar um ACOS como um operador em declarações de Texto estruturado.

## Afeta sinalizadores de status de operações matemáticas

| Controladores                         | Afeta o sinalizador de status de operações  matemáticas                  |
|---------------------------------------|--------------------------------------------------------------------------|
| ControlLogix 5580                     | Condicional, consulte Sinalizadores de status  de operações matemáticas. |
| CompactLogix 5370,  ControlLogix 5570 | Sim                                                                      |

## Falhas maiores/menores

Se o destino estiver definido para NAN, um transbordamento com sua falha menor condicional será gerado.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                                                       |
|-----------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                                                                                                     |
| Rung-condition-in é falsa N/A                                                                                         |
| Rung-condition-in é  verdadeira  O controlador calcula o arco cosseno da  Source e coloca o resultado no Destination. |
| Pós-varredura N/A                                                                                                     |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                                   |
|                                    | Tag.EnableIn é falso. EnableOut é eliminado como falso                                                            |
| Tag.EnableIn é  verdadeiro         | EnableOut é definido como verdadeiro. Se o  bloco gerar um transbordamento, EnableOut  será eliminado como falso. |

| Primeira varredura da  instrução    | N/A    |
|-------------------------------------|--------|
| Primeira execução da  instrução     | N/A    |
| Pós-varredura N/A                   |        |

## Texto estruturado

| Condição/estado A ção realizada    |                                                                                      |
|------------------------------------|--------------------------------------------------------------------------------------|
| Pré-varredura                      | N/A.                                                                                 |
| Execução normal                    | O controlador calcula o arco cosseno da  Source e coloca o resultado no Destination. |
| Pós-varredura N/A                  |                                                                                      |

## Exemplo

## Diagrama ladder

<!-- image -->

## Texto estruturado

result := ACOS(value);

## Consulte também

Instruções de trigonometria na página 724

Atributos comuns na página 879

Sinalizadores de status de operações matemáticas na página 879

Sintaxe de texto estruturado na página 912

## Seno do arco (ASN, ASIN)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução ASN pega o arco seno do valor de Source e armazena o resultado no Destination (em radianos).

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

dest :=ASIN(source);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

## Diagrama ladder

|                                   | Operando Tipo Formato Descrição    |                                   |
|-----------------------------------|------------------------------------|-----------------------------------|
| Source SINT  INT  DINT  REAL      | Imediato  tag                      | encontra o arco seno desse  valor |
| Destination SINT  INT  DINT  REAL |                                    | tag tag a armazenar o resultado   |

## Texto estruturado

|                              | Operando Tipo Formato Descrição    |                                   |
|------------------------------|------------------------------------|-----------------------------------|
| Source SINT  INT  DINT  REAL | imediato  tag                      | encontra o arco seno desse  valor |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

Use ASIN como uma função. Essa função calcula o arco seno de origem e retorna o resultado REAL.

## Bloco de funções

| Operando Tipo    | Operando Tipo                       | Formato Descrição    |
|------------------|-------------------------------------|----------------------|
|                  | ASN tag FBD_MATH_ADVANCED Estrutura | Estrutura de  ASN    |

## Estrutura de FBD\_MATH\_ADVANCED

| Parâmetro  de entrada    | Tipo de dados Descrição    |                                                                                                                        |
|--------------------------|----------------------------|------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                            | Entrada Habilitar. Se falso, a  instrução não será executada e as  saídas não serão atualizadas.  Padrão é verdadeiro. |
| Source REAL              |                            | Entrada para a instrução matemática. Válido = qualquer flutuação                                                       |

| Parâmetro  de saída    | Tipo de dados Descrição                             |
|------------------------|-----------------------------------------------------|
|                        | EnableOut BOOL Indica se instrução está habilitada. |
|                        | Dest REAL Resultado da instrução.                   |

## Descrição

A instrução ASN computa o arco seno do valor de Source e armazena e retorna o resultado REAL no Destination (em radianos). Source deve ser maior do que ou igual a -1, e menor do que ou igual a 1. O valor resultante no Destination é maior do que ou igual a -pi/2 e menor do que ou igual a pi/2. Se Source for menor do que -1 ou maior do que 1, então Destination é definido para NAN.

É possível usar ASN como um operador em expressões ladder; você pode usar um ASIN como um operador em declarações de Texto estruturado.

A instrução oferece maior precisão com relação a controladores legados para melhores resultados.

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                       | Afeta o sinalizador de status  de operações matemáticas                    |
|---------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580 | Condicional, consulte  Sinalizadores de status de  operações matemáticas . |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact  GuardLogix 5370 e GuardLogix 5570                     | Sim                                                                        |

## Falhas maiores/menores

Se o destino estiver definido para NAN, um transbordamento com sua falha menor condicional será gerado.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                           |
|-----------------------------------------------------------|
| Pré-varredura N/A                                         |
| Rung-condition-in é falsa N/A                             |
| Rung-condition-in é  verdadeira  A instrução é executada. |
| Pós-varredura N/A                                         |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                                   |
|                                    | Tag.EnableIn é falso. EnableOut é eliminado como falso                                                            |
| Tag.EnableIn é  verdadeiro         | EnableOut é definido como verdadeiro. Se o  bloco gerar um transbordamento, EnableOut  será eliminado como falso. |
| Primeira varredura da  instrução   | N/A                                                                                                               |
| Primeira execução da  instrução    | N/A                                                                                                               |
| Pós-varredura N/A                  |                                                                                                                   |

## Tangente do arco (ATN, ATAN)

## Texto estruturado

| Condição/estado A ção realizada                                                                    |
|----------------------------------------------------------------------------------------------------|
| Pré-varredura N/A.                                                                                 |
| Execução normal  O controlador calcula o arco seno da Source  e coloca o resultado no Destination. |
| Pós-varredura N/A                                                                                  |

## Exemplo

## Diagrama ladder

<!-- image -->

## Texto estruturado

result := ASIN(value);

## Consulte também

Instruções de trigonometria na página 724

Atributos comuns na página 879

Sinalizadores de status de operações matemáticas na página 879

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução ATN calcula o arco tangente do valor de Source e armazena o resultado no Destination (em radianos).

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

dest := ATAN(source);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

## Diagrama ladder

|                                   |               | Operando Tipo Formato Descrição       |
|-----------------------------------|---------------|---------------------------------------|
| Source SINT  INT  DINT  REAL      | Imediato  tag | Encontra o arco tangente desse  valor |
| Destination SINT  INT  DINT  REAL |               | tag Tag a armazenar o resultado       |

## Texto estruturado

|                              | Operando Tipo Formato Descrição    |                                       |
|------------------------------|------------------------------------|---------------------------------------|
| Source SINT  INT  DINT  REAL | Imediato  tag                      | Encontra o arco tangente desse  valor |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

Use ATAN como uma função. Essa função calcula o arco tangente de origem e retorna o resultado REAL.

## Bloco de funções

| Operando Tipo    |                                     | Formato Descrição    |
|------------------|-------------------------------------|----------------------|
|                  | ATN tag FBD_MATH_ADVANCED Estrutura | Estrutura de  ATN    |

## Estrutura de FBD\_MATH\_ADVANCED

| Parâmetro de  entrada    | Tipo de dados Descrição    |                                                                                                                        |
|--------------------------|----------------------------|------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                            | Entrada Habilitar. Se falso, a instrução  não será executada e as saídas não  serão atualizadas.  Padrão é verdadeiro. |
| Source REAL              |                            | Entrada para a instrução matemática.  Válido = qualquer flutuação                                                      |

| Parâmetro de  saída    | Tipo de dados Descrição                             |
|------------------------|-----------------------------------------------------|
|                        | EnableOut BOOL Indica se instrução está habilitada. |
|                        | Dest REAL Resultado da instrução.                   |

## Descrição

A instrução ATN calcula o arco tangente do valor de Source e armazena o resultado no Destination (em radianos). O valor resultante no Destination é maior do que ou igual a -pi/2 e menor do que ou igual a pi/2.

É possível usar ATN como um operador em expressões ladder; você pode usar um ATAN como um operador em declarações de Texto estruturado.

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                       | Afeta o sinalizador de status de  operações matemáticas                   |
|---------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580 | Condicional, consulte  Sinalizadores de status de  operações matemáticas. |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact  GuardLogix 5370 e GuardLogix 5570                     | Sim                                                                       |

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                                                        |
|------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                                                                                                      |
| Rung-condition-in é falsa N/A                                                                                          |
| Rung-condition-in é  verdadeira  O controlador calcula o arco tangente da  Source e coloca o resultado no Destination. |
| Pós-varredura N/A                                                                                                      |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                                   |
|                                    | Tag.EnableIn é falso. EnableOut é eliminado como falso                                                            |
| Tag.EnableIn é  verdadeiro         | EnableOut é definido como verdadeiro. Se o  bloco gerar um transbordamento, EnableOut  será eliminado como falso. |
| Primeira varredura da  instrução   | N/A                                                                                                               |
| Primeira execução da  instrução    | N/A                                                                                                               |
| Pós-varredura N/A                  |                                                                                                                   |
