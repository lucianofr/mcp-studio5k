---
type: Instruction
title: "REAL para String (RTOS)"
description: "A instrução RTOS produz a representação ASCII de um valor de REAL."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L21303-L21372"
---

## REAL para String (RTOS)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução RTOS produz a representação ASCII de um valor de REAL.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

RTOS(Source,Dest);

## Operandos

## Diagrama ladder e Texto estruturado

| Operando Tipo Formato Descrição Notas    | Operando Tipo Formato Descrição Notas    |     |                                       |                                                                                                          |
|------------------------------------------|------------------------------------------|-----|---------------------------------------|----------------------------------------------------------------------------------------------------------|
| Source REAL Tag                          |                                          |     | A tag que  contém o  valor de  REAL.  |                                                                                                          |
| Destination                              | Tipo  de  string                         | Tag | A tag a  armazenar o  valor de  ASCII | Tipos de strings são:    Tipo de dado de STRING  padrão    Qualquer tipo de string novo  que você cria |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões.

## Descrição

A instrução RTOS converte a Source em uma string de caracteres ASCII e coloca o resultado no Destination.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Tipo Code Causa    |                                              | Método de recuperação                                                                                                                             |
|--------------------|----------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------|
| 4 52               | A string de saída é  maior do que o  destino | Crie um novo tipo de string  que seja grande suficiente  para a string de saída. Use o  novo tipo de string como o  tipo de dados para o destino. |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                           |
|-----------------------------------------------------------|
| Pré-varredura N/A                                         |
| Rung-condition-in é falsa N/A                             |
| Rung-condition-in é  verdadeira  A instrução é executada. |
| Pós-varredura N/A                                         |

## Texto estruturado

| Condição A      | ção                                                                              |
|-----------------|----------------------------------------------------------------------------------|
| Pré-varredura   | Consulte Pré-varredura na tabela de  Diagrama ladder anterior                    |
| Execução normal | Consulte rung-condition-in é  verdadeira na tabela de Diagrama  ladder anterior. |
| Pós-varredura   | Consulte Pós-varredura na tabela de  Diagrama ladder anterior                    |

## Exemplos

Quando send\_data for definido, a instrução RTOS converte o valor em data\_1 em uma string de caracteres ASCII e coloca o resultado em data\_1\_ascii. Degraus subsequentes inserem ou concatenam o data\_1\_ascii com outras strings para produzir uma mensagem completa para um terminal de exibição.
