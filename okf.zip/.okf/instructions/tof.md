---
type: Instruction
title: "Temporizador de atraso desativado (TOF)"
description: "A instrução TOF é um temporizador não retentivo que acumula tempo quando a instrução é habilitada (rung-condition-in é falsa)."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L2977-L3077"
---

## Temporizador de atraso desativado (TOF)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução TOF é um temporizador não retentivo que acumula tempo quando a instrução é habilitada (rung-condition-in é falsa).

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

## Diagrama ladder

| Tipo de  dados    | Operando  Formato Des crição             |
|-------------------|------------------------------------------|
|                   | Timer TIMER tag Estrutura de Timer       |
|                   | Preset DINT imediato Valor de Timer.PRE. |
|                   | Accum DINT imediato Valor de Timer.ACC.  |

## Estrutura de TIMER

| Mnemônico    | Tipo de  dados    | Descrição                                                                                        |
|--------------|-------------------|--------------------------------------------------------------------------------------------------|
|              | .EN BOOL          | O bit de habilitação contém rung-condition-in  quando a instrução foi executada pela última vez. |

| .TT BOOL    | O bit de temporização quando definido indica que  a operação de temporização está em  processamento.                                                           |
|-------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------|
| .DN BOOL    | O bit executado quando eliminado indica que a  operação de temporização está completa (ou  interrompida).                                                      |
| .PRE DINT   | O valor predefinido especifica o valor ( unidades  de 1 milissegundo) que o valor acumulado precisa  alcançar antes de a instrução indicar que foi  executado. |
| .ACC DINT   | O valor acumulado especifica o número de  milissegundos que se passaram desde que a  instrução TOF foi habilitada.                                             |

## Descrição

A instrução TOF acumula tempo até:

-  O temporizador está desabilitado
-  O temporizador completa

A base de tempo é sempre 1 milissegundo. Por exemplo, para um temporizador de 2 segundos, insira 2.000 para o valor .PRE.

O temporizador eliminará o bit .DN para falso quando o temporizador completar.

Quando habilitado, o temporizador poderá ser pausado eliminando o bit .DN para falso e retomado pela definição do bit .DN como verdadeiro.

<!-- image -->

## Como o temporizador opera

Um temporizador é executado subtraindo-se o horário da sua última varredura do horário atual:

ACC = ACC + (current\_time - last\_time\_scanned)

Após isso atualizar o ACC, o temporizador define last\_time\_scanned = current\_time. Isso torna o temporizador pronto para a próxima varredura.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha maior ocorrerá se: Tipo de falha Código de falha    |    |    |
|---------------------------------------------------------------|----|----|
| .PRE < 0                                                      |  4 | 34 |
| .ACC < 0                                                      |  4 | 34 |

Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                                                                          |
|------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                    | Pré-varredura O bit .EN é eliminado para falso.  O bit .TT é eliminado para falso.  O bit .DN é eliminado para falso.  O valor .ACC é definido como igual ao  valor .PRE.                                |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como  Rung-condition-in  Consulte o fluxograma TOF (Falso).                                                                                                                   |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como  Rung-condition-in  O bit .EN é definido como verdadeiro.  O bit .TT é eliminado para falso.  O bit .DN é definido como verdadeiro.  O valor .ACC é eleminado para zero. |
|                                    | Pós-varredura O bit .EN é eliminado para falso.  O bit .TT é eliminado para falso.  O bit .DN é eliminado para falso.  O valor .ACC é definido como igual ao  valor .PRE.                                |

Fluxograma TOF (Falso)

<!-- image -->
