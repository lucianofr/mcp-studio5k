---
type: Instruction
title: "Detecção diagnóstica (DDT)"
description: "A instrução DDT compara bits em uma matriz de Source com os bits em uma matriz de Reference para encontrar bit não correspondente."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L16456-L16590"
---

## Detecção diagnóstica (DDT)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução DDT compara bits em uma matriz de Source com os bits em uma matriz de Reference para encontrar bit não correspondente. O local do bit não correspondente é, então, registrado e o bit não correspondente de Reference é alterado para corresponder ao bit Source.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados.

## Diagrama ladder

|                       |                   | Operando Tipo (Type) Format Descrição (Description)                            |
|-----------------------|-------------------|--------------------------------------------------------------------------------|
| Origem DINT           | tag de  matriz    | Matriz para comparar à referência  não use CONTROL.POS no subscrito            |
| Referência DINT       | tag de  matriz    | Matriz para comparar à origem  não use CONTROL.POS no subscrito                |
| Result DINT           | tag de  matriz    | Matriz para armazenar os resultados  não use CONTROL.POS no subscrito          |
| Cmp.  Controle        | CONTROL estrutura | Estrutura de controle para a  comparação                                       |
| Comprimento  (Length) |                   | DINT immediate Número de bits para comparar                                    |
|                       |                   | Somente DINT immediate Posição atual na origem  valor inicial tipicamente 0    |
|                       |                   | Result control CONTROL estrutura Estrutura de controle para os resultados      |
| Comprimento  (Length) | DINT immediate    | Número de locais de armazenamento no  resultado                                |
|                       |                   | Somente DINT immediate Posição atual no resultado  valor inicial tipicamente 0 |

## Importante:

Use tags diferentes para a estrutura de controle de comparação e a estrutura de controle de resultado. Usar a mesma tag para ambos poderia resultar em operação imprevisível, possivelmente causando dano ao equipamento e/ou lesão ao pessoal.

## Estrutura de COMPARE

| Mnemônico  Tipo de  dados  (Data Type)   | Descrição (Description)                                                                                                                                                                                  |
|------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| .EN BOOL                                 | O bite de habilitação indica que a instrução DDT está  habilitada.                                                                                                                                       |
| .DN BOOL                                 | O bit executado é definido quando a instrução DDT  compara o último bit nas matrizes de Source e  Reference.                                                                                             |
| .FD BOOL                                 | O bit encontrado é definido cada vez que a instrução  DDT registrar uma não correspondência (operação  uma de cada vez) ou após registrar todas as não  correspondências (operação todas por varredura). |
| .IN                                      | BOOL O bit de inibição indica o modo de pesquisa de DDT.  0 = todo modo  1 = uma não correspondência em um modo de tempo                                                                                 |
| .ER BOOL                                 | O bit de erro é definido quando POS ou LEN é  inválido.                                                                                                                                                  |
| .LEN DINT                                | O valor de comprimento identifica o número de bits  para comparar.                                                                                                                                       |
|                                          | .POS DINT O valor de posição identifica o bit atual.                                                                                                                                                     |

## Estrutura de RESULT

| Mnemônico  Tipo de  dados (Data  Type)    | Descrição (Description)                                                                     |
|-------------------------------------------|---------------------------------------------------------------------------------------------|
| .DN BOOL                                  | O bit executado é definido quando a matriz de Result  está cheia.                           |
| .LEN DINT                                 | O valor de comprimento identifica o número de locais  de armazenamento na matriz de Result. |
| .POS DINT                                 | O valor de posição identifica a posição atual na  matriz de Result.                         |

## Descrição (Description)

Quando habilitada, a instrução DDT compara os bits na matriz de Source com os bits na matriz de Reference, registra o número de bits de cada não correspondência na matriz de Result, e altera o valor do bit Reference para corresponder ao valor do bit Source correspondente.

| Importante:    | A instrução DDT opera em memória contígua. Você deve testar e  confirmar que a instrução não altera os dados que você não deseja  alterar.    |
|----------------|-----------------------------------------------------------------------------------------------------------------------------------------------|

A diferença entre as instruções DDT e FBC é que toda vez que a instrução DDT encontra uma não correspondência, a instrução DDT altera o bit de referência para corresponder ao bit de origem. A instrução FBC não altera o bit de referência.

Se a instrução tentar ler além do fim de uma matriz, a instrução definirá o bit .ER e gerará uma falha maior.

## Selecione o modo de pesquisa

| Se você quiser  detectar:         | Selecione este modo:                                                                                                                                                                                                                                                                                                                     |
|-----------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Uma não  correspondência por  vez | Definir o bit .IN na estrutura de comparação de CONTROL.  Toda vez que EnableIn ir de falso para verdadeiro, a instrução  DDT pesquisa a próxima não correspondência entre as  matrizes de Source e Reference. Após encontrar uma não  correspondência, a instrução para, define o bit .FD e registra a  posição da não correspondência. |
| Todas as não  correspondências    | Elimina o bit .IN na estrutura de comparação de CONTROL.  Toda vez que EnableIn ir de falso para verdadeiro, a instrução  DDT pesquisa todas as não correspondências entre as  matrizes de Source e Reference.                                                                                                                           |

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha maior ocorrerá se:                 | Tipo de  falha    | Código de  falha    |
|----------------------------------------------|-------------------|---------------------|
| result.POS > tamanho de matriz de  resultado |                   | 4 20                |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                            |
|------------------------------------|--------------------------------------------|
| Pré-varredura                      | Consulte o fluxograma DDT  (Pré-varredura) |
| Rung-condition-in é  falsa         | Consulte o fluxograma DDT (Falso)          |
| Rung-condition-in é  verdadeira    | Consulte o fluxograma DDT (Verdadeiro)     |
| Pós-varredura N/D                  |                                            |

## Fluxograma DDT (Pré-varredura)

<!-- image -->

## Fluxograma DDT (Falso)

<!-- image -->

## Fluxograma DDT (Verdadeiro)

<!-- image -->

## Fluxograma DDT (Verdadeiro) - Continuação

<!-- image -->

## Exemplos

## Diagrama ladder

Instruções especiais na página 679

DTR na página 680

FBC na página 692

Atributos comuns na página 879

Conversões de dados na página 883

<!-- image -->
