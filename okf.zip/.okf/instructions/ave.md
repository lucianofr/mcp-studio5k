---
type: Instruction
title: "Média de arquivo (AVE)"
description: "Operação aritmética: (matriz * matriz ) a elemento"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L12509-L12606"
---

## Média de arquivo (AVE)

## Exemplo 8:

Operação aritmética: (matriz * matriz ) a elemento

<!-- image -->

Quando habilitada, a instrução FAL multiplica o valor atual de array\_1 pelo valor atual de array\_3 e armazena o resultado em value\_1. A instrução FAL usa o modo incremental, de modo que somente um par de valores de matriz é multiplicado cada vez que a instrução é habilitada. Na próxima vez que a instrução for habilitada, ela substituirá value\_1.

<!-- image -->

## Consulte também

Instruções de arquivo/diversas na página 493

Operadores válidos na página 366

Índice por meio de matrizes na página 893

Conversões de dados na página 883

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução AVE calcula a média de um conjunto de valores.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados.

## Diagrama ladder

| Operando Tipo Formato Descrição    |                          |                                                                                                                                                           |
|------------------------------------|--------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|
| Array Tag SINT  INT  DINT  REAL    | tag                      | Encontra a média de valores nessa  matriz  especifica o primeiro elemento do  grupo de elementos para calcular a  média  Não use CONTROL.POS no subscrito |
| Dimension to  vary                 | DINT imediato  (0, 1, 2) | Qual dimensão usar  a ordem das dimensões é:  matriz[0,1,2]                                                                                               |
| Destination SINT  INT  DINT  REAL  |                          | tag Resultado da operação                                                                                                                                 |
|                                    |                          | Control CONTROL tag Estrutura de controle da operação                                                                                                     |
|                                    | Length DINT imediato     | Número de elementos da matriz para  calcular a média                                                                                                      |
|                                    | Position DINT imediato   | Deslocamento para a matriz  especificada que identifica o elemento  atual que a instrução está acessando. o valor inicial costuma ser 0                   |

## Descrição

A instrução AVE calcula a média de um conjunto de valores.

| Importante:    | O Length não deve fazer a instrução exceder a  Dimension to vary especificada. Se isso acontecer,  o Destination estará incorreto. Para obter mais  informações, consulte Visualizando uma matriz  como um bloco de memória.    |
|----------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Se ocorrer um transbordamento durante a avaliação da expressão, as instruções lerão além do fim de uma matriz, a instrução definirá o bit ER e interromperá a execução

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                        | Afeta sinalizadores de status  de operações matemáticas                   |
|----------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------|
| Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e GuardLogix  5580 | Condicional, consulte  Sinalizadores de status de  operações matemáticas. |
| Controladores CompactLogix  5370, ControlLogix 5570,  Compact GuardLogix 5370 e  GuardLogix 5570                     | Sim                                                                       |

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                                                               |
|------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | O bit .EN é eliminado.  O bit .DN é eliminado.  Se o bit .ER for zero durante a  pré-varredura, todos os bits de  controle (.DN, .EN, .EU, .EM, .UL,  .IN e .FD) serão eliminados para  zero. |
|                                    | Rung-condition-in é falsa. Consulte o fluxograma AVE (Falso)                                                                                                                                  |
| Rung-condition-in é  verdadeira.   | A instrução AVE calcula a média  adicionando todos os elementos  especificados na matriz e dividindo  pelo número de elementos.                                                               |
| Pós-varredura N/A.                 |                                                                                                                                                                                               |

Fluxograma AVE (Falso)

<!-- image -->

Exemplo 1

<!-- image -->

## Diagrama ladder

<!-- image -->
