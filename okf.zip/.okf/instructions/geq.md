---
type: Instruction
title: "Maior que ou Igual a (GEQ)"
description: "if value\_3 &gt; 'I am EQUAL' then"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L7043-L7221"
---

## Maior que ou Igual a (GEQ)

if value\_3 &gt; 'I am EQUAL' then

<!-- formula-not-decoded -->

## Consulte também

Sintaxe de texto estruturado na página 912

Conversões de dados na página 883

Índice por meio de matrizes na página 893

Valores imediatos na página 882

Funções FBD na página 425

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

Quando habilitada, a instrução GEQ e o operador testam se Source A é maior que ou igual à Source B.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

<!-- image -->

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

Dica:

Use o operador com uma expressão para obter o mesmo resultado. Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões e atribuições no texto estruturado.

## Operandos

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

## Comparação numérica

| Operando  Tipo de dados  (Data Type)  Controladores  CompactLogix  5370,  ControlLogix  5570, Compact  GuardLogix  5370 e  GuardLogix  5570    | Tipo de dados  (Data Type)  Controladores  CompactLogix  5380,  CompactLogix  5480, ControlLogix  5580, Compact  GuardLogix 5380 e  GuardLogix 5580    | Format        | Descrição  (Description)           |
|------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------|---------------|------------------------------------|
| Source A SINT  INT  DINT  REAL                                                                                                                 | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                          | imediato  tag | Valor para testar  contra Source B |
| Source B SINT  INT  DINT  REAL                                                                                                                 | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                          | imediato  tag | Valor para testar  contra Source A |

## Comparação de strings

Dica:

Literais de string imediatos apenas são aplicáveis à Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operando  Tipo de dados  (Data Type)    | Format                       | Descrição  (Description)            |
|-----------------------------------------|------------------------------|-------------------------------------|
| Source A Tipo de string                 | valor literal  imediato  tag | String para testar  contra Source B |
| Source B Tipo de string                 | valor literal  imediato  tag | String para testar  contra Source A |

## Diagrama de bloco da função

Bloco FBD

| Operando    | Tipo de dados  (Data Type)    | Format    | Descrição  (Description)             |
|-------------|-------------------------------|-----------|--------------------------------------|
|             |                               |           | GEQ FBD_COMPARE tag Estrutura de GEQ |

## Estrutura de FBD\_COMPARE

Função FBD

| Membros de  entradas    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                |
|-------------------------|-------------------------------|------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL           |                               | Entrada Habilitar. Se falso, a instrução  não será executada e as saídas não  serão atualizadas.  Padrão é verdadeiro. |
| SourceA REAL            |                               | Valor para testar contra SourceB                                                                                       |
| SourceB REAL            |                               | Valor para testar contra SourceA                                                                                       |

| Membros de  saída    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                         |
|----------------------|-------------------------------|---------------------------------------------------------------------------------------------------------------------------------|
| EnableOut BOOL       |                               | Indica se a instrução está habilitada.                                                                                          |
|                      | Dest BOOL                     | Definido como verdadeiro quando  SourceA é maior ou igual a SourceB.  Eliminado para falso quando SourceA  é menor que SourceB. |

Dica: A função FBD é aplicável apenas a Controladores Compact GuardLogix 5380 e GuardLogix 5580.

| Operandos de entrada  (pinos esquerdos)    | Tipo de dados  (Data Type)                              | Descrição (Description)            |
|--------------------------------------------|---------------------------------------------------------|------------------------------------|
| SourceA (topo) SINT                        | INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL | Valor para testar contra  SourceB. |

| SourceB (fundo) SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL    | Valor para testar contra  SourceA.    |
|----------------------------------------------------------------------------------|---------------------------------------|

| Operando de saída  (Pino direito)    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                          |
|--------------------------------------|-------------------------------|----------------------------------------------------------------------------------------------------------------------------------|
|                                      | Dest BOOL                     | Definido como verdadeiro  quando SourceA é maior ou  igual a SourceB. Eliminado  para falso quando SourceA  é menor que SourceB. |

Consulte Funções FBD .

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Consulte Fluxograma de comparação de strings GEQ para conhecer as falhas.

Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                                                                           |
|------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                                                           |
| Rung-condition-in é falsa          | Definir Rung-condition-out como  Rung-condition-in                                                                                                                                                        |
| Rung-condition-in é  verdadeira    | Comparação numérica: Se Source A e Source B não forem NANs  e Source A for maior ou igual a Source B. Defina Rung-condition-out como  verdadeira  Caso contrário  Eliminar Rung-condition-out para falso. |

| Comparação de strings:  Consulte Fluxograma de Comparação de  Strings GEQ.  Se a saída for falsa  Eliminar Rung-condition-out para falso  Caso contrário  Defina Rung-condition-out como  verdadeira    |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pós-varredura N/D                                                                                                                                                                                       |

## Diagrama de bloco da função

Bloco FBD

| Condição/estado A ção realizada    |                                                                                                                                                                                                          |
|------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                                                          |
| EnableIn é falso                   | Defina EnableOut como EnableIn                                                                                                                                                                           |
| EnableIn é verdadeiro              | Comparação numérica: Defina EnableOut como EnableIn  Se SourceA e SourceB não forem NANs  e SourceA for maior ou igual a SourceB.  Defina Dest como verdadeiro  Caso contrário  Elimina Dest como falso. |
| Primeira execução da  instrução    | N/D                                                                                                                                                                                                      |
| Primeira varredura da  instrução   | N/D                                                                                                                                                                                                      |
| Pós-varredura N/D                  |                                                                                                                                                                                                          |

Função FBD

Dica: A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580

| Condição/estado A ção realizada    |                                                                                                                                                                          |
|------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                          |
| Varredura normal                   | Comparação numérica: Se SourceA e SourceB não forem NANs  e SourceA for maior ou igual a SourceB.  Defina Dest como verdadeiro  Caso contrário  Elimina Dest como falso. |
| Primeira execução da  instrução    | N/D                                                                                                                                                                      |
| Primeira varredura da  instrução   | N/D                                                                                                                                                                      |
| Pós-varredura N/D                  |                                                                                                                                                                          |

## Fluxograma de Comparação de Strings GEQ

<!-- image -->

## Exemplo

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

## Bloco FBD

<!-- image -->
