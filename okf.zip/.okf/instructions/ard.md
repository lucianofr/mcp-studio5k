---
type: Instruction
title: "Leitura ASCII (ARD)"
description: "Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L19709-L19833"
---

## Leitura ASCII (ARD)

Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate.

A instrução ARD remove os caracteres do buffer e os armazena no Destination.

Dica:

Instruções de Porta serial ASCII (AWT, AWA, ARD, ARL, ABL, ACB, AHL, ACL) não estão disponíveis para controladores que não têm portas seriais.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

ARD(Channel,Destination,SerialPortControl);

## Operandos

## Diagrama ladder

| Operando Tipo        | Operando Tipo                   |               | Formato Descrição Notas                                                                                                                                                                   |                                                                                                                                                                                                           |
|----------------------|---------------------------------|---------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Channel DINT         |                                 | imediato  tag | 0                                                                                                                                                                                         |                                                                                                                                                                                                           |
| Destination          | Tipo de string  SINT  INT  DINT | tag           | tag para qual os  caracteres são  movidos (isto é,  lidos):  Para um tipo de  string, digite o  nome da tag.  Para uma matriz  SINT, INT ou DINT,  digita o primeiro  elemento da matriz. | Se você desejar  comparar, converter ou  manipular os caracteres,  digite uma tag de tipo de  string.  Tipos de strings são:  tipo de dado de STRING  padrão  qualquer tipo de string  novo que você cria |
| Serial Port  Control | SERIAL_PORT _CONTROL            | tag           | tag que controla a  operação                                                                                                                                                              |                                                                                                                                                                                                           |

| Serial Port  Control  Length    | DINT imediato    | número de  caracteres a serem  movidos para o  destino (lidos)    | O Serial Port Control  Length deve ser menor  ou igual ou tamanho do  Destination.  Se você desejar definir o  Serial Port Control  Length igual ao tamanho  do Destination, digite 0.    |
|---------------------------------|------------------|-------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Characters  Read                | DINT imediato 0  |                                                                   | Durante a execução,  exibe o número de  caracteres no buffer,  incluindo o primeiro  conjunto de caracteres  de terminação.                                                               |

## Texto estruturado

| Operando Tipo                | Operando Tipo                   |                 | Formato Descrição Notas                                                                                                                                                                   |                                                                                                                                                                                                           |
|------------------------------|---------------------------------|-----------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Channel DINT                 |                                 | imediato  tag   | 0                                                                                                                                                                                         |                                                                                                                                                                                                           |
| Destination                  | Tipo de string  SINT  INT  DINT | tag             | tag para qual os  caracteres são  movidos (isto é,  lidos):  Para um tipo de  string, digite o  nome da tag.  Para uma matriz  SINT, INT ou DINT,  digita o primeiro  elemento da matriz. | Se você desejar  comparar, converter ou  manipular os caracteres,  digite uma tag de tipo de  string.  Tipos de strings são:  tipo de dado de STRING  padrão  qualquer tipo de string  novo que você cria |
| Serial Port  Control         | SERIAL_PORT _CONTROL            | tag             | tag que controla a  operação                                                                                                                                                              |                                                                                                                                                                                                           |
| Serial Port  Control  Length |                                 | DINT imediato   | número de  caracteres a serem  movidos para o  destino (lidos)                                                                                                                            | O Serial Port Control  Length deve ser menor  ou igual ou tamanho do  Destination.  Se você desejar definir o  Serial Port Control  Length igual ao tamanho  do Destination, digite 0.                    |
| Characters  Read             |                                 | DINT imediato 0 |                                                                                                                                                                                           | Durante a execução,  exibe o número de  caracteres no buffer,  incluindo o primeiro  conjunto de caracteres  de terminação.                                                                               |

Você pode especificar os valores de Serial Port Control Length e Characters Read acessando os membros .LEN e .POS da estrutura SERIAL\_PORT\_CONTROL, em vez de incluir os valores na lista de operandos.

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Estrutura de SERIAL\_PORT\_CONTROL

| Mnemônico  Tipo de  dados    | Descrição                                                                                          |
|------------------------------|----------------------------------------------------------------------------------------------------|
|                              | .EN BOOL O bite de habilitação indica que a instrução está habilitada.                             |
|                              | .EU BOOL O bit de fila indica que a instrução foi digitada na fila ASCII.                          |
| .DN BOOL                     | O bit executado indica que a instrução foi executada, mas  está assíncrona à varredura de lógica.  |
| .RN BOOL                     | O bit de execução indica que a instrução está sendo  executada.                                    |
| .EM BOOL                     | O bit vazio indica quando a instrução foi executada, mas  está síncrona com a varredura da lógica. |
|                              | .ER BOOL O bit de erro indica quando a instrução falha (erros).                                    |
|                              | .FD BOOL O bit encontrado não se aplica a esta instrução.                                          |
| .LEN DINT                    | A extensão indica o número de caracteres a serem movidos  para o destino (isto é, lidos).          |
|                              | .POS DINT A posição exibe o número de caracteres que foram lidos.                                  |
| .ERROR DINT                  | O erro contém um valor hexadecimal que indica a causa de  um erro.                                 |

## Descrição

A instrução ARD remove o número especificado de caracteres do buffer e os armazena no Destination.

-  A instrução ARD continua a ser executada até que ele remova o número especificado de caracteres (operando Serial Port Control Length).
-  Enquanto a instrução ARD estiver sendo executada, nenhuma outra instrução de porta serial ASCII é executada.

Para programar a instrução ARD, siga estas diretrizes:

1. Configure a porta serial do controlador para o modo Usuário.
2. Use o resultado de uma instrução ACB para disparar a instrução ARD. Isto impede que a instrução ARD segure a fila enquanto aguarda pelo número necessário de caracteres. Consulte o exemplo de ARD abaixo para obter mais informações.
3. 3.

Esta é uma instrução de transição: Em diagrama ladder, alterne o EnableIn de eliminado para definido toda vez que a instrução tiver que ser executada. Em texto estruturado, condicione a instrução para que ela só seja executada

em uma transição

4. Para disparar uma ação subsequente quando a instrução tiver sido concluída, examine o bit .EM.

## Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição                        | Ação do Diagrama ladder                                                |
|---------------------------------|------------------------------------------------------------------------|
| Pré-varredura N/A               |                                                                        |
| Rung-condition-in é  falsa      | N/A                                                                    |
| Rung-condition-in é  verdadeira | A instrução é executada.  EnableIn altera de eliminado  para definido. |
| Pós-varredura N/A               |                                                                        |

## Texto estruturado

| Condição          | Ação de texto estruturado                                              |
|-------------------|------------------------------------------------------------------------|
| Pré-varredura N/A |                                                                        |
| Execução normal   | A instrução é executada.  EnableIn altera de eliminado  para definido. |
| Pós-varredura N/A |                                                                        |

## Exemplos

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
ACB(o,bar_code_count); IF bar_code_count.POS >= 24 THEN
```
