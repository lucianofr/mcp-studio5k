---
type: Instruction
title: "Inserir string (INSERT)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L20663-L20778"
---

## Inserir string (INSERT)

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
IF MV_read.EM THEN FIND(MV_msg,find,1,find_pos); MV_read.EM := 0; END_IF;
```

## Consulte também

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Conversões de dados na página 883

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

Use a instrução INSERT para adicionar caracteres ASCII a uma localização especificada dentro de uma string.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

## Texto estruturado

INSERT (SourceA,SourceB,Start,Dest);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados. A instrução INSERT usa os operandos a seguir:

## Diagrama ladder e Texto estruturado

| Operando Tipo Formato Descrição Notas    | Operando Tipo Formato Descrição Notas    |               |                                                      |                                                                |
|------------------------------------------|------------------------------------------|---------------|------------------------------------------------------|----------------------------------------------------------------|
| Source A                                 | Tipo de  string                          | Tag           | String para  adicionar os  caracteres a              | Os tipos de string  são tipos de  dados de                     |
| Source B                                 | Tipo de  string                          | Tag           | String contendo  os caracteres a  serem  adicionados | STRING padrão  ou qualquer tipo  novo de string  que você cria |
|                                          | Start SINT  DINT                         | Imediato  tag | Posição em  Source A para  adicionar os  caracteres  | Digite um  número entre 1 e  o tamanho de  DATA da Source.     |
| Destination                              | Tipo de  string                          | Tag           | String para  armazenar o  resultado                  |                                                                |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Descrição

A instrução INSERT adiciona os caracteres em Source B a uma posição designada dentro de Source A e coloca o resultado no Destination.

-  O Start define onde em Source A que Source B é adicionada.
-  A menos que Source A e o Destination sejam a mesma tag, Source A permanece inalterado.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Tipo Code Causa    | Tipo Code Causa                                                                        | Método de recuperação                                                                                                                                            |
|--------------------|----------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 4 51               | O valor de LEN da  tag de string é maior  do que o tamanho  de DATA da tag de  string. | 1. Verifique se nenhuma  instrução está sendo  gravada no membro LEN  da tag de string.  2. No valor de LEN, digite o  número de caracteres  contidos na string. |
| 4 56               | O valor de Start ou  Quantity não é  válido.                                           | Verifique se o valor de  Start está entre 1 e o  tamanho de DATA da  Source.                                                                                     |

## Execução

## Diagrama ladder

| Condição                        | Ação do Diagrama ladder                                                     |
|---------------------------------|-----------------------------------------------------------------------------|
| Pré-varredura                   | Rung-condition-out é definida como  falsa.                                  |
| Rung-condition-in é falsa       | Rung-condition-out é definida como  falsa.                                  |
| Rung-condition-in é  verdadeira | A instrução é executada.  A rung-condition-out é definida  como verdadeira. |
| Pós-varredura                   | Rung-condition-out é definida como  falsa.                                  |

## Execução

## Texto estruturado

| Condição A      | ção                                                                     |
|-----------------|-------------------------------------------------------------------------|
| Pré-varredura   | Consulte Pré-varredura na tabela do  Diagrama ladder                    |
| Execução normal | Consulte rung-condition-in é  verdadeira na tabela de Diagrama  ladder. |
| Pós-varredura   | Consulte Pós-varredura na tabela  do Diagrama ladder                    |

## Exemplo

Quando temp\_high for definido, a instrução INSERT adiciona os caracteres string\_2 à posição 2 dentro de string\_1 e coloca o resultado em string\_3 .

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
IF temp_high THEN INSERT(string_1,string_2,2,string_3); temp_high := 0; END_IF;
```

## Consulte também

Instruções de string ASCII na página 825

Atributos comuns na página 879

```
Sintaxe de texto estruturado na página 912
```

Conversões de dados na página 883
