---
type: Instruction
title: "Converter para BCD (TOD)"
description: "A instrução TOD converte um valor decimal (0 Source 99.999.999) em um valor BCD e armazena o resultado no Destination."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L18602-L18734"
---

## Converter para BCD (TOD)

## Consulte também

Instruções de cálculo/matemáticas na página 369

Instruções de comparação na página 293

Instruções de bit na página 75

Instruções de string ASCII na página 825

Instruções de conversão ASCII na página 845

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução TOD converte um valor decimal (0 Source 99.999.999) em um valor BCD e armazena o resultado no Destination.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

## Diagrama ladder

|                             | Operando Tipo Formato Descrição    |                                                    |
|-----------------------------|------------------------------------|----------------------------------------------------|
| Source SINT  INT  DINT      | Imediato  tag                      | valor para converter em BCD  0  Source  99.999.999 |
| Destination SINT  INT  DINT |                                    | tag tag a armazenar o resultado                    |

## Bloco de funções

| Operando Tipo    | Formato Descrição                              |
|------------------|------------------------------------------------|
|                  | TOD tag FBD_CONVERT Estrutura Estrutura de TOD |

## Estrutura de FBD\_CONVERT

| Parâmetro de  entrada    | Tipo de dados Descrição    |                                                                                                                         |
|--------------------------|----------------------------|-------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                            | Entrada Habilitar. Se eliminado, a  instrução não será executada, e as  saídas não são atualizadas.  Padrão é definido. |
| Source DINT              |                            | Entrada para a instrução de  conversão.  Válido = qualquer inteiro                                                      |

| Parâmetro de  saída    | Tipo de dados Descrição                                                                                                 |
|------------------------|-------------------------------------------------------------------------------------------------------------------------|
|                        | EnableOut BOOL Saída Habilitar.                                                                                         |
| Dest DINT              | Resultado da instrução de  conversão. Os sinalizadores de  status de operações matemáticas  são ajustados para a saída. |

## Descrição

BCD é um sistema de número do Código binário decimal que expressa dígitos decimais individuais (0-9) em uma notação binária de 4 bits.

| Source  Destination Tipo de destino    |
|----------------------------------------|
| Origem negativa < 0 0                  |
| Origem > 99.999.999 16#9999_9999 DINT  |
| Origem > 99.999.999 16#9999 INT        |
| Origem > 99.999.999 16#99 SINT         |

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                       | Afeta sinalizadores de status  de operações matemáticas                    |
|---------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580 | Condicional, consulte  Sinalizadores de status de  operações matemáticas . |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact  GuardLogix 5370 e GuardLogix 5570                     | Sim                                                                        |

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                                               |
|---------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A.                                                                                            |
| Rung-condition-in é falsa N/A.                                                                                |
| Rung-condition-in é  verdadeira  O controlador converte a Source em BCD e  coloca o resultado no Destination. |
| Pós-varredura N/A.                                                                                            |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                                   |
|                                    | Tag.EnableIn é falso. EnableOut é eliminado como falso                                                            |
| Tag.EnableIn é  verdadeiro         | EnableOut é definido como verdadeiro. Se o  bloco gerar um transbordamento, EnableOut  será eliminado como falso. |
| Primeira varredura da  instrução   | N/A                                                                                                               |
| Primeira execução da  instrução    | N/A                                                                                                               |
| Pós-varredura N/A                  |                                                                                                                   |

## Exemplo

## Exemplo 1

A instrução TOD converte value\_1 em um valor de BCD e coloca o resultado em result\_a.

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Fluxograma TOD (Verdadeiro)

<!-- image -->

## Consulte também

Instruções de cálculo na página 369

Atributos comuns na página 879

Sinalizadores de status de operações matemáticas na página 879

Conversões de dados na página 883
