---
type: Instruction
title: "Disparar tarefa de evento (EVENT)"
description: "InputA[:=] OutputB;"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L15644-L15913"
---

## Disparar tarefa de evento (EVENT)

## Texto estruturado

InputA[:=] OutputB;

IF (InputA) THEN

TND();

END\_IF;

InputE [:=] OutputF;

## Consulte também

Instruções de controle do programa na página 620

Sempre falso (AFI) na página 622

Controle de restauração principal (MCR) na página 642

Nenhuma operação (NOP) na página 646

Atributos comuns na página 879

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução EVENT dispara uma execução de uma tarefa de evento.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

EVENT(task\_name);

## Operandos

## Diagrama ladder

| Operando Tipo Formato Descrição    | Operando Tipo Formato Descrição    |                                                                                                                                              |
|------------------------------------|------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------|
|                                    | Task TASK nome                     | Tarefa de evento para executar.  Se uma tarefa for especificada  que não for a tarefa de evento, a  tarefa especificada não será  executada. |

## Texto estruturado

| Operando Tipo Formato Descrição    | Operando Tipo Formato Descrição    |                                                                                                                                              |
|------------------------------------|------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------|
|                                    | Task TASK nome                     | Tarefa de evento para executar.  Se uma tarefa for especificada  que não for a tarefa de evento, a  tarefa especificada não será  executada. |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Descrição

Use a instrução EVENT para executar de forma programada uma tarefa de evento.

Toda vez que a instrução é executada, ela dispara a tarefa de evento especificada.

Certifique-se de dar à tarefa de evento tempo suficiente para concluir a sua execução antes de dispará-la novamente. Caso contrário, uma sobreposição ocorre.

Se você executar uma instrução EVENT enquanto a tarefa de evento já está em execução, o controlador incrementa o contador de sobreposições, mas não dispara a tarefa de evento.

A instrução EVENT pode ser usada para disparar tarefas de evento com todos os tipos de disparadores.

## Determine de forma programada se uma instrução EVENT disparou uma tarefa

Para determinar se uma instrução EVENT disparou uma tarefa de evento, use uma instrução Obter valor do sistema (GSV) para monitorar o atributo Status da tarefa.

| Atributo    | Tipo de  dados    | Instrução Des crição    |                                                                                                                                                                             |                                                                                                                                                                             |
|-------------|-------------------|-------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Status      | DINT              | GSV  SSV                | Fornece as informações de status da tarefa.  Quando o controlador definir um bit, você deve  manualmente eliminar o bit para determinar se  outra falha desse tipo ocorreu. | Fornece as informações de status da tarefa.  Quando o controlador definir um bit, você deve  manualmente eliminar o bit para determinar se  outra falha desse tipo ocorreu. |
| Status      | DINT              | GSV  SSV                | Para determinar se Examine esse bit                                                                                                                                         |                                                                                                                                                                             |
| Status      | DINT              | GSV  SSV                | Uma instrução EVENT  disparou a tarefa (somente  tarefa de evento)                                                                                                          | 0                                                                                                                                                                           |
| Status      | DINT              | GSV  SSV                | Um tempo limite disparou  a tarefa (somente tarefa de  evento)                                                                                                              | 1                                                                                                                                                                           |
| Status      | DINT              | GSV  SSV                | Uma sobreposição ocorreu  para essa tarefa                                                                                                                                  | 2                                                                                                                                                                           |

O controlador não elimina os bits do atributo Status quando eles forem definidos. Para usar um bit para novas informações de status, você deve manualmente eliminar o bit. Use uma instrução Definir valor do sistema (SSV) para definir o atributo para um valor diferente.

## Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

|                                 | Condição A ção realizada    |
|---------------------------------|-----------------------------|
| Pré-varredura N/A               |                             |
| Rung-condition-in  é falsa      | N/A                         |
| Rung-condition-in  é verdadeira | A instrução é executada.    |
| Pós-varredura N/A               |                             |

## Texto estruturado

| Condição A ção realizada                 |
|------------------------------------------|
| Pré-varredura N/A                        |
| Execução normal A instrução é executada. |
| Pós-varredura N/A                        |

## Exemplos

## Exemplo 1

Um controlador usa diversos programas, mas um procedimento de desligamento comum. Cada programa usa uma tag de escopo do programa nomeada Shut\_Down\_Line que é ativada se o programa detectar uma condição que exige um desligamento. A lógica em cada programa é executada da seguinte forma.

Se Shut\_Down\_Line = on (condições exigem um desligamento) então

Execute a tarefa Shut\_Down uma vez

## Diagrama ladder

## Programa A

<!-- image -->

## Programa B

<!-- image -->

## Texto estruturado

## Programa A

```
IF Shut_Down_Line AND NOT Shut_Down_Line_One_Shot THEN EVENT (Shut_Down); END_IF; Shut_Down_Line_One_Shot:=Shut_Down_Line; Programa B IF Shut_Down_Line AND NOT Shut_Down_Line_One_Shot THEN EVENT (Shut_Down); END_IF; Shut_Down_Line_One_Shot:=Shut_Down_Line;
```

## Exemplo 2

O exemplo seguinte usa uma instrução EVENT para inicializar uma tarefa de evento. Outro tipo de evento normalmente dispara a tarefa de evento.

## Tarefa contínua

IF Initialize\_Task\_1 = 1 THEN

A instrução ONS limita a execução da instrução EVENT para 1 varredura.

A instrução EVENT dispara uma execução de Task\_1 (tarefa de evento).

<!-- image -->

## Task\_1 (tarefa de evento)

A instrução GSV define Task\_Status (DINT tag) = atributo Status para a tarefa de evento. No atributo Nome da Instância, THIS significa o objeto TASK para a tarefa em que a instrução está em (por ex., Task\_1).

<!-- image -->

Se Task\_Status.0=1 então uma instrução EVENT disparou a tarefa de evento (isto é, quando a tarefa contínua executa sua instrução EVENT para inicializar a tarefa de evento).

A instrução RES restaura um contador que a tarefa de evento usa.

<!-- image -->

O controlador não elimina os bits do atributo Status quando eles forem definidos. Para usar um bit para novas informações de status, você deve manualmente eliminar o bit.

Se Task\_Status.0 = 1 então, elimina esse bit.

A instrução OTU define Task\_Status.0 = 0.

Desabilitar interrupção do usuário (UID)/Habilitar interrupção do usuário (UIE)

A instrução SSV define o atributo Status de tarefa THIS (Task\_1) = Task\_Status. Isso inclui o bit eliminado.

<!-- image -->

## Consulte também

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

As instruções UID e UIE trabalham juntas para impedir que um número pequeno de degraus críticos sejam interrompidos por outras tarefas.

## Idiomas disponíveis

## Diagramas ladder

<!-- image -->

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

UID();

UIE();

## Operandos

## Diagrama ladder

Esta instrução não está disponível no diagrama ladder.

## Texto estruturado

Essa instrução não está disponível em texto estruturado. É necessário inserir os parênteses () após a instrução mnemônica, mesmo que não haja operandos.

## Descrição (Description)

Quando rung-condition-in é verdadeira, a:

-  instrução UID impede que tarefas com maior prioridade interrompam a tarefa atual, mas não desabilita a execução de uma rotina de falhas ou o Manipulador de falhas do controlador.
-  instrução UIE habilita outras tarefas para interromper a tarefa atual.

Para impedir que uma série de degraus sejam interrompidos:

1. Limite o número de degraus que você não quer que sejam interrompidos ao mínimo possível. Desabilitar interrupções por um período de tempo prolongado pode produzir perda de comunicação.
2. Acima do primeiro degrau que você não deseja interromper, insira um degrau e uma instrução UID.
3. Após o último degrau na série que você não deseja interromper, insira um degrau e uma instrução UIE.
4. Se necessário, você pode aninhar pares de instruções UID/UIE.

Quando a UID é chamada pela primeira vez, ela aumenta a prioridade, salva a prioridade antiga e incrementa um contador de aninhamentos. Cada chamada subsequente incrementa a contagem. A UIE decrementará o contador de aninhamentos. Se o novo valor for 0, ela restaurará a prioridade salva.

## Afeta sinalizadores de status de operações matemáticas

N°

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando

## Execução

## Diagrama ladder

| Condição/estado A ção (Action)                                                                                                                                                                                          |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                                                                                                                                                                                                       |
| Rung-condition-in é falsa N/D                                                                                                                                                                                           |
| Rung-condition-in é  verdadeira  A instrução UID impede que a tarefa contida do  usuário seja interrompida.  A instrução UIE habilita a tarefa contida do  usuário seja interrompida, como esse é  normalmente no caso. |
| Pós-varredura N/D                                                                                                                                                                                                       |

## Texto estruturado

| Condição/estado A ção (Action)                                                                                                                                                                          |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                                                                                                                                                                                       |
| Execução normal  A instrução UID impede que a tarefa contida do  usuário seja interrompida.  A instrução UIE habilita a tarefa contida do  usuário seja interrompida, como esse é  normalmente no caso. |
| Pós-varredura N/D                                                                                                                                                                                       |

## Exemplo

## Diagrama ladder

<!-- image -->

## Texto estruturado

UID();
