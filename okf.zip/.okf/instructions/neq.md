---
type: Instruction
title: "Diferente de (NEQ)"
description: "Quando habilitada, a instrução NEQ e o operador testam se a Source A não é igual à Source B."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L8000-L8302"
---

## Diferente de (NEQ)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

Quando habilitada, a instrução NEQ e o operador testam se a Source A não é igual à Source B.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

Função FBD

<!-- image -->

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

Dica:

Use o operador com uma expressão para obter o mesmo resultado. Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões e atribuições no texto estruturado.

## Operandos

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

## Comparação numérica

| Operando  Tipo de dados  (Data Type)  Controladores  CompactLogix  5370,  ControlLogix  5570, Compact  GuardLogix  5370 e  GuardLogix  5570    | Tipo de dados  (Data Type)  Controladores  CompactLogix  5380,  CompactLogix  5480,  ControlLogix  5580, Compact  GuardLogix 5380  e GuardLogix  5580    | Format         | Descrição  (Description)            |
|------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|-------------------------------------|
| Source A SINT  INT  DINT  REAL                                                                                                                 | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                            | immediate  tag | Valor para  testar contra  Source B |
| Source B SINT  INT  DINT  REAL                                                                                                                 | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                            | immediate  tag | Valor para  testar contra  Source A |

## Comparação de strings

Dica:

Literais de string imediatos apenas são aplicáveis à Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operando  Tipo de dados  (Data Type)    | Format                       | Descrição  (Description)            |
|-----------------------------------------|------------------------------|-------------------------------------|
| Source A Tipo de string                 | valor literal  imediato  tag | String para testar  contra Source B |
| Source B Tipo de string                 | valor literal  imediato  tag | String para testar  contra Source A |

## Diagrama de bloco da função

## Bloco FBD

| Operando    | Tipo de dados  (Data Type)        | Format    | Descrição  (Description)    |
|-------------|-----------------------------------|-----------|-----------------------------|
|             | NEQ FBD_COMPARE tag Estrutura NEQ |           |                             |

## Estrutura de FBD\_COMPARE

| Membros de  entradas    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                |
|-------------------------|-------------------------------|------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL           |                               | Entrada Habilitar. Se falso, a  instrução não será executada e  as saídas não serão atualizadas.  Padrão é verdadeiro. |
| SourceA REAL            |                               | Valor para testar contra SourceB.                                                                                      |
| SourceB REAL            |                               | Valor para testar contra SourceA.                                                                                      |

| Membros de  saída    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                   |
|----------------------|-------------------------------|---------------------------------------------------------------------------------------------------------------------------|
| EnableOut BOOL       |                               | Indica se a instrução está  habilitada.                                                                                   |
|                      | Dest BOOL                     | Definido como verdadeiro  quando SourceA não é igual a  SourceB. Eliminado para falso  quando SourceA é igual a  SourceB. |

## Função FBD

Dica: A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operandos de  entrada (pinos  esquerdos)    | Tipo de dados  (Data Type)                              | Descrição (Description)            |
|---------------------------------------------|---------------------------------------------------------|------------------------------------|
| SourceA (topo) SINT                         | INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL | Valor para testar contra  SourceB  |
| SourceB (fundo) SINT                        | INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL | Valor para testar contra  SourceA. |

| Operando de  saída (Pino  direito)    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                    |
|---------------------------------------|-------------------------------|----------------------------------------------------------------------------------------------------------------------------|
|                                       | Dest BOOL                     | Definido como verdadeiro  quando SourceA não é  igual a SourceB.  Eliminado para falso  quando SourceA é igual  a SourceB. |

Consulte Funções FBD

Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Consulte Fluxograma de Comparação de Strings NEQ para conhecer as falhas.

Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                                                                         |
|------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                                                         |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como  Rung-condition-in                                                                                                                                                      |
| Rung-condition-in é  verdadeira    | Comparação numérica: Se Source A e Source B forem NAN e  Source A não for igual a Source B.  Defina Rung-condition-out como  verdadeira  Caso contrário  Eliminar Rung-condition-out para  falso.       |
| Rung-condition-in é  verdadeira    | Comparação de strings:  Consulte Fluxograma de Comparação  de Strings NEQ .  Se a saída for falsa  Eliminar Rung-condition-out para  falso  caso contrário  Definir Rung-condition-out como  verdadeira |
| Pós-varredura N/D                  |                                                                                                                                                                                                         |

## Diagrama de bloco da função

Bloco FBD

| Condição/estado A ção realizada    |                                                                                                                                                                                                                         |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                                                                         |
|                                    | EnableIn é falso Defina EnableOut como EnableIn                                                                                                                                                                         |
|                                    | EnableIn é verdadeiro Comparação numérica: Defina EnableOut como EnableIn  Se SourceA ou SourceB forem NAN  ou SourceA for diferente de SourceB.  Defina Dest como verdadeiro  Caso contrário  Elimina Dest como falso. |
| Primeira execução da  instrução    | N/D                                                                                                                                                                                                                     |
| Primeira varredura da  instrução   | N/D                                                                                                                                                                                                                     |
| Pós-varredura N/D                  |                                                                                                                                                                                                                         |

## Função FBD

Dica: A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A ção realizada    |                                                                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                   |
| Varredura normal                   | Comparação numérica: Se SourceA ou SourceB forem NAN  ou SourceA for diferente de SourceB.  Defina Dest como verdadeiro  Caso contrário  Elimina Dest como falso. |
| Primeira execução da  instrução    | N/D                                                                                                                                                               |
| Primeira varredura da  instrução   | N/D                                                                                                                                                               |
| Pós-varredura N/D                  |                                                                                                                                                                   |

## Fluxograma de Comparação de Strings NEQ

<!-- image -->

## Exemplos

## Diagrama ladder

Diagrama de bloco da função

<!-- image -->

## Bloco FBD

<!-- image -->

## Operadores válidos

if value\_3 &lt;&gt; 'I am EQUAL' then

light\_5 := 1;

Caso contrário

light\_5 := 0;

end\_if;

## Consulte também

Sintaxe de texto estruturado na página 912

Conversões de dados na página 883

Índice por meio de matrizes na página 893

Valores imediatos na página 882

Funções FBD na página 425

A seguir são os operadores válidos.

| Operador Descrição  (Description)    | Permitido em       | Permitido em    | Permitido em              | Permitido em    | Permitido em    | Permitido em    |
|--------------------------------------|--------------------|-----------------|---------------------------|-----------------|-----------------|-----------------|
| Operador Descrição  (Description)    | Índice  de  matriz |                 | FSC CMP FAL CPT Segurança |                 |                 |                 |
| + somar X X X X X X                  |                    |                 |                           |                 |                 |                 |
| - subtrair/negar X X X X X X         |                    |                 |                           |                 |                 |                 |
| * multiplicar X X X X X X            |                    |                 |                           |                 |                 |                 |
| / dividir X X X X X X                |                    |                 |                           |                 |                 |                 |
| = Igual                              |                    | X X             | X                         |                 |                 |                 |
| < Menor que                          |                    | X X             | X                         |                 |                 |                 |
| <=  Menor que ou  igual              |                    | X X             | X                         |                 |                 |                 |
| > Maior que                          |                    | X X             | X                         |                 |                 |                 |
| >=  Maior que ou  igual              |                    | X X             | X                         |                 |                 |                 |
| <> não igual                         |                    | X X             | X                         |                 |                 |                 |
| **  expoente (x a  y)                |                    | X X X X         |                           |                 |                 |                 |
| ABS Valor absoluto                   |                    | X X X X X       |                           |                 |                 |                 |
| ACS arco cosseno                     |                    | X X X X         |                           |                 |                 |                 |
| AND AND bit a bit X X X X X X        |                    |                 |                           |                 |                 |                 |

|     | ASN arco seno                 | X X X X     |
|-----|-------------------------------|-------------|
|     | ATN arco tangente             | X X X X     |
|     | COS cosseno                   | X X X X     |
| DEG | Radianos para  graus          | X X X X     |
| FRD | BCD para  inteiro             | X X X X X   |
| LN  | Logaritmo  natural            | X X X X     |
| LOG | Logaritmo de  base 10         | X X X X     |
|     | MOD módulo-divisão            | X X X X X   |
|     | NOT NÃO bit a bit X X X X X X |             |
|     | OR OU bit a bit X X X X X X   |             |
| RAD | graus para  radianos          | X X X X     |
|     | SIN seno                      | X X X X     |
|     | SQR raiz quadrada X X X X X   |             |
|     | TAN tangente                  | X X X X     |
| TOD | inteiro para  BCD             | X X X X X   |
|     | TRN truncar                   | X X X X     |
| XOR | OU exclusivo  bit a bit       | X X X X X X |

## O que é preenchimento de zeros?

Há duas formas de converter um tipo de inteiro de tamanho menor em um de tamanho maior:

-  Preenchimento de zeros
-  Extensão de sinal

O método usado depende da instrução que usa o operando.

Para preenchimento de zeros, todos os bits acima da faixa do tipo de tamanho menor são preenchidos com 0.

Por exemplo, SINT: 16#87 = -121 convertido em um DINT resulta em 16#00000087 = 135

Para extensão de sinal, todos os bits acima da faixa do tipo de tamanho menor são preenchidos com o bit de sinal dele.

Por exemplo, SINT: 16#87 = -121 convertido em um DINT resulta em 16#FFFFFF87 = -121

## Consulte também

Mask igual a (MEQ) na página 349

## Instruções de cálculo/matemáticas

## Instruções de cálculo/matemáticas

As instruções de cálculo/matemáticas avaliam operações aritméticas usando uma expressão ou uma instrução aritmética específica.

## Instruções disponíveis

## Diagrama ladder

CPT

ADD

SUB

MUL

## Diagrama de bloco da função

## Bloco FBD

| ADD    | SUB    | MUL    | DIV    | MOD    | SQR    | SQRT    | NEG    | ABS   |
|--------|--------|--------|--------|--------|--------|---------|--------|-------|

## Função FBD

| ADD    | 419    | DIV    | MOD    | SQR/SQRT/    | 407    | ABS   |
|--------|--------|--------|--------|--------------|--------|-------|

## Texto estruturado

SQR

SQRT

ABS

| Se você desejar:                                         | Use esta instrução:    |
|----------------------------------------------------------|------------------------|
| avaliar uma expressão                                    | CPT                    |
| somar dois valores                                       | ADD                    |
| subtrair dois valores                                    | SUB                    |
| multiplicar dois valores                                 | MUL                    |
| dividir dois valores                                     | DIV                    |
| determinar o resto após um valor ser  dividido por outro | MOD                    |
| Calcular a raiz quadrada de um valor SQR                 |                        |

DIV

MOD

SQR

SQRT

NEG

ABS
