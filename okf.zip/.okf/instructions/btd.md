---
type: Instruction
title: "Distribuição do campo de bit (BTD)"
description: "As instruções lógicas realizam operações lógicas nos bits."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L9995-L10099"
---

## Distribuição do campo de bit (BTD)

| Mover bits dentro de um inteiro ou entre  inteiros em um bloco de funções    | BTDT    |
|------------------------------------------------------------------------------|---------|
| Eliminar um valor                                                            | CLR     |
| Reorganizar os bytes de uma tag INT,  DINT ou REAL                           | SWPB    |

As instruções lógicas realizam operações lógicas nos bits.

| Se você desejar:                              | Use esta instrução:    |
|-----------------------------------------------|------------------------|
| Realizar uma operação AND bit a bit AND       |                        |
| Realizar uma operação OU bit a bit OR         |                        |
| Realizar uma operação OU exclusivo bit  a bit | XOR                    |
| Realizar uma operação NÃO bit a bit NOT       |                        |

É possível misturar tipos de dados, mas a perda de precisão e erro de arredondamento podem ocorrer e a execução da instrução pode levar mais tempo. Verifique o bit S:V para ver se o resultado foi truncado.

Os tipos de dados em negrito indicam ótimos tipos de dados. Uma instrução é executada mais rápido e requer menos memória se todos os operandos da instrução usarem o mesmo tipo de dados otimizado, geralmente DINT ou REAL.

Uma instrução de movimento/lógica é executada uma vez sempre que a instrução é varrida desde que a rung-condition-in seja verdadeira. Se você quiser que a expressão seja avaliada apenas uma vez, use qualquer instrução de um pulso para disparar a instrução de movimento/lógica.

## Consulte também

Instruções de conversão matemática na página 763

Instruções de entrada/saída na página 153

Instruções de Circulação/Interrupção na página 663

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução BTD copia os bits especificados de Source, muda os bits para a posição adequada e grava os bits em Destination.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

## Diagrama ladder

|                             |                                      | Operando Tipo Formato Descrição                                                                                                       |
|-----------------------------|--------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------|
| Source SINT  INT  DINT      | imediato  tag                        | Tag que contém os bits a  mover                                                                                                       |
|                             | Source bit DINT imediato (0-31)      | Número do bit (menor  número de bit) do qual  começar a mover  Deve estar dentro da faixa  válida para o tipo de  dados de Source     |
| Destination SINT  INT  DINT | tag                                  | Tag para a qual mover os  bits                                                                                                        |
|                             | Destination bit DINT imediato (0-31) | O número do bit para o  qual os dados devem ser  movidos precisa estar  dentro da faixa válida para  o tipo de dados de  Destination. |
| Length                      |                                      | DINT imediato (1-32) Número de bits a mover                                                                                           |

## Descrição

Quando habilitada, a instrução BTD copia um grupo de bits de Source para Destination. O grupo de bits é identificado pelo Source bit (o menor número de bit de Source) e pelo Length (número de bits a copiar). O Destination bit identifica o menor número de bit com o qual iniciar em Destination. A Source permanece inalterada.

Se o comprimento do campo de bit estender-se além de Destination, a instrução não salvará os bits extras. Nenhum bit extra será quebrado para a próxima palavra.

Uma tag SINT ou INT é convertido em um valor DINT pelo preenchimento de zeros.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                              |
|------------------------------------|--------------------------------------------------------------|
| Pré-varredura N/A                  |                                                              |
| Rung-condition-in é  falsa.        | N/A                                                          |
| Rung-condition-in é  verdadeira.   | A instrução copia e muda os  Source bits para o Destination. |
| Pós-varredura N/A                  |                                                              |

## Exemplos

## Exemplo 1

## Diagrama ladder

<!-- image -->

Quando habilitada, a instrução BTD move os bits em value\_1.

<!-- image -->

Exemplo 2

<!-- image -->
