---
type: Instruction
title: "Teste ASCII para Linha do Buffer (ABL)"
description: "Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L20007-L20111"
---

## Teste ASCII para Linha do Buffer (ABL)

Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate.

A instrução ABL conta os caracteres no buffer até e incluindo o primeiro caractere de terminação.

## Dica:

Instruções de Porta serial ASCII (AWT, AWA, ARD, ARL, ABL, ACB, AHL, ACL) não estão disponíveis para controladores que não têm portas seriais.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

ABL(Channel,SerialPortControl);

## Operandos

## Diagrama ladder

| Operando Tipo        | Formato Descrição                                                                                                                     |
|----------------------|---------------------------------------------------------------------------------------------------------------------------------------|
| Channel DINT         | imediato 0                                                                                                                            |
|                      | SerialPort Control SERIAL_PORT_CONTROL tag tag que controla a operação                                                                |
| Character Count DINT | imediato 0  Durante a execução, exibe o  número de caracteres no buffer,  incluindo o primeiro conjunto de  caracteres de terminação. |

## Texto estruturado

| Operando Tipo        | Formato Descrição                                                                                                                     |
|----------------------|---------------------------------------------------------------------------------------------------------------------------------------|
| Channel DINT         | imediato 0                                                                                                                            |
|                      | SerialPort Control SERIAL_PORT_CONTROL tag tag que controla a operação                                                                |
| Character Count DINT | imediato 0  Durante a execução, exibe o  número de caracteres no buffer,  incluindo o primeiro conjunto de  caracteres de terminação. |

Você acessa o valor de contagem de caractere por meio do membro .POS da estrutura SERIAL\_PORT\_CONTROL.

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Estrutura de SERIAL\_PORT\_CONTROL

| Mnemônico    | Tipo de  dados    | Descrição                                                                                                                                                                                                             |
|--------------|-------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| .EN          |                   | BOOL O bite de habilitação indica que a instrução está habilitada.                                                                                                                                                    |
| .EU          |                   | BOOL O bit de fila indica que a instrução foi digitada na fila ASCII.                                                                                                                                                 |
|              | .DN BOOL          | O bit executado indica quando a instrução foi executada, mas está  assíncrona com a varredura da lógica.                                                                                                              |
| .RN          |                   | BOOL O bit de execução indica que a instrução está sendo executada.                                                                                                                                                   |
|              | .EM BOOL          | O bit vazio indica quando a instrução foi executada, mas está  síncrona com a varredura da lógica.                                                                                                                    |
| .ER          |                   | BOOL O bit de erro indica quando a instrução falha (erros).                                                                                                                                                           |
|              | .FD BOOL          | O bit encontrado indica que a instrução encontrou o(s) caractere(s)  de terminação.                                                                                                                                   |
|              | .POS DINT         | A posição determina o número de caracteres no buffer, até e  incluindo o primeiro conjunto de caracteres de terminação. A  instrução só retorna este número depois que ela encontra o(s)  caractere(s) de terminação. |
|              |                   | .ERROR DINT O erro contém um valor hexadecimal que indica a causa de um erro.                                                                                                                                         |

## Descrição

A instrução ABL pesquisa no buffer pelo primeiro conjunto de caracteres de terminação. Se a instrução encontrar os caracteres de terminação, ela:

-  define o bit .FD
-  conta os caracteres no buffer até e incluindo o primeiro conjunto de caracteres de terminação

A guia Protocolo de usuário (User Protocol) da caixa de diálogo Propriedades do controlador (Controller Properties) define os caracteres ASCII que a instrução considera como caracteres ASCII.

Para programar a instrução ABL, siga estas diretrizes:

-  Configure a porta serial do controlador para modo Usuário e defina os caracteres que servem como caracteres de terminação.

Isso é uma instrução de transição:

-  No diagrama ladder, alterne EnableIn de eliminado para definido toda vez que a instrução deve ser executada.
-  No texto estruturado, condicione a instrução para que ela apenas execute em uma transição

## Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição                        | Ação do Diagrama ladder                                                |
|---------------------------------|------------------------------------------------------------------------|
| Pré-varredura N/A               |                                                                        |
| Rung-condition-in é  falsa      | N/A                                                                    |
| Rung-condition-in é  verdadeira | A instrução é executada.  EnableIn altera de eliminado  para definido. |
| Pós-varredura N/A               |                                                                        |

## Texto estruturado

| Condição          | Ação de texto estruturado                                              |
|-------------------|------------------------------------------------------------------------|
| Pré-varredura N/A |                                                                        |
| Execução normal   | A instrução é executada.  EnableIn altera de eliminado  para definido. |
| Pós-varredura N/A |                                                                        |
