---
type: Instruction
title: "Radiano (RAD)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L18937-L19070"
---

## Radiano (RAD)

## Texto estruturado

| Condição/estado A ção realizada                                                         |
|-----------------------------------------------------------------------------------------|
| Pré-varredura N/A                                                                       |
| Execução normal  Consulte rung-condition-in é verdadeira na  tabela de Diagrama ladder. |
| Pós-varredura N/A                                                                       |

## Exemplo

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

result := DEG(value);

## Consulte também

Instruções matemáticas avançadas na página 749

Atributos comuns na página 879

Sinalizadores de status de operações matemáticas na página 879

Sintaxe de texto estruturado na página 912

Conversões de dados na página 883

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução RAD converte Source (em graus) em radianos e armazena o resultado no Destination.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

dest := RAD(source);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

## Diagrama ladder

|                                    |              | Operando Tipo (Type) Format Descrição (Description)    |
|------------------------------------|--------------|--------------------------------------------------------|
| Origem SINT  INT:  DINT  REAL      | Somente  tag | valor para converter em  radianos                      |
| Destination SINT  INT:  DINT  REAL | tag          | tag a armazenar o  resultado                           |

## Texto estruturado

Use RAD como uma função. Consulte Sintax de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Bloco de funções

| Operando Tipo (Type)                | Format    | Descrição  (Description)    |
|-------------------------------------|-----------|-----------------------------|
| RAD tag FBD_MATH_ADVANCED estrutura |           | Estrutura de  FRD           |

## Estrutura de FBD\_MATH\_ADVANCED

| Parâmetro de  entrada    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                |
|--------------------------|-------------------------------|------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                               | Entrada Habilitar. Se falso, a instrução  não será executada e as saídas não  serão atualizadas.  Padrão é verdadeiro. |
| Origem REAL              |                               | Entrada para a instrução de conversão.                                                                                 |

| Parâmetro de  saída    | Tipo de dados  (Data Type)    | Descrição (Description)              |
|------------------------|-------------------------------|--------------------------------------|
|                        |                               | EnableOut BOOL Saída Habilitar.      |
| Dest                   | REAL                          | Resultado da instrução de conversão. |

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                        | Sinalizadores de status de operações  matemáticas afetados                |
|----------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------|
| Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e GuardLogix  5580 | Condicional, consulte Sinalizadores de  status de operações matemáticas . |
| Controladores CompactLogix  5370, ControlLogix 5570,  Compact GuardLogix 5370 e  GuardLogix 5570                     | Sim                                                                       |

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                                                  |
|------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                                                                                                |
| Rung-condition-in é falsa N/D                                                                                    |
| Rung-condition-in é  verdadeira  O controlador converte Source em radianos e  coloca o resultado no Destination. |
| Pós-varredura N/D                                                                                                |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                   |
|                                    | Tag.EnableIn é falso. EnableOut é eliminado como falso                                                            |
| Tag.EnableIn é  verdadeiro         | EnableOut é definido como verdadeiro. Se o  bloco gerar um transbordamento, EnableOut  será eliminado como falso. |
| Primeira varredura da  instrução   | N/D                                                                                                               |
| Primeira execução da  instrução    | N/D                                                                                                               |
| Pós-varredura N/D                  |                                                                                                                   |

## Texto estruturado

| Condição/estado A ção realizada                                                         |
|-----------------------------------------------------------------------------------------|
| Pré-varredura N/D                                                                       |
| Execução normal  Consulte rung-condition-in é verdadeira na  tabela de Diagrama ladder. |
| Pós-varredura N/D                                                                       |

## Exemplo

## Diagrama ladder

<!-- image -->
