---
type: Instruction
title: "Um pulso (ONS)"
description: "Se S: V for falso, isso habilite a próxima instrução."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L1571-L1639"
---

## Um pulso (ONS)

## Exemplo 2

## Diagrama ladder

Se S: V for falso, isso habilite a próxima instrução.

<!-- image -->

## Consulte também

Instruções de bit na página 75

Endereçamento de bit na página 894

Indexação por meio de matrizes na página 893

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução ONS torna o resto do degrau verdadeiro todas as vezes que rung-condition-in realiza a transição de falso para verdadeiro.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                    |
|----------------|---------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                        |
|                |   Membros de um operando de estrutura estão  substituídos.                                             |
|                |   Exceto quanto especificado, os operandos da  estrutura são compartilhados por múltiplas  instruções. |

## Diagrama ladder

| Operando             | Tipo de  dados    | Formato Des crição    |                                                                                                                                                                                                                                                 |
|----------------------|-------------------|-----------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Storage bit BOOL tag |                   |                       | Bit de armazenamento  interno.  Retém a rung-condition-in  da última vez que a  instrução foi executada.  Há vários modos de  endereçamento de  operando possíveis para o  bit de armazenamento,  consulte Endereçamento de  bits para exemplo. |

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                  |
|------------------------------------|------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | O bit de armazenamento é definido  como verdadeiro para evitar disparos  inválidos durante a primeira varredura. |
| Rung-condition-in é falsa          | O bit de armazenamento é eliminado  como falso, rung-condition-out será  eliminado como falso.                   |
| Rung-condition-in é  verdadeira    | Consulte o fluxograma ONS  (Verdadeiro).                                                                         |
| Pós-varredura N/A                  |                                                                                                                  |
