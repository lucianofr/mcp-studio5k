---
type: Instruction
title: "Temporizador retentivo ativado com restauração (RTOR)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L2813-L2976"
---

## Temporizador retentivo ativado com restauração (RTOR)

## Exemplo

## Diagrama ladder

<!-- image -->

Quando limit\_switch\_7 é definido, light\_2 fica acesa por 180 milissegundos (timer\_3 está sincronizando). Quando timer\_3.acc alcança 180, light\_2 apaga e light\_3 acende. Light\_3 permanece até timer\_3 ser restaurado. Se limit\_switch\_7 for eliminado enquanto timer\_3 estiver sincronizando, light\_2 apaga. Quando limit\_switch\_7 é definido, a instrução RES restaura o timer\_3 (elimina os bits de status e o valor .ACC).

## Consulte também

Indexação por meio de matrizes na página 893

Restaurar (RES) na página 119

Temporizador de atraso desativado (TOF) na página 133

Temporizador de atraso ativado (TON) na página 142

Instruções do temporizador e do contador na página 103

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução RTOR é um temporizador retentivo que acumula tempo quando TimerEnable for definido.

## Idiomas disponíveis

## Diagrama ladder

Esta instrução não está disponível no diagrama ladder.

## Bloco de funções

<!-- image -->

## Texto estruturado

RTOR(RTOR\_tag)

## Operandos

## Texto estruturado

| Variável Tipo                | Formato Descrição    |
|------------------------------|----------------------|
| RTOR tag FBD_TIMER Estrutura | Estrutura de  RTOR   |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Bloco de funções

| Operando Tipo Formato Descrição    | Operando Tipo Formato Descrição    |
|------------------------------------|------------------------------------|
| RTOR tag FBD_TIMER Estrutura       | Estrutura de  RTOR                 |

## Estrutura de FBD\_TIMER

| Parâmetro  de entrada    | Tipo de dados Descrição                                                                                                                                                                                                                                                           |
|--------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            | Se eliminado, a instrução não é  executada e as saídas não são  atualizadas. Se definido, a instrução é  executada.  Padrão é definido.                                                                                                                                           |
| TimerEnable BOOL         | Se definido, isso permite que o  temporizador opere e acumule tempo.  Padrão é eliminado.                                                                                                                                                                                         |
| PRE DINT                 | Valor predefinido do temporizador. Esse  é o valor em unidade de 1 milissegundo  que o ACC precisa alcançar antes da  sincronização terminar. Se inválido, a  instrução define o bit correto em Status e  o temporizador não é executado.  Válido = 0 até inteiro positivo máximo |
| Reset BOOL               | Solicitar para restaurar o temporizador.  Quando definido, o temporizador  restaura.  Quando o parâmetro de entrada Reset é  definido, a instrução elimina EN, TT e DN  e define ACC = 0.                                                                                         |

| Parâmetro  de saída       | Tipo de dados Descrição    |                                                                                                                                                                                   |
|---------------------------|----------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                           |                            | EnableOut BOOL A instrução produziu um resultado válido.                                                                                                                          |
|                           | ACC DINT                   | O tempo acumulado em milissegundos.  Esse valor é retido mesmo quando a  entrada TimerEnable é eliminada.                                                                         |
|                           | EN BOOL                    | Saída habilitada pelo temporizador.  Indica que a instrução do temporizador  está habilitada.                                                                                     |
|                           | TT BOOL                    | Saída de sincronização do temporizador.  Quando definida, a operação de  sincronização está em andamento.                                                                         |
|                           | DN BOOL                    | Saída da sincronização executada.  Indica que o tempo acumulado é maior  ou igual à pré-configuração.                                                                             |
|                           |                            | Status DINT Status do bloco de funções.                                                                                                                                           |
| InstructFault  (Status.0) | BOOL                       | A instrução detectou um dos seguintes  erros de execução. Esse não é um erro  de controlar maior ou menor. Verifique os  bits de status restantes para determinar o  que ocorreu. |
| PresetInv  (Status.1)     |                            | BOOL O valor predefinido é inválido.                                                                                                                                              |

## Descrição

A instrução RTOR acumula tempo até que seja falsa. Quando a instrução RTOR é falsa, ela retém seu valor ACC. Você precisa eliminar o valor .ACC usando a entrada Reset.

A base de tempo é sempre em 1 milissegundo. Por exemplo, para um temporizador de 2 segundos, insira 2.000 para o valor PRE.

<!-- image -->

Defina o parâmetro de entrada Reset para restaurar a instrução. Se TimerEnable for definido quando Reset for definido, a instrução RTOR inicializa o temporizador novamente quando Reset é eliminado.

## Como o temporizador opera

Um temporizador é executado subtraindo-se o horário da sua última varredura do horário atual:

-  ACC = ACC + (current\_time - last\_time\_scanned)
-  Após isso atualizar o ACC, o temporizador define last\_time\_scanned= current\_time. Isso torna o temporizador pronto para a próxima varredura.

Importante:

Assegure-s de escanear o temporizador pelo menos a cada 69 minutos enquanto ele estiver em operação. Do contrário, o valor ACC não será correto.

O valor last\_time\_scanned tem uma faixa de tempo de até 69 minutos. O cálculo do temporizador será sobrescrito se você não escanear o temporizador dentro de 69 minutos. O valor ACC não será corrigido se isso acontecer.

Enquanto o temporizador estiver em execução, faça a varredura dele dentro de 69 minutos se você o colocar em uma:

-  Subrotina
-  Seção de código que está entre as instruções JMP e LBL
-  Gráfico de função sequencial (SFC)
-  Evento ou tarefa periódica
-  Rotina do estado de uma fase

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                                                                                             |
|------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | Os bits EnableIn e EnableOut são eliminados  para falso.                                                                                                                                    |
| Tag.EnableIn é falso               | Os bits EnableIn e EnableOut são eliminados  para falso.                                                                                                                                    |
| Tag.EnableIn é  verdadeiro         | Os bits EnableIn e EnableOut são definidos para  verdadeiro.  A instrução é executada.  Quando o parâmetro de entrada Reset é definido,  a instrução elimina EN, TT e DN e define ACC =  0. |
| Primeira execução  da instrução    | EN, TT and DN são eliminados para falso.  A instrução é executada.                                                                                                                          |
| Primeira varredura  da instrução   | N/A                                                                                                                                                                                         |
|                                    | Pós-varredura EnableIn e EnableOut são eliminados para falso.                                                                                                                               |

## Texto estruturado

| Condição/estado A ção realizada    |                                                                    |
|------------------------------------|--------------------------------------------------------------------|
| Pré-varredura                      | Consulte Pré-varredura na tabela de Bloco de  funções.             |
| Execução normal                    | Consulte Tag.EnableIn é verdadeiro na tabela de  Bloco de funções. |
| Pós-varredura                      | Consulte Pós-varredura na tabela de Bloco de  funções.             |

## Exemplo

## Bloco de funções

<!-- image -->

## Texto estruturado

RTOR\_01.PRE := 500;

RTOR\_01.Reset := Reset;

RTOR\_01.TimerEnable := Input;

RTOR(RTOR\_01);

timer\_state := RTOR\_01.DN;

## Consulte também

Atributos comuns na página 879

Temporizador retentivo habilitado (RTO) na página 122

Restaurar (RES) na página 119

Sintaxe de texto estruturado na página 912
