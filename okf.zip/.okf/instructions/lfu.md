---
type: Instruction
title: "Descarga LIFO (LFU)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L14059-L14251"
---

## Descarga LIFO (LFU)

## Diagrama ladder

<!-- image -->

## Consulte também

Instruções de deslocamento/matriz (arquivo) na página 565

Descarga LIFO (LFU) na página 596

Carga FIFO (FFL) na página 575

Descarga FIFO (FFU) na página 582

Atributos comuns na página 879

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução LFU descarrega o valor em .POS do LIFO e armazena 0 naquele local.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução.

## Diagrama ladder

| Operando Tipo                                                |                        | Formato Descrição                                                                             |
|--------------------------------------------------------------|------------------------|-----------------------------------------------------------------------------------------------|
| LIFO SINT  INT  DINT  REAL  Tipo de string  estrutura        | tag de  matriz         | LIFO a modificar  especifica o primeiro  elemento do LIFO  Não use  CONTROL.POS no  subscrito |
| Destination SINT  INT  DINT  REAL  Tipo de string  estrutura | tag                    | Valor descarregado do  LIFO.                                                                  |
| Control CONTROL tag                                          |                        | Estrutura de controle da  operação  geralmente usa o  mesmo CONTROL que  o LFL associado.     |
|                                                              | Length DINT imediato   | Número máximo de  elementos que o LIFO  pode conter por vez                                   |
|                                                              | Position DINT imediato | Próximo local no LIFO  em que a instrução  descarrega dados  o valor inicial costuma  ser 0   |

## Estrutura de CONTROL

| Mnemônico Tipo de dados Descrição    |                                                                                                                                    |
|--------------------------------------|------------------------------------------------------------------------------------------------------------------------------------|
| .EU BOOL                             | O bite de habilitação indica que a  instrução LFU está habilitada.                                                                 |
| .DN BOOL                             | O bit executado é definido para  indicar que o LIFO está cheio (.POS  = .LEN).                                                     |
| .EM BOOL                             | O bit vazio indica que o LIFO está  vazio. Se .LEN for < ou = 0 ou .POS  < 0, tanto o bit .EM quanto os bits  .DN serão definidos. |
| .LEN DINT                            | O comprimento especifica o número  máximo de elementos que o LIFO  pode conter por vez.                                            |
| .POS DINT                            | A posição identifica o fim dos dados  que foram carregados para o LIFO.                                                            |

## Descrição

Use a instrução LFU com a instrução LFL para armazenar e recuperar dados em uma ordem de último a entrar/primeiro a sair.

Quando habilitada, a instrução LFU descarrega o valor em .POS do LIFO e coloca o valor no Destination. A instrução descarrega um valor e o substitui por 0 cada vez que a instrução é habilitada até que o LIFO esteja vazio. Se o LIFO estiver vazio, o LFU retornará 0 ao Destination.

Importante:

Você deve testar e confirmar que a instrução não altera os dados que você não deseja alterar.

A instrução LFU opera em memória contígua. O escopo da instrução é restringido à tag base. A instrução LFL não gravará dados fora da tag base, mas pode cruzar limites de membro. Se você especificar uma matriz que seja membro de uma estrutura, o comprimento excederá o tamanho da matriz; é preciso testar e confirmar que a instrução LFL não altere os dados que você não deseja alterar.

Para Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580, os dados são restringidos pelo membro especificado.

Se a instrução tentar ler além do fim de uma matriz, a instrução definirá o bit .ER e gerará uma falha maior.

Geralmente, a Source e o LIFO são do mesmo tipo de dados. Se houver incompatibilidade do tipos de dados de Source e LIFO, a instrução converterá o valor de Source no tipo de dados da tag FIFO.

Um inteiro menor é convertido em um inteiro maior por extensão de sinal.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha maior ocorrerá se:                              | Tipo de  falha    | Código de  falha    |
|-----------------------------------------------------------|-------------------|---------------------|
| Se Length especificado for além  do fim da matriz de LIFO |                   | 4 20                |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

Todas as condições ocorrem apenas durante o modo Varredura normal

## Diagrama ladder

| Condição/estado A ção realizada    |                                            |
|------------------------------------|--------------------------------------------|
| Pré-varredura                      | Consulte o fluxograma LFU  (Pré-varredura) |
| Rung-condition-in é  falsa         | Consulte o fluxograma LFU (Falso)          |
| Rung-condition-in é  verdadeira    | Consulte o fluxograma LFU (Verdadeiro)     |
| Pós-varredura N/A                  |                                            |

## Fluxograma LFU (Pré-varredura)

<!-- image -->

Fluxograma LFU (Falso)

<!-- image -->

## Fluxograma LFU (Verdadeiro)

<!-- image -->

## Exemplos

## Exemplo 1

## Diagrama ladder

Exemplo 2

<!-- image -->

A matriz de Destino é a matriz de STRING ou a matriz de Estrutura

## Diagrama ladder

Exemplo 3

<!-- image -->

Incompatibilidade do tipo de dados da matriz de origem LIFO com o tipo de dados da matriz de destino

## Diagrama ladder

<!-- image -->

## Consulte também

Instruções de deslocamento/matriz (arquivo) na página 565

Carga LIFO (LFL) na página 589

Carga FIFO (FFL) na página 575

Descarga FIFO (FFU) na página 582

Atributos comuns na página 879

## Instruções do sequenciador

## Instruções do sequenciador

As instruções do sequenciador monitoram operações consistentes e repetíveis.

Instruções disponíveis

Diagrama ladder

<!-- image -->

## Bloco de funções

Indisponível

## Texto estruturado

Indisponível

| Se você deseja                                                | Use esta instrução    |
|---------------------------------------------------------------|-----------------------|
| Detectar quando uma etapa  estiver concluída.                 | SQI                   |
| Configurar condições de saída  para a próxima etapa.          | SQO                   |
| Carregar condições de referência  em matrizes do sequenciador | SQL                   |

Os tipos de dados em negrito indicam ótimos tipos de dados. Uma instrução é executada mais rápido e requer menos memória se todos os operandos da instrução usarem o mesmo tipo de dados otimizado, geralmente DINT ou REAL.

## Consulte também

Instruções de cálculo/matemáticas na página 369

Instruções de comparação na página 293

Instruções de bit na página 75

Instruções de string ASCII na página 825

Instruções de conversão ASCII na página 845
