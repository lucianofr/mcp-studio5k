---
type: Instruction
title: "Temporizador de atraso ativado com restauração (TONR)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L3340-L3528"
---

## Temporizador de atraso ativado com restauração (TONR)

## Exemplo

## Diagrama ladder

<!-- image -->

Quando limit\_switch\_10 é definido, light\_6 fica acesa por 2.000 milissegundos (Timer\_4 está sincronizando). Quando Timer\_4.acc alcança 2.000, light\_6 apaga e light\_7 acende. Se limit\_switch\_10 for eliminado para falso enquanto Timer\_4 estiver sincronizando, light\_6 apaga. Quando limit\_switch\_10 é eliminado para falso, o bit de status Timer\_4 e o valor .ACC são restaurados.

## Consulte também

Instruções do contador na página 103

Indexação por meio de matrizes na página 893

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução TONR é um temporizador não retentivo que acumula tempo quando TimerEnable é definida.

## Idiomas disponíveis

## Diagrama ladder

Esta instrução não está disponível no diagrama ladder.

## Bloco de funções

<!-- image -->

## Texto estruturado

TONR(TONR\_tag);

## Operandos

## Texto estruturado

| Operando Tipo Formato Descrição    | Operando Tipo Formato Descrição    |
|------------------------------------|------------------------------------|
| TONR tag FBD_TIMER Estrutura       | Estrutura de  TONR                 |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Bloco de funções

| Operando Tipo Formato Descrição    | Operando Tipo Formato Descrição    |
|------------------------------------|------------------------------------|
| TONR tag FBD_TIMER Estrutura       | Estrutura de  TONR                 |

## Estrutura de FBD\_TIMER

| Parâmetro  de entrada    | Tipo de  dados    | Descrição                                                                                                                                                                                                                                                                         |
|--------------------------|-------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                   | Se eliminado, a instrução não é executada e as  saídas não são atualizadas. Se definido, a  instrução é executada.  Padrão é definido.                                                                                                                                            |
| TimerEnable BOOL         |                   | Se definido, isso permite que o temporizador  opere e acumule tempo.  Padrão é eliminado.                                                                                                                                                                                         |
|                          | PRE DINT          | Valor predefinido do temporizador. Esse é o valor  em unidade de 1 milissegundo que o ACC  precisa alcançar antes da sincronização  terminar. Se inválido, a instrução define o bit  correto em Status e o temporizador não é  executado.  Válido = 0 até inteiro positivo máximo |

| Reset BOOL    | Solicitar para restaurar o temporizador. Quando  definido, o temporizador é restaurado.  Padrão é eliminado.  Quando o parâmetro de entrada Reset é  definido, a instrução elimina EN, TT e DN e  define ACC = 0.    |
|---------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Parâmetro  de saída       | Tipo de  dados    | Descrição                                                                                                                                                                        |
|---------------------------|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                           |                   | EnableOut BOOL A instrução produziu um resultado válido.                                                                                                                         |
|                           |                   | ACC BOOL O tempo acumulado em milissegundos.                                                                                                                                     |
|                           | ENF BOOL          | Saída habilitada pelo temporizador. Indica que a  instrução do temporizador está habilitada.                                                                                     |
|                           | TT BOOL           | Saída de sincronização do temporizador.  Quando definida, a operação de sincronização  está em andamento.                                                                        |
|                           | DN BOOL           | Saída da sincronização executada. Indica que o  tempo acumulado é maior ou igual à  pré-configuração.                                                                            |
|                           |                   | Status DINT Status do bloco de funções.                                                                                                                                          |
| InstructFault  (Status.0) | BOOL              | A instrução detectou um dos seguintes erros de  execução. Esse não é um erro de controlar maior  ou menor. Verifique os bits de status restantes  para determinar o que ocorreu. |
| PresetInv  (Status.1)     |                   | BOOL O valor predefinido é inválido.                                                                                                                                             |

## Descrição

Quando verdadeiro, a instrução TONR acumula tempo até que a:

-  A instrução TONR seja desabilitada
-  ACC PRE

A base de tempo é sempre em 1 milissegundo. Por exemplo, para um temporizador de 2 segundos, insira 2.000 para o valor PRE.

<!-- image -->

Defina o parâmetro de entrada Reset para restaurar a instrução. Se TimerEnable for definido quando Reset for verdadeiro, a instrução TONR inicializa o temporizador novamente quando Reset for falso.

## Como o temporizador opera

Um temporizador é executado subtraindo-se o horário da sua última varredura do horário atual:

-  ACC = ACC + (current\_time - last\_time\_scanned)

Após isso atualizar o ACC, o temporizador define last\_time\_scanned= current\_time. Isso torna o temporizador pronto para a próxima varredura.

Importante:

Assegure-s de escanear o temporizador pelo menos a cada 69 minutos enquanto ele estiver em operação. Do contrário, o valor ACC não será corrigido.

O valor last\_time\_scanned tem uma faixa de tempo de até 69 minutos. O cálculo do temporizador será sobrescrito se você não escanear o temporizador dentro de 69 minutos. O valor ACC não será corrigido se isso acontecer.

Enquanto o temporizador estiver em execução, faça a varredura dele dentro de 69 minutos se você o colocar em uma:

-  Subrotina
-  Seção de código que está entre as instruções JMP e LBL
-  Gráfico de função sequencial (SFC)
-  Evento ou tarefa periódica
-  Rotina do estado de uma fase

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                                           |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------|
|                                    | Pré-varredura Os bits EnableIn e EnableOut são eliminados para falso.                                                                     |
|                                    | Tag.EnableIn é falso Os bits EnableIn e EnableOut são eliminados para falso.                                                              |
| Tag.EnableIn é  verdadeiro         | Os bits EnableIn e EnableOut são definidos para verdadeiro.  O algoritmo principal da instrução é executado e as saídas  são atualizadas. |
| Primeira execução  da instrução    | N/A                                                                                                                                       |
| Primeira varredura  da instrução   | EN, TT e DN são eliminados e o valor ACC é definido como  0.                                                                              |
|                                    | Pós-varredura Os bits EnableIn e EnableOut são eliminados para falso.                                                                     |

## Texto estruturado

| Condição/estado A ção realizada                                                     |
|-------------------------------------------------------------------------------------|
| Pré-varredura Consulte Pré-varredura na tabela de Bloco de funções.                 |
| Execução normal  Consulte Tag.EnableIn é verdadeiro na tabela de Bloco de  funções. |
| Pós-varredura Consulte Pós-varredura na tabela de Bloco de funções.                 |

## Exemplo

## Bloco de funções

<!-- image -->

## Texto estruturado

```
TONR_01.PRE := 500; TONR_01.Reset := Reset; TONR_01.TimerEnable := Input; TONR(TONR_01); timer_state := TONR_01.DN; Consulte também Atributos comuns na página 879
```

Temporizador de atraso ativado (TON) na página 142

Restaurar (RES) na página 119

Sintaxe de texto estruturado na página 912

## Instruções de entrada/saída

## Entrada/Saída

As instruções de entrada/saída lêem ou gravam dados de ou para o controlador ou um bloco de dados para ou de outro módulo em outra rede.

## Instruções disponíveis

## Diagrama ladder e Texto estruturado

<!-- image -->

## Bloco de funções

## Indisponível

| Se você desejar:                                                                                                                                                  | Use esta instrução:    |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------|
| Enviar dados para ou a partir  de outro módulo                                                                                                                    | MSG                    |
| Obter informações do status  do controlador                                                                                                                       | GSV                    |
| Definir informações do status  do controlador                                                                                                                     | SSV                    |
| Enviar valores de saída para  um módulo E/S ou controlador  de consumo em um ponto  específico em sua lógica  Disparar uma tarefa de evento  em outro controlador | IOT                    |

## Consulte também

Especificar os detalhes da comunicação na página 180

Especificar mensagens CIP na página 285

Selecionar o tipo de mensagem na página 267

Exemplos da configuração MSG na página 163

Determinar as informações da memória do controlador na página 198
