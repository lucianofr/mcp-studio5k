---
type: Instruction
title: "Tamanho em elementos (SIZE)"
description: "Calcular o desvio padrão de dint\_array, que é DINT[4,5]."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L13228-L13389"
---

## Tamanho em elementos (SIZE)

## Exemplo 2

Calcular o desvio padrão de dint\_array, que é DINT[4,5].

<!-- image -->

## Diagrama ladder

<!-- image -->

## Consulte também

Instruções de arquivo/diversas na página 493

AVE na página 520

Atributos comuns na página 879

Sinalizadores de status de operações matemáticas na página 879

Conversões de dados na página 883

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução SIZE encontra o número de elementos (tamanho) na dimensão designada da matriz de Source ou do operando de string e coloca o resultado no operando Size. A instrução encontra o tamanho de uma dimensão de uma matriz.

## A instrução opera em:

-  Matrizes
-  Matrizes em uma estrutura
-  Matrizes que fazem parte de uma matriz maior
-  Tags de string

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

SIZE(Source,Dimtovary,Size);

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                    |
|----------------|---------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                        |
|                |   Membros de um operando de estrutura estão  substituídos.                                             |
|                |   Exceto quanto especificado, os operandos da  estrutura são compartilhados por múltiplas  instruções. |

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

|                    | Operando Tipo de dados Formato Descrição    |                    |                                                                                                                                 |                                                                                                                                 |
|--------------------|---------------------------------------------|--------------------|---------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------|
| Source SINT        | INT  DINT  REAL  estrutura  Tipo de string  | Tag de  Matriz     | Primeiro elemento da matriz  em que a instrução deve  operar  Tags que não são matrizes  não são aceitas durante a  verificação | Primeiro elemento da matriz  em que a instrução deve  operar  Tags que não são matrizes  não são aceitas durante a  verificação |
| Dimension to  Vary | DINT                                        | imediato (0, 1, 2) | Dimensão a usar:                                                                                                                | Dimensão a usar:                                                                                                                |
| Dimension to  Vary | DINT                                        | imediato (0, 1, 2) | Para o  tamanho de:                                                                                                             | Inserir:                                                                                                                        |
| Dimension to  Vary | DINT                                        | imediato (0, 1, 2) | primeira  dimensão                                                                                                              | 0                                                                                                                               |
| Dimension to  Vary | DINT                                        | imediato (0, 1, 2) | segunda  dimensão                                                                                                               | 1                                                                                                                               |
| Dimension to  Vary | DINT                                        | imediato (0, 1, 2) | terceira  dimensão                                                                                                              | 2                                                                                                                               |
|                    | Size SINT  INT  DINT  REAL                  | tag                | Tag para armazenar o  número de elementos da  dimensão especificada da  matriz                                                  | Tag para armazenar o  número de elementos da  dimensão especificada da  matriz                                                  |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                               |
|------------------------------------|-------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                               |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como  Rung-condition-in.                           |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como  Rung-condition-in.  A instrução é executada. |
| Pós-varredura N/A                  |                                                                               |

## Texto estruturado

| Condição/estado A ção realizada    |                                                                         |
|------------------------------------|-------------------------------------------------------------------------|
| Pré-varredura                      | Consulte Pré-varredura na tabela do  Diagrama ladder                    |
| Execução normal                    | Consulte rung-condition-in é  verdadeira na tabela de Diagrama  ladder. |
| Pós-varredura                      | Consulte Pós-varredura na tabela de  Diagrama ladder.                   |

## Exemplos

## Exemplo 1

Encontrar o número de elementos na dimensão 0 (primeira dimensão) de array\_a. Armazenar o tamanho em array\_a\_size. Neste exemplo, a dimensão 0 de array\_a tem 10 elementos.

## Diagrama ladder

<!-- image -->

## Texto estruturado

SIZE(array\_a,0,array\_a\_size);

## Exemplo 2

Encontrar o número de elementos no membro DATA de string\_1, que é uma string. Armazenar o tamanho em string\_1\_size.

Neste exemplo, o membro DATA de string\_1 tem 82 elementos. A string usa o tipo de dados STRING padrão. Uma vez que cada elemento contém um caractere, string\_1 pode conter até 82 caracteres.

## Diagrama ladder

<!-- image -->

## Texto estruturado

SIZE(string\_1.DATA[0],0,string\_1\_size);

## Exemplo 3

String\_a é uma matriz de estruturas de string. A instrução SIZE encontra o número de elementos no membro DATA da estrutura de string e armazena o tamanho em data\_size\_a.

Neste exemplo, o membro DATA tem 24 elementos. A estrutura de string tem um comprimento especificado pelo usuário de 24.

## Diagrama ladder

<!-- image -->

## Texto estruturado

SIZE(string\_a.[0].DATA[0],0,data\_size\_a);

## Consulte também

Instruções de arquivo/diversas na página 493

Indexação por meio de matrizes na página 893

Conversões de dados na página 883

Sintaxe de texto estruturado na página 912

## Modo Tudo

No modo Tudo, todos os elementos especificados na matriz são operados antes de continuar para a instrução seguinte. A operação começa quando a instrução rung-condition-in passa de falso para verdadeiro. O valor de posição (.POS) na estrutura de controle aponta para o elemento na matriz que a instrução está usando no momento. A operação para quando o valor de .POS é igual ao valor de .LEN.

<!-- image -->

O seguinte diagrama de tempo mostra a relação entre bits de status e a operação de instrução. Quando a execução da instrução é concluída, o bit .DN é definido. O bit .DN, o bit .EN e o valor de .POS são eliminados quando rung-condition-in é falsa. Somente então outra execução da instrução pode ser disparada por uma transição de falso para verdadeiro de rung-condition-in.

<!-- image -->
