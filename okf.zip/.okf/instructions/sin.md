---
type: Instruction
title: "Seno (SIN)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L17838-L17973"
---

## Seno (SIN)

## Texto estruturado

| Condição/estado A ção realizada                                                                  |
|--------------------------------------------------------------------------------------------------|
| Pré-varredura N/A.                                                                               |
| Execução normal  O controlador calcula o cosseno da Source e  coloca o resultado no Destination. |
| Pós-varredura N/A                                                                                |

## Exemplo

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

result := COS(value);

## Consulte também

Instruções de trigonometria na página 724

Radiano (RAD) na página 774

Atributos comuns na página 879

Sinalizadores de status de operações matemáticas na página 879

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução SIN pega o arco seno do valor de Source (em radianos) e armazena o resultado no Destination.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

dest := SIN(source);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

## Diagrama ladder

| Operando  Tipo  (Type)             |              | Format Des crição (Description)    |
|------------------------------------|--------------|------------------------------------|
| Origem SINT  INT:  DINT  REAL      | Somente  tag | encontra o seno desse  valor       |
| Destination SINT  INT:  DINT  REAL | tag          | tag a armazenar o  resultado       |

## Texto estruturado

|                               |              | Operando Tipo (Type) Format Descrição (Description)    |
|-------------------------------|--------------|--------------------------------------------------------|
| Origem SINT  INT:  DINT  REAL | Somente  tag | encontra o seno desse  valor                           |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Bloco de funções

| Operando Tipo (Type)                | Format    | Descrição  (Description)    |
|-------------------------------------|-----------|-----------------------------|
| SIN tag FBD_MATH_ADVANCED Structure |           | Estrutura de  SIN           |

## Estrutura de FBD\_MATH\_ADVANCED

| Parâmetro  de entrada    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                               |
|--------------------------|-------------------------------|-----------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                               | Entrada Habilitar. Se eliminado, a  instrução não é executada e as saídas  não são atualizadas.  O padrão é definido. |
| Origem REAL              |                               | Entrada para a instrução matemática.                                                                                  |

| Parâmetro  de saída    | Tipo de dados  (Data Type)    | Descrição (Description)                             |
|------------------------|-------------------------------|-----------------------------------------------------|
|                        |                               | EnableOut BOOL Indica se instrução está habilitada. |
|                        | Dest REAL                     | Resultado da instrução matemática.                  |

## Aspectos do operador

O operador SIN pode ser usado em diversas expressões. Semelhantemente, a função SIN é invocada em declarações do Texto estruturado. Ambas as aplicações de SIN retornam um resultado REAL contendo o seno da Source. Dependendo do contexto, esse valor pode, então, ter o tipo convertido, se apropriado.

## Descrição (Description)

A instrução SIN pega o arco seno do valor de Source (em radianos) e armazena o resultado no Destination.

A instrução calcula o seno da Source e retorna o resultado REAL. O valor resultante é sempre maior ou igual a -1 e menor ou igual a 1.

É possível usar SIN como um operador em expressões ladder e como uma função em declarações de Texto estruturado.

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                       | Afeta sinalizadores de status de  operações matemáticas                    |
|---------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580 | Condicional, consulte Sinalizadores  de status de operações  matemáticas . |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact  GuardLogix 5370 e GuardLogix 5570                     | Sim                                                                        |

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                                               |
|---------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A.                                                                                            |
| Rung-condition-in é falsa N/D                                                                                 |
| Rung-condition-in é  verdadeira  O controlador calcula o seno da Source e  coloca o resultado no Destination. |
| Pós-varredura N/D                                                                                             |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                   |
|                                    | Tag.EnableIn é falso. EnableOut é eliminado como falso                                                            |
| Tag.EnableIn é  verdadeiro         | EnableOut é definido como verdadeiro. Se o  bloco gerar um transbordamento, EnableOut  será eliminado como falso. |
| Primeira varredura da  instrução   | N/D                                                                                                               |
| Primeira execução da  instrução    | N/D                                                                                                               |
| Pós-varredura N/D                  |                                                                                                                   |
