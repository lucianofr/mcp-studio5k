---
type: Instruction
title: "Subtrair (SUB)"
description: "Índice por meio de matrizes na página 893"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L9675-L9994"
---

## Subtrair (SUB)

Índice por meio de matrizes na página 893

Conversões de dados na página 883

Sinalizadores de status de operações matemáticas na página 879

Funções FBD na página 425

Valores imediatos na página 882

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

Quando habilitada, a instrução SUB e o operador '-' subtraem Source B de Source A.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

<!-- image -->

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

Dica:

Use o operador '-' em uma expressão para obter o mesmo resultado. Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões e atribuições no texto estruturado.

## Operandos

## Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

| Operando      | Tipo de dados (Data  Type)  Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix 5570    | Tipo de dados (Data Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix 5380  e GuardLogix 5580    | Format         | Descrição  (Description)          |
|---------------|----------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|----------------|-----------------------------------|
| Source A SINT | INT  DINT  REAL                                                                                                                  | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                       | immediate  tag | Valor do qual  subtrair Source B. |

| Source B SINT  INT  DINT  REAL    | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL    | immediate  tag    | Valor a subtrair  da Source A.              |
|-----------------------------------|------------------------------------------------------------------|-------------------|---------------------------------------------|
| Dest SINT  INT  DINT  REAL        | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL    | tag               | Tag a armazenar  o resultado da  instrução. |

## Diagrama de bloco da função

Bloco FBD

| Operando    | Tipo de dados  (Data Type)    | Format    | Descrição  (Description)    |
|-------------|-------------------------------|-----------|-----------------------------|
|             | SUB FBD_MATH tag              |           | Estrutura de  SUB           |

## Estrutura de FBD\_MATH

| Membros  de entradas   | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                 |
|------------------------|-------------------------------|-------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL          |                               | Entrada Habilitar. Se falso,  a instrução não será  executada e as saídas não  serão atualizadas.  Padrão é verdadeiro. |
| SourceA REAL           |                               | Valor do qual subtrair a  SourceB.                                                                                      |
| SourceB REAL           |                               | Valor a subtrair de  SourceA.                                                                                           |

| Membros  de saída    | Tipo de dados  (Data Type)    | Descrição (Description)                                             |
|----------------------|-------------------------------|---------------------------------------------------------------------|
| EnableOut BOOL       |                               | Indica se a instrução foi  executada sem falhas ao  ser habilitada. |
|                      |                               | Dest REAL Resultado da instrução.                                   |

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operandos de  entrada (pinos  esquerdos)    | Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580  Tipo de dados (Data Type)    | Descrição  (Description)           |
|---------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------|
| SourceA (topo) SINT                         | USINT  INT  UINT  DINT  UDINT  LINT  ULINT  REAL                                                                                                  | Valor do qual subtrair a  SourceB. |
| SourceB (fundo) SINT                        | USINT  INT  UINT  DINT  UDINT  LINT  ULINT  REAL  LREAL                                                                                           | Valor a subtrair de  SourceA.      |

| Operando de  saída  (Pino direito)    | Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580  Tipo de dados (Data Type)    | Descrição  (Description)    |
|---------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
|                                       | Dest DINT  UDINT  LINT  ULINT  REAL  LREAL                                                                                                        | Resultado da função.        |

## Consulte Funções FBD .

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                         | Afeta sinalizadores de status  de operações matemáticas    |
|-----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580 | Condicional                                                |
| Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix 5570                     | Sim                                                        |

Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                                                 |
|-----------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                                                                                               |
| Rung-condition-in é falsa Definir Rung-condition-out como  Rung-condition-in                                    |
| Rung-condition-in é  verdadeira  Definir Rung-condition-out como  Rung-condition-in  Dest = Source A - Source B |
| Pós-varredura N/D                                                                                               |

## Diagrama de bloco da função

Bloco FBD

| Condição/estado A ção realizada    |                                                                                                                                                                    |
|------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                    |
| EnableIn é falso                   | Defina EnableOut como  EnableIn                                                                                                                                    |
|                                    | EnableIn é verdadeiro Dest = SourceA - SourceB  Se um transbordamento  ocorrer  Elimina EnableOut para falso  Caso contrário  Configure EnableOut para  verdadeiro |
| Primeira execução da  instrução    | N/D                                                                                                                                                                |
| Primeira varredura da  instrução   | N/D                                                                                                                                                                |
| Pós-varredura N/D                  |                                                                                                                                                                    |

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A ção realizada    |                                           |
|------------------------------------|-------------------------------------------|
| Pré-varredura N/D                  |                                           |
|                                    | Varredura normal Dest = SourceA - SourceB |
| Primeira execução da  instrução    | N/D                                       |
| Primeira varredura da  instrução   | N/D                                       |
| Pós-varredura N/D                  |                                           |

## Exemplos

## Diagrama ladder

<!-- image -->

## Funções FBD

## Diagrama de bloco da função

## Bloco FBD

<!-- image -->

## Função FBD

<!-- image -->

## Texto estruturado

DINT\_dest := DINT\_srcA - DINT\_srcB;

## Consulte também

Sintaxe de texto estruturado na página 912

Índice por meio de matrizes na página 893

Sinalizadores de status de operações matemáticas na página 879

Conversões de dados na página 883

Funções FBD na página 425

Valores imediatos na página 882

Essas informações aplicam-se aos controladores Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580..

Funções FBD são implementadas de acordo com IEC 61131-3 Edição 3. Funções aritméticas e numéricas são fornecidas no idioma do Diagrama do bloco de funções. Idiomas do Diagrama ladder e Texto estruturado incluem Aritmética e Numérico como operadores e funções.

## Sobrecarga de funções

Funções FBD possuem uma ou mais entradas e uma saída. Funções FBD são implementadas para eficiências, possuem pegadas menores e usam menos recursos do sistema para operar que Blocos de funções FBD.

## Funções FBD

-  Exigem todas as entradas e saídas. Todas as entradas devem ser de um tipo de dados suportado.
-  Não têm tags de suporte ou tipos de dados predefinidos. Valores de entrada conectados não são convertidos para tipos de dados predefinidos.
-  Não têm bits EnableIn e são sempre executados.

## Exemplo: Função de adição

<!-- image -->

## Consulte também

Sobrecarga de funções na página 426

Conversões de dados na página 883

Essas informações aplicam-se aos controladores Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A sobrecarga de funções define duas ou mais funções com o mesmo nome, mas assinatura diferente, como tipo de argumento ou retorno. Funções FBD que suportam sobrecarga assumem uma gama de tipos de dados de entrada. Os tipos de dados de saída dependem dos tipos de dados de entrada.

As Funções FBD seguem essas regras:

-  Promoção do tipo de entrada
-  Promoção do tipo de entrada
-  Tipos de dados da maior para a menor prioridade: LREAL, REAL, ULINT, LINT, UDINT, DINT, UINT, INT, USINT, SINT
-  Todas as entradas promovem o tipo de dados da entrada com a maior classificação antes da execução

-  Se todas as entradas tiverem um valor de DINT ou mais baixo, todas as entradas são promovidas para o tipo DINT antes da execução
-  O tipo de saída depende do tipo de entrada O tipo de saída da função é o tipo de entrada promovida

Por exemplo, função de adição,

-  Entradas SINT + UINT são promovidas para entradas DINT + DINT. Saídas são DINT
-  Entradas USINT + LINT são promovidas para entradas LInT + LINT. Saídas são LINT
-  Entradas UNIT + LREAL são promovidas para entradas LREAL + LREAL. Saídas são LREAL

## Consulte também

Funções FBD na página 425

Conversões de dados na página 883

Instruções lógicas/de movimento

## Instruções lógicas/de movimento

As instruções de Movimento modificam e movem bits.

Instruções disponíveis

Diagrama ladder

MOV

MVM

AND

OR

Diagrama de bloco da função

Bloco FBD

MVMT

AND

BNOT

BOR

Função FBD

BNOT

BOR

Texto estruturado

MVMT

SWPB

OR

BAND

BTDT

| Se você desejar:                                                  | Use esta instrução:    |
|-------------------------------------------------------------------|------------------------|
| Copiar um valor ou mover strings MOV                              |                        |
| Copiar uma parte específica de um inteiro MVM                     |                        |
| Copiar uma parte específica de um inteiro  em um bloco de funções | MVMT                   |
| Mover bits dentro de um inteiro ou entre  inteiros                | BTD                    |

XOR

XOR

NOT

BXOR

NOT

SWPB

BTDT

CLR

BAND

BTD

BXOR
