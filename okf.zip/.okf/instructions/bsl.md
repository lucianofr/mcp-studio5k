---
type: Instruction
title: "Deslocamento de bit esquerdo (BSL)"
description: "A instrução BSL desloca os bits especificados uma posição para a esquerda dentro de Array."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L13490-L13593"
---

## Deslocamento de bit esquerdo (BSL)

## Instruções de string ASCII na página 825

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução BSL desloca os bits especificados uma posição para a esquerda dentro de Array.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Diagrama ladder

|                       |                | Operando Tipo (Type) Format Descrição (Description)                                 |
|-----------------------|----------------|-------------------------------------------------------------------------------------|
| Matriz                | DINT  ARRAY    | tag Matriz a modificar  especifica o primeiro elemento  para iniciar o deslocamento |
|                       |                | Controle CONTROL tag Estrutura de controle da operação                              |
|                       |                | Source Bit BOOL tag Bit a mudar na posição liberada.                                |
| Comprimento  (Length) | DINT immediate | Número de bits da matriz para  mudar                                                |

## Estrutura de CONTROL

| Mnemônico  Tipo de  dados (Data  Type)    | Descrição (Description)                                                                                                         |
|-------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------|
| .EN BOOL                                  | O bite de habilitação indica que a instrução BSL  está habilitada.                                                              |
| .DN BOOL                                  | O bit executado é definido para indicar que bits  deslocaram uma posição para a esquerda.                                       |
| .UL BOOL                                  | O bit de descarregar é a saída da instrução. O  bit .UL armazena o status do bit que foi  deslocado para fora da faixa de bits. |
|                                           | .ER BOOL O bit de erro é definido quando .LEN <0.                                                                               |
| .LEN DINT                                 | O comprimento especifica o número de bits de  matriz a mudar.                                                                   |

## Descrição

Quando habilitada, a instrução descarrega o bit superior dos bits especificados para o bit .UL, desloca os bits restantes uma posição para a esquerda e carrega o endereço do Bit para o bit 0 de Array.

Importante: Você deve testar e confirmar que a instrução não altera os dados que você não deseja alterar.

A instrução BSL opera em memória contígua de dados. A instrução BSL opera em memória contígua de dados. Somente para os controladores CompactLogix 5370 e ControlLogix 5570, o escopo da instrução é restringido à tag base. A instrução BSL não gravará dados fora da tag base, mas pode cruzar fronteiras de membro. Se você especificar uma matriz que faça parte de uma estrutura, o comprimento excederá o tamanho dessa matriz; é preciso testar e confirmar que a instrução BSL não altere os dados que você não deseja alterar.

Para Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580, os dados são restringidos pelo membro especificado.

Nessa instrução de transição, a lógica ladder de relé alterna rung-condition-in de falso para verdadeiro para a instrução ser executada.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha maior ocorrerá se: Tipo de falha Código de falha    |    |
|---------------------------------------------------------------|----|
| O LEN exceder o tamanho da matriz 4                           | 20 |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                                 |
|------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | O bit .EN é eliminado para falso.  O bit .DN é eliminado para falso.  O bit .ER é eliminado para falso.  O valor de .POS é eliminado                            |
|                                    | Rung-condition-in é falsa O bit .EN é eliminado para falso.  O bit .DN é eliminado para falso.  O bit .ER é eliminado para falso.  O valor de .POS é eliminado. |
| Rung-condition-in é  verdadeira    | Consulte o fluxograma BSL (Verdadeiro).                                                                                                                         |
| Pós-varredura N/D                  |                                                                                                                                                                 |

## Fluxograma BSL (verdadeiro)

<!-- image -->

## Exemplos

## Exemplo 1

Quando habilitada, a instrução BSL inicia no bit 0 em array\_dint[0]. A instrução descarrega array\_dint[0].9 no bit .UL, muda os bits restantes e carrega input\_1 para array\_dint[0].0. Os bits restantes (10-31) são inválidos.

## Diagrama ladder

Exemplo 2:

<!-- image -->

Quando habilitada, a instrução BSL inicia no bit 0 em array\_dint[0]. A instrução descarrega array\_dint[1].25 no bit .UL, muda os bits restantes e carrega input\_1 para array\_dint[0].0. Os bits restantes (31-26 na array\_dint[1]) são inválidos.

<!-- image -->

## Consulte também

```
Atributos comuns na página 879 Conversões de dados na página 883
```
