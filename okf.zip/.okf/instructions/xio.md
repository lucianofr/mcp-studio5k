---
type: Instruction
title: "Examinar se aberto (XIO)"
description: "Test\_Eixo\_00 é um Alias para Eixos\_04."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L1496-L1570"
---

## Examinar se aberto (XIO)

Test\_Eixo\_00 é um Alias para Eixos\_04.

O tipo AXIS\_CIP\_DRIVE possui um membro LINT chamado CIPAxisFaults.

BusUndervoltageULFault é um membro do bit do CIPAxisFaults.

Test\_Axis\_00.BusUndervoltageULFault é bit 34 de CIPAxisFaults. O valor do bit 34 é 0x400000000.

Se Test\_Axis\_00.BusUndervoltageULFault for verdadeiro, isso habilite a próxima instrução.

## Consulte também

Instruções de bit na página 75

Endereçamento de bit na página 894

Indexação por meio de matrizes na página 893

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução XIO examina o bit de dados para definir ou eliminar a condição do degrau.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Diagrama ladder

| Operando          | Tipo de  dados    | Formato Des crição    |                                                                                                                                                     |
|-------------------|-------------------|-----------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|
| Data bit BOOL tag |                   |                       | Bit a ser testado. Há diversos  modos de endereçamento do  operando possíveis para o bit  de dados, consulte  Endereçamento de bits para  exemplos. |

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A               | ção realizada                                                                                                                                                   |
|---------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A               |                                                                                                                                                                 |
| Rung-condition-in é falsa       | Definir Rung-condition-out como  Rung-condition-in                                                                                                              |
| Rung-condition-in é  verdadeira | Se Bit de dados for verdadeiro,  rung-condition-out será eliminado para  falso.  Se Bit de dados for falso,  rung-condition-out será definido como  verdadeiro. |
| Pós-varredura N/A               |                                                                                                                                                                 |

## Exemplos

Exemplo 1

## Diagrama ladder

<!-- image -->

Se Limit\_Switch\_01 for falso, a próxima instrução será habilitada.
