---
type: Instruction
title: "Pontos de rastreamento (TPT)"
description: "Os rastreamentos resultantes aparecem conforme mostrados aqui."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L21822-L21939"
---

## Pontos de rastreamento (TPT)

Os rastreamentos resultantes aparecem conforme mostrados aqui.

<!-- image -->

## Consulte também

Atributos comuns na página 879

Conversões de dados na página 883

Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate.

Dados de log de pontos de rastreamento que você seleciona quando um degrau é verdadeiro.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados.

## Diagrama ladder

|                                        |     | Operando Tipo Formato Descrição                                                                                   |
|----------------------------------------|-----|-------------------------------------------------------------------------------------------------------------------|
| Format String Tag                      |     | Uma string define a  formatação para os relatórios  de rastreamento (tanto da tela  quanto registrados no disco). |
| Trace This BOOL  SINT  INT  DINT  REAL | Tag | A tag que você deseja  rastrear.                                                                                  |

## Descrição

Pontos de rastreamento são programados com a instrução de saída de ponto de rastreamento (TPT). Quando as entradas em um degrau contendo uma instrução TPT forem verdadeiras, a instrução TPT grava uma entrada de rastreamento em uma exibição de rastreamento ou arquivo de log.

Você pode rastrear muitas tags com a instrução TPT. Entretanto, a string de formatação pode conter apenas 82 caracteres. Como a string de formatação requer dois caracteres para cada tag que você deseja rastrear, você não pode rastrear mais de 41 tags com uma única instrução TPT. Contudo, para separar dados de tag nos rastreamentos, você precisará incluir espaços e outros elementos de formação, reduzindo, assim, o número de tags que uma instrução TPT pode efetivamente rastrear para menos de 41.

## Formato de string

Quando a string de formato nas instruções de ponto de rastreamento e ponto de interrupção, você pode controlar como as tags rastreadas aparecem nos rastreamentos ou nas janelas de ponto de interrupção. O formato da string é mostrado a seguir:

-  título:(texto)%(tipo)

Onde título é uma string de texto identificado o ponto de rastreamento ou ponto de interrupção, texto é uma string descrevendo a tag (ou qualquer outro texto da sua escolha) e %(tipo) indica o formato da tag. Você precisa de um indicador de tipo para cada tag que você está rastreando com a instrução de ponto de rastreamento ou ponto de interrupção.

Por exemplo, você poderia formatar uma string de ponto de rastreamento conforme a seguir:

-  Meu ponto de rastreamento (my tracepoint):Tag 1 = %e and Tag 2 = %d

O %e formata a primeira tag rastreada como flutuação de precisão dobrada com um expoente e o %d formata a segunda tag rastreada como um inteiro decimal assinalado.

Neste caso, você tem uma instrução de ponto de rastreamento que possui dois operandos Trace This (um para um REAL e um para um INT, embora o valor de qualquer tag possa ser formatado com qualquer sinalizador).

A janela de ponto de rastreamento resultante que apareceria quando o ponto de rastreamento é disparado ficaria conforme no exemplo.

<!-- image -->

Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

| Condição                        | Ação de lógica ladder de relé                                                                                                 |
|---------------------------------|-------------------------------------------------------------------------------------------------------------------------------|
|                                 | Pré-varredura O degrau se torna falso.                                                                                        |
| Rung-condition-in é  falsa      | O degrau se torna falso.                                                                                                      |
| Rung-condition-in é  verdadeira | O degrau se torna verdadeiro. A  execução salta para o degrau que  contém a instrução LBL com o nome  de rótulo referenciado. |
|                                 | Pós-varredura O degrau se torna falso.                                                                                        |

## Exemplo

Este degrau dispara um rastreamento de três valores analógicos quando qualquer um deles exceder um dado valor (30,01).

<!-- image -->

Exiba as informações de ponto de rastreamento na string de Formato (myformat).

Neste caso, a string de formato contém este texto:

-  Analog inputs trace:Analog inputs = %f, %f, and %f

Quando o ponto de rastreamento é disparado, os caracteres antes dos dois-pontos ('Analog input trace') aparecem na barra de título da janela de rastreamento. Os outros caracteres compõem os rastreamentos. Neste exemplo, %f representa as tags a serem rastreadas ('analogvalue1,' 'analogvalue2,' e 'analogvalue3').

Os rastreamentos resultantes aparecem conforme mostrados aqui.

<!-- image -->

Quanto este rastreamento é registrado no disco, os caracteres antes dos dois-pontos aparecem nos rastreamentos.

Isto indica qual ponto de rastreamento causou qual entrada de rastreamento. Este é um exemplo de uma entrada de rastreamento. 'Analog inputs trace:' é o texto de cabeçalho da string de formato do ponto de rastreamento.

Rastreamento de entradas analógicas: Analog inputs = 31,00201, 30,282000, and 30,110001.

## Consulte também

Instruções de depuração na página 865

Ponto de Interrupção (BPT) na página 866

Atributos comuns na página 879

Conversões de dados na página 883
