---
type: Instruction
title: "Entrada do sequenciador (SQI)"
description: "A instrução SQI detecta quando uma etapa é concluída em um par de sequência de instruções SQO/SQI."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L14252-L14333"
---

## Entrada do sequenciador (SQI)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução SQI detecta quando uma etapa é concluída em um par de sequência de instruções SQO/SQI.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

As regras de conversão de dados para tipos de dados mistos em uma instrução. Consulte Conversão de dados.

|                        |                        | Operando Tipo Formato Descrição                                                                                                                                                                                                 |
|------------------------|------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                        |                        | Array DINT tag de matriz Matriz de sequenciador  Especifica o primeiro elemento da  matriz de sequenciador  não use CONTROL.POS no subscrito                                                                                    |
| Mask SINT  INT  DINT   | tag  imediato          | Esse operando é usado para  determinar quais bits bloquear (0) ou  passar (1) quando aplicado ao  elemento de Source e Array  referenciado por .POS.  Os tipos INT e SINT são zero  estendidos para o tamanho de um  tipo DINT. |
| Source SINT  INT  DINT | tag  imediato          | Os dados de entrada utilizados para  comparar a um elemento de matriz  referenciado por .POS.                                                                                                                                   |
| Control  CONTR OL      |                        | tag Estrutura de controle da operação  A mesma tag de controle deve ser  usada nas instruções SQO e SQL                                                                                                                         |
|                        | Length DINT imediato   | Isso representa a estrutura de  CONTROL .LEN.                                                                                                                                                                                   |
|                        | Position DINT imediato | Isso representa a estrutura de  CONTROL .POS.                                                                                                                                                                                   |

## Estrutura de CONTROL

|                     | Mnemônico Tipo de dados Descrição    |                                                                                                                                |
|---------------------|--------------------------------------|--------------------------------------------------------------------------------------------------------------------------------|
|                     |                                      | .ER (Erro) BOOL A instrução encontrou um erro.                                                                                 |
| .LEN  (Comprimento) | DINT                                 | O comprimento especifica o número de  etapas do sequenciador na matriz de  sequenciador                                        |
| .POS (Posição) DINT |                                      | A posição identifica o elemento de Array  que a instrução está comparando a  Source no momento.  O valor inicial costuma ser 0 |

## Descrição

Quando verdadeira, a instrução SQI passa elemento de Array atual e Source por Mask. Os resultados dessas operações de mascaramento são comparados e, se forem iguais, a rung-condition-out será definida como verdadeira, caso contrário, a rung-condition-out será eliminada como falsa. Geralmente, usa a mesma estrutura de CONTROL que as instruções SQO e SQL.

## Usando SQI sem SQO

Quando a instrução SQI determina que uma etapa está concluída, a instrução ADD incrementa a matriz de sequenciador. GRT determina se outro valor está disponível para verificar na matriz de sequenciador. A instrução MOV redefine o valor de posição depois de passar completamente pela matriz de sequenciador de uma só vez.

<!-- image -->

Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                     |
|---------------------------------------------------------------------|
| Pré-varredura N/A                                                   |
| Rung-condition-in é falsa N/A                                       |
| Rung-condition-in é  verdadeira  Consulte o fluxograma (Verdadeiro) |
| Pós-varredura N/A                                                   |

## Fluxograma (Verdadeiro)

<!-- image -->

## Exemplo

## Diagrama ladder

<!-- image -->

Se você usar a instrução SQI sem uma instrução SQO emparelhada, é preciso incrementar externamente a matriz de sequenciador.
