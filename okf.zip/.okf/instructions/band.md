---
type: Instruction
title: "Booliano AND (BAND)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L10766-L10956"
---

## Booliano AND (BAND)

## Exemplos

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

value\_result\_or := value\_1 OR value\_2;

## Consulte também

Sintaxe de texto estruturado na página 912

Indexação por meio de matrizes na página 893

Sinalizadores de status de operações matemáticas na página 879

Conversões de dados na página 883

Instruções de movimento na página 429

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução BAND aplica uma operação ANDs de maneira lógica com oito entradas boolianas no máximo. Para realizar um AND bit a bit, consulte And bit a bit (AND) .

## Idiomas disponíveis

## Diagrama ladder

Esta instrução não está disponível no diagrama ladder.

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

Função FBD

<!-- image -->

Dica:

Função FBD suporta apenas duas entradas e é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Diagrama de bloco da função

## Bloco FBD

| Operando    | Tipo de dados (Data  Type)         | Format    | Descrição  (Description)    |
|-------------|------------------------------------|-----------|-----------------------------|
|             | BAND tag FBD_BOOLEAN_AND estrutura |           | Estrutura de  BAND          |

## Estrutura de FBD\_BOOLEAN\_AND

Função FBD

| Membros  de entradas Tipo de dados  (Data Type)    | Descrição (Description)                                                                                               |
|----------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL                                      | Entrada Habilitar. Se eliminado, a  instrução não é executada e as  saídas não são atualizadas.  O padrão é definido. |
| In1 BOOL                                           | Primeira entrada booliana.  Definida como 1 no primeiro  download.                                                    |
| In2 BOOL                                           | Segunda entrada booliana.  Definida como 1 no primeiro  download.                                                     |
| In3 BOOL                                           | Terceira entrada booliana.  Definida como 1 no primeiro  download.                                                    |
| In4 BOOL                                           | Quarta entrada booliana.  Definida como 1 no primeiro  download.                                                      |
| In5 BOOL                                           | Quinta entrada booliana.  Definida como 1 no primeiro  download.                                                      |
| In6 BOOL                                           | Sexta entrada booliana.  Definida como 1 no primeiro  download.                                                       |
| In7 BOOL                                           | Sétima entrada booliana.  Definida como 1 no primeiro  download.                                                      |
| In8 BOOL                                           | Oitava entrada booliana.  Definida como 1 no primeiro  download.                                                      |

| Membros  de saída    | Tipo de dados  (Data Type)    | Descrição (Description)                             |
|----------------------|-------------------------------|-----------------------------------------------------|
|                      |                               | EnableOut BOOL Indica se instrução está habilitada. |
|                      |                               | Saída BOOL A saída da instrução.                    |

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operandos de  entrada (pinos  esquerdos)    | Tipo de dados (Data Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix 5380  e GuardLogix 5580    | Descrição  (Description)    |
|---------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
|                                             | In1 BOOL                                                                                                                                            | Primeira entrada  booliana  |
|                                             | In2 BOOL                                                                                                                                            | Segunda entrada  booliana   |

| Operando de  saída (Pino  direito)    | Tipo de dados (Data Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix 5380  e GuardLogix 5580    | Descrição  (Description)    |
|---------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
|                                       | Saída BOOL                                                                                                                                          | A saída da  instrução.      |

Consulte Funções FBD.

## Operação

## Bloco FBD

A instrução BAND aplica uma operação ANDs com oito entradas boolianas no máximo. Se uma entrada não for usada, ela será definida como padrão (1).

Out = In1 AND In2 AND In3 AND In4 AND In5 AND In6 AND In7 AND In8

| Importante:    | Ao remover um fio de entrada da instrução BAND  durante uma edição, certifique-se de que a entrada  esteja definida (1).    |
|----------------|-----------------------------------------------------------------------------------------------------------------------------|

## Função FBD

Dica:

Função FBD suporta apenas duas entradas e é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

A função FBD aplica uma operação ANDs com duas entradas boolianas.

Out = In1 AND In2

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução.

Execução

Diagrama de bloco da função

## Bloco FBD

| Condição/estado A ção realizada    |                                                                                                                                |
|------------------------------------|--------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                       |
| Tag.EnableIn é falso               | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                       |
| Tag.EnableIn é  verdadeiro         | Os bits EnableIn e EnableOut são definidos  para verdadeiro.  A instrução é executada conforme descrito  na seção de operação. |
| Primeira execução  da instrução    | N/D                                                                                                                            |
| Primeira varredura  da instrução   | N/D                                                                                                                            |
| Pós-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                       |

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A ção realizada    |                                    |
|------------------------------------|------------------------------------|
| Pré-varredura N/D                  |                                    |
|                                    | Varredura normal Out = In1 AND In2 |
| Primeira execução da  instrução    | N/D                                |
| Primeira varredura da  instrução   | N/D                                |
| Pós-varredura N/D                  |                                    |

## Exemplo

## Diagrama de bloco da função

## Bloco FBD

Neste exemplo, bool\_in1 é copiado em BAND\_02.In1, bool\_in2 é copiado em BAND\_02.In2, o resultado de AND em execução de todas as entradas BAND\_02 é colocado em BAND\_02.Out, e BAND\_02.Out é então copiado em value\_result\_and.

| Se bool_in1 for: Se bool_in2 for: Então value_result_and será:    |
|-------------------------------------------------------------------|
| 0 0 0                                                             |
| 0 1 0                                                             |
| 1 0 0                                                             |
| 1 1 1                                                             |

<!-- image -->

## Função FBD

Esse exemplo ilustra a execução de um AND em bool\_in1 e bool\_in2 e coloca o resultado em value\_result\_and.

<!-- image -->

## Consulte também

And bit a bit (AND) na página 439

Funções FBD na página 425
