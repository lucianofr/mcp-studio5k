---
type: Instruction
title: "Fim temporário (TND)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L15571-L15643"
---

## Fim temporário (TND)

## Exemplo

## Diagrama ladder

<!-- image -->

## Consulte também

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução TND condicionalmente termina uma rotina.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

TND();

## Operandos

## Diagrama ladder

Nenhum

## Texto estruturado

Nenhum

## Descrição

Quando habilitada, a instrução TND age como o fim da rotina. Se a instrução TND estiver em uma subrotina, o controle retorna à rotina da chamada. Se a instrução TND estiver na rotina principal, o controle retorna ao próximo programa dentro da tarefa atual.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                  |
|------------------------------------|------------------|
| Pré-varredura N/A                  |                  |
| Rung-condition-in é  falsa         | N/A              |
| Rung-condition-in é  verdadeira.   | A rotina termina |
| Pós-varredura N/A                  |                  |

## Texto estruturado

| Condição/estado A ção realizada    |                                                                        |
|------------------------------------|------------------------------------------------------------------------|
| Pré-varredura                      | Consulte Pré-varredura na  tabela de Diagrama ladder.                  |
| Execução normal                    | Consulte rung-condition-in é  verdadeira na tabela de  Diagrama ladder |
| Pós-varredura                      | Consulte Pós-varredura na  tabela de Diagrama ladder.                  |
