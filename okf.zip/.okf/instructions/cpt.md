---
type: Instruction
title: "Calcular (CPT)"
description: "Ao ser habilitada, a instrução CPT avalia a expressão e armazena o resultado em Dest."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L8650-L8775"
---

## Calcular (CPT)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

Ao ser habilitada, a instrução CPT avalia a expressão e armazena o resultado em Dest.

A instrução CPT habilita expressões complexas em uma instrução.

Ao avaliar a expressão, todos os operandos não LREAL serão convertidos em LREAL antes dos cálculos serem realizados se qualquer uma dessas condições for verdadeira:

-  Qualquer operando na expressão é LREAL.
-  A expressão contém SIN, COS, TAN, ASN, ACS, ATN, LN, LOG, DEG ou RAD.
-  O Dest for LREAL

Há regras para os operadores permitidos nas aplicações de segurança. Consulte Operadores válidos .

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                   |
|----------------|--------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                       |
|                |   Membros de um operando de estrutura estão substituídos.                                             |
|                |   Exceto quanto especificado, os operandos da estrutura são  compartilhados por múltiplas instruções. |

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

| Operando  Tipo de dados  (Data Type)    |                | Format Des crição (Description)                                                         |
|-----------------------------------------|----------------|-----------------------------------------------------------------------------------------|
| Dest SINT  INT  DINT  REAL              | tag            | Tag a armazenar o resultado                                                             |
| Expression SINT  INT  DINT  REAL        | immediate  tag | Uma expressão consistindo  em tags e/ou valores  imediatos separados pelos  operadores. |

## Expressões de formatação

Para cada operador usado em uma expressão, um ou dois operandos (tags ou valores imediados) devem ser fornecidos. Use a tabela a seguir para formatar operadores e operandos dentro de uma expressão.

| Para operadores  que operam em:    | Use este formato: Exemplo               |                                                            |
|------------------------------------|-----------------------------------------|------------------------------------------------------------|
|                                    | Um operando operador(operando) ABS(tag) |                                                            |
| Dois operandos                     | operand_a operador  operand_b           | tag_b + 5  tag_c AND tag_d  (tag_e**2) MOD (tag_f / tag_g) |

## Determine a ordem da operação

A instrução realiza as operações nas expressões em uma ordem prescrita. Especifique a ordem da operação ao agrupar termos dentro de parênteses. Isso força a instrução a realizar uma operação dentro dos parênteses adiante das outras operações.

As operações de igual ordem são realizadas da esquerda para a direita.

| Ordem Op eração                                                              |
|------------------------------------------------------------------------------|
| 1 ( )                                                                        |
| 2  ABS, ACS, ASN, ATN, COS, DEG, FRD, LN,  LOG, RAD, SIN, SQR, TAN, TOD, TRN |
| 3 **                                                                         |
| 4 - (negate), NOT                                                            |
| 5 *, /, MOD                                                                  |
| 6 - (subtract), +                                                            |
| 7 AND                                                                        |
| 8 XOR                                                                        |
| 9 OR                                                                         |

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                         | Afeta sinalizadores de status  de operações matemáticas    |
|-----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580 | Condicional                                                |
| Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix 5570                     | Sim                                                        |

Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                     |
|------------------------------------|---------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                     |
| Rung-condition-in é falsa          | Definir Rung-condition-out como  Rung-condition-in                                                                  |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como  Rung-condition-in  A instrução avalia a expressão e  armazena o resultado em Dest. |
| Pós-varredura N/D                  |                                                                                                                     |

## Exemplos

## Diagrama ladder

## Exemplo 1

Ao ser habilitada, a instrução CPT avalia value\_1 multiplicado por 5, divide este resultado pelo resultado de value\_2 dividido por 7 e armazena o resultado final em result\_1.

<!-- image -->

## Exemplo 2

Ao ser habilitada, a instrução CPT trunca float\_value\_1 e float\_value\_2 para uma potência de dois, divide float\_value\_1 truncado por este resultado, e então armazena o resto da divisão em float\_value\_result\_cpt.

## Diagrama ladder

<!-- image -->

## Consulte também

Instruções de cálculo na página 369

Operadores válidos na página 366

Índice por meio de matrizes na página 893

Sinalizadores de status de operações matemáticas na página 879
