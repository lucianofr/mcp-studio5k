---
type: Instruction
title: "Instrução desconhecida (UNK)"
description: "&lt;statements&gt;"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L15914-L15955"
---

## Instrução desconhecida (UNK)

&lt;statements&gt;

UIE();

## Consulte também

Instruções de controle do programa na página 620

Atributos comuns na página 879

A instrução UNK funciona como uma indicação que você digitou um tipo de instrução que não é definido dentro do conjunto de instruções Logix Designer.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções

## Texto estruturado

Essa instrução não está disponível em bloco de funções.

## Operandos

## Diagrama ladder

| Operando Tipo Formato Descrição    | Operando Tipo Formato Descrição    |
|------------------------------------|------------------------------------|
|                                    | Unknown imediato imediato          |

## Consulte também

Instruções de controle do programa na página 620

## Instruções de Circulação/Interrupção
