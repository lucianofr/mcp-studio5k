---
type: Instruction
title: "Um pulso na borda ascendente (OSR)"
description: "Quando limit\_switch1 vai de definido para eliminado, a instrução OSFI define OutputBit para uma varredura."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L1811-L1918"
---

## Um pulso na borda ascendente (OSR)

## Texto estruturado

| Condição/estado A ção realizada    |                                                                    |
|------------------------------------|--------------------------------------------------------------------|
| Pré-varredura                      | Consulte Pré-varredura na tabela de Bloco  de funções.             |
| Execução normal                    | Consulte Tag.EnableIn é verdadeiro na  tabela de Bloco de funções. |
| Pós-varredura                      | Consulte Pós-varredura na tabela de Bloco  de funções.             |

## Exemplo

Quando limit\_switch1 vai de definido para eliminado, a instrução OSFI define OutputBit para uma varredura.

## Bloco de funções

<!-- image -->

## Texto estruturado

```
OSFI_01.InputBit := limit_switch1; OSFI(OSFI_01); Output_state := OSFI_01.OutputBit;
```

## Consulte também

```
Instruções de bit na página 75
```

OSF na página 82

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução OSR define o bit de saída para uma varredura quando rung-condition-in realiza a transição de falso para verdadeiro.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

## Diagrama ladder

| Operando  Tipo de  dados    | Formato Des crição                                                                                                                                                                                                       |
|-----------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Storage Bit BOOL tag        | Armazena rung-condition-in  de quando a instrução foi  executada pela última vez.  Há vários modos de  endereçamento de operando  possíveis para o bit de  armazenamento, consulte  Endereçamento de bits para  exemplo. |
|                             | Output Bit BOOL tag Bit a ser modificado.                                                                                                                                                                                |

## Descrição

<!-- image -->

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                                      |
|------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | O bit de armazenamento é definido como  verdadeiro para evitar disparos inválidos durante a  primeira varredura do programa.  O bit de saída é eliminado para falso. |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como Rung-condition-in  O bit de armazenamento é restaurado para falso.  O bit de saída é eliminado para falso.                           |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como Rung-condition-in  Consulte o fluxograma OSR (Verdadeiro).                                                                           |
| Pós-varredura N/A                  |                                                                                                                                                                      |

<!-- image -->

## Exemplo

## Diagrama ladder

<!-- image -->

Esse exemplo mostra como um OSR pode ser usado para fazer uma ou mais instruções de disparo da borda de subida. Todas as vezes que Limit\_Switch\_01 realiza a transição de falso para verdadeiro, OSR será definido como Output\_bit\_02 para verdadeiro. Qualquer instrução condicionada pela Output\_bit\_02 será ativada e, uma vez que Output\_bit\_02 é verdadeira somente para uma varredura, será executada uma vez por transição.

## Consulte também

Instruções de bit na página 75
