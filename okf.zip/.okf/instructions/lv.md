---
type: Instruction
title: "Validação de licença (LV)"
description: "As instruções de licença são usadas para verificar as licenças usadas em um projeto."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L21940-L24057"
---

## Validação de licença (LV)

## Instruções de licença

As instruções de licença são usadas para verificar as licenças usadas em um projeto.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Indisponível

## Texto estruturado

Indisponível

## Consulte também

Instruções de conversão matemática na página 763

Essas informações aplicam-se aos controladores Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução Validação de licença (LV) verifica se uma licença não expirada associada a uma rotina ou Instrução complementar está presente no controlador.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Diagrama ladder

| Operando                              | Tipo  (Type)    |                | Format Des crição (Description)                                                                                                                                                               |
|---------------------------------------|-----------------|----------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Código de  fornecedor  (Vendor  Code) |                 | DINT immediate | Número exclusivo de  identificação do fornecedor  da licença associada a uma  rotina ou instrução  complementar.  Aceita um valor inteiro  imediato na faixa entre 0 e  2.147.483.647.        |
| Código do  produto  (Product  Code)   |                 | DINT immediate | Número exclusivo de  identificação do código do  produto da licença  associada a uma rotina ou  instrução complementar.  Aceita um valor inteiro  imediato na faixa entre 0 e  2.147.483.647. |

Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                                       |
|------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                       |
| Rung-condition-in é  falsa         | N/D                                                                                                                                                                   |
| Rung-condition-in é  verdadeira    | Comparação numérica"  Se a licença é válida e utilizada no projeto  Defina Rung-condition-out como verdadeira  Caso contrário  Eliminar Rung-condition-out para falso |
| Pós-varredura N/D                  |                                                                                                                                                                       |

## Exemplo

<!-- image -->

## Consulte também

Instruções de licença na página 875

## Atributos comuns

## Sinalizadores de status de operações matemáticas

## Atributos comuns para instruções gerais

Siga as diretrizes neste capítulo sobre os atributos comuns das Instruções gerais.

Para obter mais informações sobre atributos que são comuns para as instruções LOGIX 5000™, clique em um dos tópicos abaixo.

Sinalizadores de status de operações matemáticas na página 879

Valores imediatos na página 882

Conversões de dados na página 883

Tipos de dados elementares na página 887

Tipos de dados LINT na página 890

Valores de ponto flutuante na página 891

Índice por meio de matrizes na página 893

Endereçamento de bit na página 894

Siga as diretrizes neste tópico sobre Sinalizadores de status de operações matemáticas.

Descrição (Description)

| Controladores Des                                                                                                     | crição (Description)                                                                                                                                                                                                                                     |
|-----------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580 | Um conjunto de Sinalizadores de status de operações matemáticas para  acessar diretamente com as instruções. Esses sinalizadores são  atualizados apenas em rotinas de diagrama ladder a não são tags e os  aliases de sinalizadores não são aplicáveis. |
| Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix 5570                     | Um conjunto de Sinalizadores de status de operações matemáticas para  acessar diretamente com as instruções. Esses sinalizadores são  atualizados em todos os tipos de rotina (mas não são tags) e os aliases  de sinalizadores não são aplicáveis.      |

## Sinalizadores de status

| Sinalizador de  status                   | Descrição (Description)  (Para Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix 5580,  Compact GuardLogix 5380 e GuardLogix 5580)                                                                                                                                                                                                                                                                                                                                                                                                                   | Descrição (Description)  (Para Controladores CompactLogix 5370,  ControlLogix 5570, Compact GuardLogix  5370 e GuardLogix 5570)                                                                                                                                                                                                                                                                                                                                                                                                                    |
|------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| S:FS  Sinalizador de  varredura  inicial | O sinalizador de varredura inicial é configurado pelo  controlador:    Na primeira vez em que é feita uma varredura em  um programa depois que o controlador entra no  Modo de execução    Na primeira vez em que é feita uma varredura em  um programa após o cancelamento de sua  inibição    Quando uma rotina é chamada de uma Ação SFC  e é feita a primeira varredura da etapa que detém  essa ação.  Use o sinalizador de varredura inicial para inicializar  dados a serem usados em varreduras posteriores.  Ele também é conhecido como bit de primeira | O sinalizador de varredura inicial é configurado  pelo controlador:    Na primeira vez em que é feita uma  varredura em um programa depois que o  controlador entra no Modo de execução    Na primeira vez em que é feita uma  varredura em um programa após o  cancelamento de sua inibição    Quando uma rotina é chamada de uma Ação  SFC e é feita a primeira varredura da Etapa  que detém essa ação.  Use este sinalizador para inicializar dados a  serem usados em varreduras posteriores. Ele  também é conhecido como bit de primeira |
| S:N  Sinalizador  negativo               | O controlador define o sinalizador negativo quando o  resultado de uma operação matemática ou lógica é  um valor negativo. Use este sinalizador como um  teste rápido para um valor negativo.                                                                                                                                                                                                                                                                                                                                                                        | O controlador define o sinalizador negativo  quando o resultado de uma operação  matemática ou lógica é um valor negativo. Use  este sinalizador como um teste rápido para um  valor negativo.  O uso de S:N é mais eficaz do que o uso da  instrução CMP.                                                                                                                                                                                                                                                                                         |
| S:Z  Sinalizador  zero                   | O sinalizador zero é definido pelo controlador  quando o resultado de uma operação matemática ou  lógica é zero. Use este sinalizador como um teste  rápido para um valor igual a zero.  O sinalizador zero é eliminado no início da execução  de uma instrução capaz de definir esse sinalizador.                                                                                                                                                                                                                                                                   | O controlador define o sinalizador zero quando  o resultado de uma operação matemática ou  lógica é zero. Use este sinalizador como um  teste rápido para um valor igual a zero.                                                                                                                                                                                                                                                                                                                                                                   |

| S: V  Sinalizador de  transbordamen to     | O controlador define o sinalizador de  transbordamento quando:    O resultado de uma operação matemática resulta  em um transbordamento.  Por exemplo, adicionar 1 a um SINT gera um  transbordamento quando o valor varia de 127 a  -128.    A tag de destino é muito pequena para manter o  valor.  Por exemplo, se você tentar armazenar o valor  123456 em uma tag SINT ou INT.  Use o transbordamento para verificar se o resultado  de uma operação ainda está dentro da faixa.  Se os dados sendo armazenados são um tipo string,  S:V será definido se a string for muito grande para  caber na tag de destino.  Dica: Se aplicável, defina S:V com uma instrução  OTE ou OTL.  Clique em Propriedades do controlador >guia  Avançado > Relatar falhas de transbordamento (Controller Properties > Advanced tab > Report  Overflow Faults) para habilitar ou desabilitar a  geração de relatórios de falhas de transbordamento.  Se um transbordamento ocorrer durante a avaliação  de um subscrito de matriz, serão geradas uma falha  principal e uma secundária para indicar que o índice  está fora da faixa.    | O controlador define o sinalizador de  transbordamento quando:    O resultado de uma operação matemática  resulta em um transbordamento.  Por exemplo, adicionar 1 a um SINT gera um  transbordamento quando o valor varia de  127…-128.    A tag de destino é muito pequena para  manter o valor.  Por exemplo, se você tentar armazenar o  valor 123456 em uma tag SINT ou INT.  Use o sinalizador de transbordamento para  verificar se o resultado de uma operação ainda  está dentro da faixa.  Uma falha secundária será gerada sempre que  o sinalizador de transbordamento estiver  configurado.  Dica: Se aplicável, defina S:V com uma  instrução OTE ou OTL.    |
|--------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| S:C  Sinalizador de  transporte            | O controlador define o sinalizador de transporte  quando uma operação matemática resulta na  geração do transporte do bit mais significativo.  Somente as instruções ADD e SUB, e não os                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | quando uma operação matemática resulta na  geração do transporte do bit mais significativo.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
|                                            | operadores + e –, com valores de números inteiros  afetam esse sinalizador.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | O controlador define o sinalizador de transporte                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| S:MINOR  Sinalizador de  falha  secundária | O controlador define o sinalizador de falha  secundária quando há pelo menos uma falha  secundária de programa.  Use a tag de falha secundária se tiver ocorrido uma  falha secundária. Esse bit só é disparado por falhas  de programação, como transbordamento. Não é  disparado por uma falha de bateria. O bit é  eliminado no início de cada varredura.  Dica: Se aplicável, defina explicitamente S:MINOR  com uma instrução OTE ou OTL.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | O controlador define o sinalizador de falha  secundária quando há pelo menos uma falha  secundária de programa.  Use o sinalizador de falha secundária para  testar se uma falha secundária ocorrer e tome  as ações apropriadas. Esse bit é disparado  somente por falhas de programação, como  transbordamento. Não é disparado por uma  falha de bateria. O bit é eliminado no início de  cada varredura.  Dica: Se aplicável, defina explicitamente  S:MINOR com uma instrução OTE ou OTL.                                                                                                                                                                               |
| Importante:                                | Os Sinalizadores de status de operações matemáticas são definidos com base no valor armazenado.  Instruções que normalmente não afetam os sinalizadores de status de operações matemáticas talvez  pareçam fazê-lo se ocorrer uma conversão dos tipos de dados mistos para os parâmetros da  instrução. O processo de conversão de tipo define os sinalizadores de status de operações                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         | Os Sinalizadores de status de operações matemáticas são definidos com base no valor armazenado.  Instruções que normalmente não afetam os sinalizadores de status de operações matemáticas talvez  pareçam fazê-lo se ocorrer uma conversão dos tipos de dados mistos para os parâmetros da  instrução. O processo de conversão de tipo define os sinalizadores de status de operações                                                                                                                                                                                                                                                                                       |

## Valores imediatos

## Expressões em subscritos de matriz

| Controladores Des                                                                                                     | crição (Description)                                                                                                                                                                                                                                                                                                                                             |
|-----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580 | As expressões não definem os sinalizadores de status com base nos resultados de  operações matemáticas. Se as expressões resultarem em transbordamento:    Uma falha secundária será gerada se o controlador está configurado para gerar falhas  menores.    Uma falha principal (tipo 4, código 20) será gerada porque o valor resultante está fora da  faixa |
| Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix 5570                     | As expressões definem os sinalizadores de status com base nos resultados de operações  matemáticas. Se um subscrito de matriz for uma expressão, tanto a expressão quanto a  instrução poderão gerar falhas menores.                                                                                                                                             |

Dica:

Se um subscrito de matriz for muito grande (fora da faixa), será gerada uma falha principal (tipo 4, código 20).

Ao inserir um valor imediato (constante) no formato decimal (por exemplo, -2, 3), o controlador armazena o valor ao usar 32 bits. Se você inserir um valor em uma base diferente de decimal, como binário ou hexadecimal, e não especificar todos os 32 bits, o controlador coloca um zero nos bits que você não especificar (preenchimento de zeros).

Importante:

Preenchimento de zeros de valores imediato binário, octal e hexadecimal menores do que 32 bits.

|              | Se você inserir O controlador armazena    |
|--------------|-------------------------------------------|
| -1           | 16#ffff ffff (-1)                         |
| 16#ffff (-1) | 16#0000 ffff (65535)                      |
|              | 8#1234 (668) 16#0000 029c (668)           |
| 2#1010 (10)  | 16#0000 000a (10)                         |

## Valores imediatos inteiros

| Se você inserir O controlador armazena    |
|-------------------------------------------|
| Sem qualquer sufixo DINT                  |
| "U" UDINT                                 |
| "L" LINT                                  |
| "UL" ULINT                                |

## Conversões de dados

## Valores imediatos de ponto flutuante

| Se você inserir O controlador armazena    |
|-------------------------------------------|
| Sem qualquer sufixo REAL                  |
| "L" LREAL                                 |

Conversões de dados ocorrem ao misturar tipos de dados na programação.

| Ao programar:                      | Conversões podem ocorrer quando  você:                                            |
|------------------------------------|-----------------------------------------------------------------------------------|
| Diagrama ladder  Texto estruturado | Misture tipos de dados para os  parâmetros dentro de uma  Instrução ou expressão. |
| Bloco de funções                   | Conecte dois parâmetros que possuem  tipos de dados diferentes                    |

Instruções são executadas com mais velocidade e exigem menos memória se todos os operandos da instrução usarem:

-  O mesmo tipo de dados.
-  Um tipo de dados intermediário:
-  Todas as instruções do bloco de funções suportam apenas um operando do tipo de dados.
-  Se misturar tipos de dados ou usar tags que não são o tipo de dados ideal, o controlador converte os dados de acordo com essas regras:
-  Operandos são convertidos de acordo com a classificação de tipos de dados de SINT, USINT, INT, UINT, DINT, UDINT, LINT, ULINT, REAL e LREAL com classificação de 1 (o mais baixo) a 10 (o mais alto).

Dica:

Para reduzir o tempo e memória para a conversão de dados, use o mesmo tipo de dados para todos os operandos de uma instrução.

## Converta SINT ou INT para DINT ou DINT para LINT

Uma tag de origem de entrada SINT ou INT é promovida para um valor DINT por extensão de sinal para tag de origem. Instruções que convertem valores SINT ou INT para valores DINT usam um dos seguintes métodos de conversão.

| Esse método de conversão converte dados ao colocar                                                                                                            |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| extensão de sinal  O valor do bit mais à esquerda (o sinal do valor) em cada  posição do bit para a esquerda dos bits existentes até que haja  32 ou 64 bits. |
| Preenchimento de zeros Zeros à esquerda dos bits existentes até que haja 32 ou 64 bits.                                                                       |

Instruções lógicas usam preenchimento de zeros. Todas as outras instruções usam extensão de sinal

O exemplo a seguir mostra os resultados da conversão de um valor usando extensão de sinal e preenchimento de zeros.

|                                                            | Este valor 2#1111_1111_1111_1111  (-1)            |
|------------------------------------------------------------|---------------------------------------------------|
| É convertido para  esse valor por  extensão de sinal       | 2#1111_1111_1111_1111_1111_1111_1111_1111 (-1)    |
| É convertido para  esse valor por  preenchimento de  zeros | 2#0000_0000_0000_0000_1111_1111_1111_1111 (65535) |

Se você usar uma tag SINT ou INT e um valor imediato em uma instrução que converte dados por extensão de sinal, use um desses métodos para lidar com valores imediatos.

Especifique qualquer valor imediato na base decimal.

Se você inserir o valor em uma base diferente de decimal, especifique todos os 32 bits do valor imediato. Para fazer isso, insira o valor do bit mais à esquerda em cada posição do bit à sua esquerda até que haja 32 bits.

Crie uma tag para cada operando e use o mesmo tipo de dados em toda a instrução. Para atribuir um valor constante:

Insira-o em uma das tags.

Adicione uma instrução MOV que move o valor a uma das tags.

Use uma instrução MEQ para verificar apenas os bits requeridos.

Os seguintes exemplos mostram duas formas de misturar um valor imediato com uma tag INT. Ambos os exemplos verificam os bits de um módulo E/S 1771 para determinar se todos os bits estão ativados. Como a palavra de dados de entrada de um módulo E/S 1771 é uma tag INT, é mais fácil usar um valor constante de 16 bits.

| Importante:    | Misturar uma tag INT com um valor imediato  Como remote_rack_1:I.Data[0] é uma tag INT, o  valor para compará-la também é inserido em uma  tag INT.    |
|----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------|

<!-- image -->

## Importante:

Misturar uma tag INT com um valor imediato Como remote\_rack\_1:I.Data[0] é uma tag INT, o valor para compará-la primeiro move para int\_0, também uma tag INT. A instrução EQU, então, compara ambas as tags.

<!-- image -->

## Converta inteiro para REAL

O controlador armazena valores REAL no formato de número de ponto flutuante de precisão simples IEEE. Ele utiliza um bit para o sinal do valor, 23 bits para o valor base e oito bits para o expoente (32 bits no total). Se você misturar uma tag de número inteiro (SINT, INT ou DINT) e uma tag REAL como entradas na mesma instrução, o controlador converterá o valor do número inteiro para um valor REAL antes da execução da instrução.

-  Um valor SINT ou INT sempre é convertido para o mesmo valor REAL.
-  Um valor DINT talvez não seja convertido para o mesmo valor REAL:
-  Um valor REAL usa até 24 bits para o valor base (23 bits armazenados mais um bit "oculto").
-  Um valor DINT usa até 32 bits para o valor (um para o sinal e 31 para o valor).

Se o valor DINT exigir mais de 24 bits significativos, ele talvez não seja convertido para o mesmo valor REAL. Se não for, o controlador armazena os 24 bits superiores arredondados para o valor par mais próximo.

## Converta DINT para SINT ou INT

Para converter um valor DINT em um valor SINT ou INT, o controlador trunca a parte superior do DINT e armazena os bits inferiores que se encaixam no tipo de dados. Se o valor for grande demais, a conversão gera um transbordamento.

| Converta um DINT para um INT e um SINT         | Converta um DINT para um INT e um SINT         |
|------------------------------------------------|------------------------------------------------|
| Este valor DINT Converte para este valor menor | Este valor DINT Converte para este valor menor |
|                                                | 16#0001_0081 (65,665) INT: 16#0081 (129)       |
|                                                | SINT: 16#81 (-127)                             |

## Converta REAL para SINT, INT ou DINT

Para converter um valor REAL para um valor inteiro, o controlador arredonda qualquer parte fracionária e armazena os bits que se encaixam no tipo de dados de resultado. Se o valor for grande demais, a conversão gera um transbordamento.

Os números são arredondados como nos seguintes exemplos:

Frações &lt; 0,5 são arredondadas para baixo para o número inteiro mais próximo.

Frações &gt; 0,5 são arredondadas para cima para o número inteiro mais próximo.

Frações = 0,5 são arredondadas para cima ou para baixo para o número par mais próximo.

| Importante:    | Conversão de valores REAL para valores DINT    |
|----------------|------------------------------------------------|
|                | Este valor REAL Converte-se neste valor DINT   |
| -2,5  -3,5     | -2  -4                                         |
| -1,6 -2        |                                                |
| -1,5 -2        |                                                |
| -1,4 -1        |                                                |
| 1,4 1          |                                                |
| 1,5 2          |                                                |
| 1,6 2          |                                                |
| 2,5  3,5       | 2  4                                           |

## Tipos de dados elementares

O controlador suporta tipos de dados elementares definidos nos tipos de dados definidos pela IEC 1131-3. Os tipos de dados elementares são:

| Tipo de dados Descrição    |                                                  | Faixa                                                                                                                                                       |
|----------------------------|--------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------|
| BOOL                       | Booliano de 1 bit                                | 0 = eliminado  1 = definido                                                                                                                                 |
| SINT                       | Inteiro de 1 bytes                               | -128 a 127                                                                                                                                                  |
| INT                        | Inteiro de 2 bytes                               | -32.768 a 32.767                                                                                                                                            |
| DINT                       | Inteiro de 4 bytes                               | -2.147.483.648 a 2.147.483.647                                                                                                                              |
| REAL                       | Número de ponto flutuante de  4 bytes            | -3,402823E 38  a -1,1754944E -38 (valores negativos)  e  0  e  1,1754944E -38  a 3,402823E 38 (valores positivos)                                           |
| LINT                       | Inteiro de 8 bytes                               | 0 para 32.535.129.599.999.999                                                                                                                               |
| USINT                      | Inteiro de 1 byte sem sinal 0 para 255           |                                                                                                                                                             |
| UINT                       | Inteiro de 2 byte sem sinal 0 para 65.535        |                                                                                                                                                             |
| UDINT                      | Inteiro de 4 byte sem sinal 0 para 4.294.967.295 |                                                                                                                                                             |
| ULINT                      |                                                  | Inteiro de 8 byte sem sinal 0 para 18.446.744.073.709.551.615                                                                                               |
| REAL                       | Número de ponto flutuante de  4 bytes            | -3.4028235E38 a -1.1754944E-38  (valores negativos)  e  0,0  e  1.1754944E-38 a 3.4028235E38  (valores positivos)                                           |
| LREAL                      | Número de ponto flutuante de  8 bytes            | -1.7976931348623157E308 a  -2.2250738585072014E-308  (valores negativos)  e  0,0  e  2.2250738585072014E-308 a  1.7976931348623157E308  (valores positivos) |

Esses controladores suportam os seguintes tipos de dados elementares:

| Controladores                                                                                                      | Tipo de dados                                                 |
|--------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix 5580,  Compact GuardLogix 5380 e GuardLogix 5580 | SINT, INT, DINT, LINT, REAL  USINT, UINT, UDINT, ULINT, LREAL |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact GuardLogix 5370  e GuardLogix 5570                    | SINT, INT, DINT, LINT, REAL.                                  |

O controlador lida com todos os valores imediatos como tipos de dados DINT.

O tipo de dados REAL também armazena dados infinito e NAN, mas a exibição do software varia de acordo com o formato de tela.

## Conversões de tipo de dados

Quando tipos de dados são misturados para operandos dentro de uma instrução, algumas instruções converterão automaticamente os dados para um tipo de dados ideal para aquela instrução. Em alguns casos, o controlador converte dados para caber em um novo tipo de dados; em outros casos, o controlador simplesmente encaixa os dados da melhor maneira possível.

| Conversão R                                               | esult                                                                                                                                                                                                                                                                   | esult                                                                                                                                                                                                                                                                   | esult                                                                                                                                                                                                                                                                   |
|-----------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| inteiro maior ao inteiro menor                            | O controlador trunca a porção superior do inteiro maior e gera um  transbordamento.  Por exemplo:                                                                                                                                                                       | O controlador trunca a porção superior do inteiro maior e gera um  transbordamento.  Por exemplo:                                                                                                                                                                       | O controlador trunca a porção superior do inteiro maior e gera um  transbordamento.  Por exemplo:                                                                                                                                                                       |
|                                                           | Decimal Biná                                                                                                                                                                                                                                                            | rio                                                                                                                                                                                                                                                                     |                                                                                                                                                                                                                                                                         |
|                                                           |                                                                                                                                                                                                                                                                         | DINT 65.665 0000_0000_0000_0001_0000_0000_1000_0001                                                                                                                                                                                                                     |                                                                                                                                                                                                                                                                         |
|                                                           |                                                                                                                                                                                                                                                                         | INT 129 0000_0000_1000_0001                                                                                                                                                                                                                                             |                                                                                                                                                                                                                                                                         |
|                                                           |                                                                                                                                                                                                                                                                         | SINT -127 1000_0001                                                                                                                                                                                                                                                     |                                                                                                                                                                                                                                                                         |
| SINT ou INT para REAL Nenhuma precisão de dados é perdida |                                                                                                                                                                                                                                                                         |                                                                                                                                                                                                                                                                         |                                                                                                                                                                                                                                                                         |
| DINT para REAL                                            | A precisão dos dados pode ser perdida. Ambos os tipos de dados armazenam  dados em 32 bits, mas o tipo REAL usa alguns dos seus 32 bits para  armazenar o valor do expoente. Se a precisão for perdida, o controlador a  assumirá da parte menos significativa do DINT. | A precisão dos dados pode ser perdida. Ambos os tipos de dados armazenam  dados em 32 bits, mas o tipo REAL usa alguns dos seus 32 bits para  armazenar o valor do expoente. Se a precisão for perdida, o controlador a  assumirá da parte menos significativa do DINT. | A precisão dos dados pode ser perdida. Ambos os tipos de dados armazenam  dados em 32 bits, mas o tipo REAL usa alguns dos seus 32 bits para  armazenar o valor do expoente. Se a precisão for perdida, o controlador a  assumirá da parte menos significativa do DINT. |
|                                                           | LREAL para LREAL Nenhuma precisão de dados é perdida.                                                                                                                                                                                                                   | LREAL para LREAL Nenhuma precisão de dados é perdida.                                                                                                                                                                                                                   | LREAL para LREAL Nenhuma precisão de dados é perdida.                                                                                                                                                                                                                   |
|                                                           | LREAL PARA REAL A precisão dos dados pode ser perdida.                                                                                                                                                                                                                  | LREAL PARA REAL A precisão dos dados pode ser perdida.                                                                                                                                                                                                                  | LREAL PARA REAL A precisão dos dados pode ser perdida.                                                                                                                                                                                                                  |
| LREAL/REAL para inteiro  sem sinal                        | A precisão dos dados pode ser perdida. Se o valor de origem for grande  demais para se encaixar no destino, o controlador armazena o que pode e  pode produzir um transbordamento.                                                                                      | A precisão dos dados pode ser perdida. Se o valor de origem for grande  demais para se encaixar no destino, o controlador armazena o que pode e  pode produzir um transbordamento.                                                                                      | A precisão dos dados pode ser perdida. Se o valor de origem for grande  demais para se encaixar no destino, o controlador armazena o que pode e  pode produzir um transbordamento.                                                                                      |
| Inteiro com sinal/Inteiro sem  sinal para LREAL/REAL      | Se o valor do inteiro tiver mais bits significativos do que possam ser  armazenados no destino, os bits menores serão truncados.                                                                                                                                        | Se o valor do inteiro tiver mais bits significativos do que possam ser  armazenados no destino, os bits menores serão truncados.                                                                                                                                        | Se o valor do inteiro tiver mais bits significativos do que possam ser  armazenados no destino, os bits menores serão truncados.                                                                                                                                        |
| Inteiro com sinal para inteiro  sem sinal                 | Se o valor de origem for grande demais para se encaixar no destino, o  controlador armazena o que pode e pode produzir um transbordamento.                                                                                                                              | Se o valor de origem for grande demais para se encaixar no destino, o  controlador armazena o que pode e pode produzir um transbordamento.                                                                                                                              | Se o valor de origem for grande demais para se encaixar no destino, o  controlador armazena o que pode e pode produzir um transbordamento.                                                                                                                              |
| Inteiro sem sinal para inteiro  com sinal                 | Se o valor de origem for grande demais para se encaixar no destino, o  controlador armazena o que pode e pode produzir um transbordamento.                                                                                                                              | Se o valor de origem for grande demais para se encaixar no destino, o  controlador armazena o que pode e pode produzir um transbordamento.                                                                                                                              | Se o valor de origem for grande demais para se encaixar no destino, o  controlador armazena o que pode e pode produzir um transbordamento.                                                                                                                              |

| REAL para inteiro    | O controlador arredonda a parte fracional e trunca a porção superior da parte  não fracional. Se dados forem perdidos, o controlador definirá o sinalizador de  status de transbordamento.  O arredondamento é para o número inteiro mais próximo:  menos de 0,5, arredondado para baixo; igual a 0,5, arredondado para o inteiro  par mais próximo; mais de 0,5, arredondado para cima  Por exemplo:    | O controlador arredonda a parte fracional e trunca a porção superior da parte  não fracional. Se dados forem perdidos, o controlador definirá o sinalizador de  status de transbordamento.  O arredondamento é para o número inteiro mais próximo:  menos de 0,5, arredondado para baixo; igual a 0,5, arredondado para o inteiro  par mais próximo; mais de 0,5, arredondado para cima  Por exemplo:    |
|----------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                      | REAL  (origem)                                                                                                                                                                                                                                                                                                                                                                                           | DINT (resultado)                                                                                                                                                                                                                                                                                                                                                                                         |
|                      | 1,6 2                                                                                                                                                                                                                                                                                                                                                                                                    |                                                                                                                                                                                                                                                                                                                                                                                                          |
|                      | -1,6 -2                                                                                                                                                                                                                                                                                                                                                                                                  |                                                                                                                                                                                                                                                                                                                                                                                                          |
|                      | 1,5 2                                                                                                                                                                                                                                                                                                                                                                                                    |                                                                                                                                                                                                                                                                                                                                                                                                          |
|                      | -1,5 -2                                                                                                                                                                                                                                                                                                                                                                                                  |                                                                                                                                                                                                                                                                                                                                                                                                          |
|                      | 1,4 1                                                                                                                                                                                                                                                                                                                                                                                                    |                                                                                                                                                                                                                                                                                                                                                                                                          |
|                      | -1,4 -1                                                                                                                                                                                                                                                                                                                                                                                                  |                                                                                                                                                                                                                                                                                                                                                                                                          |
|                      | 2,5 2                                                                                                                                                                                                                                                                                                                                                                                                    |                                                                                                                                                                                                                                                                                                                                                                                                          |
|                      | -2,5 -2                                                                                                                                                                                                                                                                                                                                                                                                  |                                                                                                                                                                                                                                                                                                                                                                                                          |

Não converta dados para ou do tipo de dados BOOL.

| Importante:    | Os sinalizadores de status de operações matemáticas são definidos                                                                                                                                                                                                                                                                                                   |
|----------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                | com base no valor que está sendo armazenado. Instruções que  normalmente não afetam as palavras-chave do status de operações  matemáticas podem aparecer para fazer isso se o tipo de conversão  ocorrer devido a tipos de dados mistos dos parâmetros de instrução.  O processo de conversão de tipo define as palavras-chave do status  de operações matemáticas. |

## Tipos de dados de segurança

O aplicativo Logix Designer evita a modificação de um tipo definido pelo usuário ou definido pelo complemento, o que acarretaria um tipo de dado inválido para os tipos definidos pelo usuário ou definidos pelo complemento referenciados diretamente ou indiretamente por uma tag de segurança. (Isso inclui as estruturas aninhadas.)

Tags de segurança podem ser compostas dos seguintes tipos de dados:

-  Todos os tipos de dados elementares
-  Tipos de dados predefinidos que são usados para instruções de segurança da aplicação.
-  Tipos de dados definidos pelo usuário ou matrizes que são compostas dos dois tipos anteriores.

## Edições online de nomes do membro UDT em tags de segurança

Edição online é permitida para nomes do membro de tipos de dados definidos pelo usuário em controladores CompactLogix 5380, Compact GuardLogix 5380,

## Tipos de dados LINT

CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. Contudo, edição online é desabilitada quando um tipo de dados definido pelo usuário é usado em uma tag de segurança e o controlador estiver no estado Protegido por segurança.

## Consulte também

Sinalizadores de status de operações matemáticas na página 879

Tipo de dados LINT é um inteiro de 64 bits.

O tipo de dados LINT pode ser usado em diversas instruções no Controlador Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 ou GuardLogix 5580, contudo, o tipo de dados LINT não pode ser usado na grande maioria das instruções em Controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570.

Considere o seguinte ao usar o tipo de dados LINT no Controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570.

Dica:

LINTs só podem ser usados com instruções de cópia (COP, CPS). São usadas com o atributo Tempo de CST/WallClock, sincronização de tempo e instruções complementares. Não é possível adicionar, subtrair, multiplicar nem dividir esse tipo de tag.

Ao usar tipos de dados LINT, considere as seguintes descrições quando esses problemas ocorrerem.

| Como Des                                                          | crição (Description)                                                                                                                                                                                                                                                                                                                 |
|-------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Mover/copiar valores DINT com dois  números inteiros para um LINT | Criar uma matriz de dois inteiros de dois  elementos, com 64 bits no total (ou seja, DINT[2]),  que poderá ser copiada em um número inteiro  longo.                                                                                                                                                                                  |
| Corrijir erro de Exibição de Data/Hora                            | Quando uma tag tem um valor negativo, não pode  ser exibida como Data/hora. No editor de tags,  verifique se o valor é negativo alterando o estilo da  tag de Data/hora para Binário. Quando o bit mais  significativo (o mais à esquerda) for 1, o valor será  negativo e, portanto, não poderá ser exibido como  uma data ou hora. |

## Valores de ponto flutuante

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

Controladores Logix lidam com valores de ponto flutuante de acordo com a norma IEEE 754 para aritmética de ponto flutuante. Esta norma define como números de ponto flutuante são armazenados e calculados. A norma IEEE 754 para matemática de ponto flutuante foi projetada para fornecer velocidade e a capacidade de lidar com números muito grandes em uma quantia razoável de espaço de armazenamento.

Uma tag REAL armazena um número de ponto flutuante normalizado de precisão simples.

Uma tag LREAL armazena um número de ponto flutuante normalizado de precisão dupla.

Os controladores suportam esses tipos de dados elementares:

| Controladores                                                                                                      | Tipo de dados (Data Type)    |
|--------------------------------------------------------------------------------------------------------------------|------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix 5580,  Compact GuardLogix 5380 e GuardLogix 5580 | REAL, LREAL                  |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact GuardLogix 5370  e GuardLogix 5570                    | REAL                         |

Números desnormalizados e -0,0 são tratados como 0,0

Se uma computação resultar em um valor NAN, o bit de sinal poderia ser positivo ou negativo. Nessa situação, o software exibe 1#.NAN sem sinal.

Nem todos os valores decimais podem ser exatamente representados nesse formato padrão, o que resulta na perda de precisão. Por exemplo, se você subtrair 10 de 10,1, você espera que o resultado seja 0,1. Em um controlador Logix, o resultado poderia muito bem ser 0,10000038. Neste exemplo, a diferença entre 0,1 e 0,10000038 é 0,000038%, ou praticamente zero. Para grande parte das operações, essa pequena imprecisão é insignificativa. Para colocar as coisas em perspectiva, se você estivesse enviando um valor de ponto flutuante para um módulo de saída analógica, não haveria diferença na tensão de saída para um valor sendo enviado ao módulo que difira em 0.000038%.

## Diretrizes para operações matemáticas de ponto flutuante

Siga essas diretrizes:

Ao realizar determinadas operações matemáticas de ponto flutuante, pode haver uma perda de precisão devido ao erro de arredondamento. Processadores de ponto flutuante possuem as suas próprias precisões internas que podem afetar os valores resultantes.

Não use matemática de ponto flutuante para valores monetários ou para funções do totalizador. Use valores INT ou DINT, converta a escala dos valores para cima e acompanhe o lugar decimal (ou use um valor INT ou DINT para dólares, e um segundo valor INT ou DINT para cents).

Não compare números de ponto flutuante. Em vez disso, verifique os valores dentro de uma faixa. A instrução LIM é fornecida especificamente para essa finalidade.

## Exemplos do totalizador

A precisão do tipo de dados REAL afeta aplicações de totalização de modo que erros ocorram ao adicionar números bem pequenos em números muito grandes.

Por exemplo, adicionar 1 a um número no decorrer de tempo. Em algum momento, a adição não afetará mais o resultado porque a soma em execução é muito maior do que 1, e não há bits suficientes para armazenar o resultado inteiro. A adição armazena quantos bits superiores for possível e descarta os bits menores restantes.

Para contar isso, faça matemática em números pequenos até que os resultados fiquem grandes. Depois, transfira-os para outro local para matemática adicional de números grandes. Por exemplo:

-  x é a variável pequena incrementada.
-  y é a variável grande incrementada.
-  z é a contagem atual total que pode ser usada em qualquer lugar.
-  x = x+1;
-  se x = 100.000;
-  {
-  y = y + 100.000;
-  x = 0;
-  }
-  z = y + x;

Ou outro exemplo:

-  x = x + some\_tiny\_number;

## Índice por meio de matrizes

```
 if (x >= 100)  {  z = z + 100;  x = x - 100; // there might be a tiny remainder  }
```

Para alterar dinamicamente o elemento de matriz ao qual sua lógica faz referência, use uma tag ou expressão como o subscrito para apontar para o elemento. Isso é semelhante ao endereçamento indireto na lógica PLC-5. Use esses operadores em uma expressão para especificar um subscrito de matriz:

## Dicas:

-  O Logix Designer permite subscritos que são apenas tags de tipo de dados estendido, e não tem suporte para expressões de subscrito com tipos de dados estendidos.
-  Todos os tipos de dados elementares de inteiro disponíveis podem ser usados como um índice de subscrito. Somente use tags SINT, INT e DINT com operadores para criar uma expressão de subscrito.

| Operador Des  crição (Description)    |
|---------------------------------------|
| + somar                               |
| - subtrair/negar                      |
| * multiplicar                         |
| / dividir                             |
| AND AND                               |
| FRD  BCD para inteiro                 |
| NOT complementar                      |
| OR OR                                 |
| TOD  inteiro para BCD                 |
| SQR raiz quadrada                     |
| XOR OU exclusivo                      |

## Por exemplo:

| Definições Exemp                                          | lo                                                | Descrição (Description)                                                                                                                               |
|-----------------------------------------------------------|---------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------|
| my_list definida como DINT[10] my_list[5]                 |                                                   | Este exemplo faz referência ao  elemento 5 na matriz. A referência é  estática porque o valor do subscrito  permanece constante.                      |
| my_list definida como DINT[10] posição definido como DINT | MOV the value 5 into  position  my_list[position] | Este exemplo faz referência ao  elemento 5 na matriz. A referência é  dinâmica porque a lógica pode  alterar o subscrito mudando o valor  de posição. |

| Definições Exemp                                                                            | lo                                                                                    | Descrição (Description)                                                                                                                                                      |
|---------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| my_list definida como DINT[10] posição definido como DINT  deslocamento definido como  DINT | MOV the value 2 into  position  MOV the value 5 into offset  my_list[position+offset] | Este exemplo faz referência ao  elemento 7 (2+5) na matriz. A  referência é dinâmica porque a  lógica pode alterar o subscrito  mudando o valor de posição ou  deslocamento. |

Dica:

Ao inserir um subscrito de matriz, veja se ele está dentro dos limites da matriz especificada. Instruções que veem matrizes como uma coleção de elementos gerarão uma falha maior (tipo 4, código 20) se um subscrito exceder suas dimensões correspondentes.

O bit endereçamento é usado para acessar um bit particular dentro de um contêiner maior. Contêineres maiores incluem qualquer inteiro, estrutura ou matriz BOOL. Por exemplo:

## Endereçamento de bit

| Definição Exemp                                                     | lo                                                    | Descrição (Description)                                          |
|---------------------------------------------------------------------|-------------------------------------------------------|------------------------------------------------------------------|
| Variable0  definida como LINT  tem 64 bits                          | variable0.42                                          | Esse exemplo faz referência ao bit 42 da  variable0.             |
| variable1  definida como DINT  tem 32 bits                          | variable1.2                                           | Esse exemplo faz referencia ao bit 2 da  variable1.              |
| variable2  definida como INT  tem 16 bits                           | variable2.15                                          | Esse exemplo faz referencia ao bit 15 da  variable2.             |
| variable3  definida como SINT  tem 8 bits                           | variable3.[4]                                         | Esse exemplo faz referencia ao bit 4 da  variable3.              |
| variable4  definida como estrutura de COUNTER  tem 5 bits de status | variable4.DN                                          | Esse exemplo faz referencia ao bit DN  da variable4.             |
| MyVariable definida como BOOL[100]  MyIndex definido como SINT      | MyVariable[(MyIndex  AND NOT 7) /  8].[MyIndex AND 7] | Esse exemplo faz referencia a um bit  dentro de uma matriz BOOL. |
| MyArray definido como BOOL[20] MyArray[3]                           |                                                       | Esse exemplo faz referência ao bit 3 de  MyArray.                |
| variable5  definida como ULINT  contém 64 bits                      | variable5.53                                          | Esse exemplo faz referência ao bit 53 da  variable5.             |

Use Endereçamento de bit sempre que uma tag do tipo BOOL for permitida.

## Consulte também

Índice por meio de matrizes na página 893

## Atributos dos blocos de funções

Clique em um tópico abaixo para obter mais informações sobre problemas que são únicos à programação de bloco de funções. Revise essas informações para garantir que você compreende como suas rotinas de bloco de funções operarão.

## Consulte também

Selecionar os elementos do bloco de funções na página 896

Dados de retenção na página 897

Ordem de execução na página 898

Respostas de bloco de funções a condições de transbordamento na página 903

Modos de temporização na página 903

Controle do operador/programa na página 907

## Selecionar os elementos do bloco de funções

Para controlar um dispositivo, use estes elementos:

<!-- image -->

Use a tabela a seguir para ajudar você a escolher os elementos do bloco de funções:

| Se você deseja fornecer um valor a partir de um  dispositivo ou uma tag de entrada                                                                              | Então, use uma referência de entrada (IREF)                                         |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------|
| Enviar um valor a um dispositivo ou uma tag de saída Referência de saída (OREF)                                                                                 |                                                                                     |
| Realizar uma operação em um valor ou valores de  entrada e produzir um valor ou valores de saída                                                                | Bloco de funções                                                                    |
| Transferir dados entre os blocos de funções quando  eles estiverem:    Distantes uns dos outros na mesma folha    Em folhas diferentes dentro da mesma rotina | Conector de fio de saída (OCON) e um conector  de fio de entrada (ICON)             |
| Dispersar dados para vários pontos na rotina                                                                                                                    | Conector de fio de saída (OCON) única e conector  de fio de entrada múltipla (ICON) |

O bloco de funções move as referências de entrada para a estrutura do bloco. Se necessário, o bloco de funções converte essas referências de entrada em valores REAL. O bloco de funções executa e move os resultados para as referências de saída. Novamente, se necessário, o bloco de funções converte esses valores de resultado da forma REAL para os tipos de dados para as referências de saída.

## Dados de retenção

Se você usar uma IREF para especificar os dados de entrada para uma instrução de bloco de funções, os dados nesta IREF são retidos para a varredura da rotina do bloco de funções. O IREF retém os dados das tags de escopo do programa e de escopo do controlador. O controlador atualiza todos os dados de IREF no início de cada varredura.

<!-- image -->

Neste exemplo, o valor de tagA é armazenado no começo da execução da rotina. O valor armazenado é usado quando Block\_01 é executado. O mesmo valor armazenado é usado quando Block\_02 é executado. Se o valor de tagA for alterado durante a execução da rotina, o valor armazenado de tagA em IREF não é alterado até a próxima execução da rotina.

<!-- image -->

Este exemplo é o semelhante ao exemplo acima. O valor de tagA é armazenado apenas uma vez no início da execução da rotina. A rotina usa este valor armazenado ao longo da execução.

<!-- image -->

Você pode usar a mesma tag em múltiplas IREFs e em uma OREF na mesma rotina. Como os valores das tags em IREFs são travados a cada varredura durante a rotina, todas as IREFs usam o mesmo valor, mesmo se uma OREF obter um valor de tag diferente durante a execução da rotina.

Neste exemplo, se tagA tiver um valor de 25,4 quando a rotina começar a executar esta varredura, e Block\_01 alterar o valor de tagA para 50,9, a segunda IREF

## Ordem de execução

<!-- image -->

conectada a Block\_02 ainda usará um valor de 25,4 quando Block\_02 executar esta varredura. O novo valor de tagA de 50,9 não será usado por nenhuma IREF nesta rotina até o início da próxima varredura.

<!-- image -->

O aplicativo de programação Logix Designer determina automaticamente a ordem de execução para os blocos em uma rotina quando você:

-  verifica a rotina de bloco de funções
-  verifica um projeto que contém uma rotina de bloco de funções
-  faz o download de um projeto que contém uma rotina de bloco de funções

Você define a ordem de execução ao conectar blocos de funções e indicar o fluxo de dados de qualquer fio de realimentação, se necessário.

Se os blocos de funções não estiverem conectados, não importa qual bloco é executado primeiro. Não há fluxo de dados entre os blocos.

<!-- image -->

<!-- image -->

Se você conectar os blocos sequencialmente, a ordem de execução muda de entrada para saída. As entradas de um bloco requerem dados para estarem disponíveis antes do controlador poder executar esse bloco. Por exemplo, o bloco 2 deve ser executado antes do bloco 3 porque as saídas do bloco 2 alimentam as entradas do bloco 3.

<!-- image -->

A ordem de execução só é relativa aos blocos que estão conectados. O exemplo a seguir está bom porque os dois grupos de blocos não estão conectados. Os blocos dentro de um grupo específico são executados na ordem apropriada em relação aos blocos nesse grupo.

<!-- image -->

<!-- image -->

## Resolver um circuito

Para criar um circuito de alimentação ao redor de um bloco, conecte um pino de saída do bloco a um pino de entrada do mesmo bloco. O exemplo a seguir está OK. O circuito contém apenas um único bloco, então a ordem de execução não importa.

<!-- image -->

Se um grupo de blocos estiver em um circuito, o controlador não pode determinar qual bloco deve ser executado primeiro. Em outras palavras, ele não pode resolver o circuito.

<!-- image -->

Para identificar qual o bloco a ser executado primeiro, marque o fio da entrada que cria o circuito (o fio de realimentação) com o indicador Supor dados disponíveis (Assume Data Available). No exemplo a seguir, o bloco 1 usa a saída do bloco 3 que foi produzida na execução anterior da rotina.

<!-- image -->

O indicador Supor dados disponíveis (Assume Data Available) define o fluxo de dados dentro do circuito. A seta indica que os dados servem como entrada para o primeiro bloco no circuito.

Não marque todos os fios de um circuito com o indicador Supor dados disponíveis (Assume Data Available).

<!-- image -->

## Resolver o fluxo de dados entre dois blocos

Se você usar dois ou mais fios para conectar dois blocos, use os mesmos indicadores de fluxo de dados para todos os fios entre os dois blocos.

<!-- image -->

## Criar um atraso de uma varredura

Para produzir um atraso de uma varredura entre blocos, use o indicador Supor dados disponíveis (Assume Data Available). No exemplo a seguir, o bloco 1 é executado primeiro. Ele usa a saída do bloco 2 que foi produzida na varredura anterior da rotina.

<!-- image -->

## Resumo

Em resumo, uma rotina de bloco de funções é executada nesta ordem:

1. O controlador trava todos os valores de dados em IREFs.
2. O controlador executa os outros blocos de funções na ordem determinada de acordo com a maneira que estão conectados.
3. O controlador grava as saídas em OREFs.

## Respostas de bloco de funções a condições de transbordamento

Em geral, as instruções do bloco de funções que mantêm histórico não atualizam tal histórico com valores NAN, ou INF quando ocorre um transbordamento. Cada instrução apresenta uma destas respostas a uma condição de transbordamento.

| Resposta In                                                                                                                                                                                                                                                                                                                               | strução                                                                                                                                  |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------|
| Resposta 1  Blocos executam seu algoritmo e verificam o  resultado para  NAN ou  INF. Se  NAN ou  INF, o bloco  fornece o resultado de  NAN ou  INF.                                                                                                                                                                                      | ALM NTCH  DEDT PMUL  DERV POSP  ESEL RLIM  FGEN RMPS  HPF SCRV  LDL2 SEL  LDLG SNEG  LPF SRTP  MAVE SSUM  MAXC TOT  MINC UPDN  MSTD  MUX |
| Resposta 2  Blocos com limitação de saída executam seu  algoritmo e verificam o resultado para  NAN  ou  INF. Os limites da saída são definidos  pelos parâmetros de entrada HighLimit e  LowLimit. Se  INF, o bloco fornece um  resultado limitado. Se  NAN, os limites da  saída não são usados e o bloco fornece o  resultado de  NAN. | HLL, INTG, PI, PIDE, SCL, SOC                                                                                                            |
| Resposta 3  A condição de transbordamento não se  aplica. Estas instruções normalmente  apresentam uma saída booliana.                                                                                                                                                                                                                    | BAND, BNOT, BOR, BXOR, CUTD, D2SD, D3SD, DFF,  JKFF, OSFI, OSRI, RESD, RTOR, SETD, TOFR, TONR                                            |

## Modos de temporização

Essas instruções de controle de processo e drives suportam diferentes modos de temporização.

-  DEDT

-  LDLG

-  RLIM

-  DERV

-  LPF

-  SCRV

-  HPF

-  NTCH

-  SOC

-  INTG

-  PI

-  TOT

-  LDL2

-  PIDE

Há três modos de temporização diferentes.

| Modo de  temporização     | Descrição (Description)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         | Descrição (Description)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
|---------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Periódico                 | O modo Periódico é o modo padrão e é adequado para a maioria das  aplicações de controle. Recomendamos que você coloque as instruções que  usam esse modo em uma rotina que seja executada em uma tarefa periódica.  O tempo delta (DeltaT) da instrução é determinado da seguinte maneira:                                                                                                                                                                                                                                                                                                                                                     | O modo Periódico é o modo padrão e é adequado para a maioria das  aplicações de controle. Recomendamos que você coloque as instruções que  usam esse modo em uma rotina que seja executada em uma tarefa periódica.  O tempo delta (DeltaT) da instrução é determinado da seguinte maneira:                                                                                                                                                                                                                                                                                                                                                     |
| Periódico                 | Se a instrução for  executada em um(a)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | Então DeltaT é igual a(o)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Periódico                 |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | Tarefa periódica Período da tarefa                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Periódico                 | Evento ou tarefa  contínua                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      | Tempo decorrido desde a execução anterior  O controlador trunca o tempo decorrido para  milissegundos inteiros (ms). Por exemplo, se o tempo  decorrido = 10,5 ms, o controlador definirá DeltaT =  10 ms.                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Periódico                 | A atualização da entrada do processo precisa ser sincronizada com a  execução da tarefa ou coletada de 5 a 10 vezes mais rapidamente do que a  execução da tarefa para minimizar o erro de amostragem entre a entrada e a                                                                                                                                                                                                                                                                                                                                                                                                                       | A atualização da entrada do processo precisa ser sincronizada com a  execução da tarefa ou coletada de 5 a 10 vezes mais rapidamente do que a  execução da tarefa para minimizar o erro de amostragem entre a entrada e a                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Sobreamostragem           | No modo de sobreamostragem, o tempo delta (DeltaT) usado pelas instruções  é o valor escrito no parâmetro OversampleDT da instrução. Se a entrada do  processo tiver um valor de data e hora, use o modo de amostragem em tempo  real.  Adicione uma lógica ao seu programa para controlar quando a instrução é  executada. Por exemplo, é possível usar um temporizador definido para o valor  de OversampleDeltaT para controlar a execução usando a entrada EnableIn  da instrução.  A entrada do processo precisa ser coletada de 5 a 10 vezes mais rapidamente  do que a execução da instrução para minimizar o erro de amostragem entre a | No modo de sobreamostragem, o tempo delta (DeltaT) usado pelas instruções  é o valor escrito no parâmetro OversampleDT da instrução. Se a entrada do  processo tiver um valor de data e hora, use o modo de amostragem em tempo  real.  Adicione uma lógica ao seu programa para controlar quando a instrução é  executada. Por exemplo, é possível usar um temporizador definido para o valor  de OversampleDeltaT para controlar a execução usando a entrada EnableIn  da instrução.  A entrada do processo precisa ser coletada de 5 a 10 vezes mais rapidamente  do que a execução da instrução para minimizar o erro de amostragem entre a |
| Amostragem em  tempo real | entrada e a instrução.  No modo de amostragem em tempo real, o tempo delta (DeltaT) usado pela  instrução é a diferença entre dois valores de data e hora que correspondem às  atualizações da entrada do processo. Use este modo quando a entrada do  processo tiver um valor de data e hora associado às atualizações e você  precisar de uma coordenação precisa.                                                                                                                                                                                                                                                                            | entrada e a instrução.  No modo de amostragem em tempo real, o tempo delta (DeltaT) usado pela  instrução é a diferença entre dois valores de data e hora que correspondem às  atualizações da entrada do processo. Use este modo quando a entrada do  processo tiver um valor de data e hora associado às atualizações e você  precisar de uma coordenação precisa.                                                                                                                                                                                                                                                                            |
| Amostragem em  tempo real | O valor de data e hora é lido a partir do nome da tag inserido para o parâmetro  RTSTimeStamp da instrução. Normalmente, esse nome de tag é um parâmetro  no módulo de entrada associado à entrada do processo.                                                                                                                                                                                                                                                                                                                                                                                                                                 | O valor de data e hora é lido a partir do nome da tag inserido para o parâmetro  RTSTimeStamp da instrução. Normalmente, esse nome de tag é um parâmetro  no módulo de entrada associado à entrada do processo.                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Amostragem em  tempo real | A instrução compara o valor RTSTime configurado (período de atualização  esperado) ao DeltaT calculado para determinar se cada atualização da entrada  do processo está sendo lida pela instrução. Se o DeltaT não estiver dentro de  1 milissegundo do tempo de configuração, a instrução definirá o bit de status  RTSMissed para indicar que há um problema na leitura de atualizações da                                                                                                                                                                                                                                                    | A instrução compara o valor RTSTime configurado (período de atualização  esperado) ao DeltaT calculado para determinar se cada atualização da entrada  do processo está sendo lida pela instrução. Se o DeltaT não estiver dentro de  1 milissegundo do tempo de configuração, a instrução definirá o bit de status  RTSMissed para indicar que há um problema na leitura de atualizações da                                                                                                                                                                                                                                                    |

As instruções baseadas no tempo requerem um valor constante para o DeltaT para que o algoritmo de controle possa calcular corretamente a saída do processo. Se DeltaT variar, uma descontinuidade ocorre na saída do processo. A severidade da descontinuidade depende da instrução e da faixa de variação do DeltaT.

Uma descontinuidade ocorrerá se:

-  Uma instrução não for executada durante uma varredura.
-  A instrução for executada várias vezes durante uma tarefa.

-  A tarefa estiver em execução e a taxa de varredura da tarefa ou o tempo de amostra da entrada do processo mudarem.
-  O usuário alterar o modo baseado no tempo enquanto a tarefa está em execução.
-  O parâmetro Order for alterado em um bloco de filtro enquanto a tarefa está em execução.
-  Alterar o parâmetro Order seleciona um algoritmo de controle diferente na instrução.

## Parâmetros comuns de instruções para modos de temporização

As instruções que suportam os modos baseados no tempo possuem esses parâmetros de entrada e saída.

## Parâmetros de entrada

| Parâmetro de  entrada    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|--------------------------|-------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| TimingMode DINT          |                               | Seleciona o modo de execução da temporização.  Valor: descrição:  0 Modo periódico  1 Modo de sobreamostragem  2 Modo de amostragem em tempo real  Válido = 0 para 2  Padrão = 0  Quando TimingMode = 0 e a tarefa for periódica, a temporização  periódica será habilitada e o DeltaT será definido para a taxa de  varredura da tarefa. Quando TimingMode = 0 e a tarefa for um  evento ou contínua, a temporização periódica será habilitada e  DeltaT será definido igual ao tempo decorrido desde a última vez  que a instrução foi executada.  Quando TimingMode = 1, a temporização de sobreamostragem  será habilitada e DeltaT será definido como o valor do parâmetro  OversampleDT. Quando TimingMode = 2, a temporização de  amostragem em tempo real será ativada e DeltaT será a  diferença entre os valores de data e hora atuais e anteriores lidos  a partir do módulo associado à entrada.  Se TimingMode for inválido, a instrução definirá o bit apropriado  em Status. |
| OversampleDT REAL        |                               | Tempo de execução para a temporização de sobreamostragem.  O valor usado para DeltaT é em segundos. Se TimingMode = 1,  então, OversampleDT = 0,0 desabilitará a execução do algoritmo  de controle. Se for inválido, a instrução definirá DeltaT = 0,0 e o  bit apropriado em Status.  Válido = 0 a 4194,303 segundos  Padrão = 0,0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |

| RTSTime DINT      | O período de atualização do módulo para a temporização da  amostragem em tempo real. O período de atualização de DeltaT  esperado é em milissegundos. Normalmente, o período de  atualização é o valor usado para configurar o tempo de  atualização do módulo. Se for inválido, a instrução definirá o bit  apropriado em Status e desabilitará a verificação RTSMissed.  Válido = 1…32.767 ms  Padrão = 1                                                   |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| RTSTimeStamp DINT | O valor de data e hora do módulo para a temporização da  amostragem em tempo real. O valor do data e hora que  corresponde à última atualização do sinal de entrada. Esse valor  é usado para calcular DeltaT. Se for inválido, a instrução definirá  o bit apropriado em Status, bem como desabilitará a execução do  algoritmo de controle e a verificação RTSMissed.  Válido = 0…32.767 ms (retorna de 32767 a 0)  1 contagem = 1 milissegundo  Padrão = 0 |

## Parâmetros de saída

| Parâmetro de saída           | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                                                                                                                                                                                                                                                                                                                                                   |
|------------------------------|-------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| DeltaT REAL                  |                               | Tempo decorrido entre as atualizações. Isso é o tempo decorrido  em segundos usado pelo algoritmo de controle para calcular a  saída do processo.  Periódico: DeltaT = taxa de varredura da tarefa se esta for uma  Tarefa periódica, DeltaT = tempo decorrido desde a última  execução da instrução se a tarefa for um Evento ou Contínua  sobreamostragem: DeltaT = OversampleDT  Amostragem em tempo real: DeltaT = (RTSTimeStampn -  RTSTimeStampn-1) |
|                              |                               | status DINT Status do bloco de funções.                                                                                                                                                                                                                                                                                                                                                                                                                   |
| TimingModeInv  (Status.27)   |                               | BOOL Valor de TimingMode inválido.                                                                                                                                                                                                                                                                                                                                                                                                                        |
| RTSMissed  (Status.28)       | BOOL                          | Somente usado no modo de amostragem em tempo real.  Definido quando ABS &#124; DeltaT - RTSTime &#124; > 1 (0,001 segundo).                                                                                                                                                                                                                                                                                                                               |
| RTSTimeInv  (Status.29)      |                               | BOOL Valor de RTSTime inválido.                                                                                                                                                                                                                                                                                                                                                                                                                           |
| RTSTimeStampInv  (Status.30) |                               | BOOL Valor de RTSTimeStamp inválido.                                                                                                                                                                                                                                                                                                                                                                                                                      |
|                              |                               | DeltaTInv (Status.31) BOOL Valor de DeltaT inválido.                                                                                                                                                                                                                                                                                                                                                                                                      |

## Controle do operador/programa

## Visão geral dos modos de temporização

O diagrama a seguir mostra como uma instrução determina o modo de temporização apropriado.

<!-- image -->

As seguintes instruções suportam o conceito de controle do Programa/Operador.

-  Seleção aprimorada (ESEL)
-  Totalizador (TOT)
-  PID aprimorada (PIDE)
-  Rampa/estabilização (RMPS)
-  Dispositivo discreto de dois estados (D2SD)
-  Dispositivo discreto de três estados (D3SD)

O controle do Programa/Operador permite que você controle essas instruções simultaneamente em seu programa do usuário e a partir de um dispositivo de interface do operador. No controle do Programa, a instrução é controlada pelas entradas do Programa para a instrução; quando no controle do Operador, a instrução é controlada pelas entradas do operador para a instrução.

O controle do Programa ou do Operador é determinado usando estas entradas.

| Entrada (Input)    | Descrição (Description)                                           |
|--------------------|-------------------------------------------------------------------|
| .ProgProgReq       | Uma solicitação do programa para acessar o  controle do Programa. |
| .ProgOperReq       | Uma solicitação do programa para acessar o  controle do Operador. |
| .OperProgReq       | Uma solicitação do operador para acessar o  controle do Programa. |
| .OperOperReq       | Uma solicitação do operador para acessar o  controle do Operador. |

Para determinar se uma instrução está no controle do Programa ou do Operador, examine a saída ProgOper. Se o ProgOper estiver configurado, a instrução estará no controle do Programa. Se ProgOper for eliminado, a instrução estará no controle do Operador.

O controle do Operador terá precedência sobre o controle do Programa se ambos os bits de solicitação de entrada forem definidos. Por exemplo, se ProgProgReq e ProgOperReq estiverem definidos, a instrução usará o controle do Operador.

As entradas da solicitação do Programa têm precedência sobre as entradas da solicitação do Operador. Isso permite usar as entradas de ProgProgReq e ProgOperReq para "bloquear" uma instrução no controle desejado.

Por exemplo, vamos supor que uma instrução do Totalizador sempre será usada no controle do Operador e que seu programa do usuário nunca controlará a execução ou a interrupção do Totalizador. Nesse caso, você poderia usar um valor literal de 1 em ProgOperReq. Isso evitaria que o operador colocasse o Totalizador no controle do Programa configurando OperProgReq a partir de um dispositivo de interface do operador.

<!-- image -->

Da mesma maneira, configurar constantemente ProgProgReq pode "bloquear" a instrução no controle do Programa. Isso é útil para sequências de inicialização automática quando você deseja que o programa controle a ação da instrução sem se preocupar com a possibilidade de um operador assumir inadvertidamente o controle da instrução.

Nesse exemplo, a entrada de ProgProgReq é configurada durante a inicialização e, em seguida, elimina a entrada de ProgProgReq após o fim da inicialização. Após a eliminação da entrada de ProgProgReq, a instrução permanecerá no controle do Programa até receber uma solicitação de alteração. Por exemplo, o operador pode definir a entrada de OperOperReq a partir de uma placa frontal para assumir o controle dessa instrução.

O exemplo a seguir mostra como bloquear uma instrução no controle do Programa.

<!-- image -->

As entradas de solicitação do Operador para uma instrução são sempre eliminadas após a execução da instrução. Isso permite que as interfaces do operador funcionem com essas instruções simplesmente definindo o bit de solicitação do modo desejado. Não é necessário programar a interface do operador para restaurar os bits de solicitação. Por exemplo, se uma interface do operador definir a entrada de OperAutoReq para uma instrução PIDE, quando a instrução PIDE for executada, ela determinará qual deverá ser a resposta apropriada e eliminará o OperAutoReq.

As entradas de solicitações do programa normalmente não são eliminadas pela instrução, pois estas normalmente são conectadas como entradas na instrução. Se a instrução eliminar essas entradas, a entrada só será configurada novamente pela entrada conectada. Talvez haja situações em que você deseja usar outra lógica para configurar as solicitações do Programa de modo que elas sejam eliminadas pela instrução. Nesse caso, é possível configurar a entrada de ProgValueReset e a instrução sempre eliminará as entradas de solicitação do modo Programa ao ser executada.

Neste exemplo, um degrau de lógica ladder em outra rotina é usado para travar ProgAutoReq para uma instrução PIDE quando um botão é pressionado.

Quando o botão TIC101AutoReq é pressionado, ProgAutoReq é travado para a instrução PIDE TIC101. TIC101 foi configurado com a entrada de ProgValueReset definida. ProgAutoReq será restaurado porque ProgValuieReset sempre está configurado.

<!-- image -->

## Programação de texto estruturado

Estas são as questões únicas da programação de texto estruturado. Revise os tópicos a seguir para garantir que compreende como a programação de texto estruturado é executada.

Sintaxe de texto estruturado na página 912

Componentes de texto estruturado: comentários na página 913

Componentes de texto estruturado: Atribuições na página 914

Componentes de texto estruturado: Expressões na página 917

Componentes de texto estruturado: Instruções na página 922

Componentes de texto estruturado: Construções na página 924

CASE...OF na página 927

FOR...DO na página 929

IF...THEN na página 932

REPEAT\_UNTIL na página 935

WHILE\_DO na página 937

## Sintaxe de texto estruturado

O texto estruturado é uma linguagem de programação textual que usa instruções para definir o que para executar.

-  O texto estruturado não diferencia maiúsculas de minúsculas.
-  Use tabulações e retornos de carro (linhas separadas) para facilitar a leitura do texto estruturado. Não afetam a execução do texto estruturado.

O texto estruturado não diferencia maiúsculas de minúsculas. O texto estruturado pode conter estes componentes.

| Termo De finição           |                                                                                                                                                                                                                                                                                                              | Exemplos                                                                                          |
|----------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|
| Atribuição                 | Use uma instrução de atribuição para atribuir valores às tags.  O operador := é o operador de atribuição.  Termine a atribuição com um ponto e vírgula.                                                                                                                                                      | tag := expression;                                                                                |
| Expression                 | Uma expressão é parte de uma atribuição completa ou  instrução de construção. Uma expressão é avaliada para  verificação da presença de um número (expressão numérica),  uma string (expressão de string) ou um estado verdadeiro ou  falso (expressão BOOL)                                                 |                                                                                                   |
| Expressão de  tag          | Uma área nomeada da memória onde os dados são  armazenados (BOOL, SINT, INT, DINT, REAL, string).                                                                                                                                                                                                            | value1                                                                                            |
| Expressão de  imediato     | Um valor constante 4                                                                                                                                                                                                                                                                                         |                                                                                                   |
| Expressão  dos  operadores | Um símbolo ou mnemônico que especifica uma operação  dentro de uma expressão.                                                                                                                                                                                                                                | tag1 + tag2  tag1 >= value1                                                                       |
| Expressão de  função       | Quando executada, uma função produz um valor. Use  parênteses para conter o operando de uma função.  Embora a sintaxe seja semelhante, as funções diferem das  instruções, pois só podem ser usadas em expressões. Não é  possível usar instruções em expressões.                                            | function(tag1)                                                                                    |
|                            | Instrução Uma instrução é uma declaração autônoma.  Uma instrução usa parênteses para conter seus operandos.  Dependendo da instrução, é possível que haja nenhum, um  ou vários operandos.  Quando executada, uma instrução produz um ou mais valores  que fazem parte de uma estrutura de dados. Termine a | instruction();  instruction(operand);  instruction(operand1,                                      |
| Construção                 | Uma instrução condicional usada para disparar o código de  texto estruturado (ou seja, outras instruções). Termine a  construção com um ponto e vírgula (;).                                                                                                                                                 | IF...THEN CASE FOR...DO  WHILE...DO  REPEAT...UNTIL  EXIT                                         |
| Comentário                 | Texto que explica ou esclarece o que faz uma seção de texto  estruturado.  Use comentários para facilitar a interpretação do texto  estruturado.  Os comentários não afetam a execução do texto estruturado.  Os comentários podem ser adicionados em qualquer lugar no  texto estruturado.                  | //comment  (*start of comment . . . end of  comment*)  /*start of comment . . . end of  comment*/ |

## Componentes do texto estruturado: comentários

## Consulte também

| Componentes do texto estruturado: atribuições na página 914   |
|---------------------------------------------------------------|
| Componentes do texto estruturado: expressões na página 917    |
| Componentes do texto estruturado: instruções na página 922    |
| Componentes do texto estruturado: constructos na página 924   |
| Componentes do texto estruturado: comentários na página 913   |

Para facilitar a interpretação de seu texto estruturado, adicione comentários.

-  Os comentários permitem que você use uma linguagem simples para descrever o funcionamento do texto estruturado.
-  Os comentários não afetam a execução do texto estruturado.

## Para adicionar comentários ao texto estruturado:

| Para adicionar um comentário Use um destes formatos                                                            |
|----------------------------------------------------------------------------------------------------------------|
| em uma única linha  //comment  (*comment*)  no final de uma linha de texto  /*comment*/                        |
| em uma linha de texto estruturado (*comment*)  /*comment*/                                                     |
| que abranja mais de uma linha (*start of comment. . .end of comment*)  /*start of comment. . .end of comment*/ |

## Por exemplo:

| Format Ex emplo                                                                                                                                                                                                                                       |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| //comment  No início de uma linha //Check conveyor belt direction  IF conveyor_direction THEN...  No final de uma linha ELSE //If conveyor isn’t moving, set alarm light  light := 1;  END_IF;                                                        |
| (*comment*) Sugar.Inlet[:=]1;(*open the inlet*)  IF Sugar.Low (*low level LS*)& Sugar.High (*high level LS*)THEN...  (*Controls the speed of the recirculation pump. The speed depends on the  temperature in the tank.*)  IF tank.temp > 200 THEN... |

| /*comment*/ Sugar.Inlet:=0;/*close the inlet*/  IF bar_code=65 /*A*/ THEN...  /*Gets the number of elements in the Inventory array and stores the value  in the Inventory_Items tag*/  SIZE(Inventory,0,Inventory_Items);    |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Componentes do texto estruturado: atribuições

Use uma atribuição para alterar o valor armazenado em uma tag. Uma atribuição tem esta sintaxe:

tag := expression;

onde:

|     | Componente Descrição (Description)                                                                                                                                                                                                                                  | Componente Descrição (Description)                                                                                                                                                                                                                                  |
|-----|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Tag | Representa a tag que está obtendo o novo valor; a tag deve ser  BOOL, SINT, INT, DINT, STRING ou REAL.  Dica: a tag STRING é aplicável apenas a Controladores  CompactLogix 5380, CompactLogix 5480, ControlLogix 5580,  Compact GuardLogix 5380 e GuardLogix 5580. | Representa a tag que está obtendo o novo valor; a tag deve ser  BOOL, SINT, INT, DINT, STRING ou REAL.  Dica: a tag STRING é aplicável apenas a Controladores  CompactLogix 5380, CompactLogix 5480, ControlLogix 5580,  Compact GuardLogix 5380 e GuardLogix 5580. |
| :=  | É o símbolo de atribuição                                                                                                                                                                                                                                           | É o símbolo de atribuição                                                                                                                                                                                                                                           |
|     | Expression Representa o novo valor que será a atribuído à tag                                                                                                                                                                                                       | Expression Representa o novo valor que será a atribuído à tag                                                                                                                                                                                                       |
|     | Se a tag for deste tipo de  dados                                                                                                                                                                                                                                   | Use este tipo de expressão                                                                                                                                                                                                                                          |
|     |                                                                                                                                                                                                                                                                     | BOOL BOOL                                                                                                                                                                                                                                                           |
|     | SINT  INT  DINT  REAL                                                                                                                                                                                                                                               | Numérico                                                                                                                                                                                                                                                            |
|     | STRING  (somente Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e  GuardLogix 5580).                                                                                                                            | Tipo de string, incluindo tag de  string e literal de string  (somente Controladores  CompactLogix 5380, CompactLogix  5480, ControlLogix 5580, Compact  GuardLogix 5380 e GuardLogix  5580).                                                                       |
| ;   | Encerra a atribuição                                                                                                                                                                                                                                                | Encerra a atribuição                                                                                                                                                                                                                                                |

A tag mantém o valor atribuído até que outra atribuição altere o valor.

A expressão pode ser simples, como um valor imediato ou outro nome de tag, ou complexa e inclue vários operadores e funções ou ambos. Consulte Expressões para obter mais informações.

## Especificar uma atribuição não retentiva

Dica:

Os dados do módulo E/S são atualizados de modo assíncrono para a execução da lógica. Se você fizer referência a uma entrada várias vezes na lógica, a entrada poderá alterar o estado entre referências separadas. Se você precisar que a entrada tenha o mesmo estado para cada referência, armazene no buffer o valor de entrada e faça referência a essa tag de buffer. Para obter mais informações, consulte LOGIX 5000 Controllers Common Procedures , publicação 1756-PM001 .

Você também pode usar parâmetros do programa de entrada e saída que armazenam automaticamente no buffer os dados durante a execução do logix. Consulte LOGIX 5000 Controllers Program Parameters Programming Manual , publicação 1756-PM021 .

## Consulte também

Atribui um caractere ASCII a um membro de dados de string na página 916

Especificar uma atribuição não retentiva na página 915

Componentes do texto estruturado: expressões na página 917

Literais de string de caracteres na página 925

A atribuição não retentiva é diferente da atribuição regular descrita acima na medida em que a tag em uma atribuição não retentiva é restaurada para zero cada vez que o controlador:

-  Entra no modo de execução
-  Sai da etapa de um SFC se você configurar o SFC para a restauração Automática. Isso será aplicável apenas se você incorpora a atribuição na ação da etapa ou usa a ação para chamar uma rotina de texto estruturado usando uma instrução JSR.

Uma atribuição não retentiva tem esta sintaxe:

tag [:=] expression ;

## onde:

| Componente De scrição (Description)    | Componente De scrição (Description)                                                                                                                                                                                                                                 | Componente De scrição (Description)                                                                                                                                                                                                                                 |
|----------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| tag                                    | Representa a tag que está obtendo o novo valor; a tag  deve ser BOOL, SINT, INT, DINT, STRING ou REAL.  Dica: a tag STRING é aplicável apenas a Controladores  CompactLogix 5380, CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e GuardLogix 5580. | Representa a tag que está obtendo o novo valor; a tag  deve ser BOOL, SINT, INT, DINT, STRING ou REAL.  Dica: a tag STRING é aplicável apenas a Controladores  CompactLogix 5380, CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e GuardLogix 5580. |
| [:=]                                   | É o símbolo da atribuição não retentiva.                                                                                                                                                                                                                            | É o símbolo da atribuição não retentiva.                                                                                                                                                                                                                            |
| expressão                              | Representa o novo valor que será a atribuído à tag.                                                                                                                                                                                                                 | Representa o novo valor que será a atribuído à tag.                                                                                                                                                                                                                 |
|                                        | Se a tag for deste tipo de  dados                                                                                                                                                                                                                                   | Use este tipo de expressão                                                                                                                                                                                                                                          |
|                                        |                                                                                                                                                                                                                                                                     | BOOL BOOL                                                                                                                                                                                                                                                           |
|                                        |                                                                                                                                                                                                                                                                     | SINT Numérico                                                                                                                                                                                                                                                       |

## Atribui um caractere ASCII a um membro de dados de string

| INT:                                                                                                                                     |                                                                                                                                                                                             |
|------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| DINT                                                                                                                                     |                                                                                                                                                                                             |
| REAL                                                                                                                                     |                                                                                                                                                                                             |
| STRING  (somente Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix 5380  e GuardLogix 5580). | Tipo de string, incluindo tag  de string e literal de string  Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e  GuardLogix 5580(somente) |

## Consulte também

Atribui um caractere ASCII a um membro de dados de string na página 916

Componentes do texto estruturado: atribuições na página 914

## Atribui um caractere ASCII a um membro de dados de string

Use o operador de atribuição para atribuir um caractere ASCII a um elemento do membro DATA de uma tag de string. Para atribuir um caractere, especifique o valor do caractere ou especifique o nome da tag, o membro DATA e o elemento do caractere. Por exemplo:

| Isso está OK                                           | Isso não está OK                                                                         |
|--------------------------------------------------------|------------------------------------------------------------------------------------------|
| string1.DATA[0] := 65;                                 | string1.DATA[0] := A;                                                                    |
| string1.DATA[0]:= string2.DATA[0]; string1 := string2; | Dica: isso atribui todo o conteúdo de  string2 a string1 em vez de apenas  um caractere. |

Para adicionar ou inserir uma string em uma tag de string, use qualquer uma destas instruções de string ASCII:

| Alvo                                         | Use esta instrução    |
|----------------------------------------------|-----------------------|
| Adicionar caracteres no final de uma  string | CONCAT                |
| Inserir caracteres em uma string INSERT      |                       |

## Consulte também

Componentes do texto estruturado: expressões na página 917

Literais de string de caracteres na página 925

## Componentes do texto estruturado: expressões

Uma expressão é um nome de tag, equação ou comparação. Para escrever uma expressão, use qualquer um dos elementos a seguir:

-  O nome da tag que armazena o valor (variável)
-  O número inserido diretamente na expressão (valor imediato)
-  Literal de string inserido diretamente na expressão (somente Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580)
-  Funções, como: ABS, TRUNC
-  Operadores, como: +, -, &lt;, &gt;, And, Or

Siga estas diretrizes para escrever expressões:

-  Use qualquer combinação de letras maiúsculas e minúsculas. Por exemplo, estas variações de "AND" são aceitáveis: AND, And, and.
-  Para requisitos mais complexos, use parênteses para agrupar expressões dentro de expressões. Isso facilita a leitura de toda a expressão e garante que seja executada na sequência desejada.

Use essas expressões para o texto estruturado:

Expressão BOOL: uma expressão que produz o valor BOOL de 1 (verdadeiro) ou 0 (falso).

-  Uma expressão bool usa tags bool, operadores relacionais e operadores lógicos para comparar valores ou verificar se as condições são verdadeiras ou falsas. Por exemplo, tag1&gt;65.
-  Uma expressão bool simples pode ser uma única tag BOOL.
-  Normalmente, use expressões bool para condicionar a execução de outra lógica.

Expressão numérica: uma expressão que calcula um valor inteiro ou de ponto flutuante.

-  Uma expressão numérica usa operadores aritméticos, funções aritméticas e operadores bit a bit. Por exemplo, tag1+5.
-  Aninhe uma expressão numérica em uma expressão BOOL. Por exemplo, (tag1+5)&gt;65.

Expressão de string: uma expressão que representa uma string

-  Uma expressão simples pode ser uma string literal ou uma tag de string

Use esta tabela para selecionar os operadores para expressões.

| Se                                                      | Use                                                           |
|---------------------------------------------------------|---------------------------------------------------------------|
|                                                         | Calcular um valor aritmético Funções e operadores aritméticos |
| Comparar dois valores ou strings Operadores relacionais |                                                               |
| Verificar se as condições são  verdadeiras ou falsas    | Operadores lógicos                                            |
| Comparar bits dentro de valores Operadores bit a bit    |                                                               |

## Consulte também

Usar funções e operadores aritméticos na página 918

Usar operadores relacionais na página 921

Usar operadores lógicos na página 920

Usar operadores bit a bit na página 919

Combine vários operadores e funções em expressões aritméticas.

Os operadores calculam novos valores.

## Usar funções e operadores aritméticos

| Alvo                                   | Use este operador Tipo de dados ideal    |
|----------------------------------------|------------------------------------------|
|                                        | Somar + DINT, REAL                       |
| Subtrair/negar - DINT, REAL            |                                          |
|                                        | Multiplicar * DINT, REAL                 |
| Expoente (x elevado na  potência de y) | ** DINT, REAL                            |
|                                        | Dividir / DINT, REAL                     |
| Divisão de módulo  MOD                 | DINT, REAL                               |

As funções executam operações matemáticas. Especifique uma constante, uma tag não booliana ou uma expressão para a função.

| Para  Use esta função                              | Tipo de dados  ideal    |
|----------------------------------------------------|-------------------------|
| Valor absoluto ABS (numeric_expression)            | DINT, REAL              |
| Arco cosseno ACOS (numeric_expression) REAL        |                         |
| Arco seno  ASIN (numeric_expression)               | REAL                    |
| Arco tangente ATAN (numeric_expression) REAL       |                         |
| Cosseno COS (numeric_expression) REAL              |                         |
| Radianos para graus DEG (numeric_expression)       | DINT, REAL              |
| Logaritmo natural LN (numeric_expression)          | REAL                    |
| Logaritmo de base 10 LOG (numeric_expression)      | REAL                    |
| Graus para radianos RAD (numeric_expression)       | DINT, REAL              |
| Seno SIN (numeric_expression) REAL                 |                         |
| Raiz quadrada SQRT (numeric_expression) DINT, REAL |                         |

## Usar operadores bit a bit

|         | Tangente TAN (numeric_expression) REAL    |
|---------|-------------------------------------------|
| Truncar | TRUNC (numeric_expression) DINT, REAL     |

A tabela apresenta exemplos do uso de funções e operadores aritméticos.

| Use este formato                            | Exemplo                                                                                                                                                                                                                    | Exemplo                                                |
|---------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------|
|                                             | Para esta situação                                                                                                                                                                                                         | Gravar                                                 |
| value1 operador value2                      | Se gain_4 e gain_4_adj forem tags DINT e sua  especificação disser:  "Adicionar 15 para gain_4 e armazenar o resultado em  gain_4_adj"                                                                                     | gain_4_adj :=  gain_4+15;                              |
| operador value1                             | Se o alarme e high_alarm forem tags DINT e sua  especificação disser:  "Negar high_alarm e armazenar o resultado em alarme."                                                                                               | alarm:= -high_alarm;                                   |
| função(numeric_expression)                  | Se sobrecurso e overtravel_POS forem tags DINT e sua  especificação disser: ‘Calcular o valor absoluto de  sobrecurso e armazenar o resultado em overtravel_POS.’                                                          | overtravel_POS :=  ABS(overtravel);                    |
| value1 operador  (função((value2+value3)/2) | Se ajuste e posição forem tags DINT e sensor1 e sensor2  forem tags REAL e sua especificação disser: "Localizar o  valor absoluto da média do sensor1 e do sensor2,  adicione o ajuste e armazene o resultado na posição". | position := adjustment  + ABS((sensor1 +  sensor2)/2); |

## Consulte também

Componentes do texto estruturado: expressões na página 917

Operadores bit a bit manipulam os bits dentro de um valor com base em dois valores.

A seguir, é apresentada uma visão geral dos operadores bit a bit.

| Para                       |        | Use este operador Tipo de dados ideal    |
|----------------------------|--------|------------------------------------------|
| AND bit a bit              | &, AND | DINT                                     |
| OU bit a bit               | OR     | DINT                                     |
| OU exclusivo bit a bit XOR |        | DINT                                     |
| bit a bit complementar NOT |        | DINT                                     |

Este é um exemplo.

| Use este formato Exemplo    |                                                                                                                                                                     |                                |
|-----------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------|
|                             | Para esta situação                                                                                                                                                  | Use                            |
| value1 operador value2      | Se input1, input2 e result1 forem tags DINT e sua  especificação disser: "Calcular o resultado bit a bit  da input1 e da input2. Armazene o resultado em  result1." | result1 := input1 AND  input2; |

## Consulte também

Componentes do texto estruturado: expressões na página 917

## Usar operadores lógicos

Use os operadores lógicos para verificar se várias condições são verdadeiras ou falsas. O resultado de uma operação lógica é um valor BOOL.

| Se a comparação for O resultado é    |
|--------------------------------------|
| verdadeiro 1                         |
| falso 0                              |

Use estes operadores lógicos.

| Para esta comparação    | Use este  operador    | Tipo de dados ideal    |
|-------------------------|-----------------------|------------------------|
| E lógico                |                       | &, AND BOOL            |
| OU lógico               | OR                    | BOOL                   |
| OU exclusivo lógico XOR |                       | BOOL                   |
| complemento lógico NOT  |                       | BOOL                   |

A tabela apresenta exemplos do uso de operadores lógicos.

| Use este formato Exemplo               |                                                                                                                                                                                                                          |                                     |
|----------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------|
|                                        | Para esta situação                                                                                                                                                                                                       | Use                                 |
| BOOLtag                                | Se photoeye for uma tag BOOL e sua especificação  disser: "Se photoeye_1 estiver ligado, então…"                                                                                                                         | IF photoeye THEN...                 |
| NOT BOOLtag                            | Se photoeye for uma tag BOOL e sua especificação  disser: "Se photoeye estiver desligado, então…"                                                                                                                        | IF NOT photoeye  THEN...            |
| expressão1 &  expressão2               | Se photoeye for uma tag BOOL, temp for uma tag  DINT e sua especificação disser: "se photoeye  estiver ligado e temp for menor do que 100, então…".                                                                      | IF photoeye &  (temp<100) THEN...   |
| expressão1 OR  expressão2              | Se photoeye for uma tag BOOL, temp for uma tag  DINT e sua especificação disser: "se photoeye  estiver ligado ou temp for menor do que 100,  então…".                                                                    | IF photoeye OR  (temp<100) THEN...  |
| expressão1 XOR  expressão2             | Se photoeye1 e photoeye2 forem tags BOOL e sua  especificação disser: "Se:  photoeye1 estiver ligado enquanto photoeye2 estiver  desligado ou  photoeye1 estiver desligado enquanto photoeye2  estiver ligado  então..." | IF photoeye1 XOR  photoeye2 THEN... |
| BOOLtag :=  expression1 &  expression2 | Se photoeye1 e photoeye2 forem tags BOOL,  abertura for uma tag BOOL e sua especificação  disser: "Se photoeye1 e photoeye2 estiverem ambos  ligados, defina abertura como verdadeira"                                   | open := photoeye1 &  photoeye2;     |

## Consulte também

Componentes do texto estruturado: expressões na página 917

## Usar operadores relacionais

Operadores relacionais comparam dois valores ou strings para fornecer um resultado verdadeiro ou falso. O resultado de uma operação relacional é um valor BOOL.

| Se a comparação for O resultado é    |
|--------------------------------------|
| Verdadeiro 1                         |
| Falso 0                              |

Use esses operadores relacionais.

| Para esta comparação Use este operador Tipo de dados ideal    |    |                            |
|---------------------------------------------------------------|----|----------------------------|
| Igual                                                         | =  | Tipo de string, DINT, REAL |
| Menor que                                                     | <  | Tipo de string, DINT, REAL |
| Menor que ou igual                                            | <= | Tipo de string, DINT, REAL |
| Maior que                                                     | >  | Tipo de string, DINT, REAL |
| Maior que ou igual                                            | >= | Tipo de string, DINT, REAL |
| Não igual                                                     | <> | Tipo de string, DINT, REAL |

A tabela apresenta exemplos do uso de operadores relacionais

| Use este formato                                                                                                                | Exemplo                                                                                                                                                                                       | Exemplo                            |
|---------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------|
|                                                                                                                                 | Para esta situação                                                                                                                                                                            | Gravar                             |
| value1 operador value2                                                                                                          | Se temp for uma tag DINT e sua  especificação disser: "se temp for menor  que 100, então…".                                                                                                   | IF temp<100 THEN...                |
| stringtag1 operador stringtag2                                                                                                  | Se bar_code e dest forem tags de string e  sua especificação disser: "Se bar_code  for igual a dest, então…"                                                                                  | IF bar_code=dest THEN...           |
| stringtag1 operator "character  string literal"                                                                                 | Se bar_code for uma tag de string e sua  especificação disser: "Se bar_code for  igual a "Teste APROVADO", então…"                                                                            | IF bar_code="Test PASSED"  THEN... |
| caracter1 operador caracter2  Para inserir um caractere  ASCII diretamente na  expressão, insira o valor  decimal do caractere. | Se bar_code for uma tag de string e sua  especificação disser: "Se  bar_code.DATA[0] for igual a 'A', então…"                                                                                 | IF bar_code.DATA[0]=65  THEN...    |
| bool_tag := bool_expressions                                                                                                    | Se contagem e o comprimento forem tags  DINT, executado for uma tag BOOL e sua  especificação disser: "Se contagem for  maior ou igual a comprimento, você  terminou de realizar a contagem". | Done := (count >= length);         |

## Como as strings são avaliadas

Os valores hexadecimais dos caracteres ASCII determinam se uma string é menor ou maior do que outra string.

## Componentes do texto estruturado: instruções

-  Quando as duas strings forem classificadas como em uma lista telefônica, a ordem das strings determina qual é maior.
-  As strings serão iguais se seus caracteres combinarem.
-  Os caracteres diferenciam maiúsculas e minúsculas. O maiúscula "A" ($ 41) não é igual à minúscula "a" ($ 61).

<!-- image -->

## Consulte também

## Componentes do texto estruturado: expressões na página 917

Declarações de texto estruturado também podem ser instruções. Uma instrução de texto estruturado será executada sempre que for submetida a uma varredura. Uma instrução de texto estruturado em uma construção é executada sempre que as condições da construção forem verdadeiras. Se as condições da construção forem falsas, não será feita uma varredura das instruções na construção. Nenhuma rung-condition ou transição de estado dispara a execução.

Isso difere das instruções do bloco de funções que usam EnableIn para disparar a execução. As instruções de texto estruturado são executadas como se EnableIn sempre estivesse definido.

Isso também difere das instruções do diagrama ladder que usam rung-condition-in para disparar a execução. Algumas instruções do diagrama ladder são executadas apenas quando rung-condition-in alterna de falso para verdadeiro. Estas são instruções de diagrama ladder transicionais. Em texto estruturado, as instruções serão executadas quando forem verificadas, a menos que você pré-condicione a execução da instrução do texto estruturado.

Por exemplo, a instrução ABL é uma instrução de transição no diagrama ladder. Neste exemplo, a instrução ABL só é executada na varredura quando ocorre a transição de tag\_xic de eliminado para definido. A instrução ABL não é executada quando tag\_xic permanece definida ou quando é eliminada.

<!-- image -->

Em texto estruturado, se estiver escrevendo este exemplo como:

IF tag\_xic THEN ABL(0,serial\_control);

END\_IF;

A instrução ABL executará todas as varreduras em que tag\_xic esteja configurado, não apenas quando tag\_xic realizar a transição de eliminado para definido.

Se você deseja que a instrução ABL seja executada somente quando tag\_xic realizar a transição de eliminado para definido, condicione as instruções do texto estruturado. Use um pulso para disparar a execução.

```
osri_1.InputBit := tag_xic; OSRI(osri_1); IF (osri_1.OutputBit) THEN ABL(0,serial_control); END_IF;
```

## Componentes do texto estruturado: constructos

Programe construtos sozinhos ou aninhe-os com outros construtos.

| Se                                                                            | Use esta  construção    |
|-------------------------------------------------------------------------------|-------------------------|
| Fazer algo se ou quando ocorrerem condições específicas IF. . . THEN          |                         |
| Selecionar o que para fazer com base em um valor numérico CASE. . . OF        |                         |
| Fazer algo um número específico de vezes antes de fazer  qualquer outra coisa | FOR. . . DO             |
| Continuar fazendo algo quando determinadas condições  forem verdadeiras       | WHILE. . . DO           |
| Continuar fazendo algo até que uma condição seja verdadeira REPEAT. . . UNTIL |                         |

## Algumas palavras-chave são reservadas

Estas construções não estão disponíveis:

-  GOTO
-  REPEAT

O aplicativo Logix Designer não permitirá que você os use como nomes de tags ou construções.

## Consulte também

IF\_THEN na página 932

CASE\_OF na página 927

FOR\_DO na página 929

WHILE\_DO na página 937

REPEAT\_UNTIL na página 935

## Literais de string de caracteres

Os literais de string de caracteres incluem caracteres codificados de byte único ou de byte duplo. Um literal de string de byte único é uma sequência de zero ou mais caracteres que são prefixados e terminados pelo caractere de aspa simples ('). Em strings de caracteres de byte único, a combinação de três caracteres do sinal de cifrão ($) seguido de dois dígitos hexadecimais é interpretada como a representação hexadecimal do código de caracteres de oito bits, como mostrado na tabela a seguir.

## Dicas:

-  Literais de string de caracteres apenas são aplicáveis a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.
-  O Studio 5000 só é compatível com caracteres de byte único.

## Literais de string de caracteres

|    | N° Des crição (Description)                                                            | Exemplo    |
|----|----------------------------------------------------------------------------------------|------------|
|    | 1a String vazia (comprimento zero)                                                     | ''         |
| 1b | String de comprimento um ou caractere CHAR  contendo um único caractere                | 'A'        |
| 1c | String de comprimento um ou caractere CHAR  contendo o caractere "espaço"              | ' '        |
| 1d | String de comprimento um ou caractere CHAR  contendo o caractere de aspa simples       | '$''       |
| 1e | String de comprimento um ou caractere CHAR  contendo o caractere de aspas duplas       | '"'        |
|    | 1f Compatível com duas combinações de caracteres '$R$L'                                |            |
| 1g | Compatível com uma representação de caracteres  com "$" e dois caracteres hexadecimais | '$0A'      |

## Combinações de dois caracteres em strings de caracteres

| N° Des crição (Description)          | Exemplo    |
|--------------------------------------|------------|
| 1 Sinal de cifrão                    | $$         |
| 2 Aspa simples                       | $'         |
| 3 Alimentação de linha               | $L ou $I   |
| 4 Nova linha                         | $N ou $n   |
| 5 Alimentação de formulário (página) | $P ou $p   |
| 6 Retorno de carro                   | $R ou $r   |
| 7 Tabulador                          | $T ou $t   |

Dicas:  O caractere de nova linha fornece um meio independente de implementação para definir o fim de uma linha de dados para E/S físicas e de arquivos. Para a impressão, o efeito é o de encerrar uma linha de dados e retomar a impressão no início da linha seguinte.

-  A combinação $'só é válida dentro de literais de string de aspa simples.

## Tipos de string

## Consulte também

Componentes do texto estruturado: atribuições na página 914

Tipos de string na página 822

Armazene caracteres ASCII em tags que usem um tipo de dados de tipo de string para:

-  Usar o tipo de dados STRING padrão, que armazena até 82 caracteres
-  Criar um novo tipo de string que armazene menos ou mais caracteres

Para criar um novo tipo de string, consulte o Manual de Programação LOGIX 5000 Controllers ASCII Strings publicação 1756-PM013 .

Cada tipo de string contém os seguintes membros:

| Nome  (Name)    | Tipo de dados  (Data Type)    | Descrição  (Description)         | Notas                                                                                                                                                                                                                                                                                                                                        |
|-----------------|-------------------------------|----------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                 | LEN DINT                      | número de  caracteres na  string | O LEN atualiza automaticamente a nova contagem de  caracteres sempre que usar:    O Navegador de String para inserir caracteres    Instruções que leem, convertem ou manipulam uma string  O LEN mostra o comprimento da string atual. O membro  DATA pode conter caracteres antigos adicionais, que não  estão incluídos na contagem LEN. |
|                 | DATA Matriz SINT              | Caracteres  ASCII da string      | Para acessar os caracteres da string, insira o nome da tag.  Por exemplo, para acessar os caracteres da tag string_1,  insira string_1.  Cada elemento da matriz DATA contém um caractere.  Crie novos tipos de string que armazenem menos ou mais  caracteres.                                                                              |

## Consulte também

Literais de string de caracteres na página 925

## CASE\_OF

Use CASE\_OF para selecionar o que para fazer com base em um valor numérico.

## Operandos

CASE numeric\_expression OF

selector1: statement;

selectorN: statement; ELSE

## Texto estruturado

| Operando Tipo (Type) Format Inserir    |                     |                |                                                                   |
|----------------------------------------|---------------------|----------------|-------------------------------------------------------------------|
| Numeric_  expressão                    | SINT INT  DINT REAL | Tag  expressão | Tag ou expressão que  avalia para um número  (expressão numérica) |
| Selector                               | SINT INT  DINT REAL | Somente        | O mesmo tipo de  numeric_expression                               |

Importante:

Se estiver usando valores REAL, use um intervalo de valores para um seletor porque é mais provável que um valor REAL esteja dentro de um intervalo de valores do que uma correspondência exata de um valor específico.

## Descrição (Description)

## A sintaxe é descrita na tabela.

<!-- image -->

Estes são a sintaxe para inserir os valores do seletor.

| Quando o seletor for Inserir                 |                                                                                                    |
|----------------------------------------------|----------------------------------------------------------------------------------------------------|
| Um valor                                     | value: statement                                                                                   |
| Múltiplos valores  distintos                 | value1, value2, valueN : <statement>  Use uma vírgula (,) para separar cada valor.                 |
|                                              | Uma faixa de valores value1..valueN : <statement>  Use dois pontos (...) para identificar a faixa. |
| Valores distintos mais  uma faixa de valores | valuea, valueb, value1..valueN : <statement>                                                       |

A construção CASE é semelhante a uma instrução de interruptor nas linguagens de programação C ou C ++. Com a construção CASE, o controlador executa apenas as instruções associadas ao primeiro valor correspondente do seletor. A execução sempre é interrompida após as instruções desse seletor e passa para a instrução END\_CASE.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

None

## Exemplo

| Se você quiser isso                                                                                                      | Insira este texto estruturado                                                                                        |
|--------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------|
| Se o número da receita = 1, então, Ingrediente A  saída 1 = aberta (1) Ingrediente B saída 4 = aberta (1)                | CASE recipe_number OF                                                                                                |
| Se o número da receita = 1, então, Ingrediente A  saída 1 = aberta (1) Ingrediente B saída 4 = aberta (1)                | 1:  Ingredient_A.Outlet_1 :=1; Ingredient_B.Outlet_4 :=1;                                                            |
| Se o número da receita = 2 ou 3, então  Ingrediente A saída 4 = aberta (1)  Ingrediente B saída 2 = aberta (1)           | 2,3:  Ingredient_A.Outlet_4 :=1; Ingredient_B.Outlet_2 :=1;                                                          |
| Se o número da receita = 4, 5, 6 ou 7, então,  Ingrediente A saída 4 = aberta (1) Ingrediente B saída  2 = aberta (1)    | 4 a 7: Ingredient_A.Outlet_4 :=1; Ingredient_B.Outlet_2 :=1;                                                         |
| Se o número da receita = 8, 11, 12 ou 13, então,  Ingrediente A saída 1 = aberta (1) Ingrediente B saída  4 = aberta (1) | 8,11…13  Ingredient_A.Outlet_1 :=1; Ingredient_B.Outlet_4 :=1;                                                       |
| Caso contrário, todas as saídas = fechadas (0) ELSE                                                                      |                                                                                                                      |
| Caso contrário, todas as saídas = fechadas (0) ELSE                                                                      | Ingredient_A.Outlet_1 [:=]0; Ingredient_A.Outlet_4 [:=]0;  Ingredient_B.Outlet_2 [:=]0; Ingredient_B.Outlet_4 [:=]0; |
| Caso contrário, todas as saídas = fechadas (0) ELSE                                                                      | END_CASE;                                                                                                            |

[: =] informa ao controlador para também eliminar as tags de saída sempre que o controlador faça o seguinte:

## FOR\_DO

Entra no modo de EXECUÇÃO.

Sai da etapa de um SFC se você configurar o SFC para a Restauração automática. Isso será aplicável apenas ao incorporar a atribuição à ação da etapa ou usar a ação para chamar uma rotina de texto estruturado por meio de uma instrução JSR.

Use o circuito FOR\_DO para realizar uma ação um número de vezes antes de fazer qualquer outra coisa.

Quando habilitada, a instrução FOR executa repetidamente a Rotina até que o valor de Index exceda o Terminal value O valor da etapa pode ser positivo ou negativo. Se for negativo, o circuito se encerra quando o índice for menor que o valor terminal. Se for negativo, o circuito se encerra quando o índice for maior que o valor terminal.

Toda vez que a instrução FOR executa a rotina, ela adiciona o Step size ao Index.

Não ligue o circuito muitas vezes em uma única varredura. Um número excessivo de repetições faz com que o watchdog do controlador atinja o tempo limite e resulta em uma falha grave.

## Operandos

FOR count:= initial\_value TO

final\_value BY increment DO

&lt;statement&gt;;

## END\_FOR;

| Operando       | Tipo  (Type)    |                          | Format Des crição (Description)                                                                                                       |
|----------------|-----------------|--------------------------|---------------------------------------------------------------------------------------------------------------------------------------|
| count          | SINT INT  DINT  | Tag                      | Tag para armazenar a posição de  contagem conforme o FOR_DO é  executado                                                              |
| initial_ value | SINT INT  DINT  | Tag  expressão  imediato | Deve avaliar para um número  Especifica o valor inicial para a  contagem                                                              |
| final_ value   | SINT INT  DINT  | Tag  expressão  imediato | Especifica o valor final para a  contagem, que determina quando  sair do circuito                                                     |
| increment      | SINT INT  DINT  | Tag  expressão  imediato | (Opcional) valor a ser incrementado  na contagem a cada circuito  Se nenhum incremento for  especificado, a contagem  aumentará em 1. |

## Importante:

Não itere no circuito vezes demais em uma única varredura.

O controlador não executará outras instruções na rotina até concluir o circuito.

Uma falha maior ocorre quando a conclusão do circuito leva mais tempo que o temporizador watchdog para a tarefa.

Considere usar uma construção diferente, como IF\_THEN.

## Descrição (Description)

## A sintaxe é descrita na tabela.

<!-- image -->

Estes diagramas ilustram como um circuito FOR\_DO é executado e como uma instrução EXIT deixa o circuito cedo.

<!-- image -->

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha maior ocorrerá se Tipo de falha Código de falha     |     |
|---------------------------------------------------------------|-----|
| Os circuitos da construção forem  executados por muito tempo. | 6 1 |

Exemplo 1

| Está realizado o seguinte,                                                                                                                                                                                                                              | Insira este texto estruturado                                    |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------|
| Eliminar os bits 0...31 em uma matriz de BOOLs:  Inicializar a tag de subscript para 0.  Eliminar i. Por exemplo, quando subscript = 5, elimine  a matriz[5].  Adicionar 1 ao subscript.  Se o subscript for ≤ 31, repita 2 e 3.  Caso contrário, pare. | For subscript:=0 to 31 by 1 do  array[subscript] := 0;  End_for; |

## Exemplo 2

|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      | Insira este texto estruturado             |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------|
| Está realizado o seguinte,  Um tipo de dados (estrutura) definido pelo usuário  armazena as seguintes informações sobre um item em  seu inventário:    ID de código de barras do item (tipo de dados de  string)    Quantidade em estoque do item (tipo de dados DINT)  Uma matriz da estrutura acima contém um elemento  para cada item diferente em seu inventário. Você deseja  pesquisar por um produto específico (use seu código de  barras) na matriz e determinar a quantidade em  estoque.  1. Obter o tamanho (número de itens) da matriz de  inventário e armazenar o resultado em  2. Inventory_Items (tag DINT).  Inicializar a tag de posição para 0.  3. Se o Código de barras corresponder à ID de um item  na matriz, então:  Definir a tag Quantidade (Quantity) =  Inventory[position].Qty. Isso informará a quantidade em  estoque do item.  Pare.  O Código de barras é uma tag de string que armazena o  código de barras do item que você está pesquisando.  Por exemplo, quando  posição = 5, compare o Código de barras a | SIZE(Inventory,0,Inventory_Items);        |
| Está realizado o seguinte,  Um tipo de dados (estrutura) definido pelo usuário  armazena as seguintes informações sobre um item em  seu inventário:    ID de código de barras do item (tipo de dados de  string)    Quantidade em estoque do item (tipo de dados DINT)  Uma matriz da estrutura acima contém um elemento  para cada item diferente em seu inventário. Você deseja  pesquisar por um produto específico (use seu código de  barras) na matriz e determinar a quantidade em  estoque.  1. Obter o tamanho (número de itens) da matriz de  inventário e armazenar o resultado em  2. Inventory_Items (tag DINT).  Inicializar a tag de posição para 0.  3. Se o Código de barras corresponder à ID de um item  na matriz, então:  Definir a tag Quantidade (Quantity) =  Inventory[position].Qty. Isso informará a quantidade em  estoque do item.  Pare.  O Código de barras é uma tag de string que armazena o  código de barras do item que você está pesquisando.  Por exemplo, quando  posição = 5, compare o Código de barras a | For position:=0 to Inventory_Items - 1 do |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      | If Barcode = Inventory[position].ID then  |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      | Quantity := Inventory[position].Qty;      |
| Inventory[5].ID.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Exit;                                     |
| Inventory[5].ID.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | End_if;                                   |
| Inventory[5].ID.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | End_for;                                  |
| 4. Adicionar 1 à posição.  5. Se a posição for ≤ para (Inventory_Items -1), repita 3  e 4. Como os números dos elementos começam em  0, o último elemento é 1 menos do que o número de  elementos na matriz.  Caso contrário, pare.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |                                           |

## IF\_THEN

Use IF\_THEN para concluir uma ação quando ocorrerem condições específicas.

## Operandos

IF bool\_expression THEN

&lt;statement&gt;;

| Operando Tipo (Type) Format Inserir    |      |                |                                                                        |
|----------------------------------------|------|----------------|------------------------------------------------------------------------|
| Bool_  expressão                       | BOOL | Tag  expressão | Tag ou expressão BOOL que avalia  para um valor BOOL  (Expressão BOOL) |

## Descrição (Description)

A sintaxe é descrita na tabela.

<!-- image -->

Para usar ELSIF ou ELSE, siga estas diretrizes.

Para selecionar de vários possíveis grupos de instruções, adicione uma ou mais instruções ELSIF.

Cada ELSIF representa um caminho alternativo.

Especifique quantos caminhos ELSIF como você precisa.

O controlador executa o primeiro IF ou ELSIF verdadeiro e ignora os demais ELSIFs e ELSE.

Para que algo seja feito quando todas as condições IF ou ELSIF forem falsas, adicione uma instrução ELSE.

A tabela resume diferentes combinações de IF, THEN, ELSIF e ELSE.

| Se                                                                                           | E                                                              | Use esta construção    |
|----------------------------------------------------------------------------------------------|----------------------------------------------------------------|------------------------|
| Fazer algo se ou quando as  condições forem verdadeiras                                      | Fazer nada se as condições forem  falsas                       | IF_THEN                |
| Fazer algo se ou quando as  condições forem verdadeiras                                      | Fazer algo diferente se as condições  forem falsas             | IF_THEN_ELSE           |
| Selecione instruções alternativas  ou grupos de instruções com base  em condições de entrada | Fazer nada se as condições forem  falsas                       | IF_THEN_ELSIF          |
| Selecione instruções alternativas  ou grupos de instruções com base  em condições de entrada | Atribuir instruções padrão se todas  as condições forem falsas | IF_THEN_ELSIF_ELSE     |

Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhum.

Exemplos

Exemplo 1

IF…THEN

| Se estiver executando isto     | Insira este texto estruturado    |
|--------------------------------|----------------------------------|
| SE desperdícios > 3, então     | IF rejects > 3 THEN              |
| transportador = desativado (0) | conveyor := 0;                   |
| alarme = ativado (1)           | alarm := 1;                      |
|                                | END_IF;                          |

## Exemplo 2

## IF\_THEN\_ELSE

| Se estiver executando isto                                         | Insira este texto estruturado    |
|--------------------------------------------------------------------|----------------------------------|
| Se o contato de direção do transportador =  para frente (1), então | IF conveyor_direction THEN       |
| luz = desligada                                                    | light := 0;                      |
| Caso contrário, luz = ligada                                       | ELSE                             |
|                                                                    | light [:=] 1;                    |
|                                                                    | END_IF;                          |

[: =] informa ao controlador para apagar a luz sempre que o controlador faça o seguinte:

Entra no modo de EXECUÇÃO.

Sai da etapa de um SFC se você configurar o SFC para a restauração Automática. (Isso será aplicável apenas se você incorpora a atribuição na ação da etapa ou usa a ação para chamar uma rotina de texto estruturado por meio de uma instrução JSR.)

## Exemplo 3

IF…THEN…ELSIF

| Se estiver executando isto                                                                                                           | Insira este texto estruturado    |
|--------------------------------------------------------------------------------------------------------------------------------------|----------------------------------|
| Se o interruptor de limite baixo de açúcar =  baixo (ativado) e o interruptor de limite alto  de açúcar = não alto  (ativado), então | IF Sugar.Low & Sugar.High THEN   |
| válvula de entrada = aberta (ativado) Sugar.Inlet [:=] 1;                                                                            |                                  |
| Até o que interruptor de limite alto de  açúcar = alto (desativado)                                                                  | ELSIF NOT(Sugar.High) THEN       |
|                                                                                                                                      | Sugar.Inlet := 0;                |
|                                                                                                                                      | END_IF;                          |

[: =] informa ao controlador para eliminar Sugar.Inlet sempre que o controlador faça o seguinte:

Entra no modo de EXECUÇÃO.

Sai da etapa de um SFC se você configurar o SFC para a restauração Automática. (Isso será aplicável apenas se você incorpora a atribuição na ação da etapa ou usa a ação para chamar uma rotina de texto estruturado por meio de uma instrução JSR.)

## Exemplo 4

IF…THEN…ELSIF…ELSE

| Se estiver executando isto Insira este texto estruturado           |
|--------------------------------------------------------------------|
| Se a temperatura do tanque > 100 IF tank.temp > 200 THEN           |
| então, bomba = lenta  pump.fast :=1; pump.slow :=0; pump.off :=0;  |
| Se a temperatura do tanque > 200 ELSIF tank.temp > 100 THEN        |
| então, bomba = rápida  pump.fast :=0; pump.slow :=1; pump.off :=0; |
| Caso contrário, bomba = desativada ELSE                            |
| pump.fast :=0; pump.slow :=0; pump.off :=1;                        |
| END_IF;                                                            |

## REPEAT\_UNTIL

Use o circuito REPEAT\_UNTIL para continuar realizando uma ação até que as condições sejam verdadeiras.

## Operandos

## REPEAT

&lt;statement&gt;;

## Texto estruturado

| Operando Tipo (Type) Format Inserir    |      |                |                                                                        |
|----------------------------------------|------|----------------|------------------------------------------------------------------------|
| bool_  expressão                       | BOOL | Tag  expressão | Tag ou expressão BOOL que avalia  para um valor BOOL  (Expressão BOOL) |

## Importante:

Não itere no circuito vezes demais em uma única varredura.

O controlador não executará outras instruções na rotina até concluir o circuito.

Uma falha maior ocorre quando a conclusão do circuito leva mais tempo que o temporizador watchdog para a tarefa.

Considere usar uma construção diferente, como IF\_THEN.

## Descrição (Description)

## A sintaxe é:

<!-- image -->

Os diagramas a seguir mostram como um circuito REPEAT\_UNTIL é executado e como uma instrução EXIT deixa o circuito cedo.

Enquanto bool\_expression é falso, o controlador executa apenas as instruções dentro do circuito REPEAT\_UNTIL.

<!-- image -->

Para parar o circuito antes que as condições sejam falsas, use uma instrução EXIT.

<!-- image -->

Afeta sinalizadores de status de operações matemáticas

Não

Condições de falha

| Uma falha maior ocorrerá  se                                  | Tipo de  falha    | Código de  falha    |
|---------------------------------------------------------------|-------------------|---------------------|
| Os circuitos da construção  forem executados por muito  tempo | 6 1               |                     |

Exemplo 1

| Está realizado o seguinte,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | Insira este texto estruturado                                 |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------|
| O circuito REPEAT_UNTIL executa as instruções na  construção e, em seguida, determina se as condições  são verdadeiras antes de executar as instruções  novamente. Isso difere do circuito WHILE_DO porque  WHILE_DO avalia suas condições primeiro.  Se as condições forem verdadeiras, o controlador,  então, executará as instruções no circuito. As instruções  em um circuito REPEAT_UNTIL são sempre executadas  pelo menos uma vez. As instruções em um circuito  WHILE_DO podem nunca ser executadas. | pos := -1;                                                    |
| O circuito REPEAT_UNTIL executa as instruções na  construção e, em seguida, determina se as condições  são verdadeiras antes de executar as instruções  novamente. Isso difere do circuito WHILE_DO porque  WHILE_DO avalia suas condições primeiro.  Se as condições forem verdadeiras, o controlador,  então, executará as instruções no circuito. As instruções  em um circuito REPEAT_UNTIL são sempre executadas  pelo menos uma vez. As instruções em um circuito  WHILE_DO podem nunca ser executadas. | REPEAT                                                        |
| O circuito REPEAT_UNTIL executa as instruções na  construção e, em seguida, determina se as condições  são verdadeiras antes de executar as instruções  novamente. Isso difere do circuito WHILE_DO porque  WHILE_DO avalia suas condições primeiro.  Se as condições forem verdadeiras, o controlador,  então, executará as instruções no circuito. As instruções  em um circuito REPEAT_UNTIL são sempre executadas  pelo menos uma vez. As instruções em um circuito  WHILE_DO podem nunca ser executadas. | pos := pos + 2;                                               |
| O circuito REPEAT_UNTIL executa as instruções na  construção e, em seguida, determina se as condições  são verdadeiras antes de executar as instruções  novamente. Isso difere do circuito WHILE_DO porque  WHILE_DO avalia suas condições primeiro.  Se as condições forem verdadeiras, o controlador,  então, executará as instruções no circuito. As instruções  em um circuito REPEAT_UNTIL são sempre executadas  pelo menos uma vez. As instruções em um circuito  WHILE_DO podem nunca ser executadas. | UNTIL ((pos = 101) OR (structarray[pos].value = targetvalue)) |
| O circuito REPEAT_UNTIL executa as instruções na  construção e, em seguida, determina se as condições  são verdadeiras antes de executar as instruções  novamente. Isso difere do circuito WHILE_DO porque  WHILE_DO avalia suas condições primeiro.  Se as condições forem verdadeiras, o controlador,  então, executará as instruções no circuito. As instruções  em um circuito REPEAT_UNTIL são sempre executadas  pelo menos uma vez. As instruções em um circuito  WHILE_DO podem nunca ser executadas. | end_repeat;                                                   |

Exemplo 2

| Está realizado o seguinte,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | Insira este texto estruturado                                   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------|
| Mover caracteres ASCII de uma matriz SINT para uma  tag de string. (Em uma matriz SINT, cada elemento tem  um caractere). Pare quando você atingir o retorno de  carro.  Inicializar Element_number para 0.  Contar o número de elementos em SINT_array (matriz  que contém os caracteres ASCII) e armazenar o  resultado em SINT_array_size (tag DINT).  Definir String_tag[element_number] = o caractere em  SINT_array[element_number].  Adicionar 1 ao element_number. Isso permite que o  controlador verifique o próximo caractere em  SINT_array.  Definir o membro de Comprimento (Length) de  String_tag = element_number. (Isso registra o número  de caracteres em String_tag até o momento.) | element_number := 0;                                            |
| Mover caracteres ASCII de uma matriz SINT para uma  tag de string. (Em uma matriz SINT, cada elemento tem  um caractere). Pare quando você atingir o retorno de  carro.  Inicializar Element_number para 0.  Contar o número de elementos em SINT_array (matriz  que contém os caracteres ASCII) e armazenar o  resultado em SINT_array_size (tag DINT).  Definir String_tag[element_number] = o caractere em  SINT_array[element_number].  Adicionar 1 ao element_number. Isso permite que o  controlador verifique o próximo caractere em  SINT_array.  Definir o membro de Comprimento (Length) de  String_tag = element_number. (Isso registra o número  de caracteres em String_tag até o momento.) | SIZE(SINT_array, 0, SINT_array_size);                           |
| Mover caracteres ASCII de uma matriz SINT para uma  tag de string. (Em uma matriz SINT, cada elemento tem  um caractere). Pare quando você atingir o retorno de  carro.  Inicializar Element_number para 0.  Contar o número de elementos em SINT_array (matriz  que contém os caracteres ASCII) e armazenar o  resultado em SINT_array_size (tag DINT).  Definir String_tag[element_number] = o caractere em  SINT_array[element_number].  Adicionar 1 ao element_number. Isso permite que o  controlador verifique o próximo caractere em  SINT_array.  Definir o membro de Comprimento (Length) de  String_tag = element_number. (Isso registra o número  de caracteres em String_tag até o momento.) | Repeat                                                          |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | String_tag.DATA[element_number] :=  SINT_array[element_number]; |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | element_number := element_number + 1;                           |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | String_tag.LEN := element_number;                               |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | If element_number = SINT_array_size then                        |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | exit;                                                           |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | end_if;                                                         |
| Se element_number = SINT_array_size, então, pare.  (Você está no final da matriz e não contém um retorno  de carro).  Se o caractere em SINT_array[element_number] = 13  (valor decimal do retorno do carro), então, pare.                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | Until SINT_array[element_number] = 13                           |
| Se element_number = SINT_array_size, então, pare.  (Você está no final da matriz e não contém um retorno  de carro).  Se o caractere em SINT_array[element_number] = 13  (valor decimal do retorno do carro), então, pare.                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | end_repeat;                                                     |

## WHILE\_DO

Use o circuito WHILE\_DO para continuar realizando uma ação enquanto determinadas condições forem verdadeiras.

## Operandos

WHILE bool\_expression DO

&lt;statement&gt;;

## Texto estruturado

| Operando Tipo (Type) Format    |                     | Descrição  (Description)                              |
|--------------------------------|---------------------|-------------------------------------------------------|
| bool_expression                | BOOL tag  expressão | Tag ou expressão  BOOL que avalia  para um valor BOOL |

## Importante:

Não itere no circuito vezes demais em uma única varredura.

O controlador não executará quaisquer outras

instruções na rotina até concluir o circuito.

Uma falha maior ocorre quando a conclusão do circuito leva mais tempo que o temporizador watchdog para a tarefa.

Considere usar uma construção diferente, como IF\_THEN.

## Descrição (Description)

## A sintaxe é:

<!-- image -->

Os diagramas a seguir ilustram como um circuito WHILE\_DO é executado e como uma instrução EXIT deixa o circuito cedo.

<!-- image -->

## Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

| Uma falha maior ocorrerá se Tipo de falha Código de falha    |     |
|--------------------------------------------------------------|-----|
| os circuitos da construção forem  executados por muito tempo | 6 1 |

Exemplo 1

| Está realizado o seguinte,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Insira este texto estruturado                                    |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------|
| O circuito WHILE_DO avalia suas condições primeiro.  Se as condições forem verdadeiras, o controlador,  então, executará as instruções no circuito.  Isso difere do circuito REPEAT_UNTIL porque o circuito  REPEAT_UNTIL executa as instruções na construção e,  em seguida, determina se as condições são verdadeiras  antes de executar as instruções novamente. As  instruções em um circuito REPEAT_UNTIL são sempre  executadas pelo menos uma vez. As instruções em um  circuito WHILE_DO podem nunca ser executadas. | pos := 0;                                                        |
| O circuito WHILE_DO avalia suas condições primeiro.  Se as condições forem verdadeiras, o controlador,  então, executará as instruções no circuito.  Isso difere do circuito REPEAT_UNTIL porque o circuito  REPEAT_UNTIL executa as instruções na construção e,  em seguida, determina se as condições são verdadeiras  antes de executar as instruções novamente. As  instruções em um circuito REPEAT_UNTIL são sempre  executadas pelo menos uma vez. As instruções em um  circuito WHILE_DO podem nunca ser executadas. | While ((pos <= 100) & structarray[pos].value <> targetvalue)) do |
| O circuito WHILE_DO avalia suas condições primeiro.  Se as condições forem verdadeiras, o controlador,  então, executará as instruções no circuito.  Isso difere do circuito REPEAT_UNTIL porque o circuito  REPEAT_UNTIL executa as instruções na construção e,  em seguida, determina se as condições são verdadeiras  antes de executar as instruções novamente. As  instruções em um circuito REPEAT_UNTIL são sempre  executadas pelo menos uma vez. As instruções em um  circuito WHILE_DO podem nunca ser executadas. | pos := pos + 2;                                                  |

Exemplo 2

| Está realizado o seguinte,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | Insira este texto estruturado                                   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------|
| Mover caracteres ASCII de uma matriz SINT para uma  tag de string. (Em uma matriz SINT, cada elemento tem  um caractere). Pare quando você atingir o retorno de  carro.  Inicializar Element_number para 0.  Contar o número de elementos em SINT_array (matriz  que contém os caracteres ASCII) e armazenar o  resultado em SINT_array_size (tag DINT).  Se o caractere em SINT_array[element_number] = 13  (valor decimal do retorno do carro), então, pare.  Definir String_tag[element_number] = o caractere em  SINT_array[element_number].  Adicionar 1 ao element_number. Isso permite que o  controlador verifique o próximo caractere em | element_number := 0;                                            |
| Mover caracteres ASCII de uma matriz SINT para uma  tag de string. (Em uma matriz SINT, cada elemento tem  um caractere). Pare quando você atingir o retorno de  carro.  Inicializar Element_number para 0.  Contar o número de elementos em SINT_array (matriz  que contém os caracteres ASCII) e armazenar o  resultado em SINT_array_size (tag DINT).  Se o caractere em SINT_array[element_number] = 13  (valor decimal do retorno do carro), então, pare.  Definir String_tag[element_number] = o caractere em  SINT_array[element_number].  Adicionar 1 ao element_number. Isso permite que o  controlador verifique o próximo caractere em | SIZE(SINT_array, 0, SINT_array_size);                           |
| Mover caracteres ASCII de uma matriz SINT para uma  tag de string. (Em uma matriz SINT, cada elemento tem  um caractere). Pare quando você atingir o retorno de  carro.  Inicializar Element_number para 0.  Contar o número de elementos em SINT_array (matriz  que contém os caracteres ASCII) e armazenar o  resultado em SINT_array_size (tag DINT).  Se o caractere em SINT_array[element_number] = 13  (valor decimal do retorno do carro), então, pare.  Definir String_tag[element_number] = o caractere em  SINT_array[element_number].  Adicionar 1 ao element_number. Isso permite que o  controlador verifique o próximo caractere em | While SINT_array[element_number] <> 13 do                       |
| SINT_array.  Definir o membro de Comprimento (Length) de  String_tag = element_number. (Isso registra o número  de caracteres em String_tag até o momento.)  Se element_number = SINT_array_size, então, pare.                                                                                                                                                                                                                                                                                                                                                                                                                                    | String_tag.DATA[element_number] :=  SINT_array[element_number]; |
| SINT_array.  Definir o membro de Comprimento (Length) de  String_tag = element_number. (Isso registra o número  de caracteres em String_tag até o momento.)  Se element_number = SINT_array_size, então, pare.                                                                                                                                                                                                                                                                                                                                                                                                                                    | element_number := element_number + 1;                           |
| SINT_array.  Definir o membro de Comprimento (Length) de  String_tag = element_number. (Isso registra o número  de caracteres em String_tag até o momento.)  Se element_number = SINT_array_size, então, pare.                                                                                                                                                                                                                                                                                                                                                                                                                                    | String_tag.LEN := element_number;                               |
| SINT_array.  Definir o membro de Comprimento (Length) de  String_tag = element_number. (Isso registra o número  de caracteres em String_tag até o momento.)  Se element_number = SINT_array_size, então, pare.                                                                                                                                                                                                                                                                                                                                                                                                                                    | If element_number = SINT_array_size then                        |
| (Você está no final da matriz e não contém um retorno  de carro).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | exit;                                                           |
| (Você está no final da matriz e não contém um retorno  de carro).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | end_if;                                                         |
| (Você está no final da matriz e não contém um retorno  de carro).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | end_while;                                                      |

## Atributos de texto estruturado

Clique no tópico abaixo para obter mais informações sobre questões exclusivas para a programação de texto estruturado. Revise essas informações para garantir que compreende como a programação de texto estruturado será executada.

## Consulte também

Componentes de texto estruturado: Atribuições na página 914

Componentes de texto estruturado: Expressões na página 917

Instruções de texto estruturado na página 922

Componentes de texto estruturado: Construções na página 924

Componentes de texto estruturado: Comentários na página 913

## A

ABL 807

ABS 370

ACB 785

ACL 788

ACS 725

ADD 376

adição (ADD) 376

AFI 622

AHL 792

alarme analógico 28

alarme analógico ALMA lógica ladder 28

alarme digital 56

alarme digital ALMD lógica ladder 56

AND 439

ASCII 783, 825, 845

Instruções de conversão ASCII 845

Instruções de porta serial ASCII 783

Instruções de string ASCII 825, 845

ASN 729

AVE 520

AWA 816

AWT 810

## B

BAND 455

BNOT 465

Booliano 455, 461, 465, 469

Booliano AND (BAND) 455

NÃO Booliano (BNOT) 465

OU booliano (BOR) 469

OU exclusivo booliano (BXOR) 461

BOR 469

BTD 430

BTDT 434

BXOR 461

## C

carga LIFO (LFL) 589

case...of 927

CLR 474

CMP 294

códigos de erro 174, 177, 179, 823

ASCII 823

mensagem 174

comparação de bits de arquivo (FBC) 692

contagem crescente (CTU) 109

contagem crescente/decrescente (CTUD) 114

contagem decrescente (CTD) 104

COP 494

copiar arquivo (COP), copiar arquivo de forma síncrona (CPS) 494

copiar arquivo de forma síncrona - CPS 494

## D

dados de retenção 897

DDT 684

detecção diagnóstica (DDT) 684

deslocamento de bit esquerdo (BSL) 566

destravamento de saída (OTU) 99

diferente de (NEQ) 358

DINT para String (DTOS) 846

distribuição do campo de bit (BTD) 430

distribuição do campo de bit com destino (BTDT)

434

DIV 387

dividir (DIV) 387

## E

encontrar string (FIND) 826

energização de saída (OTE) 95

entrada do sequenciador (SQI) 606

EQU 298

EVENT 654

examinar se aberto (XIO) 78

examinar se fechado (XIC) 76

## F

FAL 503

fluxograma FAL (falso) 503

Fluxograma FAL (verdadeiro) 503

FBC 692

comparação de bits de arquivo (FBC) 692

FFL 575

fluxograma FFL (falso) 575

fluxograma FFL (pré-varredura) 575

Fluxograma FFL (verdadeiro) 575

FFU 582

fluxograma FFU (falso) 582

## Índice

| fluxograma FFU (pré-varredura) 582  Fluxograma FFU (verdadeiro) 582  FIFO 575, 582  carga FIFO (FFL) 575  descarga FIFO (FFU) 582  fim temporário (TND) 652  FLL 524  FOR 665  for...do 929  G GEQ 315  graus (DEG) 771  GSV 191  GSV/SSV 206, 209, 261  exemplo de programação 206  objetos 209  objetos de segurança 261  I if...then 932  igual a (EQU) 298  instruções de alarmes 27  alarme analógico 28  alarme digital 56  instruções de bit 75  instruções de cálculo/matemáticas 369  instruções de circulação/interrupção 663  instruções de comparação 293  Instruções de conversão ASCII 845  DINT para string (DTOS) 846  letra maiúscula (UPPER) 862    | Teste ASCII para linha do buffer (ABL) 807  tipos de dados 822  tipos de string 822  Instruções de string ASCII 825, 826, 829, 833, 836,  841  concatenar string (CONCAT) 836  encontrar string (FIND) 826  excluir string (DELETE) 841  inserir string (INSERT) 829  string do meio (MID) 833  instruções especiais 679  instruções lógicas/de movimento 429  instruções Logix 879  atributos comuns 879  J JMP 629  JSR 632  JXR 625  L LBL 629  LEQ 331  LES 323  letra minúscula - LOWER 849  LFL 589  fluxograma LFL (falso) 589  fluxograma LFL (pré-varredura) 589  Fluxograma LFL (verdadeiro) 589  LFU 596  fluxograma LFU (falso) 596  fluxograma LFU (pré-varredura) 596    |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

MCR 642

menos que (LES) 323

menos que ou igual a (LEQ) 331

mensagem 174

códigos de erro 174

códigos de erros (.ERR) 174

MEQ 349

MID 833

MOD 393

modo incremental 561, 562

fluxograma do modo incremental (FSC) 562

modo numérico 558

modos de temporização 903

MOV 484

movimentação (MOV) 484

MSG 154, 163

exemplos de configuração 163

MUL 400

multiplicar (MUL) 400

MVM 476

MVMT 479

## N

NEG 407

negar (NEG) 407

nenhuma instrução de operação (NOP) 646

NEQ 358

NOP 646

NOT 447

## O

obter valor do sistema (GSV) 191

ONS 80

OR 451

ordem de execução 898

OSF 82

OSFI 85

OSRI 92

ou bit a bit (OR) 451

ou bit a bit exclusivo (XOR) 443

## P

pausar SFC - SFP 647

pesquisa e comparação de arquivos (FSC) 527

PID 701, 708, 712, 713, 714, 715, 716, 720, 721

circuitos em cascata 713 controlar uma relação 714 definir a zona morta 720 feedforward ou polarização de saída 715 proporção integral derivativa (PID) 701 restauração ininterrupta 712 saturação de anti-restauração 712 temporização da instrução 716 transferência ininterrupta de manual para automático 712 usando instruções PID 708 usar limitação da saída 721 preencher arquivo (FLL) 524 proporção integral derivativa - PID 701

## R

RAD 774 radiano (RAD) 774 raiz quadrada (SQR) 412 REAL para string (RTOS) 853 repeat\_until 935 RES 119 retornar (RET) 632, 669 rótulo (LBL) 629 RTO 122 RTOR 127 RTOS 853

## S

saída do sequenciador (SQO) 614

Saída imediata (IOT) 195

saltar para o rótulo (JMP) 629

saltar para rotina externa - JXR 625

SBR 632

seno (SIN) 740

SIN 740

SQI 606

SQL 610

SQO 614

SQR 412

SQRT 412

SRT 542

string do meio (MID) 833

SUB 419

subrotina (SBR) 632

subtrair (SUB) 419

## T

tamanho em elementos (SIZE) 552

TAN 744

tangente (TAN) 744

temporizador retentivo ativado (RTO) 122

temporizador retentivo ativado com restauração

(RTOR) 127

test limite (LIM) 340

texto estruturado 912, 913, 914, 917, 922, 924, 940

atribuições 914

atributos 940

comentários 913

construções 924

expressões 917

instruções 922

sintaxe de programação 912

sintaxe de texto estruturado 912

TND 652

TOD 764

TOF 133

TOFR 137

TON 142

TONR 147

trava de saída (OTL) 97

trocar byte - SWPB 488

## U

UID 659

UIE 659

um pulso (ONS) 80

um pulso na borda ascendente (OSR) 88

um pulso na borda ascendente com entrada (OSRI)

92

um pulso na borda descendente (OSF) 82

um pulso na borda descendente com entrada (OSFI)

85

## V

Valor absoluto (ABS) 370 valores imediatos 882

## W

while\_do 937

944

## X

X elevado à potência de Y (XPY) 758

XIC 76

XIO 78

XPY 758

## Suporte da Rockwell Automation

A Rockwell Automation fornece informações técnicas na web para ajudá-lo no uso dos produtos. Em http://www.rockwellautomation.com/support é possível encontrar notas técnicas e do aplicativo, código de amostra e links para pacotes de serviço de software. Também é possível acessar o nosso Centro de suporte em https://rockwellautomation.custhelp.com para atualizações de software, chats e fóruns de suporte, informações técnicas, perguntas frequentes e inscrever-se para atualizações de notificação do produto.

Além disso, oferecemos vários programas de suporte para instalação, configuração e solução de problemas. Para obter mais informações, contate o distribuidor ou representante local da Rockwell Automation ou visite http://www.rockwellautomation.com/services/online-phone .

## Assistência de instalação

Se você tiver algum problema nas primeiras 24 horas da instalação, analise as informações contidas neste manual. Você pode entrar em contato com o Suporte ao Cliente para ajuda inicial para deixar o produto ativo e operando.

| Estados Unidos ou Canadá 1.440.646.3434    |                                                                                                                                                  |
|--------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------|
| Fora dos Estados Unidos ou  Canadá         | Use o Localizador Mundial disponível em http://www.rockwellautomation.com/locations  ,  ou contate o representante local da Rockwell Automation. |

## Devolução para satisfação com produtos novos

A Rockwell Automation testa todos os seus produtos para garantir que estejam totalmente operacionais quando enviados da fábrica. Porém, se o seu produto não estiver funcionando e precisar ser devolvido, siga estes procedimentos.

| Estados Unidos    | Contate o distribuidor. É preciso fornecer um número de caso do Suporte ao Cliente  (telefone para o número acima para obter um) para o distribuidor concluir o processo de  devolução.    |
|-------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                   | Fora dos Estados Unidos Conte o representante local da Rockwell Automation para o procedimento de devolução.                                                                               |

## Feedback da documentação

Seus comentários irão nos ajudar a atender melhor as suas necessidades de documentação. Se você tiver sugestões sobre como melhorar este documento, preencha este formulário de feedback, publicação RA-DU002 .
