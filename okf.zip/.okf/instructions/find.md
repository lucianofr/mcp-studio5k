---
type: Instruction
title: "Encontrar string (FIND)"
description: "Existem regras de conversão de dados para combinar tipos de dados em uma instrução."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L20606-L20662"
---

## Encontrar string (FIND)

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados.

## Diagrama ladder e Texto estruturado

| Operando Tipo    | Operando Tipo         |              | Formato Descrição Notas                                    |                                                                                                                                                                                                                          |
|------------------|-----------------------|--------------|------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                  | Source ANY_STRING Tag |              | A string para  pesquisar  em                               | Tipos de strings são:  tipo de dados de  STRING padrão com  no máximo 82  caracteres de  extensão para a string. qualquer novo tipo de  string que você criou  com extensão  configurável de  caracteres para a  string. |
|                  | Search ANY_STRING Tag |              | A string para  encontrar                                   | Tipos de strings são:  tipo de dados de  STRING padrão com  no máximo 82  caracteres de  extensão para a string. qualquer novo tipo de  string que você criou  com extensão  configurável de  caracteres para a  string. |
| Start            | SINT  INT  DINT       | Imediato tag | A posição  em Source  onde a  pesquisa  deve ser  iniciada | Digite um número  entre 1 e o tamanho  de DATA da Source.                                                                                                                                                                |
| Result           | DINT  SINT  INT       | Tag          | A posição  em Source  onde a string  foi  encontrada       |                                                                                                                                                                                                                          |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Descrição

A instrução FIND pesquisa pela string de Source na string de Search. Se a instrução encontrar a string de Search, o Result mostra a posição inicial da string de Search dentro da string de Source. Caso contrário, o Result é zero.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha menor ocorrerá  se:                                                         | Tipo de falha Código de falha    |
|---------------------------------------------------------------------------------------|----------------------------------|
| O valor de LEN da tag de  string é maior do que o  tamanho de DATA da tag de  string. | 4 51                             |
| O valor de Start é inválido, ou  A string de Source está vazia.                       | 4 56                             |

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição A  ção                                         |
|---------------------------------------------------------|
| Pré-varredura N/A                                       |
| Rung-condition-in é falsa N/A                           |
| Rung-condition-in é verdadeira A instrução é executada. |
| Pós-varredura N/A                                       |

## Texto estruturado

| Condição A      | ção                                                                     |
|-----------------|-------------------------------------------------------------------------|
| Pré-varredura   | Consulte Pré-varredura na tabela  do Diagrama ladder                    |
| Execução normal | Consulte Rung-condition-in é  verdadeira na tabela de Diagrama  ladder. |
| Pós-varredura   | Consulte Pós-varredura na tabela  do Diagrama ladder                    |

## Exemplo

Uma mensagem de um terminal MessageView contém várias informações. O caractere da barra invertida (\) separa cada informação. Para localizar uma informação, a instrução FIND pesquisa pelo caractere da barra invertida e registra sua posição em find\_pos.
