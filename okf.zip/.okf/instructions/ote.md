---
type: Instruction
title: "Energizar saída (OTE)"
description: "OSRI(OSRI\_01);"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L2016-L2094"
---

## Energizar saída (OTE)

OSRI(OSRI\_01);

State := OSRI\_O1.OutputBit;

## Consulte também

Instruções de bit na página 75

Um pulso na borda descendente (OSF) na página 82

Um pulso (ONS) na página 80

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução OTE define ou restaura o bit de dados com base na condição do degrau.

## Idiomas disponíveis

Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

## Diagrama ladder

| Operando          | Tipo de  dados    | Formato Des crição    |                                                                                                                                                        |
|-------------------|-------------------|-----------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------|
| Data bit BOOL tag |                   |                       | Bit a ser modificado. Há  diversos modos de  endereçamento do  operando possíveis para  o bit de dados, consulte  Endereçamento de bits para exemplos. |

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                  |
|------------------------------------|--------------------------------------------------------------------------------------------------|
|                                    | Pré-varredura O bit de dados é restaurado para falso                                             |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como  Rung-condition-in.  O bit de dados é restaurado para falso      |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como  Rung-condition-in.  O bit de dados é definido como  verdadeiro. |
|                                    | Pós-varredura O bit de dados é eliminado para falso.                                             |

## Exemplo

## Diagrama ladder

<!-- image -->

Quando o interruptor é verdadeiro, a instrução OTE define Light\_01 para verdadeiro. Quando o interruptor é falso, a instrução OTE restaura Light\_01 para falso.
