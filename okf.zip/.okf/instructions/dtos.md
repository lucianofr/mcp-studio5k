---
type: Instruction
title: "DINT para String (DTOS)"
description: "Você também pode usar as instruções a seguir para comparar ou manipular caracteres ASCII:"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L21099-L21192"
---

## DINT para String (DTOS)

Você também pode usar as instruções a seguir para comparar ou manipular caracteres ASCII:

| Se você desejar:                                                             | Use esta instrução:    |
|------------------------------------------------------------------------------|------------------------|
| Adicionar caracteres no final de uma string CONCAT                           |                        |
| Excluir os caracteres de uma string                                          | DELETE                 |
| Determinar o caractere inicial de uma sub-string FIND                        |                        |
| Inserir caracteres em uma string                                             | INSERT                 |
| Extrair caracteres de uma string                                             | MID                    |
| Reorganizar os bytes de uma tag INT, DINT ou  REAL                           | SWPB                   |
| Comparar uma string a outra string                                           | CMP                    |
| Consultar se os caracteres são iguais a  caracteres específicos              | EQU                    |
| Consultar se os caracteres não são iguais a  caracteres específicos          | NEQ                    |
| Consultar se os caracteres são iguais ou maiores  que caracteres específicos | GEQ                    |
| Consultar se os caracteres são maiores que  caracteres específicos           | GRT                    |
| Consultar se os caracteres são iguais ou  menores que caracteres específicos | LEQ                    |
| Consultar se os caracteres são menores que  caracteres específicos           | LES                    |
| Encontrar uma string em uma matriz de strings. FSC                           |                        |

## Consulte também

Códigos de erro de ASCII na página 823

Tipos de string na página 822

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução DTOS produz a representação ASCII de um valor.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

DTOS(Source,Dest);

## Operandos

## Diagrama ladder e Texto estruturado

| Operando Tipo Formato Descrição Notas    | Operando Tipo Formato Descrição Notas    |     |                                     |                                                                                                            |
|------------------------------------------|------------------------------------------|-----|-------------------------------------|------------------------------------------------------------------------------------------------------------|
| Source                                   | SINT  INT  DINT  REAL                    | Tag | A tag que  contém o  valor.         | Se a Source for  REAL, a instrução  a converte em um  valor DINT.                                          |
| Destination                              | Tipo  de  string                         | Tag | A tag a  armazenar o  valor inteiro | Tipos de strings  são:    tipo de dado de  STRING padrão    qualquer tipo de  string novo que  você cria |

## Descrição

A instrução DTOS converte a Source em uma string de caracteres ASCII e coloca o resultado no Destination.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Tipo Code Causa    | Tipo Code Causa                                                                        | Método de recuperação                                                                                                                                      |
|--------------------|----------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 4 51               | O valor de LEN da  tag de string é  maior do que o  tamanho de DATA  da tag de string. | Verifique se nenhuma  instrução está sendo gravada  no membro LEN da tag de  string.  No valor de LEN, digite o  número de caracteres  contidos na string. |
| 4 52               | A string de saída é  maior do que o  destino.                                          | Crie um novo tipo de string  que seja grande suficiente  para a string de saída. Use o  novo tipo de string como o  tipo de dados para o destino.          |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                           |
|-----------------------------------------------------------|
| Pré-varredura N/A                                         |
| Rung-condition-in é falsa N/A                             |
| Rung-condition-in é  verdadeira  A instrução é executada. |
| Pós-varredura N/A                                         |

## Texto estruturado

| Condição A      | ção                                                                              |
|-----------------|----------------------------------------------------------------------------------|
| Pré-varredura   | Consulte Pré-varredura na tabela de  Diagrama ladder anterior                    |
| Execução normal | Consulte rung-condition-in é  verdadeira na tabela de Diagrama  ladder anterior. |
| Pós-varredura   | Consulte Pós-varredura na tabela de  Diagrama ladder anterior                    |

## Exemplo

Quando temp\_high for definido, a instrução DTOS converte o valor em msg\_num em uma string de caracteres ASCII e coloca o resultado em masg\_num\_ascii. Degraus subsequentes inserem ou concatenam o msg\_num\_ascii com outras strings para produzir uma mensagem completa para um terminal de exibição.
