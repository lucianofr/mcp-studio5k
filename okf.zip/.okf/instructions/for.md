---
type: Instruction
title: "Circulação (FOR)"
description: "Quando habilitada, a instrução BRK para a execução da rotina atual e retorna à instrução que segue a instrução FOR de chamada."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L16033-L16135"
---

## Circulação (FOR)

## Exemplo

Quando habilitada, a instrução BRK para a execução da rotina atual e retorna à instrução que segue a instrução FOR de chamada.

## Diagrama ladder

<!-- image -->

## Essa é routine2:

<!-- image -->

## Consulte também

Atributos comuns na página 879

Instruções de Circulação/Interrupção na página 663

Circuição (FOR) na página 665

Saltar para o rótulo (JMP) e Rótulo (LBL) na página 629

Saltar para subrotina (JSR), Subrotina (SBR) e Retornar (RET) na página 632

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução FOR executa uma rotina repetidamente.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Diagrama ladder

| Operando Tipo Formato Descrição    |               |                                                                                  |
|------------------------------------|---------------|----------------------------------------------------------------------------------|
| Routine name ROUTINE tag           |               | Subrotina que é invocada cada  vez que um circuito FOR for  executado.           |
| Index DINT tag                     |               | Conta quantas vezes a rotina foi  executada                                      |
| Initial value SINT  INT  DINT      | imediato  tag | Valor no qual iniciar o índice                                                   |
| Terminal value SINT  INT  DINT     | imediato  tag | Valor no qual parar de executar  a rotina                                        |
| Step size SINT  INT  DINT          | imediato  tag | Quantidade a adicionar ao índice  toda vez que a instrução FOR  executa a rotina |

## Descrição

Quando habilitada, a instrução FOR executa repetidamente a Rotina até que o valor de Index exceda o Terminal value Esta instrução não transmite parâmetros para a rotina.

O valor da etapa pode ser positivo ou negativo. Se for negativo, o circuito se encerra quando o índice for menor que o valor terminal. Se for negativo, o circuito se encerra quando o índice for maior que o valor terminal.

Toda vez que a instrução FOR executa a rotina, ela adiciona o Step size ao Index.

Cuidado para não ligar em circuito muitos vezes em uma única varredura. Um número excessivo de repetições pode fazer com que o watchdog do controlador atinja o tempo limite, o que pode resultar em uma falha grave.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Controladores                                                                                       | Uma falha maior  ocorrerá se:                                    | Tipo de  falha    | Código  de falha    |
|-----------------------------------------------------------------------------------------------------|------------------------------------------------------------------|-------------------|---------------------|
| Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e | O limite de nível de  aninhamento > 25                           |                   | 4 94                |
| GuardLogix 5580  Controladores CompactLogix  5370, ControlLogix 5570,                               | A subrotina é um SFC a  já está em execução  (chamada recursiva) |                   | 4 82                |
| Compact GuardLogix 5370 e  GuardLogix 5570                                                          |                                                                  |                   | N/A N/A N/A         |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

| Condição/estado A               | ção                                                                                                                                                                                                                                                                                                                                                                                         |
|---------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                   | A instrução fará a pré-varredura da subrotina  nomeada, se sua pré-varredura não tiver sido  feita antes.  Dica: Se a instrução FOR recursiva existir para  a mesma subrotina, ou existirem múltiplas  instruções FOR (não-recursivas) para a mesma  subrotina, a subrotina passa por pré-varredura  apenas uma vez. O mesmo ocorre se a  subordinada passar por pré-varredura por um  JSR. |
| Rung-condition-in é falsa N/A   |                                                                                                                                                                                                                                                                                                                                                                                             |
| Rung-condition-in é  verdadeira | Consulte o fluxograma de instrução FOR a  seguir (Verdadeiro)                                                                                                                                                                                                                                                                                                                               |
| Pós-varredura                   | A instrução fará a pós-varredura da subrotina  nomeada exatamente uma vez.                                                                                                                                                                                                                                                                                                                  |

## Fluxograma FOR (verdadeiro)

<!-- image -->

## Exemplos

Quando habilitada, a instrução FOR executa repetidamente routine\_2 e incrementa value\_2 em 1 cada vez. Quando value\_2 for &gt; 50000 ou uma instrução BRK estiver habilitada, a instrução FOR não executa mais routine\_2.

<!-- image -->

## Consulte também

Atributos comuns na página 879
