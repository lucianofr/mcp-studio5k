---
type: Instruction
title: "Destravamento de saída (OTU)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L2166-L2301"
---

## Destravamento de saída (OTU)

## Exemplo

## Diagrama ladder

<!-- image -->

Quando habilitada, a instrução OTL acende a luz.

## Consulte também

Sintaxe de texto estruturado na página 912

Instruções de bit na página 75

Endereçamento de bit na página 894

Índice por meio de matrizes na página 893

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução OTU elimina (destrava) o bit de dados.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                    |
|----------------|---------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                        |
|                |   Membros de um operando de estrutura estão  substituídos.                                             |
|                |   Exceto quanto especificado, os operandos da  estrutura são compartilhados por múltiplas  instruções. |

## Diagrama ladder

| Operando          | Tipo de  dados    | Formato Des crição    |                                                                                                                                                          |
|-------------------|-------------------|-----------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|
| Data bit BOOL tag |                   |                       | Bit a ser modificado.  Há diversos modos de  endereçamento do  operando possíveis  para o bit de dados,  consulte  Endereçamento de  bits para exemplos. |

## Descrição

Quando a condição do degrau for verdadeira, a instrução OTU elimina o bit de dados para falso. Quando a condição do degrau é alterada para falso, a instrução OTU não muda o status do bit de dados.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                            |
|------------------------------------|--------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                            |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como  Rung-condition-in                                         |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como  Rung-condition-in  O bit de dados é eliminado para falso. |
| Pós-varredura N/A                  |                                                                                            |

## Exemplo

## Diagrama ladder

<!-- image -->

Quando habilitado, a instrução OTU elimina Light\_02.

## Consulte também

Instruções de bit na página 75

Endereçamento de bit na página 894

Indexação por meio de matrizes na página 893

## Instruções do temporizador e do contador

## Instruções do temporizador e do contador

Os temporizadores e contadores controlam as operações com base no tempo e no número dos eventos.

Instruções disponíveis

Diagrama ladder

TON

TOF

RTO

CTU

## Bloco de funções e Texto estruturado

TONR

TOFR

RTOR

CTUD

| Se você deseja                                                                                                  | Use esta instrução    |
|-----------------------------------------------------------------------------------------------------------------|-----------------------|
| cronometrar por quanto tempo um  temporizador está habilitado                                                   | TON                   |
| cronometrar por quanto tempo um  temporizador está desabilitado                                                 | TOF                   |
| acumular tempo                                                                                                  | RTO                   |
| cronometrar por quanto tempo um  temporizador está habilitado com  restauração integrada ao bloco de  funções   | TONR                  |
| cronometrar por quanto tempo um  temporizador está desabilitado  com restauração integrada ao  bloco de funções | TOFR                  |
| acumular tempo com restauração  integrada no bloco de funções                                                   | RTOR                  |
| contagem crescente                                                                                              | CTU                   |
| Contagem decrescente                                                                                            | CTD                   |
| Contagem crescente e  decrescente no bloco de funções                                                           | CTUD                  |
| restaurar um temporizador ou  contador                                                                          | RES                   |

CTD

RES
