---
type: Instruction
title: "Um pulso na borda descendente (OSF)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L1640-L1719"
---

## Um pulso na borda descendente (OSF)

## Fluxograma ONS (Verdadeiro)

<!-- image -->

## Exemplo

## Diagrama ladder

<!-- image -->

Nesse exemplo, a soma incrementa todas as vezes que limit\_switch\_1 vai de falso para verdadeiro.

## Consulte também

Instruções de bit na página 75

Endereçamento de bit na página 894

Indexação por meio de matrizes na página 893

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução OSF define o bit de saída para uma varredura quando rung-condition-in realiza a transição de verdadeiro para falso.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

## Diagrama ladder

| Operando  Tipo de  dados    | Formato Des crição                                                                                                                                                                                                       |
|-----------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Storage Bit BOOL tag        | Armazena rung-condition-in  de quando a instrução foi  executada pela última vez.  Há vários modos de  endereçamento de operando  possíveis para o bit de  armazenamento, consulte  Endereçamento de bits para  exemplo. |
|                             | Output Bit BOOL tag Bit a ser modificado.                                                                                                                                                                                |

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A               | ção realizada                                                                                                                                                      |
|---------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                   | O bit de armazenamento é eliminado  para falso para evitar disparos  inválidos durante a primeira  varredura do programa.  O bit de saída é eliminado para  falso. |
| Rung-condition-in é falsa       | Definir Rung-condition-out como  Rung-condition-in.  Consulte o fluxograma OSF (Falso).                                                                            |
| Rung-condition-in é  verdadeira | Definir Rung-condition-out como  Rung-condition-in.  O bit de armazenamento é definido  como verdadeiro.  O bit de saída é eliminado para  falso.                  |
| Pós-varredura N/A               |                                                                                                                                                                    |

## Fluxograma OSF (Falso)

<!-- image -->
