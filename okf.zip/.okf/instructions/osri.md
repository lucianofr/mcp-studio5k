---
type: Instruction
title: "Um pulso na borda ascendente com entrada (OSRI)"
description: "Indexação por meio de matrizes na página 893"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L1919-L2015"
---

## Um pulso na borda ascendente com entrada (OSRI)

## Endereçamento de bit na página 894

Indexação por meio de matrizes na página 893

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução OSRI define o bit de saída para um ciclo de execução quando o bit de entrada alterna de restaurado para definido.

## Idiomas disponíveis

## Diagrama ladder

Esta instrução não está disponível no diagrama ladder.

## Bloco de funções

<!-- image -->

## Texto estruturado

OSRI(OSRI\_tag);

## Operandos

## Texto estruturado

| Operando Tipo    | Operando Tipo                  | Formato Descrição    |
|------------------|--------------------------------|----------------------|
|                  | OSRI tag FBD_ONESHOT Estrutura | Estrutura de  OSRI   |

## Bloco de funções

| Operando Tipo    | Operando Tipo                  | Formato Descrição    |
|------------------|--------------------------------|----------------------|
|                  | OSRI tag FBD_ONESHOT Estrutura | Estrutura de  OSRI   |

## Estrutura de FBD\_ONESHOT

| Parâmetro  de entrada    | Tipo de  dados    | Descrição                                                                                                                               |
|--------------------------|-------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                   | Se eliminado, a instrução não é  executada e as saídas não são  atualizadas. Se definido, a  instrução é executada.  Padrão é definido. |
| InputBit BOOL            |                   | Bit de entrada.  Padrão é eliminado.                                                                                                    |

| Parâmetro  de saída    | Tipo de  dados    | Descrição                             |
|------------------------|-------------------|---------------------------------------|
| EnableOut BOOL         |                   | Indica se instrução está  habilitada. |
|                        |                   | OutputBit BOOL Bit de saída           |

## Descrição

Se InputBit for verdadeiro e era falso da última vez, a instrução foi escaneada então OutputBit será definido, caso contrário, OutputBit será eliminado.

<!-- image -->

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                             |
|------------------------------------|-------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                                                    |
| Tag.Enable-in é falso              | Os bits EnableIn e EnableOut são  eliminados para falso.                                                    |
| Tag.Enable-in é  verdadeiro        | Os bits EnableIn e EnableOut são  definidos para verdadeiro.  A instrução é executada.                      |
| Primeira execução da  instrução    | N/A                                                                                                         |
| Primeira varredura da  instrução   | O histórico de InputBit anterior é  definido para exigir a transição de  Falso para Verdadeiro de InputBit. |
| Pós-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                                                    |

## Texto estruturado

| Condição/estado A ção realizada    |                                                                    |
|------------------------------------|--------------------------------------------------------------------|
| Pré-varredura                      | Consulte Pré-varredura na tabela de  Bloco de funções.             |
| Execução normal                    | Consulte Tag.EnableIn é verdadeiro  na tabela de Bloco de funções. |
| Pós-varredura                      | Consulte Pós-varredura na tabela de  Bloco de funções              |

## Exemplos

## Bloco de funções

<!-- image -->

Quando limit\_switch1 vai de restaurado para definido, a instrução OSRI define OutputBit para uma varredura.

## Texto estruturado

OSRI\_01.InputBit := limit\_switch1;
