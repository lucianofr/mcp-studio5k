---
type: Instruction
title: "Concatenar string (CONCAT)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L20856-L20971"
---

## Concatenar string (CONCAT)

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
IF bag_read.EM THEN MID(bag_barcode,9,9,bag_flt_and_dest); bag_read.EM := 0; END_IF;
```

## Consulte também

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Conversões de dados na página 883

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução CONCAT adiciona caracteres ASCII ao final de uma string.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

CONCAT(SourceA,SourceB,Dest);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Atributos comuns para obter mais informações sobre conversão de dados.

## Diagrama ladder e Texto estruturado

|                            | Operando Tipo Formato Descrição Notas    |                                                                                                                                                                                                                                  |
|----------------------------|------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Source A ANY_STRING tag    | Tag que  contém os  caracteres  iniciais | Tipos de strings são:   Tipo de dados de  STRING padrão  com no máximo  82 caracteres de  extensão para a  string.    Qualquer novo  tipo de string que  você criou com  extensão  configurável de  caracteres para a  string. |
| Source B ANY_STRING tag    | Tag que  contém os  caracteres  finais   | Tipos de strings são:   Tipo de dados de  STRING padrão  com no máximo  82 caracteres de  extensão para a  string.    Qualquer novo  tipo de string que  você criou com  extensão  configurável de  caracteres para a  string. |
| Destination ANY_STRING tag | Tag a  armazenar o  resultado            | Tipos de strings são:   Tipo de dados de  STRING padrão  com no máximo  82 caracteres de  extensão para a  string.    Qualquer novo  tipo de string que  você criou com  extensão  configurável de  caracteres para a  string. |

Consulte Atributos de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Descrição

A instrução CONCAT adiciona os caracteres em Source A a uma posição designada dentro de Source B e coloca o resultado no Destination.

Os caracteres de Source A vêm primeiro, seguidos pelos caracteres de Source B.

A menos que Source A e o Destination sejam a mesma tag, Source A permanece inalterado.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha menor ocorrerá  se:                                                                   | Tipo de  falha    | Código de  falha    |
|-------------------------------------------------------------------------------------------------|-------------------|---------------------|
| O valor de LEN da tag de  string é maior do que o  tamanho de DATA da tag  de string.           |                   | 4 51                |
| A soma da extensão de  Source A e Source B é  maior do que o tamanho de  DATA da tag de string. |                   | 4 51                |

Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição A                      | ção realizada            |
|---------------------------------|--------------------------|
| Pré-varredura N/A               |                          |
| Rung-condition-in é  falsa      | N/A                      |
| Rung-condition-in é  verdadeira | A instrução é executada. |
| Pós-varredura N/A               |                          |

## Texto estruturado

| Condição A      | ção realizada                                                           |
|-----------------|-------------------------------------------------------------------------|
| Pré-varredura   | Consulte Pré-varredura na  tabela de Diagrama ladder.                   |
| Execução normal | Consulte rung-condition-in é  verdadeira na tabela de  Diagrama ladder. |
| Pós-varredura   | Consulte Pós-varredura na  tabela de Diagrama ladder.                   |

## Fluxograma de string de concatenação

<!-- image -->

<!-- image -->

## Exemplo

## Diagrama ladder

<!-- image -->

## Texto estruturado

CONCAT(string\_1,string\_2,msg);

## Consulte também

Atributos comuns na página 879

Atributos de texto estruturado na página 940

Conversões de dados na página 883
