---
type: Instruction
title: "Descarga FIFO (FFU)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L13815-L13937"
---

## Descarga FIFO (FFU)

## Diagrama ladder

<!-- image -->

## Consulte também

Instruções de deslocamento/matriz (arquivo) na página 565

Descarga FIFO (FFU) na página 582

Carga LIFO (LFL) na página 589

Atributos comuns na página 879

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução FFU descarrega o valor da posição 0 (primeira posição) do FIFO e armazena o valor no Destination. Os dados restantes no FIFO deslocam uma posição para baixo.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução.

## Diagrama ladder

| Operando Tipo Formato Descrição                              |                        |                                                                                              |
|--------------------------------------------------------------|------------------------|----------------------------------------------------------------------------------------------|
| FIFO SINT  INT  DINT  REAL  Tipo de string  estrutura        | tag de  matriz         | FIFO a modificar  Especifica o primeiro elemento  do FIFO  Não use CONTROL.POS no  subscrito |
| Destination SINT  INT  DINT  REAL  Tipo de string  estrutura |                        | tag Valor descarregado do FIFO.                                                              |
| Control CONTROL tag                                          |                        | Estrutura de controle da  operação  geralmente usa o mesmo  CONTROL que o FFL  associado     |
|                                                              | Length DINT imediato   | Número máximo de elementos  que o FIFO pode conter por  vez                                  |
|                                                              | Position DINT imediato | Próximo local no FIFO em que  a instrução carrega dados  o valor inicial costuma ser 0       |

## Estrutura de CONTROL

| Mnemônico  Tipo de  dados    | Descrição                                                                                                                                                                      |
|------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| .EU BOOL                     | O bit de descarregamento habilitado  indica que a instrução FFU está  habilitada. O bit .EU é definido para  prevenir um descarregamento falso  quando a pré-varredura começa. |
| .DN BOOL                     | O bit executado é definido para indicar  que o FIFO está cheio (.POS = .LEN).                                                                                                  |
| .EM BOOL                     | O bit vazio indica que o FIFO está vazio.  Se .LEN for , ou = 0 ou .POS < 0, o bit  .EM e os bits .DN serão definidos.                                                         |
| .LEN DINT                    | O comprimento especifica o número  máximo de elementos no FIFO.                                                                                                                |
| .POS DINT                    | A posição identifica o fim dos dados que  foram carregados para o FIFO.                                                                                                        |

## Descrição

Use a instrução FFU com a instrução FFL para armazenar e recuperar dados em uma ordem de primeiro a entrar/primeiro a sair.

Quando habilitada, a instrução FFU descarrega os dados do primeiro elemento do FIFO e coloca esse valor no Destination. A instrução descarrega um valor cada vez que a instrução é habilitada até que o FIFO esteja vazio. Se o FIFO estiver vazio, o FFU retornará 0 ao Destination.

Geralmente, o Destination e o FIFO são do mesmo tipo de dado. Se os tipos diferirem, a instrução converterá o valor descarregado para o tipo de tag de destino.

Um inteiro menor é convertido em um inteiro maior por extensão de sinal.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha maior ocorrerá se:                           | Tipo de  falha    | Código de  falha    |
|--------------------------------------------------------|-------------------|---------------------|
| Length especificado for além do  fim da matriz de FIFO |                   | 4 20                |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                             |
|------------------------------------|---------------------------------------------|
| Pré-varredura                      | Consulte o fluxograma FFU  (Pré-varredura). |
| Rung-condition-in é falsa          | Consulte o fluxograma FFL  (Falso).         |
| Rung-condition-in é  verdadeira    | Consulte o fluxograma FFU  (Verdadeiro)     |
| Pós-varredura N/A                  |                                             |

## Fluxograma FFU (Pré-varredura)

<!-- image -->

Fluxograma FFL (Falso)

<!-- image -->

## Fluxograma FFU (Verdadeiro)

<!-- image -->

## Exemplos

## Exemplo 1

## Diagrama ladder

Exemplo 2

<!-- image -->

A matriz de Destino é a matriz de STRING ou a matriz de Estrutura

## Diagrama ladder

Exemplo 3

<!-- image -->

Incompatibilidade do tipo de dados da matriz de origem FIFO com o tipo de dados da matriz de destino.
