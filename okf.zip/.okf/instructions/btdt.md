---
type: Instruction
title: "Distribuição do campo de bit com destino (BTDT)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L10100-L10239"
---

## Distribuição do campo de bit com destino (BTDT)

## Quando habilitada, a instrução BTD move 10 bits de value\_1 para value\_2.

<!-- image -->

## Consulte também

Instruções de movimento na página 429

Limpar (CLR) na página 474

Atributos comuns na página 879

Conversões de dados na página 883

Movimentação mascarada (MVM) na página 476

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução BTDT primeiro copia Target para Destination. Então a instrução copia os bits especificados de Source, muda os bits para a posição adequada e grava os bits em Destination. Target e Source permanecem inalterados.

## Idiomas disponíveis

## Diagrama ladder

Essa instrução não está disponível em um diagrama ladder.

## Bloco de funções

<!-- image -->

## Texto estruturado

BTDT(BTDT\_tag);

## Operandos

## Bloco de funções

| Operando Tipo (Type) Format    |                           |           | Descrição  (Description)    |
|--------------------------------|---------------------------|-----------|-----------------------------|
| BTDT tag                       | FBD_BIT_FIELD_ DISTRIBUTE | estrutura | Estrutura de  BTDT          |

## Texto estruturado

| Parâmetro de  entrada    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                                 |
|--------------------------|-------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                               | Se eliminado, a instrução não é  executada e as saídas não são  atualizadas. Se definido, a  instrução é executada.  Padrão é definido. |
| Origem DINT              |                               | Valor de entrada contendo os bits  para mover para o Destination.  Válido = qualquer inteiro                                            |
| SourceBit DINT           |                               | A posição do bit em Source (menor  número de bit do qual começar a  mover).  Válido = 0-31                                              |
| Comprimento  (Length)    | DINT                          | Número de bits a mover.  Válido = 1-32                                                                                                  |
| DestBit DINT             |                               | A posição do bit em Dest (menor  número de bit para o qual começar  a copiar bits).  Válido = 0-31                                      |
| Target DINT              |                               | Valor de entrada a mover para Dest  antes de mover bits da Source.  Válido = qualquer inteiro                                           |

| Parâmetro de saída Tipo de dados  (Data Type)    | Descrição (Description)                     |
|--------------------------------------------------|---------------------------------------------|
| EnableOut BOOL                                   | Indica se instrução está habilitada.        |
| Dest DINT                                        | Resultado da operação de  movimento do bit. |

Consulte Sintaxe de texto estruturado para obter informações sobre a sintaxe de expressões no texto estruturado.

## Descrição (Description)

Quando verdadeira, a instrução BTDT primeiro copia Target para Destination e copia um grupo de bits de Source para Destination. O grupo de bits é identificado pelo Source bit (o menor número de bit do grupo) e pelo Length (número de bits a copiar). O Destination bit identifica o bit de menor número de bit com o qual iniciar em Destination. Source e Target permanecem inalterados.

Se o comprimento do campo de bit estender-se além de Destination, a instrução não salvará os bits extras. Nenhum bit extra será quebrado para a próxima palavra.

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                       | Sinalizador de status de  operações matemáticas afetado    |
|---------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix 5580,  Compact GuardLogix 5380 e GuardLogix  5580 | Sim                                                        |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact GuardLogix  5370 e GuardLogix 5570                     | Não                                                        |

Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando

Execução

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                        |
|------------------------------------|----------------------------------------------------------------------------------------|
|                                    | Pré-varredura Os bits EnableIn e EnableOut são eliminados para falso.                  |
|                                    | Tag.EnableIn é falso Os bits EnableIn e EnableOut são eliminados para falso.           |
| Tag.EnableIn é  verdadeiro         | Os bits EnableIn e EnableOut são definidos para  verdadeiro.  A instrução é executada. |
| Primeira  execução da  instrução   | N/D                                                                                    |
| Primeira  varredura da  instrução  | N/D                                                                                    |
|                                    | Pós-varredura Os bits EnableIn e EnableOut são eliminados para falso.                  |

## Texto estruturado

| Condição/estado A ção realizada                                                     |
|-------------------------------------------------------------------------------------|
| Pré-varredura Consulte Pré-varredura na tabela de Bloco de funções.                 |
| Execução normal  Consulte Tag.EnableIn é verdadeiro na tabela de Bloco  de funções. |
| Pós-varredura Consulte Pós-varredura na tabela de Bloco de funções.                 |

## Exemplo

Etapa 1

O controlador copia Target para Dest.

<!-- image -->

## Etapa 2

O SourceBit e o Length especificam quais bits em Source copiar para o Dest. Iniciando em DestBit, Source e Target permanecem inalterados.

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

BTDT\_01.Source := sourceSTX;

BTDT\_01.SourceBit := source\_bitSTX;

BTDT\_01.Length := LengthSTX;

BTDT\_01.DestBit := dest\_bitSTX;

BTDT\_01.Target := TargetSTX;

BTDT(BTDT\_01);

distributed\_value := BTDT\_01.Dest;

## Consulte também

Atributos comuns na página 879
