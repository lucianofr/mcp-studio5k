---
type: Instruction
title: "Carga FIFO (FFL)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L13684-L13814"
---

## Carga FIFO (FFL)

## Diagrama ladder

<!-- image -->

<!-- image -->

## Consulte também

Indexação por meio de matrizes na página 893

Conversões de dados na página 883

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução FFL copia o valor de Source para o FIFO.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

A conversão ocorre somente se o tipo do operando de origem não corresponder ao tipo do FIFO.

## Diagrama ladder

|                                                         |                        | Operando Tipo (Type) Format Descrição (Description)                                                        |
|---------------------------------------------------------|------------------------|------------------------------------------------------------------------------------------------------------|
| Origem SINT  INT  DINT  REAL  Tipo de string  estrutura | immediate  tag         | Dados a serem armazenados no  FIFO                                                                         |
| FIFO SINT  INT  DINT  REAL  Tipo de string  estrutura   | tag de  matriz         | FIFO a modificar  Especifica o primeiro elemento do  FIFO                                                  |
|                                                         |                        | Controle CONTROL tag Estrutura de controle da operação Geralmente usa o mesmo  CONTROL que o FFU associado |
| Compriment o (Length)                                   | DINT immediate         | Número máximo de elementos  que o FIFO pode conter por vez                                                 |
|                                                         | Somente DINT immediate | Próximo local no FIFO em que a  instrução carrega dados  o valor inicial costuma ser 0                     |

## Estrutura de CONTROL

| Mnemônico  Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                  |
|------------------------------------------|--------------------------------------------------------------------------------------------------------------------------|
| .EN BOOL                                 | O bite de habilitação indica que a instrução  FFL está habilitada.                                                       |
| .DN BOOL                                 | O bit executado é definido para indicar que o  FIFO está cheio. O bit .DN inibe o  carregamento do FIFO até .POS < .LEN. |
| .EM BOOL                                 | O bit vazio indica que o FIFO está vazio. Se  .LEN for < ou = 0 ou .POS < 0, o bit .EM e os  bits .DN serão definidos.   |
| .LEN DINT                                | A palavra de comprimento especifica o  número máximo de elementos no FIFO.                                               |
| .POS DINT                                | A palavra de posição identifica o local no FIFO  em que a instrução carrega o valor seguinte.                            |

## Descrição

Use a instrução FFL com a instrução FFU para armazenar e recuperar dados em uma ordem de primeiro a entrar/primeiro a sair. Quando usadas em pares, as instruções FFL e FFU estabelecem um registro de deslocamento assíncrono.

Geralmente, a Source e o FIFO são do mesmo tipo de dados.

Quando habilitada, a instrução FFL carrega o valor de Source na posição no FIFO identificado pelo valor de .POS. A instrução carrega um valor cada vez que a instrução é habilitada até que o FIFO esteja cheio.

Importante: Você deve testar e confirmar que a instrução não altera os dados que você não deseja alterar.

A instrução FFL opera em memória contígua. A instrução BSL opera em memória contígua de dados. Somente para Controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370 e GuardLogix 5570, o escopo da instrução é restringido à tag base. A instrução BSL não gravará dados fora da tag base, mas pode cruzar fronteiras de membro. Se você especificar uma matriz que faça parte de uma estrutura, o comprimento excederá o tamanho dessa matriz; é preciso testar e confirmar que a instrução BSL não altere os dados que você não deseja alterar.

Para Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580, os dados são restringidos pelo membro especificado.

Se a instrução tentar ler além do fim de uma matriz, a instrução gerará uma falha maior.

Geralmente, a Source e o FIFO são do mesmo tipo de dados. Se houver incompatibilidade do tipos de dados de Source e FIFO, a instrução converterá o valor de Source no tipo de dados da tag FIFO.

Um inteiro menor é convertido em um inteiro maior por extensão de sinal.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha maior  ocorrerá se:                                   | Tipo de  falha    | Código  de falha    |
|-----------------------------------------------------------------|-------------------|---------------------|
| O (elemento inicial +  .POS) for além do fim da  matriz de FIFO |                   | 4 20                |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                             |
|------------------------------------|---------------------------------------------|
| Pré-varredura                      | Consulte o fluxograma  FFL (Pré-varredura). |
| Rung-condition-in é  falsa         | Consulte o fluxograma  FFL (Falso)          |
| Rung-condition-in é  verdadeira    | Consulte o fluxograma  FFL (Verdadeiro)     |
| Pós-varredura N/D                  |                                             |

## Fluxograma FFL (Pré-varredura)

<!-- image -->

## Fluxograma FFL (Falso)

<!-- image -->

## Fluxograma FFL (verdadeiro)

<!-- image -->

## Exemplos

## Exemplo 1

## Diagrama ladder

Exemplo 2

<!-- image -->

A matriz de origem é a matriz de STRING ou a matriz de estrutura.

## Diagrama ladder

Exemplo 3

<!-- image -->

Incompatibilidade do tipo de dados de origem com o tipo de dados da matriz de FIFO.
