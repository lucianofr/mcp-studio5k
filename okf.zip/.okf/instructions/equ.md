---
type: Instruction
title: "Igual a (EQU)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L6683-L6865"
---

## Igual a (EQU)

## Exemplo

## Diagrama ladder

<!-- image -->

Se value\_1 for igual ao value\_2, light\_a será definida como verdadeiro. Se value\_1 não for igual ao value\_2, light\_a será definida como falso.

## Consulte também

Instruções de comparação na página 293

Operadores válidos na página 366

Indexação por meio de matrizes na página 893

Sinalizadores de status de operações matemáticas na página 879

Conversões de dados na página 883

Essa instrução se aplica aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

Quando habilitada, a instrução EQU e o operador = testam se a Source A é igual à Source B.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

<!-- image -->

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

Dica:

Use o operador '=' com uma expressão para obter o mesmo resultado. Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões e atribuições no texto estruturado.

## Operandos

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

## Comparação numérica

| Operando  Tipo de dados  (Data Type)  Controladores  CompactLogix  5370,  ControlLogix  5570, Compact  GuardLogix  5370 e  GuardLogix  5570    | Tipo de dados  (Data Type)  Controladores  CompactLogix  5380,  CompactLogix  5480,  ControlLogix  5580, Compact  GuardLogix 5380  e GuardLogix  5580    | Format         | Descrição  (Description)            |
|------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|-------------------------------------|
| Source A SINT  INT  DINT  REAL                                                                                                                 | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                            | immediate  tag | Valor para  testar contra  Source B |
| Source B SINT  INT  DINT  REAL                                                                                                                 | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                            | immediate  tag | Valor para  testar contra  Source A |

## Comparação de strings

Dica: Literais de string imediatos apenas são aplicáveis à Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operando  Tipo de dados  (Data Type)    | Format                       | Descrição  (Description)             |
|-----------------------------------------|------------------------------|--------------------------------------|
| Source A Tipo de string                 | valor literal  imediato  tag | String para  testar contra  Source B |
| Source B Tipo de string                 | valor literal  imediato  tag | String para  testar contra  Source A |

## Diagrama de bloco da função

Bloco FBD

| Operando    | Tipo de dados  (Data Type)        | Format    | Descrição  (Description)    |
|-------------|-----------------------------------|-----------|-----------------------------|
|             | EQU FBD_COMPARE tag Estrutura EQU |           |                             |

## Estrutura de FBD\_COMPARE

| Membros de  entradas    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                |
|-------------------------|-------------------------------|------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL           |                               | Entrada Habilitar. Se falso, a  instrução não será executada e as  saídas não serão atualizadas.  Padrão é verdadeiro. |
| SourceA REAL            |                               | Valor para testar contra SourceB                                                                                       |
| SourceB REAL            |                               | Valor para testar contra SourceA                                                                                       |

| Membros de  saída    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                  |
|----------------------|-------------------------------|--------------------------------------------------------------------------------------------------------------------------|
| EnableOut BOOL       |                               | Indica se a instrução está habilitada.                                                                                   |
|                      | Dest BOOL                     | Definido como verdadeiro quando  SourceA é igual a SourceB.  Eliminado para falso quando SourceA  não é igual a SourceB. |

## Função FBD

Dica: A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operandos de  entrada (pinos  esquerdos)    | Tipo de dados  (Data Type)                              | Descrição (Description)            |
|---------------------------------------------|---------------------------------------------------------|------------------------------------|
| SourceA (topo) SINT                         | INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL | Valor para testar contra  SourceB. |

| SourceB (fundo) SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL    | Valor para testar contra  SourceA    |
|----------------------------------------------------------------------------------|--------------------------------------|

| Operando de saída  (Pino direito)    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                   |
|--------------------------------------|-------------------------------|---------------------------------------------------------------------------------------------------------------------------|
|                                      | Dest BOOL                     | Definido como verdadeiro  quando SourceA é igual a  SourceB. Eliminado para falso  quando SourceA não é igual a  SourceB. |

Consulte Funções FBD .

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Consulte Fluxograma de Comparação de Strings EQU para conhecer as falhas.

Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                                                                  |
|------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                                                  |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como  Rung-condition-in                                                                                                                                               |
| Rung-condition-in é  verdadeira    | Comparação numérica: Se Source A e Source B não forem NANs e  Source A for igual a Source B.  Defina Rung-condition-out como verdadeira  Caso contrário  Eliminar Rung-condition-out para falso. |

| Comparação de strings:  Consulte Fluxograma de comparação de strings  EQU.  Se a saída for falsa  Eliminar Rung-condition-out para falso  Caso contrário  Defina Rung-condition-out como verdadeira    |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pós-varredura N/D                                                                                                                                                                                      |

## Diagrama de bloco da função

Bloco FBD

| Condição/estado A ção realizada    |                                                                                                                                                                                                                       |
|------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                                                                       |
|                                    | EnableIn é falso Defina EnableOut como EnableIn                                                                                                                                                                       |
|                                    | EnableIn é verdadeiro Comparação numérica: Defina EnableOut como EnableIn  Se SourceA e SourceB não forem NANs e  SourceA for igual a SourceB.  Defina Dest como verdadeiro  Caso contrário  Elimina Dest como falso. |
| Primeira execução da  instrução    | N/D                                                                                                                                                                                                                   |
| Primeira varredura da  instrução   | N/D                                                                                                                                                                                                                   |
| Pós-varredura N/D                  |                                                                                                                                                                                                                       |

## Função FBD

Dica:

A função FBD é aplicável a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A ção realizada    |                                                                                                                                                                 |
|------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                 |
| Varredura normal                   | Comparação numérica: Se SourceA e SourceB não forem NANs e  SourceA for igual a SourceB.  Defina Dest como verdadeiro  Caso contrário  Elimina Dest como falso. |
| Primeira execução da  instrução    | N/D                                                                                                                                                             |
| Primeira varredura da  instrução   | N/D                                                                                                                                                             |
| Pós-varredura N/D                  |                                                                                                                                                                 |

Fluxograma de comparação de strings EQU

<!-- image -->

## Exemplos

## Diagrama ladder

Diagrama de bloco da função

<!-- image -->

## Bloco FBD

<!-- image -->
