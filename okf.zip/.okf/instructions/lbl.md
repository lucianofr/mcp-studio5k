---
type: Instruction
title: "Saltar para o rótulo (JMP) e Rótulo (LBL)"
description: "A JXR pode estar síncrona ou assíncrona dependendo da implementação da DLL."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L14941-L15046"
---

## Saltar para o rótulo (JMP) e Rótulo (LBL)

## Falhas maiores/menores

| Uma falha maior ocorrerá se                                                                                             | Tipo de  falha    | Código de  falha:    |
|-------------------------------------------------------------------------------------------------------------------------|-------------------|----------------------|
| Uma exceção ocorre na rotina externa DLL.  A DLL não pôde ser carregada.  O ponto de entrada não foi encontrado na DLL. |                   | 4 88                 |

## Execução

A JXR pode estar síncrona ou assíncrona dependendo da implementação da DLL. O código na DLL também determina como responder ao status de varredura, status de rung-condition-in e status de rung-condition-out.

Para mais informações sobre o uso da instrução JXR e criação de rotinas externas, consulte o Manual do usuário SoftLogix5800 System, publicação 1789-UM002.

## Consulte também

## Atributos comuns na página 879

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

As instruções JMP e LBL pulam porções de lógica ladder.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Diagrama ladder

| Operando Tipo Formato Descrição    |                 |                                                     |
|------------------------------------|-----------------|-----------------------------------------------------|
| Instrução JMP                      | Instrução JMP   | Instrução JMP                                       |
| Label name                         | nome do  rótulo | Digite o nome para a instrução  LBL associada       |
| Instrução LBL                      | Instrução LBL   | Instrução LBL                                       |
| Label name                         | nome do  rótulo | A execução salta para a  instrução LBL referenciada |

## Descrição

Quando verdadeira, a instrução JMP ignora a instrução LBL referenciada e o controlador continua a execução a partir daí. Quando falsa, a instrução JMP não afeta a execução ladder.

As referências de JMP e LBL devem estar na mesma rotina.

A instrução JMP pode avançar ou regressar a execução ladder. Avançar para um rótulo poupa tempo de varredura do programa ao omitir um segmento lógico até que seja necessário. Regressar permite que o controlador repita iterações de lógica.

Importante:

Tenha cuidado para não regressar um número excessivo de vezes. O temporizador Watchdog poderia se esgotar porque a varredura não é concluída a tempo.

<!-- image -->

Lógica saltada não sofre varredura. Coloque lógica crítica fora da zona saltada.

Uma instrução JMP exige que o rótulo associado exista antes de você:

-  Baixar ao trabalhar offline
-  Aceitar edições ao trabalhar online

A instrução LBL deve ser a primeira instrução no degrau.

Um nome do rótulo deve ser exclusivo dentro de uma rotina. O nome pode:

-  Ter até 40 caracteres
-  Ter letras, números e sublinhados (\_)

## Afeta sinalizadores de status de operações matemáticas

N°

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição A                      | ção                                                                                                                                     |
|---------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A               |                                                                                                                                         |
| Rung-condition-in é falsa N/A   |                                                                                                                                         |
| Rung-condition-in é  verdadeira | (Para JMP) Execução salta para o degrau que  contém a instrução LBL com o nome do rótulo  referenciado.  (Para LBL) nenhuma ação tomada |
| Pós-varredura N/A               |                                                                                                                                         |

## Exemplo

## Diagrama ladder

## JMP

Quando a instrução JMP estiver habilitada, a execução pula degraus sucessivos de lógica até alcançar o degrau que contém a instrução LBL com label\_20.

<!-- image -->
