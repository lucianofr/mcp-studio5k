---
type: Instruction
title: "Dividir (DIV)"
description: "Quando habilitada, a instrução DIV e o operador '/' dividem Source A por Source B."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L8776-L8936"
---

## Dividir (DIV)

## Conversões de dados na página 883

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

Quando habilitada, a instrução DIV e o operador '/' dividem Source A por Source B.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

<!-- image -->

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Dica:

Use o operador '/' em uma expressão para obter o mesmo resultado. Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões e atribuições no texto estruturado.

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                    |
|----------------|---------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                        |
|                |   Membros de um operando de estrutura estão  substituídos.                                             |
|                |   Exceto quanto especificado, os operandos da  estrutura são compartilhados por múltiplas  instruções. |

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

| Operando     | Tipo de dados (Data  Type)  Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix  5570    | Tipo de dados (Data  Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580    | Format         | Descrição  (Description)    |
|--------------|-----------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|-----------------------------|
| SourceA SINT | INT  DINT  REAL                                                                                                                   | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                        | immediate  tag | Valor do  dividendo         |

| SourceB SINT  INT  DINT  REAL    | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL    | immediate  tag    | Valor do  divisor                               |
|----------------------------------|------------------------------------------------------------------|-------------------|-------------------------------------------------|
| Dest SINT  INT  DINT  REAL       | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL    | tag               | Tag para  armazenar o  resultado da  instrução. |

## Diagrama de bloco da função

## Bloco FBD

| Operando    | Tipo de dados  (Data Type)    | Format    | Descrição  (Description)          |
|-------------|-------------------------------|-----------|-----------------------------------|
|             |                               |           | DIV FBD_MATH tag Estrutura de DIV |

## Estrutura de FBD\_MATH

| Membros de  entradas    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                 |
|-------------------------|-------------------------------|-------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL           |                               | Entrada Habilitar. Se falso, a  instrução não será executada e  as saídas não serão  atualizadas.  Padrão é verdadeiro. |
|                         |                               | Source A REAL Valor do dividendo.                                                                                       |
|                         |                               | Source B REAL Valor do divisor.                                                                                         |

| Membros de  saída    | Tipo de dados  (Data Type)    | Descrição (Description)                                             |
|----------------------|-------------------------------|---------------------------------------------------------------------|
| EnableOut BOOL       |                               | Indica se a instrução foi  executada sem falhas ao ser  habilitada. |
|                      |                               | Dest REAL Resultado da instrução.                                   |

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operandos de  entrada (pinos  esquerdos)    | Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix 5580,  Compact GuardLogix 5380 e GuardLogix  5580  Tipo de dados (Data Type)    | Descrição  (Description)    |
|---------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
| SourceA (topo) SINT                         | USINT  INT  UINT  DINT  UDINT  LINT  ULINT  REAL                                                                                                  | Valor do dividendo.         |
| SourceB (fundo) SINT                        | USINT  INT  UINT  DINT  UDINT  LINT  ULINT  REAL  LREAL                                                                                           | Valor do divisor            |

| Operandos de  saída (pino  direito)    | Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix 5580,  Compact GuardLogix 5380 e GuardLogix  5580  Tipo de dados (Data Type)    | Descrição  (Description)    |
|----------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
|                                        | Dest DINT  UDINT  LINT  ULINT  REAL  LREAL                                                                                                        | Resultado da  função        |

Consulte Funções FBD .

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                       | Afeta sinalizadores de status  de operações matemáticas    |
|---------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580 | Condicional                                                |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact  GuardLogix 5370 e GuardLogix 5570                     | Sim                                                        |

Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

| Uma falha menor ocorrerá se: Tipo de falha Código de falha    |    |    |
|---------------------------------------------------------------|----|----|
| Source_B = 0                                                  |  4 |  4 |

Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A              | ção realizada                                                                      |
|--------------------------------|------------------------------------------------------------------------------------|
| Pré-varredura N/D              |                                                                                    |
| Rung-condition-in é falsa      | Definir Rung-condition-out como  Rung-condition-in                                 |
| Rung-condition-in é verdadeira | Definir Rung-condition-out como  Rung-condition-in  Dest = Source A / Source B 1,2 |
| Pós-varredura N/D              |                                                                                    |

## Diagrama de bloco da função

| Condição/estado A                   | ção realizada                                                                                                                                 |
|-------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                   |                                                                                                                                               |
| EnableIn é falso                    | Defina EnableOut como EnableIn                                                                                                                |
| EnableIn é verdadeiro               | Dest = SourceA / SourceB 1,2 Se um transbordamento ocorrer  Elimina EnableOut para falso  Caso contrário  Configure EnableOut para verdadeiro |
| Primeira execução da instrução N/D  |                                                                                                                                               |
| Primeira varredura da instrução N/D |                                                                                                                                               |
| Pós-varredura N/D                   |                                                                                                                                               |

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A ção realizada    |                                               |
|------------------------------------|-----------------------------------------------|
| Pré-varredura N/D                  |                                               |
|                                    | Varredura normal Dest = SourceA / SourceB 1,2 |
| Primeira execução da  instrução    | N/D                                           |
| Primeira varredura da  instrução   | N/D                                           |
| Pós-varredura N/D                  |                                               |

## Exemplos

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

## Bloco FBD

<!-- image -->
