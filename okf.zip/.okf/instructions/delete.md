---
type: Instruction
title: "Excluir string (DELETE)"
description: "A instrução DELETE remove caracteres ASCII de uma string."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L20972-L21098"
---

## Excluir string (DELETE)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução DELETE remove caracteres ASCII de uma string.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

DELETE(Source,Qty,Start,Dest);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados.

## Diagrama ladder e Texto estruturado

| Operando Tipo (Type) Format    | Descrição  (Description)                                                 | Notas                                                                                                                                                                                                                  |
|--------------------------------|--------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Origem ANY_STRING tag          | A tag que  contém a  string na qual  você deseja  excluir os  caracteres | Tipos de strings são:  tipo de dados de STRING  padrão com no máximo 82  caracteres de extensão  para a string.  qualquer novo tipo de  string que você criou com  extensão configurável de  caracteres para a string. |

| Quantity    | SINT  INT  DINT                | imediato tag    | O número de  caracteres a  excluir                | O Start mais o Quantity  devem ser menores ou  iguais à extensão de  Source mais 1.    |
|-------------|--------------------------------|-----------------|---------------------------------------------------|----------------------------------------------------------------------------------------|
| Start       | SINT  INT  DINT                | imediato tag    | A posição do  primeiro  caractere a ser  excluído | Digite um número entre 1 e  o tamanho de DATA da  Source.                              |
|             | Destination Tipo de string tag |                 | A tag a  armazenar o  resultado                   |                                                                                        |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Descrição (Description)

A instrução DELETE exclui (remove) um ou mais caracteres de Source e coloca os caracteres restantes no Destination.

-  A posição de Start e Quantity definem os caracteres a serem removidos.
-  A menos que Source A e o Destination sejam a mesma tag, Source A permanece inalterado.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha menor ocorrerá  se:                                                                             | Tipo de falha Código de falha    |
|-----------------------------------------------------------------------------------------------------------|----------------------------------|
| O valor de LEN da tag de  string de Source é maior do  que o tamanho de DATA da  tag de string de Source. | 4 51                             |
| A extensão de string de saída  é maior do que o tamanho de  DATA da tag de string.                        | 4 52                             |
| O valor de Start ou Quantity  não é válido.                                                               | 4 56                             |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A               | ção (Action)             |
|---------------------------------|--------------------------|
| Pré-varredura N/D               |                          |
| Rung-condition-in é falsa N/D   |                          |
| Rung-condition-in é  verdadeira | A instrução é executada. |
| Pós-varredura N/D               |                          |

## Texto estruturado

| Condição/estado A    | ção (Action)                                                            |
|----------------------|-------------------------------------------------------------------------|
| Pré-varredura        | Consulte Pré-varredura na tabela de  Diagrama ladder.                   |
| Execução normal      | Consulte rung-condition-in é  verdadeira na tabela de Diagrama  ladder. |
| Pós-varredura        | Consulte Pós-varredura na tabela de  Diagrama ladder.                   |

## Exemplos

As informações ASCII de um terminal contêm um caractere de cabeçalho. Após o controlador ler os dados (term\_read.EM is on), a instrução DELETE remove o caractere de cabeçalho. O controlador pode, então, usar o texto da mensagem ou passá-lo para outro dispositivo.

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
IF term_read.EM THEN DELETE(term_input,1,1,term_text); term_read.EM := 0;
```

## END\_IF;

## Consulte também

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Conversões de dados na página 883

## Instruções de conversão ASCII

## Instruções de conversão ASCII

Use as instruções de conversão ASCII para converter dados de strings ou para strings de caracteres ASCII.

## Instruções disponíveis

## Diagrama ladder e Texto estruturado

| STOD    | STOR    | RTO S   | DTOS    | LOWER    | UPPE R   |
|---------|---------|---------|---------|----------|----------|

## Bloco de funções

Indisponível

| Se você desejar converter:                                                                                                                                                                                      | Use esta instrução:    |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------|
| Representações ASCII de valores inteiros em  valores de SINT, INT, DINT ou REAL (por  exemplo, convertendo de uma balança ou outro  dispositivo ASCII em um inteiro para que você  possa usá-lo na sua lógica). | STOD                   |
| Representações ASCII de valores inteiros em um  valor de REAL (por exemplo, convertendo de  uma balança ou outro dispositivo ASCII em um  valor de REAL para que você possa usá-lo na  sua lógica).             | STOR                   |
| valores de SINT, INT, DINT ou REAL de uma  string de caracteres ASCII (por exemplo,  convertendo uma variável em uma string ASCII  para que você possa enviá-la a um terminal  MessageView™).                   | DTOS                   |
| valores de REAL de uma string de caracteres  ASCII (por exemplo, convertendo uma variável  em uma string ASCII para que você possa  enviá-la a um terminal MessageView).                                        | RTOS                   |
| as letras de uma string de caracteres ASCII em  maiúsculas (por exemplo, convertendo uma  entrada feita por um operado em maiúscula para  que você possa pesquisá-la em uma matriz).                            | UPPER                  |
| as letras de uma string de caracteres ASCII em  minúsculas (por exemplo, convertendo uma  entrada feita por um operado em minúscula para  que você possa pesquisá-la em uma matriz).                            | LOWER                  |
