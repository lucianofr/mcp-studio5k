---
type: Instruction
title: "Movimentação mascarada com destino (MVMT)"
description: "Linha 3: mask\_2"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L11569-L11708"
---

## Movimentação mascarada com destino (MVMT)

Linha 3: mask\_2

Linha 4: value\_b após MVM

<!-- image -->

Copie dados de value\_a para value\_b, enquanto permite que dados sejam mascarados (um 0 mascara os dados em value\_a).

## Consulte também

Instruções de movimento na página 429

Conversões de dados na página 883

Indexação por meio de matrizes na página 893

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução MVMT copia a Source para um Destination e permite que partes dos dados sejam mascaradas.

## Idiomas disponíveis

## Diagrama ladder

Esta instrução não está disponível no Diagrama ladder.

## Bloco de funções

<!-- image -->

## Texto estruturado

MVMT(MVMT\_tag);

## Operandos

## Texto estruturado

| Variável Tipo (Type)               | Format    | Descrição  (Description)    |
|------------------------------------|-----------|-----------------------------|
| MVMT tag FBD_MASKED_MOVE Structure |           | Estrutura de  MVMT          |

Consulte Sintaxe de texto estruturado para obter informações sobre a sintaxe de expressões no texto estruturado.

## Bloco de funções

| Operando Tipo (Type)               | Format    | Descrição  (Description)    |
|------------------------------------|-----------|-----------------------------|
| MVMT tag FBD_MASKED_MOVE Structure |           | Estrutura de  MVMT          |

## Estrutura de FBD\_MASKED\_MOVE

| Parâmetro  de entrada    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                                 |
|--------------------------|-------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                               | Se eliminado, a instrução não é  executada e as saídas não são  atualizadas. Se definido, a instrução é  executada.  Padrão é definido. |
| Origem DINT              |                               | Valor de entrada a mover para  Destination com base no valor de Mask. Válido = qualquer inteiro                                         |

| Máscara DINT    | Mask de bits para mover de Source a  Dest. Todos os bits definidos como um  fazem os bits correspondentes  moverem-se de Source a Dest. Todos  os bits que são definidos como zero  fazem os bits correspondentes não se  moverem de Source a Dest.  Válido = qualquer inteiro    |
|-----------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Target DINT     | Valor de entrada a mover para Dest  antes de mover Source bits por Mask.  Válido = qualquer inteiro                                                                                                                                                                               |

| Parâmetro  de saída    | Tipo de dados  (Data Type)    | Descrição (Description)                             |
|------------------------|-------------------------------|-----------------------------------------------------|
|                        |                               | EnableOut BOOL Indica se instrução está habilitada. |
|                        | Dest DINT                     | Resultado da operação de movimento  mascarada.      |

## Descrição (Description)

Quando habilitada, a instrução MVMT usa uma Mask para passar ou bloquear bits de dados de Source. Um "1" na máscara significa que o bit de dados passa. Um "0" na máscara significa que o bit de dados será bloqueado.

Se você misturar tipos de dados de inteiro, a instrução preencherá os bits superiores dos tipos de dados menores de inteiro com 0s de modo que tenham o mesmo tamanho que o tipo de dados maior.

## Inserindo um valor de máscara imediato usando uma Referência de entrada

Quando você insere uma máscara, o software de programação usa valores decimais como padrão. Se você quiser inserir uma máscara usando outro formato, preceda o valor com o prefixo correto.

| Prefixo Des crição (Description)       |
|----------------------------------------|
| 16# hexadecimal (por exemplo, 16#0F0F) |
| 8# Octal (por exemplo, 8#16)           |
| 2# Binário (por exemplo, 2#00110011)   |

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                       | Afeta sinalizadores de status de  operações matemáticas    |
|---------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580 | Não                                                        |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact  GuardLogix 5370 e GuardLogix 5570                     | Sim para a saída                                           |

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando

## Execução

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                        |
|------------------------------------|----------------------------------------------------------------------------------------|
| Pré-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                               |
| Tag.EnableIn é falso               | Os bits EnableIn e EnableOut são  eliminados para falso.                               |
| Tag.EnableIn é  verdadeiro         | Os bits EnableIn e EnableOut são  definidos para verdadeiro.  A instrução é executada. |
| Primeira execução da  instrução    | N/D                                                                                    |
| Primeira varredura da  instrução   | N/D                                                                                    |
| Pós-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                               |

## Texto estruturado

| Condição/estado A ção realizada    |                                                                    |
|------------------------------------|--------------------------------------------------------------------|
| Pré-varredura                      | Consulte Pré-varredura na tabela de  Bloco de funções.             |
| Execução normal                    | Consulte Tag.EnableIn é verdadeiro  na tabela de Bloco de funções. |
| Pós-varredura                      | Consulte Pós-varredura na tabela  de Bloco de funções.             |

## Exemplos

## Etapa 1

O controlador copia Target para Dest.

Etapa 2

<!-- image -->

A instrução mascara Source e a compara a Dest. Qualquer alteração necessária é feita em Dest, que se torna um parâmetro de entrada para value\_masked. Source e Target permanecem inalterados. Um 0 na máscara impede que a instrução compare o bit.

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

```
MVMT_01.Source := value_1; MVMT_01.Mask := mask_1; MVMT_01.Target := target; MVMT(MVMT_01);
```
