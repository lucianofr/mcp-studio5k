---
type: Instruction
title: "Linhas de leitura ASCII (ARL)"
description: "```"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L19834-L20006"
---

## Linhas de leitura ASCII (ARL)

```
bar_code_read.LEN := 24; ARD(0,bag_bar_code,bar_code_read); END_IF;
```

## Consulte também

Instruções de porta serial ASCII na página 783

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate.

A instrução ARL remove os caracteres do buffer e os armazena no Destination.

Dica:

Instruções de Porta serial ASCII (AWT, AWA, ARD, ARL, ABL, ACB, AHL, ACL) não estão disponíveis para controladores que não têm portas seriais.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

ARL(Channel,Destination,SerialPortControl);

## Operandos

## Diagrama ladder

| Operando Tipo                |                                             |                 | Formato Descrição Notas                                                                                                                                                                    |                                                                                                                                                                                                                                                                                                                                                                                                                                          |
|------------------------------|---------------------------------------------|-----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Channel DINT                 |                                             | imediato  tag   | 0                                                                                                                                                                                          |                                                                                                                                                                                                                                                                                                                                                                                                                                          |
|                              | Destination Tipo de string  SINT  INT  DINT | tag             | tag para qual  os caracteres  são movidos  (isto é, lidos)  Para um tipo de  string, digite o  nome da tag.  Para uma  matriz SINT,  INT ou DINT,  digita o primeiro  elemento da  matriz. | Se você desejar comparar,  converter ou manipular os  caracteres, digite uma tag  de tipo de string.  Tipos de strings são:  tipo de dado de STRING  padrão  qualquer tipo de string novo  que você cria                                                                                                                                                                                                                                 |
| SerialPort  Control          | SERIAL_PORT _CONTROL                        | tag             | tag que  controla a  operação                                                                                                                                                              |                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Serial Port  Control  Length |                                             | DINT imediato   | Número  máximo de  caracteres a  serem lidos, se  nenhum  caractere de  terminação for  encontrado.                                                                                        | Digite o número máximo de  caracteres que toda  mensagem conterá (isto é,  quando interromper a  leitura, se nenhum caractere  de terminação for  encontrado).  Por exemplo, se as  mensagens variam de 3 a 6  caracteres em extensão,  digite 6.  O Serial Port Control Length  deve ser menor ou igual ou  tamanho do Destination.  Se você desejar definir o  Serial Port Control Length  igual ao tamanho do  Destination, digite 0. |
| Characters  Read             |                                             | DINT imediato 0 |                                                                                                                                                                                            | Durante a execução, exibe o  número de caracteres que  foram lidos                                                                                                                                                                                                                                                                                                                                                                       |

## Texto estruturado

| Operando Tipo                |                                             |                 | Formato Descrição Notas                                                                                                                                                                    |                                                                                                                                                                                                                                                                                                                                                                                                                                          |
|------------------------------|---------------------------------------------|-----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Channel DINT                 |                                             | imediato  tag   | 0                                                                                                                                                                                          |                                                                                                                                                                                                                                                                                                                                                                                                                                          |
|                              | Destination Tipo de string  SINT  INT  DINT | tag             | tag para qual  os caracteres  são movidos  (isto é, lidos)  Para um tipo de  string, digite o  nome da tag.  Para uma  matriz SINT,  INT ou DINT,  digita o primeiro  elemento da  matriz. | Se você desejar comparar,  converter ou manipular os  caracteres, digite uma tag  de tipo de string.  Tipos de strings são:  tipo de dado de STRING  padrão  qualquer tipo de string novo  que você cria                                                                                                                                                                                                                                 |
| SerialPort  Control          | SERIAL_PORT _CONTROL                        | tag             | tag que  controla a  operação                                                                                                                                                              |                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Serial Port  Control  Length |                                             | DINT imediato   | Número  máximo de  caracteres a  serem lidos, se  nenhum  caractere de  terminação for  encontrado.                                                                                        | Digite o número máximo de  caracteres que toda  mensagem conterá (isto é,  quando interromper a  leitura, se nenhum caractere  de terminação for  encontrado).  Por exemplo, se as  mensagens variam de 3 a 6  caracteres em extensão,  digite 6.  O Serial Port Control Length  deve ser menor ou igual ou  tamanho do Destination.  Se você desejar definir o  Serial Port Control Length  igual ao tamanho do  Destination, digite 0. |
| Characters  Read             |                                             | DINT imediato 0 |                                                                                                                                                                                            | Durante a execução, exibe o  número de caracteres que  foram lidos                                                                                                                                                                                                                                                                                                                                                                       |

Entretanto, você especifica os valores de Serial Port Control Length e Characters Read acessando os membros .LEN e .POS da estrutura

SERIAL\_PORT\_CONTROL, em vez de incluir os valores na lista de operandos.

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Estrutura de SERIAL\_PORT\_CONTROL

| Mnemônico    | Tipo de  dados    | Descrição                                                                                                                                                                  |
|--------------|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| .EN          |                   | BOOL O bite de habilitação indica que a instrução está habilitada.                                                                                                         |
| .EU          |                   | BOOL O bit de fila indica que a instrução foi digitada na fila ASCII.                                                                                                      |
|              | .DN BOOL          | O bit executado indica que a instrução foi executada, mas  está assíncrona à varredura de lógica.                                                                          |
|              | .RN BOOL          | O bit de execução indica que a instrução está sendo  executada.                                                                                                            |
|              | .EM BOOL          | O bit vazio indica quando a instrução foi executada, mas  está síncrona com a varredura da lógica.                                                                         |
| .ER          |                   | BOOL O bit de erro indica quando a instrução falha (erros).                                                                                                                |
| .FD          |                   | BOOL O bit encontrado não se aplica a esta instrução.                                                                                                                      |
|              | .LEN DINT         | A extensão indica o número máximo de caracteres a serem  movidos para o destino (isto é, quando interromper a leitura,  se nenhum caractere de terminação for encontrado). |
|              |                   | .POS DINT A posição exibe o número de caracteres que foram lidos.                                                                                                          |
| .ERROR DINT  |                   | O erro contém um valor hexadecimal que indica a causa de  um erro.                                                                                                         |

## Descrição

A instrução ARL remove os caracteres do buffer e os armazena no Destination, conforme a seguir:

-  A instrução ARL continua a ser executada até que ela remove o:
-  Primeiro conjunto de caracteres de terminação
-  Número especificado de caracteres (operando String Length)

Enquanto a instrução ARL estiver sendo executada, nenhuma outra instrução ASCII é executada. Para programar a instrução ARL, siga estas diretrizes:

1. Configure a porta serial do controlador para modo Usuário e defina os caracteres que servem como caracteres de terminação.
2. Use os resultados de uma instrução ABL para disparar a instrução ARL. Isto impede que a instrução ARL segure a fila enquanto aguarda pelos caracteres de terminação. Consulte o exemplo de ARL abaixo para obter mais informações.

3. Esta é uma instrução de transição: Em diagrama ladder, alterne o EnableIn de eliminado para definido toda vez que a instrução tiver que ser executada. Em texto estruturado, condicione a instrução para que ela só seja executada em uma transição

4. Para disparar uma ação subsequente quando a instrução tiver sido concluída, examine o bit .EM.

## Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição                        | Ação do Diagrama ladder                                                |
|---------------------------------|------------------------------------------------------------------------|
| Pré-varredura N/A               |                                                                        |
| Rung-condition-in é  falsa      | N/A                                                                    |
| Rung-condition-in é  verdadeira | A instrução é executada.  EnableIn altera de eliminado  para definido. |
| Pós-varredura N/A               |                                                                        |

## Texto estruturado

| Condição          | Ação de texto estruturado                                              |
|-------------------|------------------------------------------------------------------------|
| Pré-varredura N/A |                                                                        |
| Execução normal   | A instrução é executada.  EnableIn altera de eliminado  para definido. |
| Pós-varredura N/A |                                                                        |

## Exemplo

Testa continuamente o buffer para uma mensagem do terminal MessageView . Já que cada mensagem termina em um retorno de carro ($r), o retorno de carro é configurado como o caractere de terminação na guia Protocolo de usuário do diálogo Propriedades do controlador.

Quando a instrução ABL encontrar um retorno de carro, ela define o bit .FD. Quando a instrução ABL encontra o retorno carro (MV\_line.FD é definido), o controlador recebeu uma mensagem completa.

A instrução ARL remove os caracteres do buffer, até e incluindo o retorno de carro, e os coloca o membro DATA da tag MV\_msg, que é um tipo de string.

## Diagrama ladder

<!-- image -->

## Texto estruturado

ABL(0,MV\_line);

osri\_1.InputBit :=MVLine.FD

OSRI(osri\_1);

IF (osri\_1.OutputBit) THEN

mv\_read.LEN := 12;

ARL(0,MV\_msg,MV\_read);

END\_IF;

## Consulte também

Instruções de porta serial ASCII na página 783

Teste ASCII para Linha do Buffer (ABL) na página 807

Caracteres ASCII no buffer (ACB) na página 785

Buffer limpo ASCII (ACL) na página 788

Linhas de handshake ASCII (AHL) na página 792

Leitura ASCII (ARD) na página 797

Acréscimo de Gravação ASCII (AWA) na página 816

Gravação ASCII (AWT) na página 810

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912
