---
type: Instruction
title: "Restaurar SFC (SFR)"
description: "A instrução SFR restaura a execução de uma rotina SFC em uma etapa especificada."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L15491-L15570"
---

## Restaurar SFC (SFR)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução SFR restaura a execução de uma rotina SFC em uma etapa especificada.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

SFR(SFCRoutineName,StepName);

## Operandos

## Diagrama ladder

| Operando Tipo Formato Descrição    |                                                    |
|------------------------------------|----------------------------------------------------|
|                                    | SFCRoutineName ROUTINE nome Rotina SFC a restaurar |
| StepName SFC_STEP tag              | Etapa de destino onde  retomar a execução          |

## Texto estruturado

| Operando Tipo Formato Descrição    |                                                    |
|------------------------------------|----------------------------------------------------|
|                                    | SFCRoutineName ROUTINE nome Rotina SFC a restaurar |
| StepName SFC_STEP tag              | Etapa de destino onde  retomar a execução          |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Descrição

Quando a instrução SFR está habilitada:

-  Na rotina SFC especificada, todas as ações armazenadas param de ser executadas (restaurar).
-  A SFC começa a ser executada na etapa especificada.
-  Se a etapa de destino for 0, o gráfico será restaurado para a sua etapa inicial.

A implementação Logix da instrução SFR é diferente daquela no controlador PLC-5. No controlador PLC-5, a SFR é executada quando a condição do degrau é verdadeira. Após a restauração, a SFC permaneceria pausada até que o degrau contendo a SFR se torne falso. Isso permitiu que a execução após uma restauração fosse atrasada. O recurso de pausar/despausar da instrução SFR de PLC-5 foi dissociada da condição do degrau e movida para a instrução SFP.

## Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

| Uma falha maior ocorrerá se:                            | Tipo de  falha    | Código de  falha    |
|---------------------------------------------------------|-------------------|---------------------|
| O tipo de rotina não é uma rotina SFC 4                 |                   | 85                  |
| Etapa de destino especificada não  existe na rotina SFC |                   | 4 89                |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                        |
|------------------------------------|----------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                        |
| Rung-condition-in é  falsa         | N/A                                                                                    |
| Rung-condition-in é  verdadeira    | A instrução restaura a execução da rotina  SFC especificada para uma etapa particular. |
| Pós-varredura N/A                  |                                                                                        |

## Texto estruturado

| Condição/estado A ção realizada                                                                         |
|---------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                                                                                       |
| Execução normal  A instrução restaura a execução da rotina  SFC especificada para uma etapa particular. |
| Pós-varredura N/A                                                                                       |
