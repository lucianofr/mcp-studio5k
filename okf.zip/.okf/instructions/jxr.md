---
type: Instruction
title: "Saltar para rotina externa (JXR)"
description: "Nenhuma específica a esta instrução."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L14839-L14940"
---

## Saltar para rotina externa (JXR)

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A               | ção realizada                                                         |
|---------------------------------|-----------------------------------------------------------------------|
| Pré-varredura N/A               |                                                                       |
| Rung-condition-in é falsa N/A   |                                                                       |
| Rung-condition-in é  verdadeira | A instrução retorna o valor de bit de dados  para a rotina de chamada |
| Pós-varredura N/A               |                                                                       |

## Texto estruturado

| Condição/estado A    | ção realizada                                                         |
|----------------------|-----------------------------------------------------------------------|
| Pré-varredura N/A    |                                                                       |
| Execução normal      | A instrução retorna o valor de bit de dados  para a rotina de chamada |
| Pós-varredura N/A    |                                                                       |

## Exemplo

<!-- image -->

## Consulte também

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Esta informação se aplica apenas ao controlador SoftLogix 5800.

A instrução JXR é executada como uma rotina externa.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível para bloco de funções.

## Texto estruturado

Esta instrução não está disponível para texto estruturado.

## Operandos

## Diagrama ladder

| Operando Tipo                                                          |                               | Formato Descrição                                                                                                                                                                                          |
|------------------------------------------------------------------------|-------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| External routine name ROUTINE                                          | Nome                          | Rotina externa para  executar                                                                                                                                                                              |
| External routine control EXT_ROUTINE_CONTROL Tag Estrutura de controle |                               |                                                                                                                                                                                                            |
| Parameter BOOL  SINT  INT  DINT  REAL  estrutura                       | Imediato  Tag  Tag de  Matriz | Dados a partir dessa  rotina que você  deseja copiar para  uma variável na  rotina externa.  Parâmetros são  opcionais.  Digite múltiplos  parâmetros, se  necessário.  É possível inserir 10  parâmetros. |
| Return parameter BOOL  SINT  INT  DINT  REAL                           | Tag                           | Tag nessa rotina à  qual você deseja  copiar um resultado  da rotina externa  O parâmetro de  retorno é opcional.  Você só pode ter um  parâmetro de  retorno                                              |

## Estrutura de EXT\_ROUTINE\_CONTROL

| Mnemônico Tipo de dados Descrição           |                                                                                                                                                                                             | Implementatação                                                                                               |
|---------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------|
| ErrorCode SINT                              | Se um erro ocorrer, esse  valor identifica o erro.  Valores válidos são de  0-255.                                                                                                          | Não há códigos de  erro predefinidos. O  desenvolvedor da  rotina externa deve  fornecer os códigos  de erro. |
| NumParams SINT                              | Esse valor indica o  número de parâmetros  associados a essa  instrução.                                                                                                                    | Apenas exibir - essa  informação é  derivada a partir da  entrada de instrução.                               |
| ParameterDefs  EXT_ROUTINE_  PARAMETERS[10] | Essa matriz contém  definições dos parâmetros  para passar para a rotina  externa. A instrução pode  passar até 10 parâmetros.                                                              | Apenas exibir - essa  informação é  derivada a partir da  entrada de instrução.                               |
| ReturnParamDef  EXT_ROUTIN_  PARAMETERS     | Esse valor contém  definições dos parâmetros  de retorno a partir da  rotina externa. Há apenas  um parâmetro de retorno.                                                                   | Apenas exibir - essa  informação é  derivada a partir da  entrada de instrução.                               |
| EN BOOL                                     | Quando definido, o bite de  habilitação indica que a  instrução JXR está  habilitada.                                                                                                       | A rotina externa  define esse bit.                                                                            |
| ReturnsValue BOOL                           | Se definido, esse bit  indica que um parâmetro  de retorno foi inserido  para a instrução. Se  eliminado, esse bit indica  que nenhum parâmetro de  retorno foi inserido para a  instrução. | Apenas exibir - essa  informação é  derivada a partir da  entrada de instrução.                               |
| DN BOOL                                     | O bit executado é definido  quando a rotina externa  foi executada uma vez até  a conclusão.                                                                                                | A rotina externa  define esse bit.                                                                            |
| ER BOOL                                     | O bit de erro é definido se  um erro ocorrer. A  instrução para de ser  executada até que o  programa elimine o bit de  erro.                                                               | A rotina externa  define esse bit.                                                                            |
| FirstScan BOOL                              | Esse bit identifica se essa  é a primeira varredura  após alternar o  controlador para o modo  de Execução. Use  FirstScan para inicializar a  rotina externa, se  necessário.              | O controlador define  esse bit para refletir o  status de varredura.                                          |
|                                             | EnableOut BOOL Saída Habilitar.                                                                                                                                                             | A rotina externa  define esse bit.                                                                            |

|                | EnableIn BOOL Entrada Habilitar.                                       | EnableIn BOOL Entrada Habilitar.                                       | O controlador define  esse bit para refletir  rung-condition-in. A  instrução é  executada  independentemente  da condição do  degrau. O  desenvolvedor da  rotina externa deve  monitorar esse status  e agir de acordo.    |
|----------------|------------------------------------------------------------------------|------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| User1 BOOL     | Esses bits estão                                                       | Esses bits estão                                                       | Ou a rotina externa  ou o programa do  usuário pode definir  esses bits.                                                                                                                                                     |
| User0 BOOL     | disponíveis para o  usuário. O controlador  não inicializa esses bits. | disponíveis para o  usuário. O controlador  não inicializa esses bits. | Ou a rotina externa  ou o programa do  usuário pode definir  esses bits.                                                                                                                                                     |
| ScanType1 BOOL | Esses bits identificam o  tipo atual de varredura:                     | Esses bits identificam o  tipo atual de varredura:                     | O controlador define  esses bits para  refletir o status de  varredura.                                                                                                                                                      |
| ScanType0 BOOL | Valores  de Bit  00  01  10                                            | Tipo de  varredura                                                     | O controlador define  esses bits para  refletir o status de  varredura.                                                                                                                                                      |
| ScanType0 BOOL |                                                                        | Normal                                                                 | O controlador define  esses bits para  refletir o status de  varredura.                                                                                                                                                      |
| ScanType0 BOOL |                                                                        | Pré-varredura                                                          | O controlador define  esses bits para  refletir o status de  varredura.                                                                                                                                                      |
| ScanType0 BOOL |                                                                        | Pós-varredura  (não aplicável  a programas  de lógica  ladder de relé) | O controlador define  esses bits para  refletir o status de  varredura.                                                                                                                                                      |

## Descrição

Use a instrução Saltar para rotina externa (JXR) para chamar a rotina externa a partir de uma rotina ladder no seu projeto. A instrução JXR suporta diversos parâmetros, por isso, você pode passar valores entre a rotina ladder e a rotina externa.

A rotina JXR é semelhante à instrução Saltar para subrotina (JSR). A instrução JXR inicia a execução da rotina externa especificada:

-  A rotina externa é executada uma vez.
-  Após a rotina externa ser executada, a execução lógica retorna à rotina que contém a instrução JXR.

## Afeta sinalizadores de status de operações matemáticas

Não
