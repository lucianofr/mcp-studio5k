---
type: Instruction
title: "Alarme digital (ALMD)"
description: "Neste exemplo, o transmissor de nível Tank 32 (Tank32LT) é monitorado para as condições de alarme."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L1045-L1279"
---

## Alarme digital (ALMD)

## Texto estruturado

Neste exemplo, o transmissor de nível Tank 32 (Tank32LT) é monitorado para as condições de alarme. A tag Tank32LevelAck pode ser usada para confirmar todas as condições desse alarme.

ALMA(Tank32Level,Tank32LT,Tank32LevelAck,0, 0);

## Consulte também

Sintaxe de texto estruturado na página 912

Sinalizadores de status de operações matemáticas na página 879

Índice por meio de matrizes na página 893

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução ALMD fornece alarme para qualquer valor booliano discreto.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

ALMD (ALMD,In,ProgAck,ProgReset,ProgDisable,ProgEnable)

## Operandos

## Diagrama ladder

|                     |               | Operando Tipo (Type) Format Descrição (Description)                                                    |
|---------------------|---------------|--------------------------------------------------------------------------------------------------------|
|                     |               | ALMD tag ALARM_DIGITAL Structure Estrutura ALMD                                                        |
| ProgAck BOOL        | Tag  Imediato | Na transição de Falso para Verdadeiro, confirma o  alarme (se a confirmação for exigida).              |
| ProgReset BOOL      | Tag  Imediato | Na transição de Falso para Verdadeiro, restaura o  alarme (se a restauração for exigida).              |
| ProgDisable BOOL    | Tag  Imediato | Quando Verdadeiro, desativa o alarme (não substitui  comandos Habilitar).                              |
| ProgEnable BOOL     | Tag  Imediato | Quando Verdadeiro, habilita o alarme (tem  precedência sobre Desabilita comandos).                     |
| MinDurationPRE DINT | Somente       | Especifica o quão longa a condição de alarme deve  ser atendida antes de ser relatada (milissegundos). |
| MinDurationACC DINT | Somente       | Indica o valor do acumulador de corrente para o  temporizador MinDuration do alarme.                   |

## Bloco de funções

| Operando Tipo (Type) Format Descrição (Description)    |
|--------------------------------------------------------|
| ALMD tag ALARM_DIGITAL estrutura Estrutura de ALMD     |

## Texto estruturado

|                     |               | Operando Tipo (Type) Format Descrição (Description)                                                    |
|---------------------|---------------|--------------------------------------------------------------------------------------------------------|
|                     |               | ALMD tag ALARM_DIGITAL Structure Estrutura de ALMD                                                     |
| ProgAck BOOL        | Tag  Imediato | Na transição de Falso para Verdadeiro, confirma o  alarme (se a confirmação for exigida).              |
| ProgReset BOOL      | Tag  Imediato | Na transição de Falso para Verdadeiro, restaura o  alarme (se a restauração for exigida).              |
| ProgDisable BOOL    | Tag  Imediato | Quando Verdadeiro, desativa o alarme (não substitui  comandos Habilitar).                              |
| ProgEnable BOOL     | Tag  Imediato | Quando Verdadeiro, habilita o alarme (tem  precedência sobre Desabilita comandos).                     |
| MinDurationPRE DINT | Somente       | Especifica o quão longa a condição de alarme deve  ser atendida antes de ser relatada (milissegundos). |
| MinDurationACC DINT | Somente       | Indica o valor do acumulador de corrente para o  temporizador MinDuration do alarme.                   |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Estrutura de ALMD

## Parâmetros de entrada

| Parâmetro de  entrada    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                                                                                                                                                                                                                                                                                               |
|--------------------------|-------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                          |                               | EnableIn BOOL Diagrama ladder:  Corresponde ao estado de degrau. Não afeta o processamento.  Bloco de funções:  Se eliminado para falso, a instrução não será executada e as  saídas não serão atualizadas.  Se definido, a instrução é executada.  Padrão é verdadeiro.  Texto estruturado:  Sem efeito. A instrução é sempre executada.                                                             |
| In                       | BOOL                          | A entrada do sinal digital para a instrução.  Padrão é falso.  Diagrama ladder:  Segue a condição de degrau. Definido como verdadeiro se a  condição do degrau for verdadeira. Eliminado para falso se a  condição do degrau for falsa.  Texto estruturado:  Copiado do operando da instrução.                                                                                                        |
| InFault BOOL             |                               | Indicador de estado mau para a entrada. A aplicativo do usuário  pode ajustar InFault para indicar que o sinal de entrada tem um  erro. Quando definida, a instrução define InFaulted (Status.1).  Quando eliminado para falso, a instrução elimina o InFaulted  (Status.1) para falso. Em ambos os casos, a instrução continua a  avaliar In para condições de alarme.  Padrão é falso (estado bom). |

| Parâmetro de  entrada  Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                                                                                                                                                                                                                                                                                     |
|------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Condition BOOL                                       | Especifica como o alarme é ativado. Quando Condição é definida  como verdadeiro, a condição de alarme é ativada quando In é  definido como verdadeiro. Quando Condição é eliminada para  falso, a condição de alarme é ativada quando In é eliminada para  falso.  Padrão é verdadeiro.                                                                                                     |
| AckRequired BOOL                                     | Especifica se a confirmação do alarme é necessária. Quando  definida como verdadeiro, a confirmação é necessária. Quando é  eliminado para falso, a confirmação não é necessária e Acked é  sempre definido como verdadeiro.  Padrão é verdadeiro.                                                                                                                                          |
| Latched BOOL                                         | Especifica se o alarme é bloqueado. Alarmes bloqueados  permanecem InAlarm quando a condição de alarme se torna falsa,  até que um comando Restaurar seja recebido. Quando definido  como verdadeiro, o alarme é bloqueado. Quando eliminado para  falso, o alarme não é bloqueado.  Padrão é falso.  Um alarme bloqueado somente pode ser restaurado quando a  condição de alarme é falsa. |
| ProgAck BOOL                                         | Definido como verdadeiro pelo programa do usuário para  confirmar o alarme. Entra em vigor apenas se o alarme não for  confirmado. Requer uma transição de falso para verdadeiro.  Padrão é falso.  Diagrama ladder:  Copiado do operando da instrução.  Texto estruturado:                                                                                                                 |
| OperAck BOOL                                         | Definido como verdadeiro pela interface do operador para  confirmar o alarme. Entra em vigor apenas se o alarme não for  confirmado. A instrução limpa esse parâmetro.  Padrão é falso.                                                                                                                                                                                                     |
| ProgReset BOOL                                       | Definido como verdadeiro pelo programa do usuário para restaurar  o alarme bloqueado. Entra em vigor apenas se o alarme  bloqueado for InAlarm e a condição de alarme for falsa. Requer  uma transição de falso para verdadeiro.  Padrão é falso.  Diagrama ladder:  Copiado do operando da instrução.  Texto estruturado:                                                                  |
| OperReset BOOL                                       | Definido como verdadeiro pela interface do operador para  restaurar o alarme bloqueado. Entra em vigor apenas se o alarme  bloqueado for InAlarm e a condição de alarme for falsa. A  instrução de alarme elimina esse parâmetro para falso.  Padrão é falso.                                                                                                                               |
| ProgSuppress BOOL                                    | Definido como verdadeiro pelo programa do usuário para suprimir  o alarme.  Padrão é falso.                                                                                                                                                                                                                                                                                                 |
| OperSuppress BOOL                                    | Definido como verdadeiro pela interface do operador para suprimir  o alarme. A instrução de alarme elimina esse parâmetro para  falso.  Padrão é falso.                                                                                                                                                                                                                                     |

| Parâmetro de  entrada  Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
|------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ProgUnsuppress BOOL                                  | Definido como verdadeiro pelo programa do usuário para cancelar  a supressão do alarme. Prevalece sobre comandos Suprimir.  Padrão é falso.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| OperUnsuppress BOOL                                  | Definido como verdadeiro pela interface do operador para  cancelar a supressão do alarme. Prevalece sobre comandos  Suprimir. A instrução de alarme elimina esse parâmetro para falso. Padrão é falso.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| OperShelve BOOL                                      | Definido como verdadeiro pela interface do operador para adiar ou  adiar novamente o alarme. Requer uma transição de falso em  uma varredura de programa para um estado verdadeiro na  próxima varredura do programa. A instrução de alarme elimina  esse parâmetro para falso.  Padrão é falso.  Comandos Cancelar o adiamento têm precedência sobre  comandos Adiar.  Atrasar um alarme adia o processamento do alarme. É como  suprimir um alarme, exceto que o atraso é limitado pelo tempo. Se  um alarme for confirmado enquanto está adiado, ele permanece  confirmado mesmo se ficar ativo novamente. Torna-se não  confirmado quando a duração do adiamento termina, contanto que |
| ProgUnshelve BOOL                                    | Definido como verdadeiro pelo programa do usuário para  adiamento cancelado do alarme. Prevalece sobre os comandos  Adiar.  Padrão é falso.  Para obter mais informações sobre como definir um alarme, veja a  descrição para o parâmetro OperShelve.                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| OperUnshelve BOOL                                    | Definido como verdadeiro pela interface do operador para  cancelar o adiamento de alarme. A instrução de alarme elimina  esse parâmetro para falso. Prevalece sobre os comandos Adiar.  Padrão é eliminado.  Para obter mais informações sobre como definir um alarme, veja a  descrição para o parâmetro OperShelve.                                                                                                                                                                                                                                                                                                                                                                      |
| ProgDisable BOOL                                     | Definido como verdadeiro pelo programa do usuário para  desabilitar o alarme.  Padrão é falso.  Diagrama ladder:  Copiado do operando da instrução.  Texto estruturado:                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| OperDisable BOOL                                     | Definido como verdadeiro pela interface do operador para  desabilitar o alarme. A instrução de alarme elimina esse  parâmetro para verdadeiro.  Padrão é falso.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ProgEnable BOOL                                      | Definido como verdadeiro pelo programa do usuário para habilitar  o alarme. Prevalece sobre um comando Desabilitar.  Padrão é falso.  Diagrama ladder:  Copiado do operando da instrução.  Texto estruturado:  Copiado do operando da instrução.                                                                                                                                                                                                                                                                                                                                                                                                                                           |

| Parâmetro de  entrada  Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
|------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| OperEnable BOOL                                      | Definido como verdadeiro pela interface do operador para habilitar  o alarme. Prevalece sobre o comando Desabilitar. A instrução de  alarme elimina esse parâmetro para falso.  Padrão é falso.                                                                                                                                                                                                                                                                                                       |
| AlarmCountReset BOOL                                 | Definido como verdadeiro pela interface do operador para  restaurar o contador de alarme para zero. A instrução de alarme  elimina esse parâmetro para falso.  Padrão é falso.                                                                                                                                                                                                                                                                                                                        |
| UseProgTime BOOL                                     | Especifica se o relógio do controlador ou o valor de ProgTime é  usado para marcar a data/hora dos eventos de alteração do  estado do alarme. Quando definido como verdadeiro, o valor de  ProgTime fornece a data/hora. Quando eliminado para falso, o  relógio do controlador fornece a data/hora.  Padrão é falso.                                                                                                                                                                                 |
| ProgTime LINT                                        | Se UseProgTime estiver definido como verdadeiro, esse valor  será usado para fornecer o valor de data/hora para todos os  eventos. Isso permite que o aplicativo aplique os valores data/hora  obtidos da origem do alarme, como um módulo de entrada de  sequência de eventos.                                                                                                                                                                                                                       |
| Severity DINT                                        | Gravidade do alarme. Isso não afeta o processamento de alarmes  feito pelo controlador, mas pode ser usado para classificar e filtrar  funções no assinante do alarme.  Válido = 1...1000 (1000 = mais grave; 1 = menos grave).  Padrão = 500.                                                                                                                                                                                                                                                        |
| MinDurationPRE DINT                                  | Duração mínima pré-ajustada (milissegundos) para que a  condição de alarme permaneça verdadeira antes que o alarme  seja marcado como InAlarm e a notificação de alarme seja  enviada aos clientes. O controlador coleta dados do alarme assim  que a condição de alarme é detectada, por isso nenhum dado é  perdido enquanto se espera a duração mínima ser atingida.  Válido = 0...2147483647.  Padrão = 0.                                                                                        |
| ShelveDuration DINT                                  | Comprimento de tempo em minutos para adiar um alarme. Atrasar  um alarme adia o processamento do alarme. É como suprimir um  alarme, exceto que o atraso é limitado pelo tempo. Se um alarme  for confirmado enquanto está adiado, ele permanece confirmado  mesmo se ficar ativo novamente. Torna-se não confirmado  quando a duração do adiamento termina (contanto que o alarme  ainda esteja ativo nesse momento).  O tempo mínimo é um minuto. O tempo máximo é definido por  MaxShelveDuration. |
| MaxShelveDurati on  DINT                             | Duração máxima de tempo em minutos para a qual um alarme  possa ser adiado. Para obter mais informações sobre adiar um  alarme, veja a descrição para o parâmetro ShelveDuration.                                                                                                                                                                                                                                                                                                                     |

## Parâmetros de saída

| Parâmetro de  saída  Tipo de  Tipo (Type)    | Descrição (Description)                                                                                                                                                                                                                                                                                                                                                                                                                         |
|----------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                              | EnableOut BOOL Saída Habilitar.                                                                                                                                                                                                                                                                                                                                                                                                                 |
| InAlarm BOOL                                 | Status do alarme ativo Definido como verdadeiro quando o alarme  estiver ativo. Eliminado para falso quando o alarme não estiver  ativo (status normal).                                                                                                                                                                                                                                                                                        |
| Acked BOOL                                   | Status do alarme confirmado. Definido como verdadeiro quando o  alarme for confirmado. Eliminado para falso quando o alarme não  for confirmado.  Acked é sempre definido como verdadeiro quando AckRequired  for eliminado.para falso.                                                                                                                                                                                                         |
| InAlarmUnack BOOL                            | Alarme ativo e confirmação de status combinados. Definido como  verdadeiro quando o alarme estiver ativo (InAlarm for verdadeiro)  e não confirmado (Acked for falso). Eliminado para falso quando o  alarme estiver inativo, confirmado ou ambos.                                                                                                                                                                                              |
| Suppressed BOOL                              | Status de supressão do alarme. Definido como verdadeiro quando  o alarme é suprimido. Eliminado para falso quando o alarme não  estiver suprimido.                                                                                                                                                                                                                                                                                              |
| Shelved BOOL                                 | Status adiado do alarme. Definido como verdadeiro quando o  alarme for adiado. Eliminado para falso quando o alarme não  estiver adiado.  Atrasar um alarme adia o processamento do alarme. É como  suprimir um alarme, exceto que o atraso é limitado pelo tempo. Se  um alarme for confirmado enquanto está adiado, ele permanece  confirmado mesmo se ficar ativo novamente. Ele torna-se  confirmado quando a duração do adiamento termina. |
| Desabilitado BOOL                            | Status de desabilitação do alarme. Definido como verdadeiro  quando o alarme não estiver habilitado. Eliminado para falso  quando o alarme está desativado.                                                                                                                                                                                                                                                                                     |
| Commissioned BOOL                            | Status de comissionado do alarme. Definido como verdadeiro  quando o alarme estiver comissionado. Eliminado para falso  quando o alarme está descomissionado. Atualmente sempre  definido para verdadeiro.                                                                                                                                                                                                                                      |
| MinDurationACC DINT                          | Não usado. O valor é sempre 0.                                                                                                                                                                                                                                                                                                                                                                                                                  |
| AlarmCount DINT                              | Número de vezes que o alarme foi ativado (InAlarm está definido).  Se o valor máximo for atingido, o contador deixa o valor na sua  contagem máxima.                                                                                                                                                                                                                                                                                            |
| InAlarmTime LINT                             | Data/hora de detecção do alarme.                                                                                                                                                                                                                                                                                                                                                                                                                |
| AckTime LINT                                 | Data/hora de confirmação do alarme. Se o alarme não exigir  confirmação, esta data/hora será igual ao horário do alarme.                                                                                                                                                                                                                                                                                                                        |
| RetToNormalTime LINT                         | Data/hora do retorno do alarme ao estado normal.                                                                                                                                                                                                                                                                                                                                                                                                |
| AlarmCountReset Time  LINT                   | Data/hora que indica quando a contagem de alarme foi  restaurada.                                                                                                                                                                                                                                                                                                                                                                               |
| ShelveTime LINT                              | Data/hora indicando quando o alarme foi adiado pela última vez.  Esse valor é definido pelo controlador quando o alarme é adiado.  O alarme podem ser cancelado ou ter cancelamento adiado  muitas vezes. Todas vezes que o alarme for adiado a data/hora  será definida para a hora atual.  Para obter mais informações sobre como adiar um alarme, veja a  descrição para o parâmetro Adiado.                                                 |

| UnshelveTime LIN          |      | Data/hora indicando quando será cancelado o adiamento do  alarme. Este valor é definido toda vez que o alarme é adiado  (mesmo se o alarme já tiver sido adiado). A informação de  Data/hora é determinada adicionando o ShelveDuration ao horário  atual. Se for cancelado o adiamento do alarme programaticamente  ou por um operador, então o valor será definido para o horário  atual.  Para obter mais informações sobre como adiar a condição de um  alarme, veja a descrição para o parâmetro Adiado.    |
|---------------------------|------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                           |      | status DINT Indicadores de status combinados:  Status.0 = InstructFault  Status.1 = InFaulted  Status.2 = SeverityInv                                                                                                                                                                                                                                                                                                                                                                                            |
| InstructFault  (Status.0) | BOOL | Existem condições de erro de instrução. Esse não é um erro de  controlar maior ou menor. Verifique os bits de status restantes  para determinar o que ocorreu.                                                                                                                                                                                                                                                                                                                                                   |
| InFaulted  (Status.1)     | BOOL | O programa do usuário ajustou InFault para indicar dados de  entrada de má qualidade. Alarme continua a avaliar In para a  condição de alarme.                                                                                                                                                                                                                                                                                                                                                                   |
| SeverityInv  (Status.2)   |      | BOOL Configuração da gravidade do alarme.  Se gravidade <1, a instrução usa Gravidade = 1.  Se gravidade >1000, a instrução usa Gravidade = 1000.                                                                                                                                                                                                                                                                                                                                                                |

## Diagramas do estado de alarme digital

<!-- image -->

<!-- image -->

Diagramas de tempo de alarme digital

<!-- image -->

## Confirmação do alarme ALMD exigido e bloqueado

<!-- image -->

## Confirmação do alarme ALMD exigido e não bloqueado

<!-- image -->

## Confirmação do alarme ALMD não exigido e bloqueado

<!-- image -->

## Confirmação do alarme ALMD não exigido e não bloqueado

<!-- image -->

## Conectar um botão à tag OperShelve

Para evitar adiamento indesejado do alarme, a instrução de alarme só processa a tag OperShelve se realizar a transição de falso para verdadeiro entre uma varredura de programa e a próxima. Se um operador pressionar um botão de apertar para adiar o alarme enquanto a tag ProgUnshelve for verdadeira, o alarme não é adiado porque a tag ProgUnshelve tem precedência. Contudo, como o programa varre completamente em milissegundos, o operador ainda estará pressionando o botão para que a tag OperShelve permaneça definida sobre várias varreduras do programa mesmo que a tag ProgUnshelve tenha sido eliminada para falso. Isso significa que o alarme não é adiado.

Para adiar o alarme, o operador pode soltar e pressionar o botão novamente

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                                                                                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | EnableOut é eliminado para falso  A saída InAlarm foi eliminada para falso  A saída Adiada foi eliminada para falso  A saída Confirmada foi definida como verdadeiro.  Todas as condições de alarme foram confirmadas.  Todas as solicitações do operador foram eliminadas  Todas as datas/horas foram eliminadas |
|                                    | Rung-condition-in é falsa Degrau é eliminado para falso.  A saída do parâmetro de entrada foi eliminada para falso  A instrução é executada.                                                                                                                                                                      |
| Rung-condition-in é  verdadeira    | Degrau é definido como verdeiro.  O padrão de entrada foi definido como verdadeiro  A instrução é executada.                                                                                                                                                                                                      |
| Pós-varredura                      | O bit degrau é eliminado para falso.                                                                                                                                                                                                                                                                              |

## Bloco de funções

| Condição/estado A ção realizada               |                                                                                                                                                                                                                                                                       |
|-----------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                                 | Tag.EnableOut é desmarcada como false.  A saída InAlarm foi eliminada para falso  A saída Adiada foi eliminada para falso  A saída Confirmada foi definida como verdadeira  Todas as solicitações do operador foram eliminadas  Todas as datas/horas foram eliminadas |
|                                               | Tag.EnableIn é falso Tag.EnableOut é eliminado para falso                                                                                                                                                                                                             |
| Tag.EnableIn é verdadeiro A instrução executa | Tag.EnableOut é definido como verdadeiro                                                                                                                                                                                                                              |
| Primeira execução da  instrução               | N/D                                                                                                                                                                                                                                                                   |
| Primeira varredura da  instrução              | N/D                                                                                                                                                                                                                                                                   |
| Pós-varredura                                 | Tag.EnableOut é desmarcada como false.                                                                                                                                                                                                                                |

## Texto estruturado

| Condição/estado A ção realizada    |                                                                                       |
|------------------------------------|---------------------------------------------------------------------------------------|
| Pré-varredura                      | Consulte Pré-varredura na tabela de Diagrama ladder.                                  |
|                                    | Execução normal Consulte Rung-condition-in é verdadeira na tabela de Diagrama ladder. |
| Pós-varredura                      | Consulte Pós-varredura na tabela de Diagrama ladder.                                  |

## Exemplo

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

Um exemplo de instrução ALMD em texto estruturado é mostrado abaixo. Nesse exemplo, dois sinais de falha do motor são combinados de modo que se um deles ocorrer, um alarme de falha do motor é ativado. A tag Motor101Ack pode ser usada para confirmar o alarme.

Motor101FaultConditions := Motor101Overtemp OR Motor101FailToStart;

ALMD(Motor101Fault,Motor101FaultConditions,Motor101Ack,0, 0,0 );

## Consulte também

Sintaxe de texto estruturado na página 912

Sinalizadores de status de operações matemáticas na página 879

Índice por meio de matrizes na página 893
