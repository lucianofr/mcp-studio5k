---
type: Instruction
title: "OU exclusivo booliano (BXOR)"
description: "A instrução BXOR executa um OU exclusivo em duas entradas boolianas."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L10957-L11090"
---

## OU exclusivo booliano (BXOR)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução BXOR executa um OU exclusivo em duas entradas boolianas.

## Idiomas disponíveis

## Diagrama ladder

Esta instrução não está disponível no diagrama ladder.

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

<!-- image -->

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Diagrama de bloco da função

## Bloco FBD

| Operando    | Tipo de dados  (Data Type)    | Format    | Descrição  (Description)    |
|-------------|-------------------------------|-----------|-----------------------------|
| BXOR tag    | FBD_BOOLEAN_ XOR              | Structure | Estrutura de  BXOR          |

## Estrutura de FBD\_BOOLEAN\_XOR

| Membros  de entradas   | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                |
|------------------------|-------------------------------|------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL          |                               | Entrada Habilitar. Se  eliminado, a instrução não é  executada e as saídas não  são atualizadas.  O padrão é definido. |
|                        | In1 BOOL                      | Primeira entrada booliana.  Padrão é eliminado.                                                                        |
|                        | In2 BOOL                      | Segunda entrada booliana.  Padrão é eliminado.                                                                         |

| Membros  de saída    | Tipo de dados  (Data Type)    | Descrição (Description)               |
|----------------------|-------------------------------|---------------------------------------|
| EnableOut BOOL       |                               | Indica se instrução está  habilitada. |
|                      | Saída BOOL                    | A saída da instrução.                 |

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580

| Operandos de  entrada (pinos  esquerdos)    | Tipo de dados (Data Type)  Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e  GuardLogix 5580    | Descrição  (Description)    |
|---------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
|                                             | In1 BOOL                                                                                                                                           | Primeira entrada  booliana. |
|                                             | In2 BOOL                                                                                                                                           | Segunda entrada  booliana.  |

| Operandos de  saída (pino  direito)    | Tipo de dados (Data Type)  Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e  GuardLogix 5580    | Descrição  (Description)    |
|----------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
| Saída                                  | BOOL                                                                                                                                               | A saída da instrução.       |

Consulte Funções FBD.

## Operação

A instrução BXOR executa um OU exclusivo em duas entradas boolianas.

Out = In1 XOR In2

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução.

Execução

Diagrama de bloco da função

## Bloco FBD

| Condição/estado A ção realizada    |                                                                                                                                |
|------------------------------------|--------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                       |
| Tag.EnableIn é  falso              | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                       |
| Tag.EnableIn é  verdadeiro         | Os bits EnableIn e EnableOut são  definidos para verdadeiro.  A instrução é executada conforme descrito  na seção de operação. |
| Primeira  execução da  instrução   | N/D                                                                                                                            |
| Primeira  varredura da  instrução  | N/D                                                                                                                            |
| Pós-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                       |

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A ção realizada    |                                    |
|------------------------------------|------------------------------------|
| Pré-varredura N/D                  |                                    |
|                                    | Varredura normal Out = In1 XOR In2 |
| Primeira execução  da instrução    | N/D                                |
| Primeira varredura  da instrução   | N/D                                |
| Pós-varredura N/D                  |                                    |

## Exemplo

## Diagrama de bloco da função

Neste exemplo, bool\_in1 é copiado em BXOR\_02.In1, bool\_in2 é copiado em BXOR\_02.In2, o resultado de um OR exclusivo em execução em BXOR\_02.In1 e BXOR\_02.In2 é colocado em BXOR\_02.Out, e BXOR\_02.Out é então copiado em value\_result\_xor.

| Se bool_in1 for: Se bool_in2 for:  Então value_result_xor  será:    |
|---------------------------------------------------------------------|
| 0 0 0                                                               |
| 0 1 1                                                               |
| 1 0 1                                                               |
| 1 1 0                                                               |

## Bloco FBD

Esse exemplo ilustra um OR exclusivo em execução em bool\_in1 e bool\_in2 e coloca o resultado em value\_result\_xor.

<!-- image -->
