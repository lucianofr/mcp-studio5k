---
type: Instruction
title: "Restaurar (RES)"
description: "```"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L2613-L2699"
---

## Restaurar (RES)

## Texto estruturado

```
CTUD_01.PRE := 500; CTUD_01.Reset := Reset; CTUD_01.CUEnable := Input; CTUD(CTUD_01); counter_state := CTUD_01.DN;
```

## Consulte também

Atributos comuns na página 879

Contagem crescente (CTU) na página 109

Contagem decrescente (CTD) na página 104

Restaurar (RES) na página 119

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução RES restaura uma estrutura de TIMER, COUNTER ou CONTROL.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                   |
|----------------|--------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                       |
|                |   Membros de um operando de estrutura estão  substituídos.                                            |
|                |   Exceto quanto especificado, os operandos da  estrutura são compartilhados por múltiplas instruções. |

## Diagrama ladder

| Operando        | Tipo de  dados    | Formato Des crição    |                           |
|-----------------|-------------------|-----------------------|---------------------------|
| Structure TIMER | CONTROL  COUNTER  | Tag                   | Estrutura para  restaurar |

## Descrição

Quando verdadeiro, a instrução RES elimina esses elementos:

| Ao usar uma instrução  RES para um:    | A instrução elimina:                                        |
|----------------------------------------|-------------------------------------------------------------|
| TIMER                                  | O valor .ACC para 0  Bits do status de controle para  falso |
| COUNTER                                | O valor .ACC para 0  Bits do status de controle para  falso |
| CONTROL                                | Valor .POS para 0  Bits do status de controle para  falso   |

Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                          |
|------------------------------------|------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                          |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como  Rung-condition-in.                                      |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como  Rung-condition-in.  Restaurar a estrutura especificada. |
| Pós-varredura N/A                  |                                                                                          |

## Exemplo

## Diagrama ladder

<!-- image -->
