---
type: Instruction
title: "Interrupção (BRK)"
description: "Use a instrução FOR para chamar repetidamente uma subrotina."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L15956-L16032"
---

## Interrupção (BRK)

## Instruções de

## Circulação/Interrupção

Use a instrução FOR para chamar repetidamente uma subrotina. Use a instrução BRK para interromper a execução de uma subrotina.

Instruções disponíveis

Diagrama ladder

<!-- image -->

Use a instrução FOR para chamar repetidamente uma subrotina. Use a instrução BRK para interromper a execução da subrotina.

| Se você desejar:                             | Use esta instrução:    |
|----------------------------------------------|------------------------|
| Executar uma rotina  repetidamente.          | Circulação (FOR)       |
| Encerrar a execução repetida  de uma rotina. | Interrupção (BRK)      |
| Retornar à instrução FOR Retornar (RET)      |                        |

## Consulte também

Instruções de cálculo/matemáticas na página 369

Instruções de comparação na página 293

Instruções de bit na página 75

Instruções de string ASCII na página 825

Instruções de conversão ASCII na página 845

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução BRK interrompe a execução de uma rotina que foi chamada por uma instrução FOR.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Descrição (Description)

Quando habilitada, a instrução BRK sai da rotina e retorna o controle para a rotina contendo a instrução FOR cuja execução foi a mais recente, retomando a execução seguindo essa instrução. Se nenhuma instrução FOR precedeu essa instrução BRK na sua execução durante essa varredura, a BRK não fará nada.

Se houver instruções FOR aninhadas, uma instrução BRK retorna o controle para a instrução FOR mais profunda.

## Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando

## Execução

## Diagrama ladder

| Condição/estado A ção (Action)                             |
|------------------------------------------------------------|
| Pré-varredura N/D                                          |
| Rung-condition-in é falsa N/D                              |
| Rung-condition-in é  verdadeira  A instrução é  executada. |
| Pós-varredura N/D                                          |
