---
type: Instruction
title: "Truncar (TRN)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L19071-L19271"
---

## Truncar (TRN)

## Bloco de funções

<!-- image -->

## Texto estruturado

result := RAD(value);

## Consulte também

Sintaxe de texto estruturado na página 912

Atributos comuns na página 879

Sinalizadores de status de operações matemáticas na página 879

Conversões de dados na página 883

Instruções matemáticas avançadas na página 749

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução TRN remove (trunca) a parte fracionária da Source e armazena o resultado no Destination.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

dest := TRUNC(source);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

Diagrama ladder e Bloco de funções usam TRN como uma instrução. Ao usar a instrução TRN no Diagrama ladder, o operando Source aceita apenas tag de REAL ou valores imediatos, o destino pode ser REAL, DINT, SINT e INT. Mas para Bloco de funções, o destino só pode ser DINT.

Texto estruturado usa TRUNC como operador. Para o operador TRUNC, o operando Source pode aceitar REAL, SINT, INT e DINT. Mas o destino só pode aceitar DINT.

Ao usar TRUNC dentro de uma instrução de expressão como CPT, tome TRUNC como um operador. O operando Source pode ser qualquer dos tipos inteiros como SINT, INT, DINT e também REAL.

## Diagrama ladder

| Operando Tipo                                              |                                                            |                                                            | Formato Descrição                                          |
|------------------------------------------------------------|------------------------------------------------------------|------------------------------------------------------------|------------------------------------------------------------|
|                                                            |                                                            | Source* REAL imediato  tag                                 | valor para truncar                                         |
| Destination SINT                                           | INT  DINT  REAL                                            |                                                            | tag tag a armazenar o resultado                            |
| Conversão de dados: Tags SINT e INT são sinais-estendidos. | Conversão de dados: Tags SINT e INT são sinais-estendidos. | Conversão de dados: Tags SINT e INT são sinais-estendidos. | Conversão de dados: Tags SINT e INT são sinais-estendidos. |

## Bloco de funções

| Operando Tipo    | Formato Descrição                               |
|------------------|-------------------------------------------------|
|                  | TRN tag FBD_TRUNCATE Estrutura Estrutura de TRN |

## Estrutura de FBD\_TRUNCATE

| Parâmetro de  entrada    | Tipo de dados Descrição    |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
|--------------------------|----------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                            | Entrada Habilitar. Se falso, a instrução não será executada e  as saídas não serão atualizadas.  Padrão é verdadeiro.                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Source REAL              |                            | Entrada para a instrução de conversão.  Entrada também toma DINT, SINT e INT. Mas o tipo inteiro  será convertido em tipo REAL primeiro.  A conversão de SINT ou INT para REAL não ocasiona perda  de precisão de dados.  Mas a conversão de DINT para REAL poderia ocasionar a  perda de precisão de dados. Ambos os tipos de dados  armazenam dados em 32 bits, mas o tipo REAL usa alguns  dos seus 32 bits para armazenar o valor do expoente. Se a  precisão for perdida, o controlador a assumirá da parte menos  significativa do DINT. |

| Parâmetro de  saída    | Tipo de dados Descrição    |                                                                                                                      |
|------------------------|----------------------------|----------------------------------------------------------------------------------------------------------------------|
| EnableOut BOOL         |                            | Saída Habilitar. Eliminado para falso se Dest resultar em  transbordamento, caso contrário definido como verdadeiro. |
| Dest                   | DINT                       | Resultado da instrução de conversão.                                                                                 |

## Texto estruturado

Use TRUNC como uma função. Essa função trunca a origem e retorna um valor inteiro.

Consulte Sintax de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

| Operando Tipo    |                       |               | Formato Descrição                      |
|------------------|-----------------------|---------------|----------------------------------------|
| Source           | REAL  DINT  SINT  INT | imediato  tag | Entrada para a instrução de conversão. |

## Descrição

Truncar não arredonda o valor; em vez disso, a parte não fracionária permanece a mesma, independentemente do valor da parte fracionária.

Truncar um número real grande que poderia resultar em transbordamento de matemática interna retorna um valor em vez de um valor de zero.

É possível usar TRN como um operador em expressões do diagrama ladder; você pode usar um TRUNC como um operador em declarações de Texto estruturado.

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                       | Sinalizadores de status de  operações matemáticas afetados                 |
|---------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------|
| Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580 | Condicional, consulte Sinalizadores  de status de operações  matemáticas . |
| Controladores CompactLogix 5370,  ControlLogix 5570, Compact  GuardLogix 5370 e GuardLogix  5570                    | Sim                                                                        |

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                           |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | O degrau está definido como falso.                                                                                                        |
| Rung-condition-in é falsa N/A.     |                                                                                                                                           |
| Rung-condition-in é  verdadeira    | O controlador remove a parte fracionária da  Source e coloca o resultado no Destination.  A rung-condition-in é definida como verdadeira. |
| Pós-varredura                      | O degrau está definido como falso.                                                                                                        |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                                   |
|                                    | Tag.EnableIn é falso. EnableOut é eliminado como falso                                                            |
| Tag.EnableIn é  verdadeiro         | EnableOut é definido como verdadeiro. Se o  bloco gerar um transbordamento, EnableOut  será eliminado como falso. |
| Primeira varredura da  instrução   | N/A                                                                                                               |
| Primeira execução da  instrução    | N/A                                                                                                               |
| Pós-varredura N/A                  |                                                                                                                   |

## Texto estruturado

| Condição/estado A ção realizada    |                                                                            |
|------------------------------------|----------------------------------------------------------------------------|
| Pré-varredura                      | Consulte Pré-varredura no Diagrama ladder.                                 |
| Execução normal                    | Consulte rung-condition-in é definida como  verdadeira no Diagrama ladder. |
| Pós-varredura                      | Consulte Pós-varredura na tabela de Diagrama  ladder.                      |

## Exemplo

## Diagrama ladder

<!-- image -->

## Texto estruturado

float\_value\_1\_truncated := TRUNC(float\_value\_1);

## Consulte também

Sintaxe de texto estruturado na página 912

Instruções matemáticas avançadas na página 749

Atributos comuns na página 879

Sinalizadores de status de operações matemáticas na página 879

Conversões de dados na página 883

## Instruções de porta serial ASCII

## Instruções de porta serial ASCII

Use as instruções de porta serial ASCII para ler e gravar caractere ASCII.

Importante:

Para usar as instruções de porta serial ASCII, você deve configurar a porta serial do controlador. Consulte o Manual LOGIX 5000 Controller Common Procedures (publicação 1756-PM001) para obter mais informações.

Dica:

Instruções de porta serial ASCII (AWT, AWA, ARD, ARL, ABL, ACB, AHL, ACL) não estão disponíveis para projetos usando controladores que não têm portas seriais.

Instruções disponíveis

Diagrama ladder e Texto estruturado

<!-- image -->

## Bloco de funções

Indisponível Instruções de porta serial ASCII são executadas de forma assíncrona à varredura da lógica:

| Se você desejar:                                                                                                                                                                                                                     | Use esta instrução:    |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------|
| Verificar dados que contêm caracteres de  terminação                                                                                                                                                                                 | ABL                    |
| Verificar o número obrigatório de  caracteres antes de fazer a leitura do  buffer                                                                                                                                                    | ACB                    |
| Eliminar o buffer. Por exemplo, remova  dados antigos no buffer ao inicializá-lo ou  sincronize o buffer com um dispositivo.  Eliminar as instruções de porta serial ASCII  que estão sendo executadas atualmente  ou estão na fila. | ACL                    |
| Obter o status das linhas de controle de  porta serial. Por exemplo, faça com que o  modem desligue.  Ativar ou desativar o sinal DTR  Ativar ou desativar o sinal RTS                                                               | AHL                    |

| Ler um número fixo de caracteres. Por  exemplo, leia dados de um dispositivo que  envia o mesmo número de caracteres com  cada transmissão)                                                                          | ARD    |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------|
| Ler um número variado de caracteres, até  e incluindo o primeiro conjunto de  caracteres de terminação. Por exemplo,  leia dados de um dispositivo que envia um  número variado de caracteres com cada  transmissão. | ARL    |
| Enviar caracteres e adicionar  automaticamente um ou dois caracteres  adicionais para marcar o fim dos dados.  Por exemplo, envie mensagens que  sempre usam o(s) mesmo(s) caractere(s)  de terminação.              | AWA    |
| Enviar caracteres. Por exemplo, envie  caracteres que usam vários caracteres de  terminação.                                                                                                                         | AWT    |

<!-- image -->

Cada instrução ASCII, exceto a instrução ACL, usa uma estrutura SERIAL\_PORT\_CONTROL. O Operando de Controle SerialPort:

-  controla a execução da instrução
-  fornece informações de status sobre que as instruções ASCII são executadas de forma assíncrona à varredura da lógica:
