---
type: Instruction
title: "Carga do sequenciador (SQL)"
description: "A rung-condition-in será definida como verdadeira quando as instruções enableOut forem verdadeiras quando o resultado de ANDing o valor da matriz especificado pela Position por exemplo, Array[Position] com o valor de Mas"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L14334-L14422"
---

## Carga do sequenciador (SQL)

A rung-condition-in será definida como verdadeira quando as instruções enableOut forem verdadeiras quando o resultado de ANDing o valor da matriz especificado pela Position por exemplo, Array[Position] com o valor de Mask é igual ao resultado de ANDing o valor de Source com o valor de Mask , caso contrário, rung-condition-out será eliminada para falso.

## Consulte também

Instruções do sequenciador na página 605

```
Atributos comuns na página 879
```

Conversões de dados na página 883

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução SQL carrega o valor do operando de origem na matriz de sequenciador.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

As regras de conversão de dados para tipos de dados mistos em uma instrução. Consulte Conversão de dados.

|                        |                        | Operando Tipo (Type) Format Descrição (Description)                                                                      |
|------------------------|------------------------|--------------------------------------------------------------------------------------------------------------------------|
| Matriz DINT            | tag de  matriz         | Matriz de sequenciador  especifica o primeiro elemento da matriz  de sequenciador  não use CONTROL.POS no subscrito      |
| Origem SINT  INT  DINT | tag  immediate         | Dados para carregar na matriz de  sequenciador em um local especificado  por .POS.                                       |
|                        |                        | Controle CONTROL tag estrutura de controle da operação  A mesma tag de controle deve ser usada  nas instruções SQI e SQO |
| Comprimento  (Length)  | DINT immediate         | Isso representa a estrutura de CONTROL  .LEN.                                                                            |
|                        | Somente DINT immediate | Isso representa a estrutura de CONTROL  .POS.                                                                            |

## Estrutura de CONTROL

| Mnemônico            | Tipo de  dados (Data  Type)    | Descrição (Description)                                                                        |
|----------------------|--------------------------------|------------------------------------------------------------------------------------------------|
| .EN (Habilitar)      | BOOL                           | O bite de habilitação indica que a instrução SQL está  habilitada.                             |
| .DN (Executado) BOOL |                                | O bit executado é definido quando todos os  elementos especificados foram carregados no Array. |
| .ER (Erro)           | BOOL                           | O bit de erro é definido quando .LEN < ou = a 0, .POS  < 0 ou .POS > .LEN.                     |
| .LEN  (Comprimento)  | DINT                           | O comprimento especifica o número de etapas de  sequenciador na matriz de sequenciador.        |
| .POS (Posição) DINT  |                                | A posição identifica em que lugar no Array o valor de  Source será armazenado.                 |

## Descrição

Quando .EN realiza a transição de falso para verdadeiro, o .POS é incrementado. O .POS é restaurado para 1 quando .POS se torna &gt; ou = a .LEN. A instrução SQL carrega o valor de Source no Array na nova posição.

Quando .EN é verdadeiro, a instrução SQL carrega o valor de Source no Array na posição atual.

Geralmente use a mesma estrutura de CONTROL que as instruções SQI e SQO.

Importante:

Você deve testar e confirmar que a instrução não altera os dados que você não deseja alterar.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha maior ocorrerá se: Tipo de falha Código de falha    |    |
|---------------------------------------------------------------|----|
| posição > tamanho de Matriz 4                                 | 20 |

## Execução

| Condição/estado A               | ção realizada                                         |
|---------------------------------|-------------------------------------------------------|
| Pré-varredura                   | .EN é definido como verdadeiro.                       |
|                                 | Rung-condition-in é falsa .EN é eliminado para falso. |
| Rung-condition-in é  verdadeira | Consulte o fluxograma (Verdadeiro)                    |
| Pós-varredura N/D               |                                                       |

## Fluxograma -Verdadeiro

<!-- image -->
