---
type: Instruction
title: "Converter para Inteiro (FRD)"
description: "A instrução FRD converte um valor de BCD (Source) em um valor decimal e armazena o resultado no Destination."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L18735-L18834"
---

## Converter para Inteiro (FRD)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução FRD converte um valor de BCD (Source) em um valor decimal e armazena o resultado no Destination.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

## Diagrama ladder

|                             |               | Operando Tipo Formato Descrição    |
|-----------------------------|---------------|------------------------------------|
| Source SINT  INT  DINT      | Imediato  tag | valor para converter em decimal    |
| Destination SINT  INT  DINT |               | tag tag a armazenar o resultado    |

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Bloco de funções

| Operando Tipo    | Formato Descrição                              |
|------------------|------------------------------------------------|
|                  | FRD tag FBD_CONVERT Estrutura Estrutura de FRD |

## Estrutura de FBD\_CONVERT

| Parâmetro de  entrada    | Tipo de dados Descrição    |                                                                                                                        |
|--------------------------|----------------------------|------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                            | Entrada Habilitar. Se falso, a  instrução não será executada e as  saídas não serão atualizadas.  Padrão é verdadeiro. |
| Source DINT              |                            | Entrada para a instrução de  conversão.  Válido = qualquer inteiro                                                     |

| Parâmetros  de saída    | Tipo de dados Descrição    |                                        |
|-------------------------|----------------------------|----------------------------------------|
| EnableOut BOOL          |                            | Indica se a instrução está habilitada. |
| Dest                    | DINT                       | Resultado da instrução de conversão.   |

## Descrição

A instrução FRD converte um valor de BCD (Source) em um valor decimal e armazena o resultado no Destination

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                        | Afeta sinalizadores de status de  operações matemáticas                   |
|----------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------|
| Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e GuardLogix  5580 | Condicional, consulte Sinalizadores  de status de operações matemáticas . |
| Controladores CompactLogix  5370, ControlLogix 5570, Compact  GuardLogix 5370 e GuardLogix  5570                     | Sim                                                                       |

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                                                          |
|--------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                                                                                                        |
| Rung-condition-in é falsa N/A                                                                                            |
| Rung-condition-in é  verdadeira  O controlador converte Source em um valor  decimal e coloca o resultado no Destination. |
| Pós-varredura N/A                                                                                                        |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                                   |
|                                    | Tag.EnableIn é falso. EnableOut é eliminado como falso                                                            |
| Tag.EnableIn é  verdadeiro         | EnableOut é definido como verdadeiro. Se o  bloco gerar um transbordamento, EnableOut  será eliminado como falso. |
| Primeira varredura da  instrução   | N/A                                                                                                               |
| Primeira execução da  instrução    | N/A                                                                                                               |
| Pós-varredura N/A                  |                                                                                                                   |

## Exemplos

## Diagrama ladder

Consulte também

<!-- image -->

Instruções de cálculo na página 369
