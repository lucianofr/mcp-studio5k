---
type: Instruction
title: "Logaritmo de base 10 (LOG)"
description: "A instrução LOG leva o logaritmo de base 10 da Source e armazena o resultado no Destination."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L18166-L18284"
---

## Logaritmo de base 10 (LOG)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução LOG leva o logaritmo de base 10 da Source e armazena o resultado no Destination.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

<!-- image -->

## Texto estruturado

dest := LOG(source);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados .

## Diagrama ladder

|                                   | Operando Tipo Formato Descrição    |                                   |
|-----------------------------------|------------------------------------|-----------------------------------|
| Source SINT  INT  DINT  REAL      | Imediato  tag                      | Encontra o logaritmo desse  valor |
| Destination SINT  INT  DINT  REAL |                                    | tag Tag a armazenar o resultado   |

## Texto estruturado

Use LOG como uma função. Essa função calcula o logaritmo de origem e armazena o resultado em dest.

Consulte Sintax de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Bloco de funções

| Operando Tipo Formato Descrição    |                    |                            |
|------------------------------------|--------------------|----------------------------|
| LOG tag                            | FBD_MATH_ ADVANCED | Estrutura Estrutura de LOG |

## Estrutura de FBD\_MATH\_ADVANCED

| Parâmetro de  entrada    | Tipo de  dados    | Descrição                                                                                                               |
|--------------------------|-------------------|-------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                   | Entrada Habilitar. Se eliminado, a  instrução não será executada, e as saídas  não são atualizadas.  Padrão é definido. |
| Source REAL              |                   | Entrada para a instrução matemática.                                                                                    |

| Parâmetro de  saída    | Tipo de  dados    | Descrição                                                                                                            |
|------------------------|-------------------|----------------------------------------------------------------------------------------------------------------------|
|                        |                   | EnableOut BOOL Saída Habilitar.                                                                                      |
|                        | Dest REAL         | Resultado da instrução matemática. Os  sinalizadores de status de operações  matemáticas são ajustados para a saída. |

## Descrição

A instrução LOG leva o logaritmo de base 10 da Source e armazena o resultado no Destination. Source deve ser maior do que zero ou uma falha menor será gerada.

| Source Destin                                        | ation                                                     |
|------------------------------------------------------|-----------------------------------------------------------|
| Não é um número  Número negativo  Infinito negativo, | Não é um número, falha menor de  transbordamento ocorre   |
| Zero  Número negativo  Número positivo               | Infinito negativo, falha menor de  transbordamento ocorre |
|                                                      | Número positivo Resultados normais                        |
| Infinito positivo                                    | Infinito positivo, falha menor de  transbordamento ocorre |

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                         | Afeta o sinalizador de status de  operações matemáticas                  |
|-----------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------|
| Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580 | Condicional, consulte Sinalizadores de  status de operações matemáticas. |
| Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix 5570                     | Sim                                                                      |

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                                                                                            |
|----------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A.                                                                                                         |
| Rung-condition-in é falsa N/A.                                                                                             |
| Rung-condition-in é  verdadeira  O controlador calcula o logaritmo natural da  Source e coloca o resultado no Destination. |
| Pós-varredura N/A.                                                                                                         |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                                   |
|                                    | Tag.EnableIn é falso. EnableOut é eliminado como falso                                                            |
| Tag.EnableIn é  verdadeiro         | EnableOut é definido como verdadeiro. Se o  bloco gerar um transbordamento, EnableOut  será eliminado como falso. |
| Primeira varredura da  instrução   | N/A                                                                                                               |
| Primeira execução da  instrução    | N/A                                                                                                               |
| Pós-varredura N/A                  |                                                                                                                   |

## Texto estruturado

| Condição/estado A ção realizada                                                         |
|-----------------------------------------------------------------------------------------|
| Pré-varredura N/A.                                                                      |
| Execução normal  Consulte rung-condition-in é verdadeira na  tabela de Diagrama ladder. |
| Pós-varredura N/A.                                                                      |

## Exemplo

Calcule o logaritmo de valor e coloque o resultado em result.

## Diagrama ladder

<!-- image -->

## Texto estruturado

result := LOG(value);
