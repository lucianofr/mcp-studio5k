---
type: Instruction
title: "Deslocamento de bit direito (BSR)"
description: "A instrução BSR desloca os bits especificados uma posição para a direita dentro de Array."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L13594-L13683"
---

## Deslocamento de bit direito (BSR)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução BSR desloca os bits especificados uma posição para a direita dentro de Array. Quando habilitada, a instrução descarrega o valor no bit 0 de Array para o bit .UL, desloca os bits restantes uma posição para a direita e carrega o bit do endereço de Bit.

## Importante:

Teste e confirme que a instrução alterou os dados corretos. A instrução BSR opera em memória contínua. Se uma Array for uma matriz do membro, a instrução poderá deslocar além do limite da matriz para outros membros depois dela. Selecione com atenção um comprimento que provoque esse cenário.

A instrução BSR opera em memória contígua de dados. Somente para Controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370 e GuardLogix 5570, o escopo da instrução é restringido à tag base. A instrução BSL não gravará dados fora da tag base, mas pode cruzar fronteiras de membro. Se especificar uma matriz que faça parte de uma estrutura, o comprimento excederá o tamanho dessa matriz, teste e confirme que a instrução BSL não alterou os dados corretos.

Para Controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370 e GuardLogix 5570, os dados são restringidos pelo membro especificado.

Se a instrução tentar ler além do fim de uma matriz (o LEN for grande demais), a instrução definirá o bit .ER e gerará uma falha maior.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados.

## Diagrama ladder

| Operando             | Tipo de  dados    | Formato Des crição                                                       |
|----------------------|-------------------|--------------------------------------------------------------------------|
| Array                | DINT  ARRAY       | tag Matriz a modificar  especifica o primeiro elemento a  ser deslocado. |
|                      |                   | Control CONTROL tag Estrutura de controle da operação                    |
|                      |                   | Source Bit BOOL tag Bit a carregar na posição liberada.                  |
| Length DINT imediato |                   | Número de bits da matriz para  mudar                                     |

## Estrutura de CONTROL

| Mnemônico  Tipo de  dados    | Descrição                                                                                                                       |
|------------------------------|---------------------------------------------------------------------------------------------------------------------------------|
| .EN BOOL                     | O bite de habilitação indica que a instrução BSR  está habilitada.                                                              |
| .DN BOOL                     | O bit executado é definido para indicar que bits  deslocaram uma posição para a direita.                                        |
| .UL BOOL                     | O bit de descarregar é a saída da instrução. O  bit .UL armazena o status do bit que foi  deslocado para fora da faixa de bits. |
| .ER                          | BOOL O bit de erro é definido quando .LEN <0.                                                                                   |
| .LEN DINT                    | O comprimento especifica o número de bits de  matriz a mudar.                                                                   |

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                                 |
|------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | O bit .EN é eliminado para falso.  O bit .DN é eliminado para falso.  O bit .ER é eliminado para falso.  O valor de .POS é eliminado.                           |
|                                    | Rung-condition-in é falsa O bit .EN é eliminado para falso.  O bit .DN é eliminado para falso.  O bit .ER é eliminado para falso.  O valor de .POS é eliminado. |
| Rung-condition-in é  verdadeira    | Consulte o fluxograma BSR a seguir (Verdadeiro)                                                                                                                 |
| Pós-varredura N/A                  |                                                                                                                                                                 |

## Fluxograma BSR (Verdadeiro)

<!-- image -->

## Exemplos

## Exemplo 1

Quando habilitada, a instrução BSR copia array\_dint[0].0 para o bit .UL, desloca 0-9 para a direita e carrega a input\_1 para array\_dint[0].9. Os bits restantes (10-31) são inválidos, o que indica que os bits não podem ser modificados.

## Diagrama ladder

<!-- image -->

## Exemplo 2

Quando habilitada, a instrução BSR copia array\_dint[0].0 para o bit .UL, desloca 0-9 para a direita e carrega a input\_1 para array\_dint[1].25. Os bits restantes (31-26 em dint\_array[1]) são inválidos, o que indica que os bits não podem ser modificados. Observe como array\_dint[1].0 desloca entre palavras em array\_dint[0].31.
