---
type: Instruction
title: "String para REAL (STOR)"
description: "Quando MV\_read.EM for definido, a instrução STOD converte o primeiro conjunto de caracteres números em MV\_msg em um valor inteiro."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L21465-L21595"
---

## String para REAL (STOR)

## Exemplo

Quando MV\_read.EM for definido, a instrução STOD converte o primeiro conjunto de caracteres números em MV\_msg em um valor inteiro. A instrução pula o caractere de controle inicial ($06) e para no delimitador (\).

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
IF MV_read.EM THEN STOD(MV_msg,MV_msg_nmbr); MV_read.EM := 0; END_IF;
```

## Consulte também

Atributos comuns na página 879

```
Sintaxe de texto estruturado na página 912
```

Conversões de dados na página 883

Sinalizadores de status de operações matemáticas na página 879

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução STOR converte a representação ASCII de valor de ponto flutuante em um valor de REAL.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

STOR(Source,Dest);

## Operandos

Existem regras de conversão de dados para tipos de dados mistos dentro de uma instrução. Consulte Conversão de dados .

## Diagrama ladder e Texto estruturado

| Operando Tipo Formato Descrição Notas    | Operando Tipo Formato Descrição Notas    |     |                                       |                                                                                                            |
|------------------------------------------|------------------------------------------|-----|---------------------------------------|------------------------------------------------------------------------------------------------------------|
| Source                                   | Tipo  de  string                         | tag | A tag que  contém o  valor em  ASCII. | Tipos de strings  são:    Tipo de dado de  STRING padrão    Qualquer tipo de  string novo que  você cria |
| Destination REAL tag                     |                                          |     | A tag a  armazenar o  valor de REAL   |                                                                                                            |

Texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Descrição

A instrução STOR converte a Source em um valor de REAL e coloca o resultado no Destination.

-  A instrução converte números positivos e negativos.

-  Se a string da Source contém caracteres não numéricos, a STOR converte o primeiro conjunto de números contíguos, incluindo o ponto decimal [.].

A instrução pula qualquer controle inicial ou caracteres não numéricos, (exceto o sinal de menos em frente a um número).

Se a string contém vários grupos de números que são separados por delimitadores (por exemplo, /), a instrução converte apenas o primeiro grupo de números.

## Afeta sinalizadores de status de operações matemáticas

Condicional, com base na linguagem de programação. Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

| Tipo Code Causa    | Tipo Code Causa                                                                         | Método de recuperação                                                                                                                                      |
|--------------------|-----------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 4 51               | O valor de LEN  da tag de string é  maior do que o  tamanho de  DATA da tag de  string. | Verifique se nenhuma  instrução está sendo  gravada no membro LEN  da tag de string.  No valor de LEN, digite o  número de caracteres  contidos na string. |
| 4 53               | O número de  saída está além  dos limites do  tipo de dados de  destino.                |   Reduza o tamanho do  valor de ASCII, ou    Use um tipo de dado  maior para o destino.                                                                  |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição                        | Ação do Diagrama ladder    |
|---------------------------------|----------------------------|
| Pré-varredura N/A               |                            |
| Rung-condition-in é falsa N/A   |                            |
| Rung-condition-in é  verdadeira | A instrução é executada.   |
| Pós-varredura N/A               |                            |

## Texto estruturado

| Condição A      | ção                                                                              |
|-----------------|----------------------------------------------------------------------------------|
| Pré-varredura   | Consulte Pré-varredura na tabela  de Diagrama ladder anterior                    |
| Execução normal | Consulte rung-condition-in é  verdadeira na tabela de Diagrama  ladder anterior. |
| Pós-varredura   | Consulte Pós-varredura na tabela  de Diagrama ladder anterior                    |

## Exemplo

Depois de fazer a leitura do peso em uma balança (weight\_read é definido), a instrução STOR converte os caracteres número em weight\_ascii em um valor REAL.

Você poderá ver uma pequena diferença entre as partes fracionais da Source e do Destination.

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
IF weight_read THEN STOR(weight_ascii,weight); END_IF;
```

## Consulte também

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

```
Conversões de dados na página 883
```

Sinalizadores de status de operações matemáticas na página 879
