---
type: Instruction
title: "Movimentação mascarada (MVM)"
description: "Índice por meio de matrizes na página 893"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L11472-L11568"
---

## Movimentação mascarada (MVM)

Índice por meio de matrizes na página 893

Tipos de dados elementares na página 887

Sinalizadores de status de operações matemáticas na página 879

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução MVM copia a Source para um Destination e permite que partes dos dados sejam mascaradas.

A instrução MVM usa uma Máscara para passar ou bloquear bits de dados de Source. Um "1" na máscara significa que o bit de dados é passado; um "0" na máscara significa que o bit de dados é bloqueado.

Se tipos de dados de inteiro forem misturados, a instrução preencherá os bits superiores dos tipos de dados de inteiro com 0s de modo que tenham o mesmo tamanho que o tipo de dados maior.

## Inserindo um valor imediato de máscara

Quando a máscara é inserida, o software de programação usa valores decimais como padrão. Para inserir uma máscara usando outro formato, preceda o valor com o prefixo correto.

| Prefixo Des crição                     |
|----------------------------------------|
| 16# Hexadecimal (por exemplo, 16#0F0F) |
| 8# Octal (por exemplo, 8#16)           |
| 2# Binário (por exemplo, 2#00110011)   |

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

| Operando  Tipo de  dados    | Formato Des crição    |                                    |
|-----------------------------|-----------------------|------------------------------------|
| Source SINT  INT  DINT      | imediato  tag         | Valor a mover                      |
| Mask SINT  INT  DINT        | imediato  tag         | Que bits para  bloquear ou  passar |
| Dest SINT  INT  DINT        | tag                   | Tag a armazenar o  resultado       |

Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                         | Afeta sinalizadores de status  de operações matemáticas    |
|-----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580 | Não                                                        |
| Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix 5570                     | Sim                                                        |

## Falhas maiores/menores

| Controladores                                                                                                         | Uma falha menor  ocorrerá se:                             | Tipo de  falha    | Código de  falha    |
|-----------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------|-------------------|---------------------|
| Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580 | O recurso é  habilitado e o  transbordamento é  detectado |                   | 4 4                 |
| Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix 5570                     |                                                           | N/A N/A N/A       |                     |

Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                            |
|------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                                                            |
| Rung-condition-in é  falsa         | N/A                                                                                                                                        |
| Rung-condition-in é  verdadeira    | A instrução passa a Source pela Mask e copia o  resultado para o Destination. Bits não  mascarados no Destination permanecem  inalterados. |
| Pós-varredura N/A                  |                                                                                                                                            |

## Exemplo

## Diagrama ladder

<!-- image -->

Linha 1: value\_b antes de MVM

Linha 2: value\_a
