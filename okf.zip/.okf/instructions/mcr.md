---
type: Instruction
title: "Controle de restauração principal (MCR)"
description: "A instrução MCR simula um relé de controle mestre (um relé físico obrigatório que pode ser desenergizado por qualquer interruptor de parada de emergência conectado em série)."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L15241-L15338"
---

## Controle de restauração principal (MCR)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução MCR simula um relé de controle mestre (um relé físico obrigatório que pode ser desenergizado por qualquer interruptor de parada de emergência conectado em série). Sempre que o relé é desenergizado, seus contatos são abertos para desenergizar todos os dispositivos E/S da aplicação. A instrução MCR pode seletivamente desabilitar uma seção de degraus.

## Idiomas disponíveis

## Diagrama ladder

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Descrição

A instrução MCR pode substituir o comportamento normal de degraus; forçando a execução de cada instrução como se rung-condition-in fosse falsa. Geralmente, execução falsa de uma instrução é mais rápida do que a verdadeira, então, seletivamente desabilitar seções de código desnecessárias poderia resultar no aperfeiçoamento geral no tempo de varredura.

Toda vez que a instrução MCR for executada com rung-condition-in falsa, o comportamento de substituição é alternado. Assim, duas instruções MCR são normalmente obrigatórias: uma para começar a "zona" e uma segunda para terminá-la.

A MCR de início é geralmente condicionada por uma ou mais instruções de entrada. Quando as condições de entrada forem falsas, a zona estará desabilitada. Quando as condições de entrada forem verdadeiras, a zona operará normalmente.

A MCR de término é normalmente incondicional. Se a zona estiver habilitada, a MCR de término será verdadeira, por isso, não fará nada. Se a zona estiver desabilitada, a MCR de término será falsa, então, ela alternará a substituição, reabilitando o degrau que a segue.

Ao programar uma zona MCR, observe que:

A instrução MCR deve ser a última instrução de um degrau.

-  Você deve terminar a zona com uma instrução MCR incondicional. Se a MCR de término for falsa e a zona estiver habilitada, a MCR de término desabilitará todos os degraus que a segue.
-  Não é possível aninhar uma zona MCR dentro de outra. Há apenas um bit de substituição em cada programa. Cada instrução MCR pode alternar essa substituição. Tentar aninhar zonas MCR resultará na criação de diversas zonas menores.
-  Não salte em uma zona MCR. Se a MCR de início não for executada, a zona não estará habilitada.
-  O bit de substituição é automaticamente restaurado no fim da rotina. Se uma zona MCR continuar até o fim da rotina, não é necessário programar uma instrução MCR para terminar a zona, contudo, para evitar confusão ao editar online, recomenda-se que a MCR de término seja sempre usada.

Se a MCR estiver desabilitada em uma subrotina ou uma AOI, o bit de substituição será restaurado quando a subrotina/AOI retornar.

AOIs têm o seu próprio bit de substituição que é inicializado quando AOI é invocada. Se uma AOI for invocada dentro de uma zona MCR desabilitada, a rotina de modo de varredura falsa será normalmente executada. Após a AOI retornar, o estado da zona será restaurado ao que era antes da AOI ser invocada.

Importante:

A instrução MCR não é adequada para um relé físico de controle mestre que fornece capacidade de parada de emergência. Você ainda deve instalar um relé físico de controle mestre para fornecer desligamento de energia E/S de emergência.

Importante:

Não sobreponha ou aninhe zonas MCR. Cada zona MCR deve estar separada e completa. Se eles sobrepuserem ou aninharem, operação imprevisível da máquina poderia ocorrer com dano possível ao equipamento ou lesão ao pessoal.

Coloque operações críticas fora da zona MCR. Se você começar as instruções como temporizadores em uma zona MCR, a execução de instrução se torna falsa quando a zona estiver desabilitada e o temporizador será eliminado.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                  |
|------------------------------------|--------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                  |
| Rung-condition-in é  falsa         | O comportamento de substituição é alternado  habilitando ou desabilitando os degraus que seguem. |
| Rung-condition-in é  verdadeira    | N/A                                                                                              |
| Pós-varredura N/A                  |                                                                                                  |

## Exemplo

## Diagrama ladder

Quando a primeira instrução MCR está habilitada (input\_1, input\_2 e input\_3 estão definidos), o controlador executa os degraus na zona MCR (entre as duas instruções MCR) e define ou elimina saídas, dependendo das condições de entrada.

Quando a primeira instrução MCR está desabilitada (input\_1, input\_2 e input\_3 não estão definidos), o controlador executa os degraus na zona MCR (entre as duas instruções MCR) e EnableIn vai para falso para todos os degraus na zona MCR, independentemente das condições de entrada.

<!-- image -->

## Consulte também

Instruções de controle do programa na página 620

Sempre falso (AFI) na página 622

Nenhuma operação (NOP) na página 646

Fim temporário (TND) na página 652

Atributos comuns na página 879

<!-- image -->

## Fluxograma MCR (Falso)
