---
type: Instruction
title: "String do meio (MID)"
description: "A instrução MID copie um número especificado de caracteres ASCII de uma string e os armazena em outra string."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L20779-L20855"
---

## String do meio (MID)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução MID copie um número especificado de caracteres ASCII de uma string e os armazena em outra string.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

MID(Source,Qty,Start,Dest);

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados.

## Diagrama ladder e Texto estruturado

| Operando Tipo Formato Descrição Notas    | Operando Tipo Formato Descrição Notas    |              |                                                         |                                                                                                                                                                                                                            |
|------------------------------------------|------------------------------------------|--------------|---------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                          | Source ANY_STRING Tag                    |              | A string de  onde os  caracteres  devem ser  copiados   | Tipos de strings são:  tipo de dados de  STRING padrão com  no máximo 82  caracteres de  extensão para a  string.  qualquer novo tipo de  string que você criou  com extensão  configurável de  caracteres para a  string. |
| Quantity                                 | SINT  INT  DINT                          | Imediato tag | O número de  caracteres a  serem  copiados              | O Start mais a  Quantity devem ser  menores ou iguais à  extensão de Source  mais 1.                                                                                                                                       |
| Start                                    | SINT  INT  DINT                          | Imediato tag | A posição do  primeiro  caractere a ser  copiado        | Digite um número  entre 1 e o tamanho  de DATA da Source.                                                                                                                                                                  |
|                                          | Destination ANY_STRING Tag               |              | A string para  onde os  caracteres  devem ser  copiados |                                                                                                                                                                                                                            |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Descrição

A instrução MID copia um grupo de caracteres de Source e coloca o resultado no Destination.

-  A posição de Start e a Quantity definem os caracteres a serem copiados.
-  A menos que a Source e o Destination sejam a mesma tag, a Source permanece inalterada.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha menor ocorrerá se:                                                                             | Tipo de  falha    | Código de  falha    |
|----------------------------------------------------------------------------------------------------------|-------------------|---------------------|
| O valor de LEN da tag de string de  Source é maior do que o tamanho de  DATA da tag de string de Source. |                   | 4 51                |
| A extensão de string de saída é maior do  que o tamanho de DATA da tag de string.                        |                   | 4 52                |
| O valor de Start ou Quantity não é válido. 4 56                                                          |                   |                     |

## Execução

## Diagrama ladder

| Condição                        | Ação do Diagrama ladder    |
|---------------------------------|----------------------------|
| Pré-varredura N/A               |                            |
| Rung-condition-in é falsa N/A   |                            |
| Rung-condition-in é  verdadeira | A instrução é executada.   |
| Pós-varredura N/A               |                            |

## Texto estruturado

| Condição A      | ção                                                                    |
|-----------------|------------------------------------------------------------------------|
| Pré-varredura   | Consulte Pré-varredura na tabela do  Diagrama ladder                   |
| Execução normal | Consulte rung-condition-in é verdadeira  na tabela de Diagrama ladder. |
| Pós-varredura   | Consulte Pós-varredura na tabela do  Diagrama ladder                   |

## Exemplo

No transportador de tratamento de bagagem de um aeroporto, cada mala recebe um código de barras. Os caracteres de 9 a 17 do código de barras são o número do vôo e o aeroporto de destino da bagagem. Depois que o código de barras é lido (bag\_read.EM é ativado), a instrução MID copia o número do vôo e o aeroporto de destino para a string bag\_flt\_and\_dest. Os degraus subsequentes usam bag\_flt\_and\_dest para determinar para onde a bagagem deve ser roteada.
