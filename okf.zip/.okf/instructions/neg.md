---
type: Instruction
title: "Negar (NEG)"
description: "Quando habilitada, a instrução NEG e o operador subtraem o valor de Source de zero."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L9324-L9674"
---

## Negar (NEG)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

Quando habilitada, a instrução NEG e o operador subtraem o valor de Source de zero.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

<!-- image -->

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

Dica:

Use o operador '-' em uma expressão para obter o mesmo resultado. Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões e atribuições no texto estruturado.

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                    |
|----------------|---------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                        |
|                |   Membros de um operando de estrutura estão  substituídos.                                             |
|                |   Exceto quanto especificado, os operandos da  estrutura são compartilhados por múltiplas  instruções. |

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

| Operando  Tipo de dados  (Data Type)  Controladores  CompactLogix  5370,  ControlLogix  5570, Compact  GuardLogix  5370 e  GuardLogix  5570    | Tipo de dados  (Data Type)  Controladores  CompactLogix  5380,  CompactLogix  5480,  ControlLogix  5580, Compact  GuardLogix 5380  e GuardLogix  5580    | Format         | Descrição  (Description)                    |
|------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|---------------------------------------------|
| Origem SINT  INT  DINT  REAL                                                                                                                   | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                            | immediate  tag | Valor para negar                            |
| Dest SINT  INT  DINT  REAL                                                                                                                     | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                            | tag            | Tag a armazenar  o resultado da  instrução. |

## Diagrama de bloco da função

Bloco FBD

| Operando    | Tipo de  dados (Data  Type)    | Format    | Descrição  (Description)    |
|-------------|--------------------------------|-----------|-----------------------------|
| NEG         | FBD_MATH_ ADVANCED             |           | tag Estrutura NEG           |

## Estrutura de FBD\_MATH\_ADVANCED

| Membros de  entradas    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                 |
|-------------------------|-------------------------------|-------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL           |                               | Entrada Habilitar. Se falso, a  instrução não será executada e  as saídas não serão  atualizadas.  Padrão é verdadeiro. |
| Origem REAL             |                               | Valor para negar.                                                                                                       |

| Membros de  saída    | Tipo de dados  (Data Type)    | Descrição (Description)                                             |
|----------------------|-------------------------------|---------------------------------------------------------------------|
| EnableOut BOOL       |                               | Indica se a instrução foi  executada sem falhas ao ser  habilitada. |
|                      |                               | Dest REAL Resultado da instrução                                    |

## Função FBD

Dica: A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operando de entrada  (pino esquerdo)    | Tipo de dados  (Data Type)                              | Descrição  (Description)    |
|-----------------------------------------|---------------------------------------------------------|-----------------------------|
| Origem SINT                             | USINT  INT  UINT  DINT  UDINT  LINT  ULINT  REAL  LREAL | Valor para negar.           |

| Operando de saída  (Pino direito)    | Tipo de  dados (Data  Type)                | Descrição  (Description)    |
|--------------------------------------|--------------------------------------------|-----------------------------|
|                                      | Dest DINT  UDINT  LINT  ULINT  REAL  LREAL | Resultado da função.        |

Consulte Funções FBD .

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                          | Afeta sinalizadores de status de  operações matemáticas    |
|------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix  5580 | Condicional                                                |
| Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix  5570                     | Sim                                                        |

Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                         |
|------------------------------------|-------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                         |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como  Rung-condition-in.                     |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como  Rung-condition-in.  Dest = 0 - Source. |
| Pós-varredura N/D                  |                                                                         |

## Diagrama de bloco da função

Bloco FBD

| Condição/estado A ção realizada          |                                                                                                                  |
|------------------------------------------|------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                        |                                                                                                                  |
|                                          | EnableIn é falso Defina EnableOut como EnableIn.                                                                 |
| EnableIn é verdadeiro Dest = 0 - Source. | Se um transbordamento ocorrer  Elimina EnableOut para falso  Caso contrário  Configure EnableOut para verdadeiro |
| Primeira execução da  instrução          | N/D                                                                                                              |
| Primeira varredura da  instrução         | N/D                                                                                                              |
| Pós-varredura N/D                        |                                                                                                                  |

## Função FBD

Dica: A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A ção realizada    |                                     |
|------------------------------------|-------------------------------------|
| Pré-varredura N/D                  |                                     |
|                                    | Varredura normal Dest = 0 - Source. |
| Primeira execução da  instrução    | N/D                                 |
| Primeira varredura da  instrução   | N/D                                 |
| Pós-varredura N/D                  |                                     |

## Exemplos

## Diagrama ladder

<!-- image -->

## Raiz quadrada (SQR/SQRT)

## Diagrama de bloco da função

## Bloco FBD

<!-- image -->

## Função FBD

<!-- image -->

## Texto estruturado

DINT\_dest := -DINT\_src;

## Consulte também

Sintaxe de texto estruturado na página 912

Índice por meio de matrizes na página 893

Sinalizadores de status de operações matemáticas na página 879

Conversões de dados na página 883

Funções FBD na página 425

Valores imediatos na página 882

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução SQR e o operador calculam a raiz quadrada da Source e coloca o resultado em Dest.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

<!-- image -->

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

Dica:

Use SQRT como um operador em uma expressão para obter o mesmo resultado. Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões e atribuições no texto estruturado.

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                    |
|----------------|---------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                        |
|                |   Membros de um operando de estrutura estão  substituídos.                                             |
|                |   Exceto quanto especificado, os operandos da  estrutura são compartilhados por múltiplas  instruções. |

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

| Operando  Tipo de dados  (Data Type)  Controladores  CompactLogix  5370,  ControlLogix  5570, Compact  GuardLogix  5370 e  GuardLogix  5570    | Tipo de dados  (Data Type)  Controladores  CompactLogix  5380,  CompactLogix  5480, ControlLogix  5580, Compact  GuardLogix 5380 e  GuardLogix 5580    | Format         | Descrição  (Description)                        |
|------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|-------------------------------------------------|
| Origem SINT  INT  DINT  REAL                                                                                                                   | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                          | immediate  tag | Calcula a raiz  quadrada desse  valor.          |
| Dest SINT  INT  DINT  REAL                                                                                                                     | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                          | tag            | Tag para  armazenar o  resultado da  instrução. |

## Diagrama de bloco da função

Bloco FBD

| Operando    | Tipo de dados (Data  Type)    | Format    | Descrição  (Description)    |
|-------------|-------------------------------|-----------|-----------------------------|
|             | SQR FBD_MATH_ADVANCED tag     |           | Estrutura de  SQR           |

## Estrutura de FBD\_MATH\_ADVANCED

| Membros de  entradas    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                 |
|-------------------------|-------------------------------|-------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL           |                               | Entrada Habilitar. Se falso, a  instrução não será executada e  as saídas não serão  atualizadas.  Padrão é verdadeiro. |
| Origem REAL             |                               | Encontrar a raiz quadrada  desse valor.                                                                                 |

| Membros de  saída    | Tipo de dados  (Data Type)    | Descrição (Description)                                             |
|----------------------|-------------------------------|---------------------------------------------------------------------|
| EnableOut BOOL       |                               | Indica se a instrução foi  executada sem falhas ao ser  habilitada. |
|                      |                               | Dest REAL Resultado da instrução.                                   |

## Função FBD

Dica: A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operando de  entrada (pino  esquerdo)    | Tipo de dados (Data Type)  Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580    | Descrição  (Description)               |
|------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------|
| SourceA SINT                             | USINT  INT  UINT  DINT  UDINT  LINT  ULINT  REAL  LREAL                                                                                           | Calcula a raiz  quadrada desse  valor. |

| Operando de  saída (Pino  direito)    | Tipo de dados (Data Type)  Controladores CompactLogix 5380,  CompactLogix 5480, ControlLogix  5580, Compact GuardLogix 5380 e  GuardLogix 5580    | Descrição  (Description)    |
|---------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
|                                       | Dest DINT  UDINT  LINT  ULINT  REAL  LREAL                                                                                                        | Resultado da  função.       |

Consulte Funções FBD.

## Descrição (Description)

Se Dest não for um LREAL/REAL, a instrução tratará a parte fracionária do resultado da seguinte maneira:

| Se a origem for:             | (Para Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact  GuardLogix 5370 e  GuardLogix 5570)  A parte fracional do  resultado:    | Exemplo     | (Para Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix  5580)  A parte fracional do  resultado:    | Exemplo     | Exemplo    | Exemplo    |
|------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------|-------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------|------------|------------|
| qualquer                     |                                                                                                                                                |             | Trunca Origem DINT 3 Arredonda Origem DINT 3                                                                                                                       |             |            |            |
| tag/valor inteiro  elementar |                                                                                                                                                | Dest DINT 1 |                                                                                                                                                                    | Dest DINT 2 |            |            |
| qualquer                     |                                                                                                                                                |             | Arredonda Origem REAL 3,0 Arredonda Origem REAL 3,0                                                                                                                |             |            |            |
| tag/valor ponto  flutuante   |                                                                                                                                                | Dest DINT 2 |                                                                                                                                                                    | Dest DINT 2 |            |            |

Se a Source for negativa, a instrução tomará o valor absoluto da Source antes de calcular a raiz quadrada.

Para Controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370 e GuardLogix 5570, se a Source for um tipo de dado inteiro e o Dest for um tipo de dado inteiro, a instrução truncará o resultado. Por exemplo, se o valor inteiro de Source for 3, o resultado será 1,732, e o valor de Dest passará a ser 1.

Se a Source for um tipo de dado real e o Dest for um tipo de dado inteiro, a instrução arredondará o resultado. Por exemplo, se o valor real de Source for 3.0, o resultado será 1,732, e o valor de Dest passará a ser 2.

SQR é usado como um operador em expressões do diagrama ladder; SQRT é usado como um operador em instruções de Texto estruturado.

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                        | Afeta sinalizadores de status  de operações matemáticas    |
|----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e GuardLogix  5580 | Condicional                                                |
| Controladores CompactLogix  5370, ControlLogix 5570,  Compact GuardLogix 5370 e  GuardLogix 5570                     | Sim                                                        |

Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A              | ção realizada                                                                        |
|--------------------------------|--------------------------------------------------------------------------------------|
| Pré-varredura N/D              |                                                                                      |
| Rung-condition-in é falsa      | Definir Rung-condition-out como  Rung-condition-in.                                  |
| Rung-condition-in é verdadeira | Definir Rung-condition-out como  Rung-condition-in.  Dest = raiz quadrada de Source. |
| Pós-varredura N/D              |                                                                                      |

## Diagrama de bloco da função

Bloco FBD

| Condição/estado A                   | ção realizada                                                                                                                                      |
|-------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                   |                                                                                                                                                    |
| EnableIn é falso                    | Defina EnableOut como EnableIn.                                                                                                                    |
| EnableIn é verdadeiro               | Dest. = raiz quadrada de Source.  Se um transbordamento ocorrer  Elimina EnableOut para falso  Caso contrário  Configure EnableOut para verdadeiro |
| Primeira execução da instrução N/D  |                                                                                                                                                    |
| Primeira varredura da instrução N/D |                                                                                                                                                    |
| Pós-varredura N/D                   |                                                                                                                                                    |

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A  ção realizada                 |
|--------------------------------------------------|
| Pré-varredura N/D                                |
| Varredura normal  Dest = raiz quadrada de Source |
| Primeira execução da instrução N/D               |
| Primeira varredura da instrução N/D              |
| Pós-varredura N/D                                |

## Exemplos

## Diagrama ladder

Diagrama de bloco da função

<!-- image -->

## Bloco FBD

<!-- image -->

Função FBD

<!-- image -->

## Texto estruturado

REAL\_dest := SQRT(INT\_src);

## Consulte também

Sintaxe de texto estruturado na página 912
