---
type: Instruction
title: "Letra minúscula (LOWER)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L21193-L21302"
---

## Letra minúscula (LOWER)

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
IF temp_high THEN DTOS(msg_num,msg_num_ascii); temp_high := 0; END_IF;
```

## Consulte também

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução LOWER converte os caracteres alfabéticos em uma string em caracteres minúsculos.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

LOWER(Source,Dest);

## Operandos

## Diagrama ladder e Texto estruturado

| Operando Tipo Formato Descrição    | Operando Tipo Formato Descrição                                          |
|------------------------------------|--------------------------------------------------------------------------|
| Source String Tag                  | A tag que contém os  caracteres que você  deseja converter em  minúsculo |
| Destination String Tag             | A tag a armazenar os  caracteres em  minúsculo                           |

Consulte Texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Descrição

A instrução LOWER converte todas as letras na Source em minúsculas e posiciona o resultado no Destination.

-  Os caracteres ASCII diferenciam maiúsculas e minúsculas.. O maiúsculo "A" ($41) não é igual ao minúsculo "a" ($61).
-  Se os operadores digitarem diretamente caracteres ASCII, converta os caracteres em maiúsculos ou minúsculos antes de compará-los.

Qualquer caractere na string de Source que não for uma letra permanece inalterado.

## Afeta sinalizadores de status de operações matemáticas

Não

Falhas maiores/menores

| Tipo Code Causa    |                                                                                        | Método de recuperação                                                                                                                                      |
|--------------------|----------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 4 51               | O valor de LEN da  tag de string é  maior do que o  tamanho de DATA  da tag de string. | Verifique se nenhuma  instrução está sendo gravada  no membro LEN da tag de  string.  No valor de LEN, digite o  número de caracteres  contidos na string. |

| 4 52    | A string de saída é  maior do que o  destino    | Crie um novo tipo de string  que seja grande suficiente  para a string de saída. Use o  novo tipo de string como o  tipo de dados para o destino.    |
|---------|-------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                           |
|-----------------------------------------------------------|
| Pré-varredura N/A                                         |
| Rung-condition-in é falsa N/A                             |
| Rung-condition-in é  verdadeira  A instrução é executada. |
| Pós-varredura N/A                                         |

## Texto estruturado

| Condição A      | ção                                                                              |
|-----------------|----------------------------------------------------------------------------------|
| Pré-varredura   | Consulte Pré-varredura na tabela de  Diagrama ladder anterior                    |
| Execução normal | Consulte rung-condition-in é  verdadeira na tabela de Diagrama  ladder anterior. |
| Pós-varredura   | Consulte Pós-varredura na tabela de  Diagrama ladder anterior                    |

## Exemplos

Para encontrar informações sobre um item específico, um operador digita o número de item em um terminal ASCII. Após o controlador ler a entrada de um terminal (terminal\_read é definido), a instrução LOWER converte os caracteres em item\_number em caracteres todos minúsculos e armazena o resultado em item\_number\_lower\_case. Um degrau subsequente então pesquisa em uma matriz por caracteres que correspondam àqueles em item\_number\_lower\_case.

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
IF terminal_read THEN LOWER(item_number,item_number_lower_case); terminal_read := 0; END_IF;
```

## Consulte também

```
Atributos comuns na página 879
```

Sintaxe de texto estruturado na página 912
