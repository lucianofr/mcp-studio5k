---
type: Instruction
title: "Gravação ASCII (AWT)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L20112-L20303"
---

## Gravação ASCII (AWT)

## Exemplo

## Diagrama ladder

<!-- image -->

## Texto estruturado

ABL(0,MV\_line);

## Consulte também

Instruções de porta serial ASCII na página 783

Caracteres ASCII no buffer (ACB) na página 785

Buffer limpo ASCII (ACL) na página 788

Linhas de handshake ASCII (AHL) na página 792

Leitura ASCII (ARD) na página 797

Linhas de leitura ASCII (ARL) na página 801

Acréscimo de Gravação ASCII (AWA) na página 816

Gravação ASCII (AWT) na página 810

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate.

A instrução AWT envia caracteres da matriz da Source a um dispositivo serial.

Dica:

Instruções de Porta serial ASCII (AWT, AWA, ARD, ARL, ABL, ACB, AHL, ACL) não estão disponíveis para controladores que não têm portas seriais.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

AWT(Channel,Source,SerialPortControl);

## Operandos

## Diagrama ladder

| Operando Tipo               |                                 |                 | Formato Descrição                                                                                                                                                   | Notas                                                                                                                                                                                                    |
|-----------------------------|---------------------------------|-----------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Channel DINT                |                                 | imediato  tag   | 0                                                                                                                                                                   |                                                                                                                                                                                                          |
| Source                      | Tipo de string  SINT  INT  DINT | tag             | Tag que contém os  caracteres a enviar  Para um tipo de string,  digite o nome da tag.  Para uma matriz  SINT, INT ou DINT,  digita o primeiro  elemento da matriz. | Se você desejar comparar,  converter ou manipular os  caracteres, digite uma tag de  tipo de string.  Tipos de strings são:  tipo de dado de STRING  padrão  qualquer tipo de string novo  que você cria |
| Serial Port  Control        | SERIAL_PORT_CONTROL tag         |                 | Tag que controla a  operação                                                                                                                                        |                                                                                                                                                                                                          |
| Serial Port  Control Length |                                 | DINT imediato   | número de caracteres  a enviar                                                                                                                                      | A extensão do controle de  porta serial deve ser menor ou  igual ao tamanho da Source.  Se você desejar ajustar o  Serial Port Control Length  igual ao número de caracteres  na Source, digite 0.       |
| Characters  Sent            |                                 | DINT imediato 0 |                                                                                                                                                                     | Durante a execução, exibe o  número de caracteres que  foram enviados                                                                                                                                    |

## Texto estruturado

| Operando Tipo               |                                 |                 | Formato Descrição                                                                                                                                                   | Notas                                                                                                                                                                                                    |
|-----------------------------|---------------------------------|-----------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Channel DINT                |                                 | imediato  tag   | 0                                                                                                                                                                   |                                                                                                                                                                                                          |
| Source                      | Tipo de string  SINT  INT  DINT | tag             | Tag que contém os  caracteres a enviar  Para um tipo de string,  digite o nome da tag.  Para uma matriz  SINT, INT ou DINT,  digita o primeiro  elemento da matriz. | Se você desejar comparar,  converter ou manipular os  caracteres, digite uma tag de  tipo de string.  Tipos de strings são:  tipo de dado de STRING  padrão  qualquer tipo de string novo  que você cria |
| Serial Port  Control        | SERIAL_PORT_CONTROL tag         |                 | Tag que controla a  operação                                                                                                                                        |                                                                                                                                                                                                          |
| Serial Port  Control Length |                                 | DINT imediato   | número de caracteres  a enviar                                                                                                                                      | A extensão do controle de  porta serial deve ser menor ou  igual ao tamanho da Source.  Se você desejar ajustar o  Serial Port Control Length  igual ao número de caracteres  na Source, digite 0.       |
| Characters  Sent            |                                 | DINT imediato 0 |                                                                                                                                                                     | Durante a execução, exibe o  número de caracteres que  foram enviados                                                                                                                                    |

Você pode especificar os valores de Serial Port Control Length e Characters Sent acessando os membros .LEN e .POS da estrutura SERIAL\_PORT\_CONTROL, em vez de incluir os valores na lista de operandos.

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Estrutura de SERIAL\_PORT\_CONTROL

| Mnemônico  Tipo de    | Descrição                                                                                          |
|-----------------------|----------------------------------------------------------------------------------------------------|
| .EN BOOL              | O bite de habilitação indica que a instrução está  habilitada.                                     |
| .EU BOOL              | O bit de fila indica que a instrução foi digitada na fila  ASCII.                                  |
| .DN BOOL              | O bit executado indica que a instrução foi  executada, mas está assíncrona à varredura de  lógica. |
| .RN BOOL              | O bit de execução indica que a instrução está sendo  executada.                                    |
| .EM BOOL              | O bit vazio indica quando a instrução foi executada,  mas está síncrona com a varredura da lógica. |
| .ER                   | BOOL O bit de erro indica quando a instrução falha (erros).                                        |
| .FD                   | BOOL O bit encontrado não se aplica a esta instrução.                                              |

|             | .LEN DINT A extensão indica o número de caracteres a enviar.       |
|-------------|--------------------------------------------------------------------|
| .POS DINT   | A posição exibe o número de caracteres que foram  enviados.        |
| .ERROR DINT | O erro contém um valor hexadecimal que indica a  causa de um erro. |

## Descrição

A instrução AWT envia o número especificado de caracteres (isto é, a extensão do controle de portal serial) da tag de Source ao dispositivo que está conectado à porta serial do controlador

Para programar a instrução AWT, siga estas diretrizes:

1. Configure a porta serial do controlador.
2. Isso é uma instrução de transição: No diagrama ladder, alterne EnableIn de eliminado para definido toda vez que a instrução deve ser executada. No texto estruturado, condicione a instrução para que ela apenas execute em uma transição
3. Cada vez que a instrução é executada, você sempre envia o mesmo número de caracteres?

| Se seu aplicativo:               | Então:                               |
|----------------------------------|--------------------------------------|
| Usa a instrução ARD ou ARL       | Selecione o modo Usuário             |
| Não usa as instruções ARD ou ARL | Selecione o modo Usuário ou  Sistema |

| Se: Então:    |                                                                                                                                                    |
|---------------|----------------------------------------------------------------------------------------------------------------------------------------------------|
| Sim           | Em Serial Port Control Length, digite o  número de caracteres a enviar.                                                                            |
| Não           | Antes da instrução ser executada, mova  o membro LEN da tag de Source para o  membro LEN da tag Serial Port Control.  Consulte o exemplo 2 abaixo. |

Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição                        | Ação do Diagrama ladder                                                |
|---------------------------------|------------------------------------------------------------------------|
| Pré-varredura N/A               |                                                                        |
| Rung-condition-in é  falsa      | N/A                                                                    |
| Rung-condition-in é  verdadeira | A instrução é executada.  EnableIn altera de eliminado  para definido. |
| Pós-varredura N/A               |                                                                        |

## Texto estruturado

| Condição          | Ação de texto estruturado                                              |
|-------------------|------------------------------------------------------------------------|
| Pré-varredura N/A |                                                                        |
| Execução normal   | A instrução é executada.  EnableIn altera de eliminado  para definido. |
| Pós-varredura N/A |                                                                        |

## Exemplos

## Exemplo 1

Quando a temperatura atingir o limite baixo (isto é, temp\_low está ativado), a instrução AWT envia uma mensagem ao terminal MessageView que está conectado à porta serial do controlador. A mensagem contém nove caracteres do membro DATA da tag string[2], que é um tipo de string. (O $14 conta como um caractere; ele é hexadecimal para o caractere Ctrl-T.) O último caractere é um retorno de carro ($r), que marca o fim da mensagem.

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
osri_1.InputBit := temp_low; OSRI(osri_1);
```

```
IF (osri_1.OutputBit) THEN temp_low_write.LEN := 9; AWT(0.string[2],temp_low_write); END_IF;
```

## Exemplo 2

Quando MV\_update está ativado, a instrução AWT envia os caracteres em MV\_msg. Como o número de caracteres em MV\_msg varia, o degrau move primeiro a extensão da string (MV\_msg.LEN) para o Serial Port Control Length da instrução AWT (MV\_write.LEN). (Em MV\_msg, o $16 conta como um caractere; ele é um código hexadecimal para o caractere Ctrl-V.)

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
osri_1.InputBit := MV_update; OSRI(osri_1); IF (osri_1.OutputBit) THEN MV_write.LEN := Mv_msg.LEN; AWT(0.MV_msg,MV_write); END_IF;
```

## Consulte também

Instruções de porta serial ASCII na página 783

Teste ASCII para Linha do Buffer (ABL) na página 807

Caracteres ASCII no buffer (ACB) na página 785

```
Buffer limpo ASCII (ACL) na página 788
```
