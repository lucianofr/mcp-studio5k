---
type: Instruction
title: "String para DINT (STOD)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L21373-L21464"
---

## String para DINT (STOD)

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
IF send_data THEN RTOS(data_1,data_1_ascii); send_data:= 0; END_IF;
```

## Consulte também

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução STOD converte a representação ASCII de um inteiro em um valor inteiro ou de REAL.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

STOD(Source,Dest);

## Operandos

Existem regras de conversão de dados para tipos de dados mistos dentro de uma instrução. Consulte Conversão de dados .

## Diagrama ladder e Texto estruturado

| Operando Tipo Formato Descrição Notas    | Operando Tipo Formato Descrição Notas    |     |                                       |                                                                                                                                                                           |
|------------------------------------------|------------------------------------------|-----|---------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Source                                   | Tipo  de  string                         | Tag | A tag que  contém o  valor em  ASCII. | Tipos de strings são:    Tipo de dado de  STRING padrão    Qualquer tipo de  string novo que  você cria                                                                 |
| Destination                              | SINT  INT  DINT                          | Tag | A tag a  armazenar  o valor  inteiro  | Se o valor da  Source for um  número de ponto  flutuante, a instrução  converte apenas a  parte não-fracionária  do número  (independente do  tipo de dados de  destino). |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões.

## Descrição

A instrução STOD converte a Source em um inteiro e coloca o resultado no Destination.

-  A instrução converte números positivos e negativos.
-  Se a string da Source contém caracteres não numéricos, a STOD converte o primeiro conjunto de números contíguos.

A instrução pula qualquer controle inicial ou caracteres não numéricos, exceto o sinal de menos em frente a um número.

Se a string contém vários grupos de números que são separados por delimitadores (por exemplo, /), a instrução converte apenas o primeiro grupo de números.

## Afeta sinalizadores de status de operações matemáticas

Apenas no diagrama ladder. Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

| Tipo Code Causa    | Tipo Code Causa                                                                         | Método de recuperação                                                                                                                                      |
|--------------------|-----------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 4 51               | O valor de LEN  da tag de string é  maior do que o  tamanho de  DATA da tag de  string. | Verifique se nenhuma  instrução está sendo  gravada no membro LEN  da tag de string.  No valor de LEN, digite o  número de caracteres  contidos na string. |
| 4 53               | O número de  saída está além  dos limites do  tipo de dados de  destino.                |   Reduza o tamanho do  valor de ASCII, ou    Use um tipo de dado  maior para o destino.                                                                  |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

|                                 | Condição A ção realizada                                                        |
|---------------------------------|---------------------------------------------------------------------------------|
| Pré-varredura N/A               |                                                                                 |
| Rung-condition-in é  falsa      | N/A                                                                             |
| Rung-condition-in é  verdadeira | A instrução é executada.  O Destino é eliminado  A instrução converte a Source. |
| Pós-varredura N/A               |                                                                                 |

## Texto estruturado

| Condição A ção    |                                                                                  |
|-------------------|----------------------------------------------------------------------------------|
| Pré-varredura     | Consulte Pré-varredura na  tabela de Diagrama ladder  anterior                   |
| Execução normal   | Consulte rung-condition-in é  verdadeira na tabela de  Diagrama ladder anterior. |
| Pós-varredura     | Consulte Pós-varredura na  tabela de Diagrama ladder  anterior                   |
