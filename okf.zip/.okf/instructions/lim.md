---
type: Instruction
title: "Limite (LIM)"
description: "```"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L7592-L7778"
---

## Limite (LIM)

```
end_if; if value_3 <= 'I am EQUAL' then light_3 := 1; Caso contrário light_3 := 0; end_if;
```

## Consulte também

Sintaxe de texto estruturado na página 912

Conversões de dados na página 883

Índice por meio de matrizes na página 893

Valores imediatos na página 882

Funções FBD na página 425

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução LIM testa se o valor de Test está dentro da faixa de Limite baixo e Limite alto como indicado no Fluxograma LIM (Verdadeiro).

Se algum operando não for um número (NAN), EnableOut será eliminado para falso.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

Função FBD

<!-- image -->

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

| Operando  Tipo de dados (Data  Type)  Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix 5570   | Tipo de dados (Data Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix 5380  e GuardLogix 5580    | Format         | Descrição  (Description)            |
|-------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|----------------|-------------------------------------|
| Low Limit SINT  INT  DINT  REAL                                                                                                           | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                       | immediate  tag | Valor de limite  inferior.          |
| Test SINT  INT  DINT  REAL                                                                                                                | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                       | immediate  tag | Valor para  testar contra  limites. |
| High Limit SINT  INT  DINT  REAL                                                                                                          | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                                       | immediate  tag | Valor de limite  superior.          |

## Diagrama de bloco da função

## Bloco FBD

| Operando    | Tipo de dados  (Data Type)    | Format    | Descrição  (Description)           |
|-------------|-------------------------------|-----------|------------------------------------|
|             |                               |           | LIM FBD_LIMIT tag Estrutura de LIM |

## Estrutura de FBD\_LIMIT

| Membros  de entradas Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                 |
|----------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL                                      | Entrada Habilitar. Se falso, a  instrução não será  executada e as saídas não  serão atualizadas.  Padrão é verdadeiro. |
| LowLimit REAL                                      | Valor de limite inferior.                                                                                               |
| Test REAL                                          | Valor para testar contra  limites.                                                                                      |
| HighLimit REAL                                     | Valor de limite superior.                                                                                               |

| Membros  de saída    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                 |
|----------------------|-------------------------------|---------------------------------------------------------------------------------------------------------|
| EnableOut BOOL       |                               | Indica se a instrução está  habilitada.                                                                 |
|                      | Dest BOOL                     | Definido como verdadeiro se  Limit test for verdadeiro.  Eliminado como falso se  Limit test for falso. |

## Função FBD

Dica: A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operandos de  entrada (pinos  esquerdos)    | Tipo de dados (Data  Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix    | Descrição  (Description)    |
|---------------------------------------------|------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
| Low Limit SINT                              | INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                                      | Valor de limite  inferior   |

| Test SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL       | Valor para  testar contra  limites.    |
|--------------------------------------------------------------------------|----------------------------------------|
| High Limit SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL | Valor de limite  superior.             |

| Operando de  saída (Pino  direito)    | Tipo de dados  (Data Type)    | Descrição  (Description)                                                                                 |
|---------------------------------------|-------------------------------|----------------------------------------------------------------------------------------------------------|
|                                       | Dest BOOL                     | Definido como  verdadeiro se Limit test  for verdadeiro.  Eliminado como falso se  Limit test for falso. |

Consulte Funções FBD .

## Operação

Esta seção ilustra a operação da instrução LIM.

<!-- image -->

| Se Low  Limit:          | E se o valor de teste for:                                  | Então EnableOut  será:    |
|-------------------------|-------------------------------------------------------------|---------------------------|
| < ou = para  High Limit | igual ou dentro dos limites  diferente ou fora dos limites  | verdadeiro  falso         |
| > High Limit            | igual ou fora dos limites  diferente ou dentro dos  limites | verdadeiro  falso         |

Os inteiros com sinal realizam transição de um número máximo positivo a um número máximo negativo quando o bit mais significativo for verdadeiro. Por exemplo, em inteiros de 16 bits (tipo INT), o máximo inteiro positivo é 32.767, que é representado em hexadecimal como 16#7FFF (os bits de 0 até 14 são todos verdadeiros). Se este número for incrementado em um, o resultado é 16#8000 (bit 15 é verdadeiro). Para inteiros com sinal, o hexadecimal 16#8000 é igual ao decimal -32.768. Ao se incrementar deste ponto até que todos os 16 bits estejam definidos, termina-se em 16#FFFF, que é igual ao decimal -1.

Isso pode ser mostrado em uma linha circular numerada. A instrução LIM começa em Low Limit e é incrementada no sentido horário até alcançar High Limit. Qualquer valor de Test no sentido horário que vai de Low Limit até High Limit define EnableOut como verdadeiro. Qualquer valor de Test no sentido horário que vai de High Limit até Low Limit elimina EnableOut para falso.

Se algum operando não for um número (NAN), EnableOut será eliminado para falso.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                                      |
|------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                      |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como  Rung-condition-in.                                                                                                                  |
| Rung-condition-in é  verdadeira    | Consulte Fluxograma LIM (Verdadeiro) Se a saída for verdadeira  Defina Rung-condition-out como  verdadeira.  Caso contrário  Eliminar Rung-condition-out para falso. |
| Pós-varredura N/D                  |                                                                                                                                                                      |

## Diagrama de bloco da função

## Bloco FBD

| Condição/estado A ção realizada    |                                                                                      |
|------------------------------------|--------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                      |
|                                    | EnableIn é falso Defina EnableOut como EnableIn.                                     |
| EnableIn é verdadeiro              | Definir EnableOut como EnableIn.  Consulte Fluxograma LIM (Verdadeiro)  Dest = saída |
| Primeira execução da  instrução    | N/D                                                                                  |
| Primeira varredura da  instrução   | N/D                                                                                  |
| Pós-varredura N/D                  |                                                                                      |

## Função FBD

Dica: A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A ção realizada    |                                                                     |
|------------------------------------|---------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                     |
|                                    | Varredura normal Consulte Fluxograma LIM (Verdadeiro)  Dest = saída |
| Primeira execução da  instrução    | N/D                                                                 |
| Primeira varredura da  instrução   | N/D                                                                 |
| Pós-varredura N/D                  |                                                                     |

## Fluxograma LIM (verdadeiro)

<!-- image -->

## Exemplos

## Exemplo 1: Limite baixo &lt;= Limite alto

Quando o valor de Test for igual ou maior que Limite baixo e menor ou igual ao Limite alto, light\_1 é definido.

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

## Bloco FBD

Exemplo 2: Limite baixo &gt; Limite alto

<!-- image -->

Quando o valor ou = a 0 ou valor ou = a -100, defina light\_1 para verdadeiro. Se o valor 0 e valor -100, elimina light\_1 para falso.
