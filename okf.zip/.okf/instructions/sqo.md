---
type: Instruction
title: "Saída do sequenciador (SQO)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L14423-L14723"
---

## Saída do sequenciador (SQO)

## Exemplo

## Diagrama ladder

<!-- image -->

Quando habilitada, a instrução SQL carrega value\_3 na nova posição na matriz de sequenciador, que é array\_dint[5] nesse exemplo.

## Consulte também

Instruções do sequenciador na página 605

SQO na página 614

SQI na página 606

Atributos comuns na página 879

Conversões de dados na página 883

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução SQO define condições de saída para a próxima etapa de um par de sequência das instruções SQO/SQI.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

As regras de conversão de dados para tipos de dados mistos em uma instrução. Consulte Conversão de dados.

| Operando Tipo Formato Descrição    |                      |                                                                                                                         |
|------------------------------------|----------------------|-------------------------------------------------------------------------------------------------------------------------|
| Array DINT                         | tag de  matriz       | matriz de sequenciador  especifica o primeiro elemento da  matriz de sequenciador  não use CONTROL.POS no  subscrito    |
| Mask SINT  INT  DINT               | tag  imediato        | Usado para determinar quais bits  bloquear (0) ou passar (1) e  aplicado durante a operação de  mascaramento de saída.  |
| Destination DINT tag               |                      | Dados desaída a partir da matriz  de sequenciador. Esse valor é  usado na operação de  mascaramento de saída.           |
|                                    |                      | Control CONTROL tag estrutura de controle da operação  A mesma tag de controle deve ser  usada nas instruções SQI e SQL |
|                                    | Length DINT imediato | Número de elementos no Array  (tabela de sequenciador) para a  saída                                                    |
|                                    |                      | Position DINT imediato Posição atual na matriz  Valor inicial costuma ser 0.                                            |

## Estrutura de CONTROL

| Mnemônico           | Tipo de  dados    | Descrição                                                                                                               |
|---------------------|-------------------|-------------------------------------------------------------------------------------------------------------------------|
| .EN (Habilitar)     | BOOL              | O bite de habilitação indica que a instrução  SQO está habilitada.                                                      |
| .DN  (Executado)    | BOOL              | O bit executado é definido quando .POS =  .LEN                                                                          |
|                     |                   | .ER (Erro) BOOL Indica que a instrução encontrou um erro.                                                               |
| .LEN  (Comprimento) | DINT              | O comprimento especifica o número de  etapas de sequenciador na matriz de  sequenciador.                                |
| .POS (Posição) DINT |                   | A posição identifica o elemento de Array que  a instrução está usando atualmente na  operação de encobrimento de saída. |

## Descrição

Quando .EN realiza a transição de falso para verdadeiro, o .POS é incrementado. O .POS é restaurado para 1 quando .POS se torna maior ou igual a .LEN

Quando .EN é verdadeiro, a instrução SQO move os dados de Array no .POS através do Mask e, então, move o valor atual de Destination através do Mask complementado. Os resultados dessas operações são OU juntos e o resultado é armazenado no Destination.

<!-- image -->

Geralmente, você deve usar a mesma estrutura de CONTROL que as instruções SQI e SQL.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A               | ção realizada                                         |
|---------------------------------|-------------------------------------------------------|
| Pré-varredura                   | .EN é definido como verdadeiro.                       |
|                                 | Rung-condition-in é falsa .EN é eliminado para falso. |
| Rung-condition-in é  verdadeira | Consulte o seguinte Fluxograma (Verdadeiro)           |
| Pós-varredura N/A               |                                                       |

## Fluxograma (Verdadeiro)

<!-- image -->

## Exemplo

O valor de Mask é AND'd com o valor da matriz, por ex., Array[SqoControl.POS]. O complemento do valor de Mask é AND'd com o valor de Dest atual. Os resultados dessas duas operações são então OU juntos e o resultado é armazenado no Dest.

Para restaurar .POS para o valor inicial (.POS = 0), use uma instrução RES para eliminar a estrutura de controle. Esse exemplo usa o status do bit da primeira varredura para eliminar o valor de .POS.

<!-- image -->

## Consulte também

Instruções do sequenciador na página 605

SQI na página 606

SQL na página 610

Atributos comuns na página 879

Conversões de dados na página 883

## Instruções de controle do programa

Use as instruções de controle do programa para alterar o fluxo de lógica.

Instruções disponíveis

Diagrama ladder

JMP

LBL

UID

UIE

Bloco de funções

JSR

RET

Texto estruturado

JSR

RET

UIE

SFP

| Se você desejar:                                                                                        | Use esta instrução:    |
|---------------------------------------------------------------------------------------------------------|------------------------|
| Pular uma seção de lógica que não  precisa ser executada sempre.                                        | JMP  LBL               |
| Saltar para uma rotina separada,  passar dados para a rotina, executar  a rotina e retornar resultados. | JSR  SBR  RET          |
| Saltar para uma rotina externa. JXR                                                                     |                        |

JSR

SFR

SBR

SBR

JXR

SFP

TND

RET

EVENT

EVENT

SBR

AFI

UID

TND

EOT

EOT

MCR

NOP

SFR

## Instruções de controle do programa

| Marcar um final temporário que  interrompe a execução da rotina.    | TND    |
|---------------------------------------------------------------------|--------|
| Desabilitar todos os degraus em uma  seção de lógica                | MCR    |
| Desabilitar tarefas de usuário. UID                                 |        |
| Habilitar tarefas de usuário. UIE                                   |        |
| Pausar um gráfico de função  sequencial                             | SFP    |
| Restaurar um gráfico de função  sequencial                          | SFR    |
| Encerrar uma transição para um  gráfico de função sequencial        | EOT    |
| Disparar a execução de uma tarefa  de evento                        | EVENT  |
| Desabilitar um degrau                                               | AFI    |
| Inserir um espaço reservado na  lógica.                             | NOP    |

## Consulte também

Instruções de cálculo/matemáticas na página 369

Instruções de comparação na página 293

Instruções de bit na página 75

Instruções de string ASCII na página 825

Instruções de conversão ASCII na página 845

Use as instruções de controle do programa para alterar o fluxo de lógica.

## Instruções disponíveis

## Diagrama ladder

JMP

LBL

UID

UIE

## Bloco de funções

JSR

RET

JSR

SFR

SBR

JXR

SFP

RET

EVENT

SBR

AFI

TND

EOT

MCR

NOP

## Texto estruturado

| JSR    | RET    | SBR    | TND    | EVENT    | UID    | EOT    | SFR   |
|--------|--------|--------|--------|----------|--------|--------|-------|

UIE

SFP

| Se você desejar:                                                                                         | Use esta instrução:    |
|----------------------------------------------------------------------------------------------------------|------------------------|
| Pular uma seção de lógica que  não precisa ser executada sempre.                                         | JMP  LBL               |
| Saltar para uma rotina separada,  passar dados para a rotina,  executar a rotina e retornar  resultados. | JSR  SBR  RET          |
| Saltar para uma rotina externa. JXR                                                                      |                        |
| Marcar um final temporário que  interrompe a execução da rotina.                                         | TND                    |
| Desabilitar todos os degraus em  uma seção de lógica                                                     | MCR                    |
| Desabilitar tarefas de usuário. UID                                                                      |                        |
| Habilitar tarefas de usuário. UIE                                                                        |                        |
| Pausar um gráfico de função  sequencial                                                                  | SFP                    |
| Restaurar um gráfico de função  sequencial                                                               | SFR                    |
| Encerrar uma transição para um  gráfico de função sequencial                                             | EOT                    |
| Disparar a execução de uma tarefa  de evento                                                             | EVENT                  |
| Desabilitar um degrau                                                                                    | AFI                    |
| Inserir um espaço reservado na  lógica.                                                                  | NOP                    |

## Consulte também

Instruções de cálculo/matemáticas na página 369

Instruções de comparação na página 293

Instruções de bit na página 75

Instruções de string ASCII na página 825

Instruções de conversão ASCII na página 845
