---
type: Instruction
title: "Examinar se fechado (XIC)"
description: "A instrução XIC examine o bit de dados para definir ou eliminar a condição do degrau."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L1417-L1495"
---

## Examinar se fechado (XIC)

## Consulte também

Instruções de comparação na página 293

Instruções de cálculo/matemáticas na página 369

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução XIC examine o bit de dados para definir ou eliminar a condição do degrau.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Diagrama ladder

| Operando          | Tipo de  dados    | Formato Des crição    |                                                                                                                                                   |
|-------------------|-------------------|-----------------------|---------------------------------------------------------------------------------------------------------------------------------------------------|
| Data bit BOOL tag |                   |                       | Bit a ser testado. Há diversos modos  de endereçamento do operando  possíveis para o bit de dados,  consulte Endereçamento de bits para exemplos. |

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                                     |
|------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/A                  |                                                                                                                                                     |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como Rung-condition-in                                                                                                   |
| Rung-condition-in é  verdadeira    | Se DataBit for verdadeiro, rung-condition-out será  definida como verdadeira.  Se DataBit for falso, rung-condition-out será  eliminado para falso. |
| Pós-varredura N/A                  |                                                                                                                                                     |

## Exemplo 1

## Diagrama ladder

<!-- image -->

Se Limit\_Switch\_1 for verdadeiro, a próxima instrução será habilitada.

## Exemplo 2

## Diagrama ladder

<!-- image -->

Se S:V for verdadeiro (gerado por MOV),a próxima instrução será habilitada.

## Exemplo 3

## Diagrama ladder

<!-- image -->

Número LINT do acesso XIC

Tag Eixo\_04 ié um AXIS\_CIP\_DRIVE.
