---
type: Instruction
title: "Módulo (MOD)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L8937-L9128"
---

## Módulo (MOD)

## Função FBD

<!-- image -->

## Texto estruturado

DINT\_dst := DINT\_srcA / DINT\_srcB;

## Consulte também

Sintaxe de texto estruturado na página 912

Índice por meio de matrizes na página 893

Sinalizadores de status de operações matemáticas na página 879

Conversões de dados na página 883

Valores imediatos na página 882

Funções FBD na página 425

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

Quando habilitada, a instrução MOD e o operador dividem Source A por Source B e colocam o resto no Dest. Isso é feito usando o algoritmo:

Dest = Source A – (truncar ( Source A / Source B) * Source B)

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

O Diagrama do bloco de funções suporta esses elementos:

## Bloco FBD

Função FBD

<!-- image -->

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

<!-- image -->

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

Dica:

Use MOD como um operador em uma expressão para obter o mesmo resultado. Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões e atribuições no texto estruturado.

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                    |
|----------------|---------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                        |
|                |   Membros de um operando de estrutura estão  substituídos.                                             |
|                |   Exceto quanto especificado, os operandos da  estrutura são compartilhados por múltiplas  instruções. |

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados .

## Diagrama ladder

Esses são os operandos para Diagrama ladder.

| Operando  Tipo de dados  (Data Type)                                                                  | Tipo de dados  (Data Type)                                                                                              | Format         | Descrição  (Description)                    |
|-------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------|----------------|---------------------------------------------|
| Controladores  CompactLogix  5370,  ControlLogix  5570, Compact  GuardLogix  5370 e  GuardLogix  5570 | Controladores  CompactLogix  5380,  CompactLogix  5480, ControlLogix  5580, Compact  GuardLogix 5380 e  GuardLogix 5580 |                |                                             |
| Source A SINT  INT  DINT  REAL                                                                        | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                           | immediate  tag | Valor do  dividendo.                        |
| Source B SINT  INT  DINT  REAL                                                                        | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                           | immediate  tag | Valor do divisor.                           |
| Dest SINT  INT  DINT  REAL                                                                            | SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL                                                           | tag            | Tag a armazenar  o resultado da  instrução. |

## Diagrama de bloco da função

## Bloco FBD

| Operando    | Tipo de dados  (Data Type)    | Format    | Descrição  (Description)          |
|-------------|-------------------------------|-----------|-----------------------------------|
|             |                               |           | MOD FBD_MATH tag Estrutura de MOD |

Estrutura de FBD\_MATH

| Membros de  entradas    | Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                 |
|-------------------------|-------------------------------|-------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL           |                               | Entrada Habilitar. Se falso, a  instrução não será executada e  as saídas não serão  atualizadas.  Padrão é verdadeiro. |
| SourceA REAL            |                               | Valor do dividendo.                                                                                                     |
| SourceB REAL            |                               | Valor do divisor.                                                                                                       |

| Membros de  saída    | Tipo de dados  (Data Type)    | Descrição (Description)                                             |
|----------------------|-------------------------------|---------------------------------------------------------------------|
| EnableOut BOOL       |                               | Indica se a instrução foi  executada sem falhas ao ser  habilitada. |
|                      |                               | Dest REAL Resultado da instrução.                                   |

## Função FBD

Dica: A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Operandos de  entrada (pinos  esquerdos)    | Tipo de dados (Data Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix 5380  e GuardLogix 5580    | Descrição  (Description)    |
|---------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
| SourceA (topo) SINT                         | USINT  INT  UINT  DINT  UDINT  LINT  ULINT  REAL  LREAL                                                                                             | Valor do  dividendo.        |

| SourceB (fundo) SINT  USINT  INT  UINT  DINT  UDINT  LINT  ULINT  REAL  LREAL    | Valor do divisor    |
|----------------------------------------------------------------------------------|---------------------|

| Operando de  saída (Pino  direito)    | Tipo de dados (Data Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix 5380  e GuardLogix 5580    | Descrição  (Description)    |
|---------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
|                                       | Dest DINT  UDINT  LINT  ULINT  REAL  LREAL                                                                                                          | Resultado da  função.       |

Consulte Funções FBD .

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                         | Afeta sinalizadores de status de  operações matemáticas    |
|-----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580 | Condicional                                                |
| Controladores  CompactLogix 5370,  ControlLogix 5570,  Compact GuardLogix  5370 e GuardLogix 5570                     | Sim                                                        |

Consulte Sinalizadores de status de operações matemáticas .

## Falhas maiores/menores

| Uma falha menor  ocorrerá se:    |    |   Tipo de falha Código de falha  |
|----------------------------------|----|----------------------------------|
| Source B = 0                     |  4 |                                4 |

Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                            |
|------------------------------------|----------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                            |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como  Rung-condition-in                                                                         |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como  Rung-condition-in  Dest é definido (para o resto)  conforme descrito na seção  Descrição. |
| Pós-varredura N/D                  |                                                                                                                            |

Diagrama de bloco da função

## Bloco FBD

| Condição/estado A ção realizada    |                                                                                                                                                                                           |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                                                                                                           |
|                                    | EnableIn é falso Defina EnableOut como EnableIn                                                                                                                                           |
| EnableIn é verdadeiro              | Dest é definido (para o resto)  conforme descrito na seção  Descrição.  Se ocorrer um transbordamento  Elimina EnableOut para falso  Caso contrário  Configure EnableOut para  verdadeiro |
| Primeira execução da  instrução    | N/D                                                                                                                                                                                       |
| Primeira varredura da  instrução   | N/D                                                                                                                                                                                       |
| Pós-varredura N/D                  |                                                                                                                                                                                           |

## Função FBD

Dica:

A função FBD é aplicável apenas a Controladores CompactLogix 5380, CompactLogix 5480, ControlLogix 5580, Compact GuardLogix 5380 e GuardLogix 5580.

| Condição/estado A ção realizada    |                                                                        |
|------------------------------------|------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                        |
| Varredura normal                   | Dest é definido (para o resto)  conforme descrito na seção  Descrição. |
| Primeira execução da  instrução    | N/D                                                                    |
| Primeira varredura da  instrução   | N/D                                                                    |
| Pós-varredura N/D                  |                                                                        |

Dica:

Se Source B for 0, o resultado será 0 e uma falha menor será gerada.

## Exemplos

## Diagrama ladder

<!-- image -->

Dividir o dividendo pelo divisor e colocar o resto no resto. Neste exemplo, 3 vai em 10, três vezes, com um resto de 1.

## Diagrama de bloco da função

## Bloco FBD

<!-- image -->
