---
type: Instruction
title: "Preencher arquivo (FLL)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L12607-L12698"
---

## Preencher arquivo (FLL)

## Exemplo 2

<!-- image -->

## Diagrama ladder

<!-- image -->

## Consulte também

Atributos comuns na página 879

Sinalizadores de status de operações matemáticas na página 879

Conversões de dados na página 883

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução FLL preenche um bloco de memória com o valor de origem fornecido. A Source permanece inalterada.

Se a matriz de destino for SINT, INT, DINT ou REAL e o tipo do valor de origem for diferente, o valor de origem será convertido no tipo de destino antes de ser armazenado. Tipos inteiros menores serão convertidos em os maiores por extensão de sinal.

Se a matriz de destino for uma estrutura, o valor de origem será gravado sem conversão.

<!-- image -->

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

Existem regras de conversão de dados para misturar tipos de dados numéricos em uma instrução. Consulte Conversões de dados.

## Diagrama ladder

| Operando  Tipo de  dados                     | Formato Des crição    |                                                  |
|----------------------------------------------|-----------------------|--------------------------------------------------|
| Source SINT  INT  DINT  REAL                 | imediato  tag         | Elemento a copiar                                |
| Destination SINT  INT  DINT  REAL  estrutura | tag                   | Elemento inicial a ser  substituído  por Origem. |
| Length DINT  INT  SINT                       | imediato  tag         | Número de elementos  de destino a  preencher.    |

O número de bytes preenchidos é o menor de:

-  Valor solicitado = Length x (número de bytes em um elemento de destino)
-  O número de bytes na tag de destino

Dica:

O fim da tag de destino é definido como o último byte da tag base. Se a tag for uma estrutura, o final da tag será o último byte do último elemento da estrutura. Isso significa que a instrução FLL poderia gravar além do fim de uma matriz do membro, mas nunca gravaria além da tag base. Teste e confirme que a instrução FLL não altera dados que não devem ser alterados.

Para melhores resultados, a Source e o Destination devem ser do mesmo tipo. Use FLL para preencher uma estrutura com uma constante, como 0s.

Se estiver inicializando uma estrutura, verifique se há uma instância contendo os valores iniciais e use COP para replicá-la. FLL pode ser usado, por exemplo, zerar toda a estrutura.

| Se a origem for: E o Destination erá:    | A Source é  convertida em:    |
|------------------------------------------|-------------------------------|
| SINT, INT, DINT ou  REAL                 | SINT SINT                     |
| SINT, INT, DINT ou  REAL                 | INT INT                       |
| SINT, INT, DINT ou  REAL                 | DINT DINT                     |
| SINT, INT, DINT ou  REAL                 | REAL REAL                     |

Conversão de inteiros maiores para inteiros menores resultará em truncamento (os bits altos são descartados). Quando a origem é convertida, ela é gravada no destino N vezes, em que N = contagem de bytes. Resultados da extensão de sinal ao converter de inteiros menores para inteiros maiores. Números REAL serão arredondados quando convertidos em inteiros.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.
