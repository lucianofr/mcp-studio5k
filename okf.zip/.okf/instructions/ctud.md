---
type: Instruction
title: "Contagem crescente/decrescente (CTUD)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L2496-L2612"
---

## Contagem crescente/decrescente (CTUD)

## Exemplo

## Diagrama ladder

<!-- image -->

Após limit\_switch\_1 ir de desabilitado para habilitado 10 vezes, o bit .DN bit será definido como verdadeiro e light\_1 acende Se limit\_switch\_1 continuar a ir de desabilitado para habilitado, o counter\_1 continuará a incrementar a sua contagem e o bit .DN permanecerá definido. Quando limit\_switch\_2 estiver habilitado, a instrução RES restaura o counter\_1 (elimina os bits de status e o valor .ACC) e light\_1 apaga.

## Consulte também

Indexação por meio de matrizes na página 893

Instruções do contador na página 103

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução CTUD faz a contagem crescente por um quando CUEnable realiza a transição de eliminado para definido. A instrução faz a contagem decrescente em um quando CDEnable realiza a transição de eliminado para definido.

## Idiomas disponíveis

## Diagrama ladder

Esta instrução não está disponível no diagrama ladder.

## Bloco de funções

<!-- image -->

## Texto estruturado

CTUD(CTUD\_tag)

## Operandos

## Texto estruturado

| Variável Tipo                  | Formato Descrição    |
|--------------------------------|----------------------|
| CTUD tag FBD_COUNTER Estrutura | Estrutura de  CTUD   |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Bloco de funções

| Operando Tipo                  | Formato Descrição    |
|--------------------------------|----------------------|
| CTUD tag FBD_COUNTER Estrutura | Estrutura de  CTUD   |

## Estrutura de FBD\_COUNTER

| Parâmetro  de entrada    | Tipo de  dados    | Descrição                                                                                                                                              |
|--------------------------|-------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------|
| EnableIn BOOL            |                   | Se eliminado, a instrução não é  executada e as saídas não são  atualizadas. Se definido, a instrução é  executada.  Padrão é definido.                |
| CUEnable BOOL            |                   | Habilitar contagem crescente Quando  a entrada alterna de eliminado para  definido, o acumulador faz a  contagem crescente em um.  Padrão é eliminado. |

| CDEnable BOOL    | Habilitar contagem decrescente.  Quando a entrada alterna de  eliminado para definido, o acumulador  faz a contagem decrescente em um.  Padrão é eliminado    |
|------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| PRE DINT         | Valor predefinido da contagem. Esse  é o valor que o valor acumulado  alcança antes de DN ser definido.  Válido= qualquer inteiro  Padrão é 0                 |
| Reset BOOL       | Solicitar para restaurar o  temporizador. Quando definido, o  contador é restaurado.  Padrão é eliminado.                                                     |

| Parâmetro  de saída    | Tipo de  dados    | Descrição                                                                                                                                                                                       |
|------------------------|-------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| EnableOut BOOL         |                   | A instrução produziu um resultado  válido.                                                                                                                                                      |
|                        |                   | ACC DINT Valor acumulado.                                                                                                                                                                       |
| CU                     |                   | BOOL Contagem crescente habilitada.                                                                                                                                                             |
| CD                     |                   | BOOL Contagem decrescente habilitada.                                                                                                                                                           |
|                        | DN BOOL           | Contagem feita. Definir quando o  valor acumulado for maior ou igual ao  predefinido.                                                                                                           |
|                        | OV BOOL           | Transbordamento do contador. Indica  que o contador excedeu o limite  superior de 2,147,483,647. O  contador então sobrescreve até  -2.147.483.648 e começa a contagem  decrescente novamente.  |
|                        | UN BOOL           | Estouro negativo do contador. Indica  que o contador excedeu o limite  inferior de -2.147.483.648. O contador  então sobrescreve até 2.147.483.647  e começa a contagem decrescente  novamente. |

## Descrição

Quando verdadeiro e CUEnable for verdadeiro, as instruções CTUD incrementam o contador em um. Quando verdadeiro e CDEnable for verdadeiro, a instrução CTUD diminui o contador em um.

Os dois parâmetros de entrada CUEnable e CDEnable podem ser alternados durante a mesma varredura. A instrução executa a contagem crescente antes da contagem decrescente.

## Contagem crescente

<!-- image -->

Quando desativada, a instrução CTUD retém seu valor acumulado. Defina o parâmetro de entrada Reset para restaurar a instrução.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

Execução Bloco de funções

| Condição/estado A ção realizada    |                                                                                                                                                                   |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                                                          |
| Tag.EnableIn é falso               | Os bits EnableIn e EnableOut são  eliminados para falso. Inicializar dados  para exigir uma transição "zero para um"  de CuEnable ou CdEnable para efetivar  ACC. |
| Tag.EnableIn é  verdadeiro         | Os bits EnableIn e EnableOut são  definidos para verdadeiro.  A instrução é executada.                                                                            |
| Primeira execução  da instrução    | Inicializar dados para exigir uma transição  "zero para um" de CuEnable ou CdEnable  para efetivar ACC.                                                           |
| Primeira varredura  da instrução   | Inicializar dados para exigir uma transição  "zero para um" de CuEnable ou CdEnable  para efetivar ACC.                                                           |
| Pós-varredura                      | Os bits EnableIn e EnableOut são  eliminados para falso.                                                                                                          |

## Texto estruturado

| Condição/estado A ção realizada    |                                                                    |
|------------------------------------|--------------------------------------------------------------------|
| Pré-varredura                      | Consulte Pré-varredura na tabela de Bloco  de funções.             |
| Execução normal                    | Consulte Tag.EnableIn é verdadeiro na  tabela de Bloco de funções. |
| Pós-varredura                      | Consulte Pós-varredura na tabela de Bloco  de funções.             |

## Exemplo

## Bloco de funções

<!-- image -->
