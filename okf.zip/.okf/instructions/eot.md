---
type: Instruction
title: "Fim de transição (EOT)"
description: "Todas as condições abaixo da linha sólida grossa só podem ocorrer durante o modo Varredura normal."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L14762-L14838"
---

## Fim de transição (EOT)

## Execução

Todas as condições abaixo da linha sólida grossa só podem ocorrer durante o modo Varredura normal.

| Condição A                      | ção                                                     |
|---------------------------------|---------------------------------------------------------|
| Pré-varredura N/A               |                                                         |
|                                 | Rung-condition-in é falsa Elimina EnableOut para falso. |
| Rung-condition-in é  verdadeira | Elimina EnableOut para falso.                           |
| Pós-varredura N/A               |                                                         |

## Exemplos

## Diagrama ladder

Use a instrução AFI para temporariamente desabilitar um degrau enquanto você está depurando um programa. AFI desabilita todas as instruções nesse degrau.

<!-- image -->

## Consulte também

Instruções de controle do programa na página 620

Controle de restauração principal (MCR) na página 642

Nenhuma operação (NOP) na página 646

Fim temporário (TND) na página 652

Atributos comuns na página 879

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução EOT é usada para definir o estado de uma transição. Normalmente ocorre em uma subrotina chamada de uma transição (JSR). O parâmetro state bit usado em EOT determina o estado da Transição. Se o state bit for definido como verdadeiro, o SFC realizará transição para o próximo estado, caso contrário, EOT atuará como NOP.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

EOT(StateBit);

## Operandos

## Diagrama ladder

| Operando Tipo Formato Descrição    | Operando Tipo Formato Descrição                  |
|------------------------------------|--------------------------------------------------|
| State Bit BOOL tag                 | estado da transição  (0=executando, 1=concluído) |

## Texto estruturado

| Operando Tipo Formato Descrição    | Operando Tipo Formato Descrição                  |
|------------------------------------|--------------------------------------------------|
| State Bit BOOL tag                 | estado da transição  (0=executando, 1=concluído) |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Descrição

Como a instrução EOT retorna um estado booliano, múltiplas rotinas SFC podem compartilhar a mesma rotina que contém a instrução EOT. Se a rotina de chamada não for uma transição, a instrução EOT age como uma instrução NOP.

Em um controlador Logix, o parâmetro de retorno retorna o estado da transição, pois a condição do degrau não está disponível em todas as linguagens de programação do Logix.

## Afeta sinalizadores de status de operações matemáticas

Não
