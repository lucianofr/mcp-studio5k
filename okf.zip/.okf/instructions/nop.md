---
type: Instruction
title: "Nenhuma operação (NOP)"
description: "A instrução NOP funciona como um espaço reservado."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L15339-L15376"
---

## Nenhuma operação (NOP)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução NOP funciona como um espaço reservado.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Diagrama ladder

Nenhum

## Descrição

Você pode colocar a instrução NOP em qualquer lugar em um degrau. Quando habilitada, a instrução NOP não realiza operações. Quando desabilitada, a instrução NOP não realiza operações.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.
