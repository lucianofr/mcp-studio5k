---
type: Instruction
title: "Trava de saída (OTL)"
description: "Sintaxe de texto estruturado na página 912"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L2095-L2165"
---

## Trava de saída (OTL)

## Consulte também

Sintaxe de texto estruturado na página 912

Instruções de bit na página 75

Endereçamento de bit na página 894

Indexação por meio de matrizes na página 893

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução OTL define (trava) o bit de dados.

## Idiomas disponíveis

Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

## Diagrama ladder

| Operando          | Tipo de dados  (Data Type)    | Format    | Descrição  (Description)                                                                                                                                 |
|-------------------|-------------------------------|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------|
| Data bit BOOL tag |                               |           | Bit a ser modificado.  Há diversos modos  de endereçamento  do operando  possíveis para o bit  de dados, consulte  Endereçamento de  bits para exemplos. |

## Descrição (Description)

Quando a condição do degrau for verdadeira, a instrução OTL definirá o bit de dados como verdadeiro. O bit de dados permanece verdadeiro até que seja restaurado, geralmente por uma instrução OTU. Quando a condição do degrau é alterada para falso, a instrução OTL não muda o status do bit de dados.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

ParaControllers Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580, se o operando for uma referência indireta ao matriz e o subscrito estiver fora da faixa, então o controlador não gerará uma falha maior quando a instrução OTL for falsa.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                  |
|------------------------------------|--------------------------------------------------------------------------------------------------|
| Pré-varredura N/D                  |                                                                                                  |
| Rung-condition-in é  falsa         | Definir Rung-condition-out  como Rung-condition-in.                                              |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out  como Rung-condition-in.  O bit de dados é definido como  verdadeiro. |
| Pós-varredura N/D                  |                                                                                                  |
