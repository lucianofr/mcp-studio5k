---
type: Instruction
title: "Desvio padrão do arquivo (STD)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L13102-L13227"
---

## Desvio padrão do arquivo (STD)

## Diagrama ladder

<!-- image -->

## Texto estruturado

```
ctrl.LEN := 4; ctrl.POS := 0; SRT(DINT_array[0,2],0, ctrl);
```

## Consulte também

Instruções de arquivo/diversas na página 493

Média de arquivo (AVE) na página 520

Conversões de dados na página 883

Atributos comuns na página 879

Sintaxe de texto estruturado na página 912

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução STD calcula o desvio padrão de um conjunto de valores em uma dimensão da Array e armazena o resultado no Destination.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução. Consulte Conversão de dados.

## Diagrama ladder

| Operando                            |                  |                        | Tipo (Type) Format Descrição (Description)                                                                                                     |
|-------------------------------------|------------------|------------------------|------------------------------------------------------------------------------------------------------------------------------------------------|
| Matriz SINT                         | INT:  DINT  REAL | tag de matriz          | Encontrar o desvio padrão dos  valores nessa matriz  especifica o primeiro elemento do  grupo de elementos a usar no  cálculo do desvio padrão |
| Dimensão para variar DINT immediate |                  | (0, 1, 2)              | quais dimensões usar  a ordem das dimensões é:  matriz[0,1,2]                                                                                  |
| Destination                         | REAL tag         |                        | resultado da operação                                                                                                                          |
|                                     | Controle CONTROL |                        | tag Estrutura de controle da operação                                                                                                          |
| Comprimento  (Length)               |                  | DINT immediate         | número de elementos da matriz a  usar no cálculo do desvio padrão                                                                              |
|                                     |                  | Somente DINT immediate | Deslocamento para a matriz  especificada que identifica o  elemento atual que a instrução  está acessando.  o valor inicial costuma ser 0      |

## Estrutura de CONTROL

| Mnemônico  Tipo de dados  (Data Type)    | Descrição (Description)                                                                                                                                                                                                      |
|------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| .EN BOOL                                 | O bite de habilitação indica que a instrução STD está  habilitada.                                                                                                                                                           |
| .DN BOOL                                 | O bit executado é definido quando a instrução operou no  último elemento em Array.                                                                                                                                           |
| .ER BOOL                                 | O bit de erro é definido quando a instrução gera um  transbordamento. A instrução para de ser executada até que  o programa elimine o bit .ER. O valor de .POS armazena a  posição do elemento que causou o transbordamento. |
| .LEN DINT                                | A palavra de comprimento especifica o número de  elementos na matriz em que a instrução opera.                                                                                                                               |
| .POS DINT                                | A palavra de posição é um deslocamento para a matriz  especificada, que identifica o elemento atual que a instrução  está acessando.                                                                                         |

## Descrição (Description)

O desvio padrão é calculado de acordo com esta fórmula:

Onde:

start = subscrito da dimensão para variar do operando da matriz

xi = elemento variável na matriz

N = número de elementos especificados na matriz

AVE =

Importante:

O Length não deve fazer a instrução exceder a Dimension to vary especificada. Se isso acontecer, o Destination estará incorreto.

Se ocorrer um transbordamento durante a avaliação da expressão ou se as instruções lerem além do fim de uma matriz, a instrução definirá o bit ER e interromperá a execução.

## Afeta sinalizadores de status de operações matemáticas

| Controladores                                                                                                        | Afeta sinalizadores de status de  operações matemáticas                                                          |
|----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------|
| Controladores CompactLogix  5380, CompactLogix 5480,  ControlLogix 5580, Compact  GuardLogix 5380 e GuardLogix  5580 | Condicional, com base na  linguagem de programação.  Consulte Sinalizadores de status  de operações matemáticas. |
| Controladores CompactLogix  5370, ControlLogix 5570,  Compact GuardLogix 5370 e  GuardLogix 5570                     | Sim                                                                                                              |

## Falhas maiores/menores

| Uma falha maior ocorrerá se:             |   Tipo de  falha  | Código de  falha    |
|------------------------------------------|-------------------|---------------------|
| .POS <0 ou .LEN <0                       |                 4 | 21                  |
| Dimension to vary > número de  dimensões |                   | 4 20                |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                                              |
|------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | O bit .EN será eliminado.  O bit .DN será eliminado.  O bit .ER será eliminado.                                                              |
| Rung-condition-in é falsa          | O bit .EN será eliminado.  O bit .ER será eliminado.  O bit .DN será eliminado.  O valor de .POS é eliminado.  A rung-condition-out é falsa. |
| Rung-condition-in é  verdadeira    | Internamente, a instrução usa a  instrução FAL para calcular a média:  Expressão = cálculo do desvio padrão  Modo = TUDO                     |
| Pós-varredura N/A.                 |                                                                                                                                              |

## Exemplos

## Exemplo 1

Calcular o desvio padrão de arrayDint, que é DINT[4,5].

<!-- image -->

## Diagrama ladder

<!-- image -->
