---
type: Instruction
title: "Transição de dados (DTR)"
description: "A instrução DTR passa o valor de Source através de uma Mask e compara o resultado com o valor de Reference."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L16357-L16455"
---

## Transição de dados (DTR)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução DTR passa o valor de Source através de uma Mask e compara o resultado com o valor de Reference.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Diagrama ladder

| Operando Tipo (Type) Format    |                            | Descrição  (Description)           |
|--------------------------------|----------------------------|------------------------------------|
|                                | Origem DINT immediate tag  | matriz para comparar à  referência |
|                                | Máscara DINT immediate tag | que bits para bloquear  ou passar  |
| Referência DINT tag            |                            | matriz para comparar à  origem     |

## Descrição (Description)

A instrução DTR passa o valor de Source através de uma Mask e compara o resultado com o valor de Reference. A instrução DTR também grava o valor de Source mascarada no valor de Reference para a próxima comparação. A Source permanece inalterada.

Um "1" na máscara significa que o bit de dados passa. Um "0" na máscara significa que o bit de dados será bloqueado.

Quando habilitada, a Mask passa dados quando os bits de Mask forem definidos; a máscara bloqueia dados quando os bits de Mask forem eliminados.

Quando a Source mascarada é diferente de Reference, EnableOut passa para verdadeiro para uma varredura. Quando a Source mascarada é o mesmo que Reference, EnableOut é falso.

Importante:

A programação online com essa instrução pode ser perigosa. Se o valor de Reference é diferente do valor de Source, EnableOut passa para verdadeiro. Tenha cuidado se você inserir essa instrução quando o processador estiver no modo de Execução ou Execução Remota.

## Inserindo um valor imediato de máscara

Quando você insere uma máscara, o software de programação usa valores decimais como padrão. Se você quiser inserir uma máscara usando outro formato, preceda o valor com o prefixo correto.

| Prefixo Des crição (Description)       |
|----------------------------------------|
| 16# hexadecimal (por exemplo, 16#0F0F) |
| 8# Octal (por exemplo, 8#16)           |
| 2# Binário (por exemplo, 2#00110011)   |

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

|                                 | Condition A ção (Action)                     |
|---------------------------------|----------------------------------------------|
|                                 | Pré-varredura O Reference = Source AND Mask. |
| Rung-condition-in  é falsa      | O Reference = Source AND Mask.               |
| Rung-condition-in  é verdadeira | Consulte o fluxograma DTR (Verdadeiro)       |
| Pós-varredura N/D               |                                              |

## Fluxograma DTR (verdadeiro)

<!-- image -->

## Exemplo

## Diagrama ladder

<!-- image -->

Quando habilitada, a instrução DTR mascara value\_1. Se houver uma diferença nos dois valores mascarados, EnableOut é definido como verdadeiro.

<!-- image -->

No exemplo 1, como o valor de referência é igual a sourcevalue\_1 AND máscara, EnableOut sempre será definido como falso. No exemplo 2, por algum motivo, o valor de origem é alterado, então reference\_value não é igual a source\_value AND máscara, por isso, nesse caso, EnableOut será definido como VERDADEIRO e referencevalue será atualizado com base em sourceValue e máscara. É por isso que você vê em varreduras prévias que o valor de referência é 183, mas a varredura atual é 187. O degrau permanece verdadeiro apenas para uma varredura quando uma alteração é detectada porque na próxima varredura, contanto que a origem não seja alterada, o degrau permanecerá falso porque o valor de referência será igual ao valor de origem AND máscara novamente.

## Consulte também

Instruções especiais na página 679

FBC na página 692

DDT na página 684

Atributos comuns na página 879
