---
type: Instruction
title: "Sempre falso (AFI)"
description: "A instrução AFI define EnableOut para falso."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L14724-L14761"
---

## Sempre falso (AFI)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução AFI define EnableOut para falso.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

## Diagrama ladder

Nenhum

## Descrição

A instrução AFI define seu EnableOut para falso.

## Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando
