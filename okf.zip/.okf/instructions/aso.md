---
type: Instruction
title: "Operação de definição de alarme (ASO)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L1280-L1416"
---

## Operação de definição de alarme (ASO)

<!-- image -->

Essas informações aplicam-se aos controladores Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução de Operação de definição de alarme emite uma operação especificada a todas as condições de alarme da definição do alarme especificado. A instrução de Operação de definição de alarme é usada para iniciar a execução assíncrona de uma operação de alarme para todas as condições de alarme da definição do alarme especificado. A instrução itera pelas condições de alarme da definição do alarme especificado e define um sinalizador interno solicitando a execução da operação para cada uma das condições. Os sinalizadores internos têm o mesmo propósito e prioridade que os bits Progxxx acessíveis pelo usuário existentes e serão processados por todas as condições de alarme da definição do alarme especificado durante a próxima avaliação periódica de cada condição de alarme em particular da definição.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Diagrama de bloco da função

Essa instrução não está disponível no Diagrama de bloco de funções.

## Texto estruturado

ASO (Definição de alarme, Controle de definição de alarme, Operação)

## Operandos

## Importante:

Operação inesperada pode ocorrer se:

-  A mesma tag (ALARM\_SET\_CONTROL) é usada como parâmetro para mais de uma invocação da instrução.
-  O membro da estrutura de .LastState é modificado por um programa de aplicação do usuário.

ATENÇÃO: a estrutura de Controle de definição de alarme contém informações sobre o estado interno. Se qualquer um dos operandos de configuração forem alterados durante o modo de execução, aceite as edições pendentes e reinicie o modo do controlador de Programa a ser executado para que as alterações entrem em vigor.

A tabela seguinte fornece os operandos usados para configurar a instrução.

| Operando                          | Tipo de dados (Data  Type)    |           | Format Des crição (Description)                                                                                                                                                                                                                                                                                                                         |
|-----------------------------------|-------------------------------|-----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Definição de  alarme              | ALARM_SET AlarmSet            |           | A estrutura de ALARM_SET representa  condições de alarme operadas por esta  instrução.                                                                                                                                                                                                                                                                  |
| Controle de  definição de  alarme | ALARM_SET_CONTROL tag         |           | Esse tipo de dados contém três sinalizadores  BOOL:    EnableIn    EnableOut    LastState  A instrução reage à borda (transição de  .EnableIn de falso para verdadeiro), em vez do  nível.  EnableOut está sempre definido como  .EnableIn.  A solicitação para realizar a operação da  instrução tem a mesma prioridade que  sinalizadores ProgXXX. |
| Operação                          |                               | immediate | Esse operando pode ser selecionado na lista  ou inserido como um valor inteiro:  0 – Confirmar  1 – Restaurar  2 – Habilitar  3 – Desabilitar  4 – Cancelar adiamento  5 – Suprimir  6 – Cancelar supressão  7 – ResetAlarmCount                                                                                                                        |

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Índice por meio de matrizes para conhecer falhas de índice de matrizes.

## Execução

| Condição/estado A              | ção realizada                                                                                                                                                                                            |
|--------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                  | A instrução elimina todos os membros da estrutura de  ALARM_SET.                                                                                                                                         |
| Rung-condition-in é falsa      | A instrução elimina os membros da estrutura de .EnableOut  e .LastState.                                                                                                                                 |
| Rung-condition-in é verdadeira | Se .LastState for falso, então a instrução iniciará a operação  e definirá o membro da estrutura de .LastState como  verdadeiro. O membro da estrutura de .EnableOut é sempre  definido como verdadeiro. |
| Pós-varredura                  | A instrução elimina todos os membros da estrutura de  ALARM_SET.                                                                                                                                         |

## Operação

A instrução Operação de definição de alarme inicia de modo assíncrono a execução de uma das seguintes operações de alarme na definição do alarme especificado:

-  Confirmar
-  Restaurar
-  Habilitar
-  Desabilitado
-  Cancelar adiamento
-  Suprimir
-  Cancelar supressão
-  ResetAlarmCount

A instrução itera em todas as condições de alarme incluídas na definição do alarme especificado ou nas definições do alarme aninhado para definir um sinalizador interno representando a solicitação para executar a operação necessária em uma condição de alarme em particular. A operação é iniciada para todas as condições de alarme iteradas pela instrução com as seguintes exceções:

-  Condições de alarme configuradas não têm suporte para operações de alarme
-  Condições de alarme configuradas como não usadas

Quando uma operação de alarme é iniciada para uma condição de alarme em particular pela instrução, a operação é realizada durante a próxima avaliação periódica da condição de alarme.

Quando a instrução é chamada várias vezes para a mesma Definição do alarme para iniciar operações de alarme contraditórias, a última operação solicitada sempre é aplicada a todas as condições de alarme na Definição do alarme. As operações do alarme iniciadas para a Definição do alarme poderão ser aplicadas às condições antes que a última operação solicitada seja realizada.

Quando a Condição de alarme é avaliada periodicamente, as solicitações para realizar operações de alarme em particular têm a mesma prioridade que as solicitações para realizar operações de alarme iniciadas por meio de sinalizadores Progxxx acessíveis ao usuário. Significa que, se uma solicitação para realizar uma operação de alarme for gerada pela instrução, ela será tratada como se o sinalizador Progxxx correspondente estivesse definido e as mesmas regras usadas para resolver solicitações conflitantes especificadas para sinalizadores ProgXXX fossem usadas para resolver conflitos entre solicitações de instrução e solicitações feitas por meio de sinalizadores Progxxx.

A instrução da Operação de definição de alarme inicia a operação de alarme necessária somente quando detecta a transição do valor .EnableIn de falso para verdadeiro. Para detectar a transição, o membro da estrutura de .LastState é usado para armazenar o valor .EnableIn da execução da instrução anterior. Veja a seção Execução acima.

Dica: Se a Definição do alarme fornecida como um parâmetro de instrução contiver um número excessivo de condições de alarme, o tempo de execução da instrução ASO poderá aumentar significativamente.

## Consulte também

Instruções de alarmes na página 27

Índice por meio de matrizes na página 893

## Instruções de bit

## Instruções de bit

Use as instruções de bit (tipo de relé) para monitorar e controlar o status dos bits como, por exemplo, bits de entrada ou bits de palavra de controle do temporizador.

## Instruções disponíveis

## Diagrama ladder

XIC

XIO

OTE

OTL

## Bloco de funções e Texto estruturado

OSRI

OSFI

| Se você desejar:                                                                                           | Use esta instrução:    |
|------------------------------------------------------------------------------------------------------------|------------------------|
| Habilitar as saídas quando um bit for  definido                                                            | XIC                    |
| Habilitar as saídas quando um bit for  eliminado                                                           | XIO                    |
| definir um bit                                                                                             | OTE                    |
| definir um bit (retentivo)                                                                                 | OTL                    |
| Eliminar um bit (retentivo)                                                                                | OTU                    |
| Habilitar as saídas para uma  varredura todas as vezes que um  degrau for para verdadeiro                  | ONS                    |
| definir um bit para uma varredura  todas as vezes que um degrau for  para verdadeiro                       | OSR                    |
| definir um bit para uma varredura  todas as vezes que o degrau for para  falso                             | OSF                    |
| definir um bit para uma varredura  todas as vezes que um bit de entrada  for definido no bloco de funções  | OSRI                   |
| definir um bit para uma varredura  todas as vezes que um bit de entrada  for eliminado no bloco de funções | OSFI                   |

OTU

ONS

OSR

OSF
