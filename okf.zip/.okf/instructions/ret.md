---
type: Instruction
title: "Saltar para subrotina (JSR), Subrotina (SBR) e Retornar (RET)"
description: "A instrução JSR invoca outra rotina."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L16136-L16356"
---

## Saltar para subrotina (JSR), Subrotina (SBR) e Retornar (RET)

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução JSR invoca outra rotina. Quando essa routine é concluída, a execução retorna para a instrução JSR.

A instrução SBR recebe os parâmetros de entrada passados pela JSR.

A instrução RET passa os parâmetros de retorno de volta para JSR e termina a varredura da subrotina.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Diagrama de função sequencial

<!-- image -->

## Texto estruturado

JSR(RoutineName,InputCount,InputPar,ReturnPar);

SBR(InputPar);

RET(ReturnPar);

## Operandos

## Importante:

Operação inesperada pode ocorrer se:

-  Operandos da tag de saída estão substituídos.
-  Membros de um operando de estrutura estão substituídos.
-  Exceto quanto especificado, os operandos da estrutura são compartilhados por múltiplas instruções.

<!-- image -->

Para cada parâmetro em uma instrução SBR ou RET, use o mesmo tipo de dados (incluindo quaisquer dimensões de matrizes) como o parâmetro correspondente na instrução JSR. Usar diferentes tipos de dados pode produzir resultados inesperados.

## Diagrama ladder

## Instrução de JSR

| Operando             | Tipo de dados  (Data Type)  Controladores  CompactLogix  5370, ControlLogix  5570, Compact  GuardLogix 5370 e  GuardLogix 5570    | Tipo de dados (Data  Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580    | Format    | Descrição  (Description)    |
|----------------------|-----------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|-----------|-----------------------------|
| Routine Name ROUTINE |                                                                                                                                   | ROUTINE                                                                                                                                              |           | nome Subrotina a executar   |

| Operando  Tipo de dados  (Data Type)  Controladores  CompactLogix  5370, ControlLogix  5570, Compact  GuardLogix 5370 e  GuardLogix 5570    | Tipo de dados (Data  Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580    | Format                         | Descrição  (Description)                                                                                                                                                            |
|---------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Input Par BOOL  SINT  INT  DINT  REAL  estrutura                                                                                            | BOOL  SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL  estrutura                                                                       | immediate  tag  tag de  matriz | Dados a partir dessa  rotina para copiar  para uma tag na  subrotina.    Parâmetros de  entrada são  opcionais    Digite um máximo  de 40 parâmetros  de entrada, se  necessário. |
| Return Par BOOL  SINT  INT  DINT  REAL  estrutura                                                                                           | BOOL  SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL  estrutura                                                                       | tag  tag de  matriz            | Tag nessa rotina  para copiar resultado  da subrotina.    Parâmetros de  retorno são  opcionais    Digite um máximo  de 40 parâmetros  de retorno, se  necessário                 |

## Instrução SBR

| Operando       | Tipo de dados  (Data Type)  Controladores  CompactLogix  5370, ControlLogix  5570, Compact  GuardLogix 5370 e  GuardLogix 5570    | Tipo de dados (Data  Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580    | Format              | Descrição  (Description)                                                                                                       |
|----------------|-----------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------|--------------------------------------------------------------------------------------------------------------------------------|
| Input Par BOOL | SINT  INT  DINT  REAL  estrutura                                                                                                  | BOOL  SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL  estrutura                                                                       | tag  tag de  matriz |   Tag nessa rotina  na qual para copiar  o parâmetro de  entrada  correspondente  (máximo de 40) a  partir da instrução  JSR. |

## Instrução RET

| Operando        | Tipo de dados  (Data Type)  Controladores  CompactLogix  5370, ControlLogix  5570, Compact  GuardLogix 5370 e  GuardLogix 5570    | Tipo de dados (Data  Type)  Controladores  CompactLogix 5380,  CompactLogix 5480,  ControlLogix 5580,  Compact GuardLogix  5380 e GuardLogix 5580    | Format                        | Descrição  (Description)                                                                                   |
|-----------------|-----------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------|------------------------------------------------------------------------------------------------------------|
| Return Par BOOL | SINT  INT  DINT  REAL  estrutura                                                                                                  | BOOL  SINT  INT  DINT  LINT  USINT  UINT  UDINT  ULINT  REAL  LREAL  estrutura                                                                       | imediato  tag  tag de  matriz | Dados dessa rotina  para copiar o  parâmetro de retorno  correspondente  (máximo de 40) na  instrução JSR. |

Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha maior ocorrerá se:                                              | Tipo de falha Código de falha    |
|---------------------------------------------------------------------------|----------------------------------|
| A instrução JSR tiver menos parâmetros de  entrada do que a instrução SBR | 4 31                             |
| A instrução JSR saltar para uma rotina de falha 4                         | 990 ou fornecido pelo usuário    |
| A instrução RET tiver menos parâmetros de  retorno do que a instrução JSR | 4 31                             |
| A rotina principal conter uma instrução RET 4                             | 31                               |

## Operação

Importante: Qualquer rotina pode conter uma instrução JSR, mas uma instrução JSR não pode chamar (executar) a rotina principal.

<!-- image -->

A instrução JSR inicia a execução da rotina especificada, que é referida como uma subrotina;

-  A subrotina é executada toda vez que é feita uma varredura.
-  Após a execução da subrotina, a execução lógica retorna à rotina que contém a instrução JSR e continua com a instrução seguindo a JSR.

Para programar um salto para uma subrotina, siga essas diretrizes.

## JSR

-  Para copiar dados a uma tag na subrotina, digite um parâmetro de entrada.
-  Para copiar um resultado da subrotina para uma tag nessa rotina, digite um parâmetro de retorno.

-  Digite até 40 entradas e digite até 40 parâmetros de retorno, conforme necessário.

## SBR

-  Se a instrução JSR tiver um parâmetro de entrada, digite uma instrução SBR.
-  Coloque a instrução SBR como a primeira instrução na rotina.
-  Para cada Parâmetro de entrada na instrução JSR, digite a tag em que você deseja copiar os dados.

## RET

-  Se a instrução JSR tiver um parâmetro de retorno, digite uma instrução RET.
-  Coloque a instrução RET como a última instrução na rotina.
-  Para cada parâmetro de retorno na instrução JSR, digite um parâmetro de retorno para enviar à instrução JSR.
-  Em uma rotina ladder, coloque instruções RET adicionais para sair da subrotina baseada em diferentes condições de entrada, se requerido (rotinas de Bloco de funções permitem apenas uma instrução RET).

Invoque até 25 subrotinas aninhadas, com um máximo de 40 parâmetros passados em uma subrotina, e um máximo de 40 parâmetros retornados de uma subrotina.

<!-- image -->

Dica: Selecione o menu Editar &gt; Editar Elemento ladder (Edit &gt; Edit Ladder Element) para adicionar e remover operandos variáveis. Para as instruções JSR e SBR, adicione paramêtro de entrada. Para as instruções JSR e RET, adicione parâmetro de saída. Para todas as três instrução, remova parâmetro de instrução.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada                    |                                                                                                                                                                                                                                                                                                                                                                                                                                      |
|----------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                                    | Pré-varredura O degrau está definido como falso.  O controlador executa todas as subrotinas. Para  assegurar que todos os degraus na subrotina sejam  incluídos na pré-varredura, o controlador ignora  instruções RET (isso é, instruções RET não saem da  subrotina).  Os parâmetros de entrada e retorno não são passados.  Se a mesma subrotina for invocada diversas vezes, ela  será incluída na pré-varredura apenas uma vez. |
| Rung-condition-in é  falsa (para a instrução  JSR) | N/D                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Rung-condition-in é  verdadeira                    | Parâmetros são passados e a subrotina é executada.                                                                                                                                                                                                                                                                                                                                                                                   |
|                                                    | Pós-varredura Mesma ação que Prescan                                                                                                                                                                                                                                                                                                                                                                                                 |

## Bloco de funções

| Condição/estado A ção realizada    |                                                                         |
|------------------------------------|-------------------------------------------------------------------------|
|                                    | Pré-varredura Consulte Pré-varredura na tabela de Diagrama ladder.      |
| EnableIn é falso N/D               |                                                                         |
|                                    | EnableIn é verdadeiro Parâmetros são passados e a subrotina é executada |
| Primeira execução da  instrução    | N/D                                                                     |
| Primeira varredura da  instrução   | N/D                                                                     |
|                                    | Pós-varredura Consulte Pós-varredura na tabela de Diagrama ladder.      |

## Texto estruturado

| Condição/estado A ção realizada                                    |
|--------------------------------------------------------------------|
| Pré-varredura Consulte Pré-varredura na tabela de Diagrama ladder. |
| Execução normal Parâmetros são passados e a subrotina é executada. |
| Pós-varredura Consulte Pós-varredura na tabela de Diagrama ladder. |

<!-- image -->

<!-- image -->

## Texto estruturado

| Routine Progra  ma                                               |
|------------------------------------------------------------------|
| Rotina principal JSR(routine_1,2,value_1,value_2,float_value_1); |
| Subrotina SBR(value_a,value_b);  <statements>;  RET(float_a);    |

## Exemplo 2

## Diagrama ladder

## Rotina principal

<!-- image -->

## subroutine\_1

<!-- image -->

## Exemplo 3

## Bloco de funções

<!-- image -->

## Consulte também

Instruções de controle do programa na página 620

Índice por meio de matrizes na página 893

Valores imediatos na página 882

## Instruções especiais

## Instruções especiais

As instruções especiais realizam operações específicas de aplicativo.

Instruções disponíveis

Texto estruturado

<!-- image -->

## Bloco de funções

Indisponível

## Texto estruturado

Indisponível

| Se você desejar:                                                                                                                                                       | Use esta instrução:    |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------|
| Comparar os dados em relação uma  referência sólida e conhecida e  registrar todas as não  correspondências.                                                           | FBC                    |
| Comparar os dados em relação a uma  referência sólida e conhecida, registrar  qualquer não correspondência e  atualizar a referência para que  corresponda à origem.   | DDT                    |
| Passar os dados de origem através de  uma máscara e comparar o resultado  com os dados de referência. Então  gravar a origem na referência para a  próxima comparação. | DTR                    |
| Controlar um circuito PID.                                                                                                                                             | PID                    |

## Consulte também

Usando instruções PID na página 708

Fechamento anti-restauração e transferência ininterrupta de manual para automático (PID) na página 712

Temporização da instrução PID na página 716
