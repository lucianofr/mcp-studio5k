---
type: Instruction
title: "Contagem decrescente (CTD)"
description: "A base de tempo é 1 ms para todos os temporizadores."
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L2302-L2397"
---

## Contagem decrescente (CTD)

A base de tempo é 1 ms para todos os temporizadores. Por exemplo, o valor .PRE de temporizador de 2 segundos deve ser 2.000.

## Consulte também

Instruções de cálculo/matemáticas na página 369

Instruções de comparação na página 293

Instruções de bit na página 75

Instruções de string ASCII na página 825

Instruções de conversão ASCII na página 845

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução CTD faz a contagem decrescente todas as vezes que a rung-condition-in realiza a transição de falso para verdadeiro.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                    |
|----------------|---------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                        |
|                |   Membros de um operando de estrutura estão  substituídos.                                             |
|                |   Exceto quanto especificado, os operandos da  estrutura são compartilhados por múltiplas  instruções. |

## Diagrama ladder

| Tipo de  dados    | Operando  Formato Des crição               |
|-------------------|--------------------------------------------|
|                   | Counter COUNTER tag Estrutura de Counter   |
|                   | Preset DINT imediato Valor do Counter.PRE. |
|                   | Accum DINT imediato Valor do Counter.ACC.  |

## Estrutura de COUNTER

| Mnemônico  Tipo de  dados    | Descrição                                                                                                                        |
|------------------------------|----------------------------------------------------------------------------------------------------------------------------------|
| .CD BOOL                     | O bit de habilitação de contagem  decrescente contém rung-condition-in  quando a instrução foi executada pela  última vez.       |
| .DN BOOL                     | O bit executado quando da eliminação  indica que a operação de contagem  está completa.                                          |
| .OV BOOL                     | O bit de transbordamento quando  definido indica o contador  incrementado após o limite superior de  2.147.483.647.              |
| .UN BOOL                     | O estouro negativo quando definido  indica o contador diminuído após o  limite inferior de -2.147.483.648.                       |
| .PRE DINT                    | O valor predefinido especifica o valor  que o valor acumulado precisa  alcançar antes de a instrução indicar  que foi executado. |
| .ACC DINT                    | O valor acumulado especifica o  número de transições que a instrução  contou.                                                    |

## Descrição

A instrução CTD geralmente é usada com uma instrução CTU que se refere à mesma estrutura do contador.

Quando rung-condition-in é definida como verdadeira e .CD é falso, .ACC será diminuído em um. Quando rung-condition-in for falsa, .CD será elininado para falso.

<!-- image -->

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

Nenhuma específica a esta instrução. Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                    |
|------------------------------------|--------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | O bit .CD é definido como verdadeiro para evitar  diminuições inválidas durante a primeira varredura do  programa. |
| Rung-condition-in é  falsa         | Definir Rung-condition-out como Rung-condition-in  Consulte o fluxograma CTD (Falso)                               |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out como Rung-condition-in  Consulte o fluxograma CTD (Verdadeiro)                          |
| Pós-varredura N/A                  |                                                                                                                    |

Fluxograma CTD (Falso)

<!-- image -->

## Fluxograma CTD (Verdadeiro)

<!-- image -->
