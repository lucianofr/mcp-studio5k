---
type: Instruction
title: "Carga LIFO (LFL)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L13938-L14058"
---

## Carga LIFO (LFL)

## Diagrama ladder

<!-- image -->

## Consulte também

Instruções de deslocamento/matriz (arquivo) na página 565

```
Atributos comuns na página 879 FFL na página 575
```

LFL na página 589

LFU na página 596

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580. As diferenças de controladores são indicadas quando aplicáveis.

A instrução LFL copia o valor de Source para o LIFO.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

Existem regras de conversão de dados para combinar tipos de dados em uma instrução.

## Diagrama ladder

|                                                         |                        | Operando Tipo Formato Descrição                                                          |
|---------------------------------------------------------|------------------------|------------------------------------------------------------------------------------------|
| Source SINT  INT  DINT  REAL  Tipo de string  estrutura | imediato  tag          | Dados a serem armazenados  no LIFO.                                                      |
| LIFO SINT  INT  DINT  REAL  Tipo de string  estrutura   | tag de  matriz         | LIFO a modificar  especifica o primeiro  elemento do LIFO                                |
| Control CONTROL tag                                     |                        | Estrutura de controle da  operação  geralmente usa o mesmo  CONTROL que o LFU  associado |
|                                                         | Length DINT imediato   | Número máximo de  elementos que o LIFO pode  conter por vez                              |
|                                                         | Position DINT imediato | Próximo local no LIFO em  que a instrução carrega  dados  o valor inicial costuma ser 0  |

## Estrutura de CONTROL

| Mnemônico Tipo de dados Descrição    |                                                                                                                                         |
|--------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| .EN BOOL                             | O bite de habilitação indica que a  instrução LFL está habilitada.                                                                      |
| .DN BOOL                             | O bit executado é definido para indicar  que o LIFO está cheio (.POS = .LEN). O  bit .DN inibe o carregamento do LIFO  até .POS < .LEN. |
| .EM BOOL                             | O bit vazio indica que o LIFO está vazio.  Se .LEN for < ou = 0 ou .POS < 0, o bit  .EM e os bits .DN serão definidos.                  |
| .LEN DINT                            | O comprimento especifica o número  máximo de elementos que o LIFO pode  conter por vez.                                                 |
| .POS DINT                            | A posição identifica o local no LIFO em  que a instrução carregará o  valor seguinte.                                                   |

## Descrição

Use a instrução LFL com a instrução LFU para armazenar e recuperar dados em uma ordem de último a entrar/primeiro a sair. Quando usadas em pares, as instruções LFL e LFU estabelecem um registro de deslocamento assíncrono.

Geralmente, a Source e o LIFO são do mesmo tipo de dados.

Quando habilitada, a instrução LFL carrega o valor de Source na posição no LIFO identificado pelo valor de .POS. A instrução carrega um valor cada vez que a instrução é habilitada até que o LIFO esteja cheio.

Importante: Você deve testar e confirmar que a instrução não altera os dados que você não deseja alterar.

A instrução LFL opera em memória contígua de dados. ParaControladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370 e GuardLogix 5570, o escopo da instrução é restringido à tag base. Geralmente, a Source e o LIFO são do mesmo tipo de dados. Se houver incompatibilidade do tipos de dados de Source e LIFO, a instrução converterá o valor de Source no tipo de dados da tag FIFO. Um inteiro menor será convertido em um maior por extensão de sinal.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha maior ocorrerá se:                                    | Tipo de  falha    | Código de falha    |
|-----------------------------------------------------------------|-------------------|--------------------|
| Se (elemento inicial + .POS) for  além do fim da matriz de LIFO |                   | 4 20               |

Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição/estado A              | ção realizada                              |
|--------------------------------|--------------------------------------------|
| Pré-varredura                  | Consulte o fluxograma LFL  (Pré-varredura) |
| Rung-condition-in é falsa      | Consulte o fluxograma LFL  (Falso)         |
| Rung-condition-in é verdadeira | Consulte o fluxograma LFL  (Verdadeiro)    |
| Pós-varredura N/A.             |                                            |

## Fluxograma LFL (Pré-varredura)

<!-- image -->

Fluxograma LFL (Falso)

<!-- image -->

## Fluxograma LFL (Verdadeiro)

<!-- image -->

Exemplo 2

<!-- image -->

A matriz de origem é a matriz de STRING ou a matriz de estrutura.

## Diagrama ladder

Exemplo 3

<!-- image -->

Incompatibilidade do tipo de dados de origem com o tipo de dados da matriz de LIFO
