---
type: Instruction
title: "Temporizador Retentivo ativado (RTO)"
description: "No exemplo anterior:"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L2700-L2812"
---

## Temporizador Retentivo ativado (RTO)

## Restaurar exemplo

No exemplo anterior:

quando limit\_switch\_8 for habilitado, restaurar o counter\_4

Quando limit\_switch\_5 for habilitado, restaurar Timer\_1

quando limit\_switch\_6 for habilitado, restaurar control\_1

## Consulte também

Instrução do contador na página 103

Indexação por meio de matrizes na página 893

Essas informações se aplicam aos controladores CompactLogix 5370, ControlLogix 5570, Compact GuardLogix 5370, GuardLogix 5570, Compact GuardLogix 5380, CompactLogix 5380, CompactLogix 5480, ControlLogix 5580 e GuardLogix 5580.

A instrução RTO é um temporizador retentivo que acumula tempo quando a instrução é habilitada.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

Essa instrução não está disponível em texto estruturado.

## Operandos

| Importante:    | Operação inesperada pode ocorrer se:                                                                    |
|----------------|---------------------------------------------------------------------------------------------------------|
|                |   Operandos da tag de saída estão substituídos.                                                        |
|                |   Membros de um operando de estrutura estão  substituídos.                                             |
|                |   Exceto quanto especificado, os operandos da  estrutura são compartilhados por múltiplas  instruções. |

## Diagrama ladder

| Tipo de  dados    | Operando  Formato Des crição             |
|-------------------|------------------------------------------|
|                   | Timer TIMER tag Estrutura de Timer       |
|                   | Preset DINT imediato Valor de Timer.PRE. |
|                   | Accum DINT imediato Valor de Timer.ACC.  |

## Estrutura de TIMER

| Mnemônico  Tipo de  dados    | Descrição                                                                                                                                                     |
|------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| .EN BOOL                     | O bit de habilitação contém rung-condition-in quando a  instrução foi executada pela última vez.                                                              |
| .TT BOOL                     | O bit de temporização quando definido indica que a  operação de temporização está em processamento.                                                           |
| .DN BOOL                     | O bit executado quando definido indica que a operação  de temporização está completa (ou interrompida).                                                       |
| .PRE DINT                    | O valor predefinido especifica o valor ( unidades de 1  milissegundo) que o valor acumulado precisa alcançar  antes de a instrução indicar que foi executado. |
| .ACC DINT                    | O valor acumulado especifica o número de  milissegundos que se passaram desde que a instrução  RTO foi habilitada.                                            |

## Descrição

A instrução RTO acumula tempo até:

-  O temporizador ser desabilitado.
-  O temporizador completa.

A base de tempo é sempre 1 milissegundo. Por exemplo, para um temporizador de 2 segundos, insira 2.000 para o valor .PRE.

O temporizador definirá o bit .DN para verdadeiro quando o temporizador completar.

Quando habilitado, o temporizador poderá ser pausado definindo o bit .DN como verdadeiro e retomado eliminando o bit .DN para falso.

<!-- image -->

## Como o temporizador opera

Um temporizador é executado subtraindo-se o horário da sua última varredura do horário atual:

<!-- formula-not-decoded -->

Após isso atualizar o ACC, o temporizador define last\_time\_scanned = current\_time. Isso torna o temporizador pronto para a próxima varredura.

## Afeta sinalizadores de status de operações matemáticas

Não

## Falhas maiores/menores

| Uma falha maior ocorrerá  se:    |   Tipo de  falha  |   Código de  falha  |
|----------------------------------|-------------------|---------------------|
| .PRE < 0                         |                 4 |                  34 |
| .ACC < 0                         |                 4 |                  34 |

Consulte Indexação por meio de matrizes para conhecer falhas de indexação de matrizes.

## Execução

## Diagrama ladder

| Condição/estado A ção realizada    |                                                                                                                           |
|------------------------------------|---------------------------------------------------------------------------------------------------------------------------|
| Pré-varredura                      | O bit .EN é eliminado para  falso.  O bit .TT é eliminado para falso.                                                     |
| Rung-condition-in é  falsa         | Definir Rung-condition-out  como Rung-condition-in  O bit .EN é eliminado para  falso.  O bit .TT é eliminado para falso. |
| Rung-condition-in é  verdadeira    | Definir Rung-condition-out  como Rung-condition-in  Consulte o fluxograma RTO  (Verdadeiro).                              |
| Pós-varredura N/A                  |                                                                                                                           |

## Fluxograma RTO (Verdadeiro)

<!-- image -->
