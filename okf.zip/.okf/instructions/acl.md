---
type: Instruction
title: "Buffer limpo ASCII (ACL)"
description: "<!-- image -->"
tags: [rslogix, controllogix, 1756-rm003, ladder, instruction-set]
resource: "raw/1756-rm003_-pt-p.md#L19363-L19525"
---

## Buffer limpo ASCII (ACL)

## Execução

## Diagrama ladder

| Condição                        | Ação do Diagrama ladder                                                       |
|---------------------------------|-------------------------------------------------------------------------------|
| Pré-varredura N/A               |                                                                               |
| Rung-condition-in é  falsa      | N/A                                                                           |
| Rung-condition-in é  verdadeira | A instrução é executada quando  EnableIn alterna de eliminado  para definido. |
| Pós-varredura N/A               |                                                                               |

## Texto estruturado

| Condição          | Ação de texto estruturado                                                     |
|-------------------|-------------------------------------------------------------------------------|
| Pré-varredura N/A |                                                                               |
| Execução normal   | A instrução é executada quando  EnableIn alterna de eliminado  para definido. |
| Pós-varredura N/A |                                                                               |

## Exemplo

## Diagrama ladder

<!-- image -->

## Texto estruturado

ACB(0,bar\_code\_count);

## Consulte também

Instruções de porta serial ASCII na página 783

Sintaxe de texto estruturado na página 912

Atributos comuns na página 879

Esta instrução é compatível apenas com controladores Studio 5000 Logix Emulate.

A instrução ACL elimina imediatamente o buffer e a fila ASCII.

Dica:

Instruções de Porta serial ASCII (AWT, AWA, ARD, ARL, ABL, ACB, AHL, ACL) não estão disponíveis para controladores que não têm portas seriais.

## Idiomas disponíveis

## Diagrama ladder

<!-- image -->

## Bloco de funções

Essa instrução não está disponível em bloco de funções.

## Texto estruturado

ACL(Channel,ClearSerialPortRead,ClearSerialPortWrite);

## Operandos

## Diagrama ladder

| Operando Tipo                |               | Formato Descrição                                                             |
|------------------------------|---------------|-------------------------------------------------------------------------------|
| Channel DINT                 | imediato  tag | 0                                                                             |
| Clear Serial Port Read BOOL  | imediato  tag | Para esvaziar o buffer e  remover as instruções ARD e  ARL da fila, digite 1. |
| Clear Serial Port Write BOOL | imediato  tag | Para remover as instruções  AWA e AWT da fila, digite 1.                      |

## Texto estruturado

| Operando Tipo                |               | Formato Descrição                                                             |
|------------------------------|---------------|-------------------------------------------------------------------------------|
| Channel DINT                 | imediato  tag | 0                                                                             |
| Clear Serial Port Read BOOL  | imediato  tag | Para esvaziar o buffer e  remover as instruções ARD e  ARL da fila, digite 1. |
| Clear Serial Port Write BOOL | imediato  tag | Para remover as instruções  AWA e AWT da fila, digite 1.                      |

Consulte Sintaxe de texto estruturado para obter mais informações sobre a sintaxe de expressões no texto estruturado.

## Descrição

A instrução ACL executa imediatamente uma ou mais das ações a seguir:

-  Elimina o buffer ou os caracteres e elimina a fila ASCII de instruções de leitura.
-  Elimina a fila ASCII de instruções de gravação Para programar as instruções ACL, siga estas diretrizes:

Configure a porta serial do controlador.

| Se seu aplicativo:  Então:                                           |
|----------------------------------------------------------------------|
| Usa a instrução ARD ou ARL Selecione o modo Usuário                  |
| Não usa as instruções ARD ou ARL Selecione o modo Usuário ou Sistema |

Para determinar se uma instrução foi removida da fila ou abortada, examine a instrução apropriada a seguir:

-  Bit .ER é definido
-  Membro .ERROR é 16#E

## Afeta sinalizadores de status de operações matemáticas

Não

## Condições de falha

Nenhuma específica a esta instrução. Consulte Atributos comuns para falhas relacionadas ao operando.

## Execução

## Diagrama ladder

| Condição                       | Ação do Diagrama  ladder    |
|--------------------------------|-----------------------------|
| Pré-varredura N/A              |                             |
| Rung-condition-in é falsa N/A  |                             |
| Rung-condition-in é verdadeira | A instrução é  executada.   |
| Pós-varredura N/A              |                             |

## Texto estruturado

| Condição          | Ação de texto estruturado                                         |
|-------------------|-------------------------------------------------------------------|
| Pré-varredura N/A |                                                                   |
| Execução normal   | A instrução elimina a  instrução e o(s) buffer(s)  especificados. |
| Pós-varredura N/A |                                                                   |

## Exemplo

## Diagrama ladder

<!-- image -->

## Texto estruturado

IF (osri\_1.OutputBit THEN

ACL(0,0,1);

END\_IF;

## Consulte também

Instruções de porta serial ASCII na página 783

Teste ASCII para Linha do Buffer (ABL) na página 807

Caracteres ASCII no buffer (ACB) na página 785

Linhas de handshake ASCII (AHL) na página 792

Leitura ASCII (ARD) na página 797

Linhas de leitura ASCII (ARL) na página 801

Acréscimo de Gravação ASCII (AWA) na página 816

Gravação ASCII (AWT) na página 810

Sintaxe de texto estruturado na página 912

Atributos comuns na página 879
