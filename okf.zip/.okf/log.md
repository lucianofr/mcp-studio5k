# Update Log

## 2026-07-03
- **Creation**: Adicionado `malha_03.md` (AOI `MALHA_03` rev 2.0 — PID com cascata, feedforward, output tracking, override, bumpless), extraído de `MALHA_03_AOI_R2-DOC.md`.
- **Update**: `index.md` (raiz) atualizado com link pra `malha_03.md`.
