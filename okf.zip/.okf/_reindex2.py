import io, os, glob, re

INSTR_DIR = r"C:\Projetos\mcp-doc-rockwell\.okf\instructions"
entries = []
for path in sorted(glob.glob(os.path.join(INSTR_DIR, "*.md"))):
    if os.path.basename(path) == "index.md":
        continue
    text = io.open(path, encoding="utf-8").read()
    title_m = re.search(r'^title:\s*"(.*)"\s*$', text, re.MULTILINE)
    desc_m = re.search(r'^description:\s*"(.*)"\s*$', text, re.MULTILINE)
    fname = os.path.splitext(os.path.basename(path))[0]
    title = title_m.group(1) if title_m else fname
    desc = desc_m.group(1) if desc_m else ""
    entries.append((fname, title, desc))

with io.open(os.path.join(INSTR_DIR, "index.md"), "w", encoding="utf-8") as f:
    f.write("# Instruções\n\n")
    f.write("Lista de instruções do Logix 5000 documentadas neste bundle.\n\n")
    for fname, title, desc in entries:
        line = f"- [{title}](/instructions/{fname}.md)"
        if desc:
            line += f" - {desc}"
        f.write(line + "\n")

print(f"Indexed {len(entries)} instructions")
