---
okf_version: "0.1"
---

# mcp-doc-rockwell - Base de Conhecimento OKF

Bundle OKF (Open Knowledge Format v0.1) com conhecimento extraído da documentação Rockwell/Studio 5000 em `raw/`.

- [Instruções (instructions/)](./instructions/index.md) - 128 instruções ControlLogix/CompactLogix (Ladder, Bloco de Funções, Texto Estruturado) extraídas de 1756-RM003 (PT).
- [MALHA_03](./malha_03.md) - Add-On Instruction padrão para malha de controle PID contínuo com cascata, feedforward, output tracking, override e bumpless transfer.
