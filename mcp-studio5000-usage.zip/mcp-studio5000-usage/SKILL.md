---
name: mcp-studio5000-usage
description: Regras operacionais, limites reais de produção e recuperação de erros das tools MCP deste workspace Studio 5000/ControlLogix (mcp-studio5k, studio5000-ai-assistant, controllogix-docs). Use SEMPRE antes de abrir, fechar ou reiniciar a sessão do projeto .ACD, antes de qualquer tool de escrita (import_component_l5x, import_tag_l5x, import_routine_l5x, save_project, save_project_as, create_*), ao planejar uma sequência de imports L5X ou migração de malha, ao listar programas/rotinas/tags de um .ACD grande (list_programs, list_routines, list_tags, export_l5x), ao ler tag estruturada/PID (get_tag_value), ou ao usar controllogix-docs (answer_query_tool). Dispare também ao escrever/editar lógica ladder (RLL) via import_rungs_l5x ou import_routine_l5x, ou com qualquer erro destas tools — "max_bytes", "write limit", "LgxSrv_E_FATAL_ERROR", "LgxSrv_E_SERVER_FAULTED", "XMLSrv_E_IMPORT_ABORTED_NO_CHANGES", "no_changes", "import NOT node change", "adopted, not spawned by this process", "Server execution failed", "TargetType must be", "confirmed=True is required" — ou menções a "orçamento de escrita", "engine faultado", "branch de perna única", "rung culpado", "abrir projeto", "importar L5X", "exportar rotina" ou automação do Studio 5000 via MCP.
---

# Uso das tools MCP do workspace Studio 5000

Limites reais observados em produção (sessão de migração RC02a, 2026-07-02, projeto de 25.6MB;
ampliado na sessão de escrita de lógica ladder RLL, 2026-07-23). O SDK Logix é frágil: um
payload errado derruba o engine e **fault é permanente até matar o processo**. Planejar a
sessão de escrita ANTES de começar evita perder trabalho não salvo.

## mcp-studio5k — regras por tool

### Orçamento de escrita (a regra mais importante)

O servidor impõe **limite de ~4 operações de escrita por sessão de projeto aberto**
(imports, saves — todos contam). Ao estourar: `"write limit reached this session;
re-confirm required"`. Fatos:

- `confirmed=true` NÃO destrava; `restart_engine` NÃO reseta o contador.
- `close_project` + `open_project` **reseta** (`health` mostra `write_count: 0`).
- Um import aplicado mas não salvo **pode sobreviver** ao close (o engine persiste imports
  imediatamente em alguns casos), mas não conte com isso — trate como perdido.

**Planeje ciclos de no máximo 3 escritas + 1 save**, depois close/reopen:

```
Ciclo A: import_component (UDT) → import_component (AOI) → save   → close/open
Ciclo B: import_tag ×3 → save                                     → close/open
Ciclo C: import_tag restante → import_routine → save              → close/open
Ciclo D (só leituras): export_l5x → verificação                   → (sem limite)
```

Leituras (`list_*`, `export_l5x`, `get_*`) não contam no limite.

### Sessão e arquivos

| Tool | Regra / limite |
|---|---|
| `open_project` | Recusa se já houver projeto aberto — chame `close_project` antes. Após fault do engine, falha com `LgxSrv_E_SERVER_FAULTED` até seguir a recuperação abaixo. |
| `save_project_as` | Só aceita caminho `.acd` (sem export L5K). **NÃO troca a sessão para o novo arquivo** — `health` continua mostrando o path antigo; escritas seguintes atingiriam o arquivo ORIGINAL. Sempre: `save_project_as` → `close_project` → `open_project` na cópia. Verifique com `health`. |
| `health` | Sempre disponível. Use para confirmar `session.path` (qual arquivo será mutado!) e `write_count` antes de qualquer escrita. |
| `restart_engine` | Respawna o engine child **quando o MCP é dono do processo**; se o engine foi adotado do serviço `LdSdkService`, recusa com `"adopted, not spawned by this process"` (ver subseção de ativação COM). Em nenhum caso mata um `RSLogix5000Services` faultado nem reseta o write limit. |

### Leituras em projetos grandes (>20MB)

`list_programs` e `list_programs_routines` **serializam o projeto inteiro** e estouram
`max_bytes` (cap 20MB) em qualquer projeto grande — `page_size` não ajuda. Alternativas:

1. `list_routines(program="NOME")` — funciona, mas exige o nome do programa.
2. Nomes de programas sem listagem: o .ACD embute um XML `LogixTagInfo` (tag database
   completo com programas e tags). Extração offline:
   - localizar streams gzip pelo magic `\x1f\x8b\x08` no binário, descomprimir com
     `zlib.decompressobj(31)`;
   - decodificar UTF-16LE e procurar `<LogixTagInfo` … `</LogixTagInfo>`;
   - dá programas + tags por scope + DataTypes (não contém lógica de rungs).
3. `list_tags(scope=...)` funciona normalmente com filtros (`datatype_filter="PID"` acha
   todos os PID clássicos do controller scope em uma chamada).

`export_l5x` tem cap de retorno de **5MB** — use `x_path` estreito
(`.../Routines/Routine[@Name='X']`, `.../Tags/Tag[@Name='Y']`), nunca `Controller/Programs`.
Resultados grandes chegam como arquivo em `tool-results/…​.txt` (JSON com campo
`data.l5x`) — parseie do disco em vez de reler o output.

### Leitura de valores de tag

`get_tag_value` aceita **apenas tipos escalares** (`bool/real/dint/...`) e um `tag_xpath`
restrito — não aceita tipo `PID` nem membro via XPath de estrutura. Para ler a configuração
de uma tag estruturada (PID, UDT), use `export_l5x` da tag: o `<Data Format="Decorated">`
traz todos os membros com valores (SP, KP, KI, MAXS, MINO, bits de CTL etc.).

### Imports L5X

Gate humano: toda escrita exige `confirmed=true` (sem isso: `"confirmed=True is required
(human gate)"`). Imports que dirigem processo continuam gated por política do workspace —
OK explícito do usuário (um /goal que manda importar conta).

| Tool | Regra / limite |
|---|---|
| `import_component_l5x` | Aceita arquivo com TargetType `DataType` / `AddOnInstructionDefinition`. Importa dependências junto (UDTs do AOI). Ordem: UDTs → AOI → tags → rotinas. |
| `import_tag_l5x` | **Payload deve ter `TargetType="Tag"` — UMA tag por chamada.** `TargetType="Tags"` (plural, como o Studio exporta coleções) é recusado. Estrutura mínima: header + `<Controller Use="Context">` + (`<Tags Use="Context">` ou `<Programs>/<Program Use="Context">/<Tags>`) + `<Tag Use="Target" ...>`. `x_path` = container de destino (`Controller/Tags` ou `Controller/Programs/Program[@Name='P']/Tags`). Scope importa: tag de faceplate → controller; backing de AOI e ONS → program scope do programa que executa a rotina. |
| `import_routine_l5x` | **PERIGO: L5X de rotina com contexto completo (~480KB, como sai do `export_l5x`) causa `LgxSrv_E_FATAL_ERROR` e faulta o servidor.** Antes de importar, ENXUGUE o L5X: manter só a declaração XML, o header `<RSLogix5000Content>`, `<Controller Use="Context">`, `<Programs>/<Program Use="Context">`, `<Routines Use="Context">` e a `<Routine Use="Target">`. Remover TODOS os blocos de contexto `DataTypes`, `AddOnInstructionDefinitions`, `Tags`, `LocalTags` — referências resolvem contra o projeto (importe UDTs/AOI/tags ANTES). Rotina enxuta de 12KB importou limpo onde a de 480KB derrubou o engine. Falha de import faz rollback automático da rotina. |
| `validate_l5x` / `preview_import` | Use antes do import quando disponível; também rode o validador offline da skill `controllogix-ftview-control` (`scripts/validate_l5x.py`) — ele é mais estrito que o importador (exige `Use="Target"` e dependências), então avisos de dependência em payload de tag são aceitáveis. |

### Escrita de lógica ladder (RLL) — armadilhas

O importador de rungs é all-or-nothing e silencioso sobre a causa: um único rung malformado
**aborta o payload inteiro** e não grava nem os rungs válidos que vieram junto. Vale o mesmo
para `import_routine_l5x`. Todas as observações abaixo foram verificadas ao vivo.

- **Branch de perna única aborta tudo.** Um branch ladder `[X]` com UMA só perna (sem
  vírgula) é rejeitado pelo SDK: o import inteiro aborta com
  `XMLSrv_E_IMPORT_ABORTED_NO_CHANGES` e NADA grava. Um caminho condicional único vai em
  **série**, não em branch: escreva `MUL(...)GRT(...)MOV(...)`, nunca
  `MUL(...)[GRT(...)MOV(...)]`. Reserve `[A , B]` para dois ou mais ramos paralelos reais.
- **`no_changes` = payload inválido, não limite de "count-changing".** import_rungs que muda
  a contagem de rungs (N→M, ex.: replace 1→2) e `import_routine_l5x` em modo OVERWRITE (ex.:
  20 rungs) FUNCIONAM com payload válido. Se voltar `no_changes`/abort, a causa é um rung
  malformado (ver acima), não a operação em si. Corrija qualquer memória/doc antiga que diga
  "só append ou count-preserving grava" — está errada.
- **Isolar o rung culpado por bisseção.** Quando um payload aborta sem apontar o rung,
  substitua o rung 0 por cada candidato isolado (`import_rungs_l5x` com `insert_position=0`,
  `replace_count=1`, 1→1) e observe `ok`/`status` de cada um; o que voltar `no_changes` é o
  culpado.

### Recuperação de engine faultado

Sintomas: `LgxSrv_E_FATAL_ERROR` num import, depois `LgxSrv_E_SERVER_FAULTED` em qualquer
chamada ("No further calls will be accepted").

1. `restart_engine` sozinho NÃO resolve — o processo `RSLogix5000Services` faultado persiste.
2. PowerShell: `Get-Process RSLogix5000Services` → `Stop-Process -Id <pid> -Force`.
3. `restart_engine` → `open_project` → `health` para confirmar sessão limpa.
4. Verifique o que sobreviveu (tags/rotinas) com leituras antes de refazer escritas —
   parte dos imports não salvos pode ter persistido.

### open_project pendura ou "Server execution failed" (ativação COM)

Sintoma diferente do fault acima: `open_project` retorna `"Server execution failed"` ou
**pendura (>120s)** sem nunca abrir. Causa = a ativação COM do SDK Logix falhou (o servidor
COM não subiu), não um fault de payload.

1. Abra a **GUI do Studio 5000** uma vez — isso "prima" a ativação COM; depois refaça
   `open_project`.
2. Se persistir, reinicie o serviço Windows `LdSdkService` e/ou reboote a máquina.
3. Neste deployment o MCP **adota** o engine já servido pelo `LdSdkService` em vez de spawnar
   um child próprio — por isso `restart_engine` recusa com `"adopted, not spawned by this
   process"` e não ajuda aqui (contrasta com a sessão RC02a, em que o engine era child do
   MCP; o comportamento de `restart_engine` diz qual modelo está ativo).

**Diagnóstico diferencial (nesta ordem — isola a causa em 3 passos baratos):**

1. **É o arquivo ou o ambiente?** Tente abrir um `.ACD` que abriu com sucesso hoje. Se ele
   também falhar, o problema NÃO é do arquivo — pule direto para o passo 3.
2. **É o MCP ou o SDK?** Chame o SDK direto, fora do MCP:
   `python -c "import asyncio; from logix_designer_sdk import LogixProject; asyncio.run(LogixProject.open_logix_project(r'<caminho>.ACD'))"`.
   Se o erro se repetir (`OperationFailedError: Server execution failed`), o MCP está
   inocente e a causa é a ativação COM.
3. **Confirme no Event Log**: `Get-WinEvent -FilterHashtable @{LogName='System'}` filtrando
   `DistributedCOM`. O evento **10010** ("server did not register with DCOM within the
   required timeout") repetindo a cada tentativa fecha o diagnóstico: só reboot resolve.

**Armadilha do restart de serviço:** `Restart-Service LdSdkService` pode deixar o processo
`LdSdkServer` ANTIGO vivo (confira com `Get-Process LdSdkServer | Select Id,StartTime` — se
houver mais de um, ou um com `StartTime` velho, é ele). O MCP continua falando com o obsoleto.
Mate o antigo com `Stop-Process -Id <pid> -Force`; o MCP reaponta sozinho para a engine nova
(confirme por `health` que `listening_pid` mudou). `Restart-Service` e `Stop-Process` sobre
esse serviço **exigem terminal elevado**; sem elevação retornam "Access is denied" /
"Cannot open 'LdSdkService' service".

**Importante:** engine nova + GUI aberta + processo obsoleto morto **não** garantem cura. Se o
DCOM 10010 continuar, o registro COM está travado no nível do SO e o único caminho é reboot —
não insista em `open_project` (cada tentativa custa ~2 min de timeout).

### Verificação pós-import (obrigatória)

Import "ok" não basta — e `applied:true` sozinho também não. Confirme por VALOR o que
efetivamente entrou no projeto.

- **Não confie só na flag.** Sucesso real = `{ok:true, status:"ok", applied:true}`. Aborto
  silencioso = `{ok:false, status:"no_changes", applied:false, error:"import NOT node
  change"}` (ou `XMLSrv_E_IMPORT_ABORTED_NO_CHANGES`). Leia sempre `ok`+`status`, nunca só
  `applied`.
- **Verifique por VALOR, nunca por comentário de rung.** O `export_l5x` de rotina REMOVE os
  `<Comment>` dos rungs — um marcador deixado em comentário dá falso-negativo (parece que não
  gravou quando gravou). Cheque literais, instruções e operandos (contagem de rungs,
  `MALHA_03(`=1, `PID(`=0, pontes presentes), não texto de comentário.
- **Verifique no estado persistido reaberto.** Export in-memory logo após o import pode não
  refletir a mudança; confie no estado salvo e reaberto. Feche o ciclo `save_project` →
  `close_project` → `open_project` → `export_l5x` do artefato → conferir conteúdo. Só então
  declarar pronto e registrar no `<PROJETO>-MODIFICATIONS.md`.

## studio5000-ai-assistant

- `index_acd_project` **pode falhar silenciosamente** ("Failed to index project - check
  logs") em ACDs grandes/v31; `get_project_overview`, `search_l5x_content`,
  `analyze_routine_structure` etc. exigem index prévio e retornam "No L5X data indexed".
- Se o index falhar, NÃO insista: caia para grounding direto no mcp-studio5k
  (`list_tags`, `list_routines`, `export_l5x`) e, para estrutura de programas, para a
  extração binária do `LogixTagInfo` descrita acima.
- Nunca use as tools de escrita do ai-assistant (`create_acd_project`,
  `smart_insert_logic`) — mutação de .ACD é exclusiva do mcp-studio5k (regra do CLAUDE.md).

## controllogix-docs

- `answer_query_tool` retorna trechos curtos e fragmentados do 1756-rm003 (PT-BR). Perguntas
  longas/compostas voltam lixo. Faça perguntas **atômicas e com termos do manual**
  ("unidade do ganho integral Ki instrução PID ganhos independentes"), uma por chamada, e
  reformule 1-2 vezes se vier "sem correspondência confiável".
- Confirmações críticas obtidas assim nesta base: PID clássico independente → Ki em 1/s;
  PIDE ISA (dependente) → TI em minutos. Conversão consolidada: `JGP=KP`,
  `JTI=KP/(60·KI)` min, `JTD=KD/(60·KP)` min, `JFF=BIAS`.

## Checklist de sessão de mutação

- [ ] `health` → confirmar `session.path` = cópia de trabalho (nunca o .ACD de produção)
- [ ] Grounding só por leituras do mcp-studio5k (nomes lembrados não contam)
- [ ] Planejar ciclos de ≤3 escritas + save (orçamento de 4)
- [ ] L5X de rotina enxuto (sem contexto de DataTypes/AOI/Tags) antes do import
- [ ] Tags: 1 por `import_tag_l5x`, `TargetType="Tag"`, scope correto
- [ ] RLL: caminho condicional único em SÉRIE, nunca branch de perna única (aborta tudo)
- [ ] Pós-import: conferir por VALOR (não por `applied` sozinho nem por comentário de rung)
- [ ] Pós-import: save → close → open → export → conferir → MODIFICATIONS.md
